import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.invert();
        int int6 = fraction4.getDenominator();
        long long7 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.negate();
        float float11 = fraction10.floatValue();
        int int12 = fraction10.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.divideBy(fraction16);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int20 = fraction19.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long23 = fraction22.longValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction22.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction21.subtract(fraction24);
        boolean boolean26 = fraction19.equals((java.lang.Object) fraction21);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction18.subtract(fraction21);
        double double28 = fraction21.doubleValue();
        int int29 = fraction21.intValue();
        java.lang.Class<?> wildcardClass30 = fraction21.getClass();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction13.multiplyBy(fraction21);
        int int32 = fraction10.compareTo(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction4.divideBy(fraction31);
        int int34 = fraction31.getProperWhole();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + (-0.75f) + "'", float11 == (-0.75f));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.5d + "'", double28 == 0.5d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(0, (int) (short) 100);
        short short3 = fraction2.shortValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 32);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.abs();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.multiplyBy(fraction9);
        int int11 = fraction2.compareTo(fraction10);
        int int12 = fraction2.getDenominator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("3500/35");
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        short short3 = fraction2.shortValue();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.negate();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertNotNull(fraction4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("-100");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("-2 1/2");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double4 = fraction3.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        long long6 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction8.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.invert();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction3.multiplyBy(fraction7);
        int int15 = fraction14.getProperWhole();
        short short16 = fraction14.shortValue();
        int int17 = fraction14.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.01d + "'", double4 == 10.01d);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 6 + "'", short16 == (short) 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        float float5 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.invert();
        java.lang.String str7 = fraction6.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.4f + "'", float5 == 0.4f);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "5/2" + "'", str7.equals("5/2"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        int int4 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction3.reduce();
        long long7 = fraction6.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.reduce();
        java.lang.String str4 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int8 = fraction5.compareTo(fraction7);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        float float10 = fraction7.floatValue();
        byte byte11 = fraction7.byteValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.divideBy(fraction7);
        float float13 = fraction7.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction7.invert();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3/4" + "'", str4.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.4f + "'", float10 == 0.4f);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.4f + "'", float13 == 0.4f);
        org.junit.Assert.assertNotNull(fraction14);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        long long1 = fraction0.longValue();
        int int2 = fraction0.getNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        int int1 = fraction0.getNumerator();
        int int2 = fraction0.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.reduce();
        int int4 = fraction3.getDenominator();
        int int5 = fraction3.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(32, (int) ' ', 3);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        int int4 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction8 = fraction5.subtract(fraction7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction(100.0d);
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.reduce();
        int int4 = fraction1.compareTo(fraction3);
        java.lang.Class<?> wildcardClass5 = fraction3.getClass();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.divideBy(fraction9);
        short short11 = fraction10.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.abs();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int16 = fraction13.compareTo(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction15);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction(0.75d);
        int int20 = fraction10.compareTo(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction3.multiplyBy(fraction10);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long23 = fraction22.longValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction22.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long27 = fraction26.longValue();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction26.reduce();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction25.subtract(fraction28);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int32 = fraction30.compareTo(fraction31);
        int int33 = fraction28.compareTo(fraction31);
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float35 = fraction34.floatValue();
        int int36 = fraction34.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction34.reduce();
        org.apache.commons.lang3.math.Fraction fraction38 = fraction28.multiplyBy(fraction37);
        org.apache.commons.lang3.math.Fraction fraction39 = fraction24.divideBy(fraction37);
        boolean boolean40 = fraction21.equals((java.lang.Object) fraction24);
        org.apache.commons.lang3.math.Fraction fraction41 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction42 = fraction41.reduce();
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction44 = fraction41.subtract(fraction43);
        int int45 = fraction44.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction46 = fraction44.negate();
        org.apache.commons.lang3.math.Fraction fraction47 = fraction46.negate();
        org.apache.commons.lang3.math.Fraction fraction48 = fraction47.invert();
        org.apache.commons.lang3.math.Fraction fraction49 = fraction48.reduce();
        org.apache.commons.lang3.math.Fraction fraction50 = fraction21.divideBy(fraction49);
        int int51 = fraction49.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.75f + "'", float35 == 0.75f);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertNotNull(fraction48);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.negate();
        float float24 = fraction23.floatValue();
        java.lang.String str25 = fraction23.toProperString();
        short short26 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction20.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long30 = fraction29.longValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.reduce();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction28.subtract(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int35 = fraction33.compareTo(fraction34);
        int int36 = fraction31.compareTo(fraction34);
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float38 = fraction37.floatValue();
        int int39 = fraction37.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction37.reduce();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction31.multiplyBy(fraction40);
        org.apache.commons.lang3.math.Fraction fraction42 = fraction20.divideBy(fraction31);
        short short43 = fraction20.shortValue();
        int int44 = fraction20.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3/4" + "'", str7.equals("3/4"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + (-0.75f) + "'", float24 == (-0.75f));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-3/4" + "'", str25.equals("-3/4"));
        org.junit.Assert.assertTrue("'" + short26 + "' != '" + (short) 0 + "'", short26 == (short) 0);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.75f + "'", float38 == 0.75f);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertTrue("'" + short43 + "' != '" + (short) 0 + "'", short43 == (short) 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        short short2 = fraction1.shortValue();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction7.negate();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction10.invert();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction10);
        boolean boolean13 = fraction1.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int18 = fraction17.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long21 = fraction20.longValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction19.subtract(fraction22);
        boolean boolean24 = fraction17.equals((java.lang.Object) fraction19);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction16.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction28 = fraction26.pow((int) (short) 10);
        int int29 = fraction16.compareTo(fraction28);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int32 = fraction31.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long35 = fraction34.longValue();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction34.reduce();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction33.subtract(fraction36);
        boolean boolean38 = fraction31.equals((java.lang.Object) fraction33);
        org.apache.commons.lang3.math.Fraction fraction39 = fraction30.subtract(fraction33);
        double double40 = fraction33.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction16.subtract(fraction33);
        byte byte42 = fraction16.byteValue();
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction44 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long45 = fraction44.longValue();
        org.apache.commons.lang3.math.Fraction fraction46 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        int int47 = fraction44.compareTo(fraction46);
        org.apache.commons.lang3.math.Fraction fraction48 = fraction43.divideBy(fraction44);
        org.apache.commons.lang3.math.Fraction fraction49 = fraction16.multiplyBy(fraction43);
        int int50 = fraction43.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction51 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction52 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int53 = fraction52.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction54 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction55 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long56 = fraction55.longValue();
        org.apache.commons.lang3.math.Fraction fraction57 = fraction55.reduce();
        org.apache.commons.lang3.math.Fraction fraction58 = fraction54.subtract(fraction57);
        boolean boolean59 = fraction52.equals((java.lang.Object) fraction54);
        org.apache.commons.lang3.math.Fraction fraction60 = fraction51.subtract(fraction54);
        org.apache.commons.lang3.math.Fraction fraction61 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction62 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int63 = fraction62.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction64 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction65 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long66 = fraction65.longValue();
        org.apache.commons.lang3.math.Fraction fraction67 = fraction65.reduce();
        org.apache.commons.lang3.math.Fraction fraction68 = fraction64.subtract(fraction67);
        boolean boolean69 = fraction62.equals((java.lang.Object) fraction64);
        org.apache.commons.lang3.math.Fraction fraction70 = fraction61.subtract(fraction64);
        org.apache.commons.lang3.math.Fraction fraction71 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction73 = fraction71.pow((int) (short) 10);
        int int74 = fraction61.compareTo(fraction73);
        int int75 = fraction54.compareTo(fraction61);
        float float76 = fraction61.floatValue();
        short short77 = fraction61.shortValue();
        org.apache.commons.lang3.math.Fraction fraction78 = fraction43.divideBy(fraction61);
        org.apache.commons.lang3.math.Fraction fraction80 = org.apache.commons.lang3.math.Fraction.getFraction(100.0d);
        org.apache.commons.lang3.math.Fraction fraction81 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction82 = fraction81.reduce();
        int int83 = fraction80.compareTo(fraction82);
        org.apache.commons.lang3.math.Fraction fraction84 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction85 = fraction84.reduce();
        org.apache.commons.lang3.math.Fraction fraction86 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int87 = fraction84.compareTo(fraction86);
        org.apache.commons.lang3.math.Fraction fraction88 = fraction86.reduce();
        float float89 = fraction86.floatValue();
        org.apache.commons.lang3.math.Fraction fraction90 = fraction86.invert();
        org.apache.commons.lang3.math.Fraction fraction91 = fraction86.negate();
        org.apache.commons.lang3.math.Fraction fraction92 = fraction82.subtract(fraction86);
        int int93 = fraction78.compareTo(fraction86);
        java.lang.String str94 = fraction78.toProperString();
        org.apache.commons.lang3.math.Fraction fraction95 = fraction15.subtract(fraction78);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.5d + "'", double40 == 0.5d);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertTrue("'" + byte42 + "' != '" + (byte) 0 + "'", byte42 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(fraction48);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(fraction57);
        org.junit.Assert.assertNotNull(fraction58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(fraction60);
        org.junit.Assert.assertNotNull(fraction61);
        org.junit.Assert.assertNotNull(fraction62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(fraction64);
        org.junit.Assert.assertNotNull(fraction65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
        org.junit.Assert.assertNotNull(fraction67);
        org.junit.Assert.assertNotNull(fraction68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(fraction70);
        org.junit.Assert.assertNotNull(fraction71);
        org.junit.Assert.assertNotNull(fraction73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertTrue("'" + float76 + "' != '" + 0.4f + "'", float76 == 0.4f);
        org.junit.Assert.assertTrue("'" + short77 + "' != '" + (short) 0 + "'", short77 == (short) 0);
        org.junit.Assert.assertNotNull(fraction78);
        org.junit.Assert.assertNotNull(fraction80);
        org.junit.Assert.assertNotNull(fraction81);
        org.junit.Assert.assertNotNull(fraction82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNotNull(fraction84);
        org.junit.Assert.assertNotNull(fraction85);
        org.junit.Assert.assertNotNull(fraction86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertNotNull(fraction88);
        org.junit.Assert.assertTrue("'" + float89 + "' != '" + 0.4f + "'", float89 == 0.4f);
        org.junit.Assert.assertNotNull(fraction90);
        org.junit.Assert.assertNotNull(fraction91);
        org.junit.Assert.assertNotNull(fraction92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "1 7/8" + "'", str94.equals("1 7/8"));
        org.junit.Assert.assertNotNull(fraction95);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-4), (int) (short) -11, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.reduce();
        java.lang.String str4 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int8 = fraction5.compareTo(fraction7);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        float float10 = fraction7.floatValue();
        byte byte11 = fraction7.byteValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.divideBy(fraction7);
        float float13 = fraction7.floatValue();
        long long14 = fraction7.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3/4" + "'", str4.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.4f + "'", float10 == 0.4f);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.4f + "'", float13 == 0.4f);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.reduce();
        java.lang.String str4 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int8 = fraction5.compareTo(fraction7);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        float float10 = fraction7.floatValue();
        byte byte11 = fraction7.byteValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.divideBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        int int16 = fraction13.compareTo(fraction15);
        java.lang.String str17 = fraction13.toProperString();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction21.multiplyBy(fraction25);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction21.reduce();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction13.subtract(fraction27);
        short short29 = fraction27.shortValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction12.add(fraction27);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction27.abs();
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.2f);
        int int34 = fraction33.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction37 = fraction36.reduce();
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction39 = fraction36.subtract(fraction38);
        org.apache.commons.lang3.math.Fraction fraction40 = fraction36.invert();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction35.subtract(fraction40);
        org.apache.commons.lang3.math.Fraction fraction42 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction44 = fraction43.reduce();
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction46 = fraction43.subtract(fraction45);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction43.invert();
        org.apache.commons.lang3.math.Fraction fraction48 = fraction42.subtract(fraction47);
        org.apache.commons.lang3.math.Fraction fraction49 = fraction48.invert();
        org.apache.commons.lang3.math.Fraction fraction50 = fraction35.add(fraction48);
        short short51 = fraction48.shortValue();
        org.apache.commons.lang3.math.Fraction fraction52 = fraction48.invert();
        int int53 = fraction33.compareTo(fraction52);
        org.apache.commons.lang3.math.Fraction fraction54 = fraction52.reduce();
        short short55 = fraction54.shortValue();
        org.apache.commons.lang3.math.Fraction fraction56 = fraction31.add(fraction54);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3/4" + "'", str4.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.4f + "'", float10 == 0.4f);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "3/4" + "'", str17.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + short29 + "' != '" + (short) 10 + "'", short29 == (short) 10);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertNotNull(fraction48);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertTrue("'" + short51 + "' != '" + (short) 0 + "'", short51 == (short) 0);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertTrue("'" + short55 + "' != '" + (short) -2 + "'", short55 == (short) -2);
        org.junit.Assert.assertNotNull(fraction56);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.invert();
        double double4 = fraction2.doubleValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3125d + "'", double4 == 0.3125d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("20/7");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        int int3 = fraction2.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int8 = fraction7.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long11 = fraction10.longValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.reduce();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.subtract(fraction12);
        boolean boolean14 = fraction7.equals((java.lang.Object) fraction9);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction6.subtract(fraction9);
        boolean boolean16 = fraction2.equals((java.lang.Object) fraction9);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction1.subtract(fraction2);
        int int18 = fraction2.intValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', (int) (short) 35);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        int int5 = fraction3.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int8 = fraction6.compareTo(fraction7);
        int int9 = fraction7.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.multiplyBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double15 = fraction14.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.abs();
        int int17 = fraction14.getDenominator();
        int int18 = fraction14.intValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction14.reduce();
        int int20 = fraction7.compareTo(fraction19);
        long long21 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long24 = fraction23.longValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction22.subtract(fraction25);
        java.lang.Class<?> wildcardClass27 = fraction22.getClass();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long30 = fraction29.longValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.reduce();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction28.subtract(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long35 = fraction34.longValue();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction34.reduce();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction33.subtract(fraction36);
        org.apache.commons.lang3.math.Fraction fraction41 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction42 = fraction37.add(fraction41);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction41.pow(4);
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long46 = fraction45.longValue();
        org.apache.commons.lang3.math.Fraction fraction47 = fraction45.invert();
        int int48 = fraction44.compareTo(fraction45);
        boolean boolean49 = fraction31.equals((java.lang.Object) fraction44);
        org.apache.commons.lang3.math.Fraction fraction50 = fraction22.multiplyBy(fraction31);
        org.apache.commons.lang3.math.Fraction fraction51 = fraction7.add(fraction22);
        org.apache.commons.lang3.math.Fraction fraction52 = fraction7.reduce();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.01d + "'", double15 == 10.01d);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertNotNull(fraction52);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(0, (int) '#', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        float float3 = fraction2.floatValue();
        int int4 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long6 = fraction5.longValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int12 = fraction11.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long15 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.subtract(fraction16);
        boolean boolean18 = fraction11.equals((java.lang.Object) fraction13);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction10.subtract(fraction13);
        double double20 = fraction13.doubleValue();
        int int21 = fraction13.intValue();
        java.lang.Class<?> wildcardClass22 = fraction13.getClass();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction5.multiplyBy(fraction13);
        int int24 = fraction2.compareTo(fraction23);
        int int25 = fraction2.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-0.75f) + "'", float3 == (-0.75f));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5d + "'", double20 == 0.5d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        float float3 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction(0.5d);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.add(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.negate();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float10 = fraction9.floatValue();
        int int11 = fraction9.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.reduce();
        java.lang.String str13 = fraction9.toProperString();
        int int14 = fraction7.compareTo(fraction9);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-0.75f) + "'", float3 == (-0.75f));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.75f + "'", float10 == 0.75f);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "3/4" + "'", str13.equals("3/4"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("0");
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.pow(0);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        float float9 = fraction6.floatValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction6.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.abs();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction1.subtract(fraction12);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.4f + "'", float9 == 0.4f);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(5, (-35), (int) (short) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The numerator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction(32.0d);
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.invert();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1/2");
        byte byte2 = fraction1.byteValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int1 = fraction0.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        boolean boolean7 = fraction0.equals((java.lang.Object) fraction2);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.invert();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.invert();
        int int10 = fraction9.getProperWhole();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-17), 0, (int) (short) 100);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(0, 2);
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        float float6 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.abs();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction12.abs();
        byte byte16 = fraction15.byteValue();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction5.add(fraction15);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction2.subtract(fraction17);
        int int19 = fraction2.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-0.75f) + "'", float6 == (-0.75f));
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 10 + "'", byte16 == (byte) 10);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.pow((int) (short) 0);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction11.negate();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction14.invert();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double20 = fraction19.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.abs();
        java.lang.Class<?> wildcardClass22 = fraction21.getClass();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction14.subtract(fraction21);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction10.divideBy(fraction21);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.01d + "'", double20 == 10.01d);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        boolean boolean8 = fraction1.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.pow((int) (short) 10);
        int int13 = fraction0.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int16 = fraction15.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long19 = fraction18.longValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.subtract(fraction20);
        boolean boolean22 = fraction15.equals((java.lang.Object) fraction17);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction14.subtract(fraction17);
        double double24 = fraction17.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction0.subtract(fraction17);
        byte byte26 = fraction0.byteValue();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long29 = fraction28.longValue();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        int int31 = fraction28.compareTo(fraction30);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction27.divideBy(fraction28);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction0.multiplyBy(fraction27);
        int int34 = fraction27.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction27.reduce();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.5d + "'", double24 == 0.5d);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + byte26 + "' != '" + (byte) 0 + "'", byte26 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
        org.junit.Assert.assertNotNull(fraction35);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        float float3 = fraction0.floatValue();
        int int4 = fraction0.intValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_THIRD;
        short short6 = fraction5.shortValue();
        int int7 = fraction5.getProperWhole();
        boolean boolean8 = fraction0.equals((java.lang.Object) fraction5);
        java.lang.String str9 = fraction5.toString();
        byte byte10 = fraction5.byteValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.75f + "'", float3 == 0.75f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1/3" + "'", str9.equals("1/3"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction5.abs();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction(3, (int) ' ', (int) 'a');
        org.apache.commons.lang3.math.Fraction fraction12 = fraction5.subtract(fraction11);
        long long13 = fraction5.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int4 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.subtract(fraction8);
        boolean boolean10 = fraction3.equals((java.lang.Object) fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.subtract(fraction5);
        int int12 = fraction11.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double17 = fraction16.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction16.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction11.divideBy(fraction18);
        int int20 = fraction18.getDenominator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.01d + "'", double17 == 10.01d);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double4 = fraction3.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        java.lang.Class<?> wildcardClass6 = fraction5.getClass();
        int int7 = fraction5.intValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.01d + "'", double4 == 10.01d);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-97), 4, 2);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        java.lang.String str9 = fraction2.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3/4" + "'", str7.equals("3/4"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3/4" + "'", str9.equals("3/4"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        java.lang.Class<?> wildcardClass5 = fraction0.getClass();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.subtract(fraction9);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction20 = fraction15.add(fraction19);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction19.pow(4);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long24 = fraction23.longValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.invert();
        int int26 = fraction22.compareTo(fraction23);
        boolean boolean27 = fraction9.equals((java.lang.Object) fraction22);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction0.multiplyBy(fraction9);
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long30 = fraction29.longValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.reduce();
        org.apache.commons.lang3.math.Fraction fraction32 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction33 = fraction29.divideBy(fraction32);
        int int34 = fraction32.intValue();
        int int35 = fraction32.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction0.add(fraction32);
        int int37 = fraction36.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        int int39 = fraction38.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction38.negate();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction38.abs();
        int int42 = fraction41.intValue();
        int int43 = fraction36.compareTo(fraction41);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(3, 10);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.invert();
        double double5 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.negate();
        long long8 = fraction6.longValue();
        int int9 = fraction6.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 0, 5);
        java.lang.Class<?> wildcardClass3 = fraction2.getClass();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double8 = fraction7.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.abs();
        java.lang.Class<?> wildcardClass10 = fraction9.getClass();
        java.lang.String str11 = fraction9.toProperString();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction2.divideBy(fraction9);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.pow(7);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.01d + "'", double8 == 10.01d);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10 1/100" + "'", str11.equals("10 1/100"));
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction15);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.subtract(fraction4);
        byte byte6 = fraction4.byteValue();
        java.lang.Class<?> wildcardClass7 = fraction4.getClass();
        java.lang.String str8 = fraction4.toString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3/5" + "'", str8.equals("3/5"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double4 = fraction3.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        java.lang.Class<?> wildcardClass6 = fraction5.getClass();
        java.lang.String str7 = fraction5.toProperString();
        int int8 = fraction5.getProperWhole();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.01d + "'", double4 == 10.01d);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10 1/100" + "'", str7.equals("10 1/100"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        boolean boolean12 = fraction5.equals((java.lang.Object) fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction7.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction4.multiplyBy(fraction7);
        float float16 = fraction15.floatValue();
        byte byte17 = fraction15.byteValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.reduce();
        double double19 = fraction15.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.getFraction(0.0d);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long23 = fraction22.longValue();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        int int25 = fraction22.compareTo(fraction24);
        java.lang.String str26 = fraction22.toProperString();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction35 = fraction30.multiplyBy(fraction34);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction30.reduce();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction22.subtract(fraction36);
        org.apache.commons.lang3.math.Fraction fraction38 = fraction21.subtract(fraction36);
        short short39 = fraction36.shortValue();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction15.subtract(fraction36);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.2f + "'", float16 == 0.2f);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 0 + "'", byte17 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "3/4" + "'", str26.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertTrue("'" + short39 + "' != '" + (short) 10 + "'", short39 == (short) 10);
        org.junit.Assert.assertNotNull(fraction40);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        int int3 = fraction2.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str9 = fraction8.toString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction5.multiplyBy(fraction8);
        java.lang.String str11 = fraction5.toProperString();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction4.multiplyBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction2.add(fraction5);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction17 = fraction14.subtract(fraction16);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction14.invert();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction23 = fraction20.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction20.invert();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction19.subtract(fraction24);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction14.multiplyBy(fraction19);
        int int27 = fraction2.compareTo(fraction19);
        int int28 = fraction2.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3/4" + "'", str9.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1/5" + "'", str11.equals("1/5"));
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        float float3 = fraction2.floatValue();
        int int4 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long6 = fraction5.longValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int12 = fraction11.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long15 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.subtract(fraction16);
        boolean boolean18 = fraction11.equals((java.lang.Object) fraction13);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction10.subtract(fraction13);
        double double20 = fraction13.doubleValue();
        int int21 = fraction13.intValue();
        java.lang.Class<?> wildcardClass22 = fraction13.getClass();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction5.multiplyBy(fraction13);
        int int24 = fraction2.compareTo(fraction23);
        byte byte25 = fraction2.byteValue();
        int int26 = fraction2.getDenominator();
        long long27 = fraction2.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-0.75f) + "'", float3 == (-0.75f));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5d + "'", double20 == 0.5d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + byte25 + "' != '" + (byte) 0 + "'", byte25 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 4);
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.negate();
        short short3 = fraction1.shortValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4 + "'", short3 == (short) 4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (-97));
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("3/4");
        int int2 = fraction1.getNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction5.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction0.multiplyBy(fraction5);
        int int13 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction0.negate();
        int int15 = fraction14.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 1, (int) (short) 10);
        int int3 = fraction2.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        double double7 = fraction6.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.subtract(fraction6);
        int int9 = fraction2.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction(10.01d);
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.abs();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 97);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        boolean boolean12 = fraction5.equals((java.lang.Object) fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction7.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction4.multiplyBy(fraction7);
        int int16 = fraction4.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction4.negate();
        int int18 = fraction4.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction4.negate();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(fraction19);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.pow((int) (short) 10);
        int int3 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.pow(0);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 0, 5);
        long long3 = fraction2.longValue();
        byte byte4 = fraction2.byteValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        java.lang.String str2 = fraction1.toString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0/1" + "'", str2.equals("0/1"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        double double1 = fraction0.doubleValue();
        int int2 = fraction0.getNumerator();
        java.lang.Class<?> wildcardClass3 = fraction0.getClass();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int5 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.subtract(fraction9);
        boolean boolean11 = fraction4.equals((java.lang.Object) fraction6);
        float float12 = fraction6.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction0.add(fraction6);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.invert();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.75d + "'", double1 == 0.75d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        int int4 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.pow((int) (short) -10);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(fraction6);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        double double1 = fraction0.doubleValue();
        java.lang.String str2 = fraction0.toProperString();
        double double3 = fraction0.doubleValue();
        byte byte4 = fraction0.byteValue();
        float float5 = fraction0.floatValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.75d + "'", double1 == 0.75d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3/4" + "'", str2.equals("3/4"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.75d + "'", double3 == 0.75d);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.75f + "'", float5 == 0.75f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 35);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(0, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction14 = fraction9.add(fraction13);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction13.pow(4);
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long18 = fraction17.longValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.invert();
        int int20 = fraction16.compareTo(fraction17);
        float float21 = fraction17.floatValue();
        int int22 = fraction0.compareTo(fraction17);
        int int23 = fraction0.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.75f + "'", float21 == 0.75f);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        double double1 = fraction0.doubleValue();
        java.lang.String str2 = fraction0.toProperString();
        double double3 = fraction0.doubleValue();
        byte byte4 = fraction0.byteValue();
        java.lang.String str5 = fraction0.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.75d + "'", double1 == 0.75d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3/4" + "'", str2.equals("3/4"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.75d + "'", double3 == 0.75d);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "3/4" + "'", str5.equals("3/4"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        boolean boolean8 = fraction1.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.pow((int) (short) 10);
        int int13 = fraction0.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int16 = fraction15.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long19 = fraction18.longValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.subtract(fraction20);
        boolean boolean22 = fraction15.equals((java.lang.Object) fraction17);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction14.subtract(fraction17);
        double double24 = fraction17.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction0.subtract(fraction17);
        byte byte26 = fraction0.byteValue();
        short short27 = fraction0.shortValue();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction30 = fraction29.reduce();
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int32 = fraction29.compareTo(fraction31);
        boolean boolean33 = fraction0.equals((java.lang.Object) fraction31);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.5d + "'", double24 == 0.5d);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + byte26 + "' != '" + (byte) 0 + "'", byte26 == (byte) 0);
        org.junit.Assert.assertTrue("'" + short27 + "' != '" + (short) 0 + "'", short27 == (short) 0);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction5.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction0.multiplyBy(fraction5);
        int int13 = fraction12.getDenominator();
        double double14 = fraction12.doubleValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.6d + "'", double14 == 0.6d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.abs();
        double double4 = fraction2.doubleValue();
        int int5 = fraction2.getProperNumerator();
        java.lang.String str6 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 11, (-10));
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 0, (int) (short) 10);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.add(fraction12);
        int int14 = fraction9.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.divideBy(fraction9);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.97d + "'", double4 == 0.97d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97/100" + "'", str6.equals("97/100"));
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(fraction15);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("10/10");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction6.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long10 = fraction9.longValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.subtract(fraction11);
        boolean boolean13 = fraction6.equals((java.lang.Object) fraction8);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction5.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int17 = fraction16.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long20 = fraction19.longValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.subtract(fraction21);
        boolean boolean23 = fraction16.equals((java.lang.Object) fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction15.subtract(fraction18);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.pow((int) (short) 10);
        int int28 = fraction15.compareTo(fraction27);
        int int29 = fraction8.compareTo(fraction15);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction4.divideBy(fraction15);
        int int32 = fraction15.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        double double34 = fraction33.doubleValue();
        int int35 = fraction33.getNumerator();
        java.lang.Class<?> wildcardClass36 = fraction33.getClass();
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int38 = fraction37.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction40 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long41 = fraction40.longValue();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction40.reduce();
        org.apache.commons.lang3.math.Fraction fraction43 = fraction39.subtract(fraction42);
        boolean boolean44 = fraction37.equals((java.lang.Object) fraction39);
        float float45 = fraction39.floatValue();
        org.apache.commons.lang3.math.Fraction fraction46 = fraction33.add(fraction39);
        byte byte47 = fraction33.byteValue();
        org.apache.commons.lang3.math.Fraction fraction48 = fraction15.divideBy(fraction33);
        org.apache.commons.lang3.math.Fraction fraction49 = fraction33.reduce();
        int int50 = fraction49.getProperWhole();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.75d + "'", double34 == 0.75d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.5f + "'", float45 == 0.5f);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + byte47 + "' != '" + (byte) 0 + "'", byte47 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction48);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 0, (int) (byte) 35);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction0.compareTo(fraction1);
        int int3 = fraction1.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction1.reduce();
        java.lang.String str5 = fraction1.toProperString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "3/4" + "'", str5.equals("3/4"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        java.lang.String str4 = fraction0.toString();
        java.lang.Class<?> wildcardClass5 = fraction0.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1/1" + "'", str4.equals("1/1"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.invert();
        java.lang.String str4 = fraction2.toString();
        java.lang.String str5 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.subtract(fraction11);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.invert();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.subtract(fraction17);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.invert();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction14.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction9.multiplyBy(fraction14);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction6.divideBy(fraction9);
        int int23 = fraction9.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction9.abs();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction2.subtract(fraction9);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1/1" + "'", str4.equals("1/1"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("97/100");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction("20/7");
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        int int5 = fraction4.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction9.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        boolean boolean16 = fraction9.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction8.subtract(fraction11);
        boolean boolean18 = fraction4.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction3.subtract(fraction4);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction1.add(fraction4);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        float float3 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction(0.5d);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.add(fraction5);
        int int7 = fraction5.getProperWhole();
        int int8 = fraction5.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.invert();
        int int10 = fraction5.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-0.75f) + "'", float3 == (-0.75f));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.multiplyBy(fraction7);
        boolean boolean10 = fraction8.equals((java.lang.Object) 1L);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction(0, 100000000);
        int int14 = fraction8.compareTo(fraction13);
        short short15 = fraction13.shortValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction0.compareTo(fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str4 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction0.multiplyBy(fraction3);
        byte byte6 = fraction5.byteValue();
        double double7 = fraction5.doubleValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3/4" + "'", str4.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.15d + "'", double7 == 0.15d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        int int3 = fraction2.getProperWhole();
        java.lang.String str4 = fraction2.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-3/4" + "'", str4.equals("-3/4"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 1, (int) (short) 10);
        int int3 = fraction2.getDenominator();
        int int4 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction2.reduce();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(fraction5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("3/20");
        int int2 = fraction1.getProperNumerator();
        double double3 = fraction1.doubleValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.15d + "'", double3 == 0.15d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 11, (-10));
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 0, (int) (short) 10);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.add(fraction5);
        int int7 = fraction5.intValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        java.lang.String str3 = fraction0.toString();
        int int4 = fraction0.getNumerator();
        long long5 = fraction0.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3/4" + "'", str3.equals("3/4"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        int int4 = fraction2.getNumerator();
        float float5 = fraction2.floatValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.4f + "'", float5 == 0.4f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction5.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction0.multiplyBy(fraction5);
        int int13 = fraction12.getDenominator();
        byte byte14 = fraction12.byteValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 2, (int) (byte) 35, 6);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        short short2 = fraction1.shortValue();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int6 = fraction3.compareTo(fraction5);
        long long7 = fraction5.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int9 = fraction8.intValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction5.add(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction1.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.negate();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction12.reduce();
        java.lang.String str16 = fraction15.toString();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction17.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int20 = fraction17.compareTo(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.reduce();
        float float22 = fraction19.floatValue();
        byte byte23 = fraction19.byteValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction15.divideBy(fraction19);
        int int25 = fraction11.compareTo(fraction15);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3/4" + "'", str16.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.4f + "'", float22 == 0.4f);
        org.junit.Assert.assertTrue("'" + byte23 + "' != '" + (byte) 0 + "'", byte23 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction5.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction0.multiplyBy(fraction5);
        int int13 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction0.negate();
        int int15 = fraction0.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', (int) (byte) 100);
        int int19 = fraction18.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction0.multiplyBy(fraction18);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 97 + "'", int19 == 97);
        org.junit.Assert.assertNotNull(fraction20);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        byte byte1 = fraction0.byteValue();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long3 = fraction2.longValue();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction4.subtract(fraction7);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.abs();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction7.abs();
        byte byte11 = fraction10.byteValue();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction21 = fraction16.add(fraction20);
        int int22 = fraction10.compareTo(fraction20);
        int int23 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction0.add(fraction10);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction24.reduce();
        int int26 = fraction25.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.negate();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertNotNull(fraction27);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        long long1 = fraction0.longValue();
        short short2 = fraction0.shortValue();
        java.lang.String str3 = fraction0.toProperString();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction(10.0d);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.abs();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction0.subtract(fraction6);
        int int9 = fraction8.intValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1/2" + "'", str3.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-9) + "'", int9 == (-9));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        int int5 = fraction3.intValue();
        int int6 = fraction3.intValue();
        int int7 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.invert();
        int int9 = fraction3.getNumerator();
        java.lang.Class<?> wildcardClass10 = fraction3.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(6, (int) (short) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction8.compareTo(fraction9);
        int int11 = fraction9.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int19 = fraction17.compareTo(fraction18);
        int int20 = fraction15.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction21.reduce();
        int int23 = fraction9.compareTo(fraction22);
        int int24 = fraction2.compareTo(fraction22);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction22.reduce();
        int int26 = fraction22.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction22.invert();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3/4" + "'", str7.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
        org.junit.Assert.assertNotNull(fraction27);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        int int8 = fraction3.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float10 = fraction9.floatValue();
        int int11 = fraction9.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction3.multiplyBy(fraction12);
        try {
            org.apache.commons.lang3.math.Fraction fraction15 = fraction13.pow(323);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mulPos");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.75f + "'", float10 == 0.75f);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.subtract(fraction11);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.invert();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.subtract(fraction17);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.invert();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction14.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction9.multiplyBy(fraction14);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction21.abs();
        int int23 = fraction2.compareTo(fraction22);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction22.multiplyBy(fraction26);
        org.apache.commons.lang3.math.Fraction fraction28 = null;
        try {
            int int29 = fraction27.compareTo(fraction28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        int int5 = fraction3.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int8 = fraction6.compareTo(fraction7);
        int int9 = fraction7.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.multiplyBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = fraction11.subtract(fraction13);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.subtract(fraction14);
        java.lang.Class<?> wildcardClass16 = fraction14.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(97, 35);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 32, (int) ' ');
        int int6 = fraction2.compareTo(fraction5);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.intValue();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int4 = fraction2.compareTo(fraction3);
        int int5 = fraction3.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int9 = fraction6.compareTo(fraction8);
        int int10 = fraction8.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction3.multiplyBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction8.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction0.divideBy(fraction13);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction0.invert();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction1.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.invert();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction0.subtract(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction8.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.invert();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.invert();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction0.add(fraction13);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction0.abs();
        int int17 = fraction0.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -11, (int) (short) 100);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        double double1 = fraction0.doubleValue();
        float float2 = fraction0.floatValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) -1, (int) (byte) 1, (int) (short) 35);
        int int8 = fraction3.compareTo(fraction7);
        int int9 = fraction3.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.75d + "'", double1 == 0.75d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.75f + "'", float2 == 0.75f);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-35), (int) (short) 1, (int) (byte) 4);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        int int5 = fraction3.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int8 = fraction6.compareTo(fraction7);
        int int9 = fraction7.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.multiplyBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double15 = fraction14.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.abs();
        int int17 = fraction14.getDenominator();
        int int18 = fraction14.intValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction14.reduce();
        int int20 = fraction7.compareTo(fraction19);
        long long21 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long24 = fraction23.longValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction22.subtract(fraction25);
        java.lang.Class<?> wildcardClass27 = fraction22.getClass();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long30 = fraction29.longValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.reduce();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction28.subtract(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long35 = fraction34.longValue();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction34.reduce();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction33.subtract(fraction36);
        org.apache.commons.lang3.math.Fraction fraction41 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction42 = fraction37.add(fraction41);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction41.pow(4);
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long46 = fraction45.longValue();
        org.apache.commons.lang3.math.Fraction fraction47 = fraction45.invert();
        int int48 = fraction44.compareTo(fraction45);
        boolean boolean49 = fraction31.equals((java.lang.Object) fraction44);
        org.apache.commons.lang3.math.Fraction fraction50 = fraction22.multiplyBy(fraction31);
        org.apache.commons.lang3.math.Fraction fraction51 = fraction7.add(fraction22);
        java.lang.Class<?> wildcardClass52 = fraction51.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.01d + "'", double15 == 10.01d);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertNotNull(wildcardClass52);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.invert();
        java.lang.String str4 = fraction2.toString();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) -1, (int) (byte) 32);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.subtract(fraction7);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1/1" + "'", str4.equals("1/1"));
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 3, 100000001, (int) '4');
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        int int5 = fraction3.intValue();
        int int6 = fraction3.intValue();
        int int7 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.invert();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction("1/16");
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction(10.0d);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.abs();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction18.invert();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double24 = fraction23.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.abs();
        java.lang.Class<?> wildcardClass26 = fraction25.getClass();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction18.subtract(fraction25);
        int int28 = fraction14.compareTo(fraction27);
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction30 = fraction29.reduce();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.reduce();
        int int32 = fraction31.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int36 = fraction34.compareTo(fraction35);
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str38 = fraction37.toString();
        org.apache.commons.lang3.math.Fraction fraction39 = fraction34.multiplyBy(fraction37);
        java.lang.String str40 = fraction34.toProperString();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction33.multiplyBy(fraction34);
        org.apache.commons.lang3.math.Fraction fraction42 = fraction31.add(fraction34);
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction44 = fraction43.reduce();
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction46 = fraction43.subtract(fraction45);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction43.invert();
        org.apache.commons.lang3.math.Fraction fraction48 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction49 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction50 = fraction49.reduce();
        org.apache.commons.lang3.math.Fraction fraction51 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction52 = fraction49.subtract(fraction51);
        org.apache.commons.lang3.math.Fraction fraction53 = fraction49.invert();
        org.apache.commons.lang3.math.Fraction fraction54 = fraction48.subtract(fraction53);
        org.apache.commons.lang3.math.Fraction fraction55 = fraction43.multiplyBy(fraction48);
        int int56 = fraction31.compareTo(fraction48);
        java.lang.String str57 = fraction48.toString();
        org.apache.commons.lang3.math.Fraction fraction58 = fraction27.multiplyBy(fraction48);
        org.apache.commons.lang3.math.Fraction fraction59 = fraction11.add(fraction27);
        org.apache.commons.lang3.math.Fraction fraction60 = fraction3.divideBy(fraction27);
        byte byte61 = fraction60.byteValue();
        float float62 = fraction60.floatValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.01d + "'", double24 == 10.01d);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "3/4" + "'", str38.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1/5" + "'", str40.equals("1/5"));
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertNotNull(fraction48);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "3/5" + "'", str57.equals("3/5"));
        org.junit.Assert.assertNotNull(fraction58);
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertNotNull(fraction60);
        org.junit.Assert.assertTrue("'" + byte61 + "' != '" + (byte) 0 + "'", byte61 == (byte) 0);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + (-0.09082652f) + "'", float62 == (-0.09082652f));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) -1, (int) (byte) 4, 8);
        int int4 = fraction3.getProperWhole();
        int int5 = fraction3.getDenominator();
        float float6 = fraction3.floatValue();
        int int7 = fraction3.getDenominator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.5f) + "'", float6 == (-1.5f));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction5.abs();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int11 = fraction8.compareTo(fraction10);
        float float12 = fraction10.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.multiplyBy(fraction10);
        int int14 = fraction13.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction17 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction19 = fraction16.subtract(fraction18);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction16.invert();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction15.subtract(fraction20);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction15.abs();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction13.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction13.pow((int) (short) -1);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.4f + "'", float12 == 0.4f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction25);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ZERO;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        int int5 = fraction4.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.divideBy(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.subtract(fraction3);
        int int9 = fraction8.getDenominator();
        float float10 = fraction8.floatValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-0.75f) + "'", float10 == (-0.75f));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("35/1");
        java.lang.String str2 = fraction1.toString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35/1" + "'", str2.equals("35/1"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction6.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long10 = fraction9.longValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.subtract(fraction11);
        boolean boolean13 = fraction6.equals((java.lang.Object) fraction8);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction5.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int17 = fraction16.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long20 = fraction19.longValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.subtract(fraction21);
        boolean boolean23 = fraction16.equals((java.lang.Object) fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction15.subtract(fraction18);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.pow((int) (short) 10);
        int int28 = fraction15.compareTo(fraction27);
        int int29 = fraction8.compareTo(fraction15);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction4.divideBy(fraction15);
        int int32 = fraction15.getProperWhole();
        int int33 = fraction15.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction5.abs();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int11 = fraction8.compareTo(fraction10);
        float float12 = fraction10.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.multiplyBy(fraction10);
        double double14 = fraction7.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction7.abs();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        int int19 = fraction18.getProperNumerator();
        byte byte20 = fraction18.byteValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction18.invert();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction7.subtract(fraction18);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 32);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction27.abs();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction25.multiplyBy(fraction28);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction18.add(fraction29);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.4f + "'", float12 == 0.4f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 35 + "'", byte20 == (byte) 35);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("97/100");
        int int2 = fraction1.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction0.compareTo(fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str4 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction0.multiplyBy(fraction3);
        byte byte6 = fraction5.byteValue();
        java.lang.String str7 = fraction5.toString();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction5.abs();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.reduce();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3/4" + "'", str4.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3/20" + "'", str7.equals("3/20"));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction6.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long10 = fraction9.longValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.subtract(fraction11);
        boolean boolean13 = fraction6.equals((java.lang.Object) fraction8);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction5.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int17 = fraction16.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long20 = fraction19.longValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.subtract(fraction21);
        boolean boolean23 = fraction16.equals((java.lang.Object) fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction15.subtract(fraction18);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.pow((int) (short) 10);
        int int28 = fraction15.compareTo(fraction27);
        int int29 = fraction8.compareTo(fraction15);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction4.divideBy(fraction15);
        java.lang.String str32 = fraction31.toProperString();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction31.pow(1);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "-2 1/2" + "'", str32.equals("-2 1/2"));
        org.junit.Assert.assertNotNull(fraction34);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(100, (int) '#');
        double double3 = fraction2.doubleValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.857142857142857d + "'", double3 == 2.857142857142857d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 35, (int) (byte) 0, (int) (byte) 10);
        int int4 = fraction3.getDenominator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        java.lang.String str4 = fraction2.toString();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.pow((int) (short) 6);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2/5" + "'", str4.equals("2/5"));
        org.junit.Assert.assertNotNull(fraction6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float1 = fraction0.floatValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction(10.0d);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.abs();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.invert();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double15 = fraction14.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.abs();
        java.lang.Class<?> wildcardClass17 = fraction16.getClass();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction16);
        int int19 = fraction5.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.reduce();
        int int23 = fraction22.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int27 = fraction25.compareTo(fraction26);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str29 = fraction28.toString();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction25.multiplyBy(fraction28);
        java.lang.String str31 = fraction25.toProperString();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction24.multiplyBy(fraction25);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction22.add(fraction25);
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction35 = fraction34.reduce();
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction37 = fraction34.subtract(fraction36);
        org.apache.commons.lang3.math.Fraction fraction38 = fraction34.invert();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction40 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction41 = fraction40.reduce();
        org.apache.commons.lang3.math.Fraction fraction42 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction43 = fraction40.subtract(fraction42);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction40.invert();
        org.apache.commons.lang3.math.Fraction fraction45 = fraction39.subtract(fraction44);
        org.apache.commons.lang3.math.Fraction fraction46 = fraction34.multiplyBy(fraction39);
        int int47 = fraction22.compareTo(fraction39);
        java.lang.String str48 = fraction39.toString();
        org.apache.commons.lang3.math.Fraction fraction49 = fraction18.multiplyBy(fraction39);
        org.apache.commons.lang3.math.Fraction fraction50 = fraction0.multiplyBy(fraction39);
        org.apache.commons.lang3.math.Fraction fraction51 = fraction39.invert();
        org.apache.commons.lang3.math.Fraction fraction52 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction55 = org.apache.commons.lang3.math.Fraction.getFraction(0, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction56 = fraction52.subtract(fraction55);
        org.apache.commons.lang3.math.Fraction fraction57 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction58 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long59 = fraction58.longValue();
        org.apache.commons.lang3.math.Fraction fraction60 = fraction58.reduce();
        org.apache.commons.lang3.math.Fraction fraction61 = fraction57.subtract(fraction60);
        org.apache.commons.lang3.math.Fraction fraction65 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction66 = fraction61.add(fraction65);
        org.apache.commons.lang3.math.Fraction fraction68 = fraction65.pow(4);
        org.apache.commons.lang3.math.Fraction fraction69 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long70 = fraction69.longValue();
        org.apache.commons.lang3.math.Fraction fraction71 = fraction69.invert();
        int int72 = fraction68.compareTo(fraction69);
        float float73 = fraction69.floatValue();
        int int74 = fraction52.compareTo(fraction69);
        org.apache.commons.lang3.math.Fraction fraction75 = fraction39.add(fraction69);
        org.apache.commons.lang3.math.Fraction fraction76 = fraction75.reduce();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.75f + "'", float1 == 0.75f);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.01d + "'", double15 == 10.01d);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "3/4" + "'", str29.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1/5" + "'", str31.equals("1/5"));
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "3/5" + "'", str48.equals("3/5"));
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertNotNull(fraction56);
        org.junit.Assert.assertNotNull(fraction57);
        org.junit.Assert.assertNotNull(fraction58);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
        org.junit.Assert.assertNotNull(fraction60);
        org.junit.Assert.assertNotNull(fraction61);
        org.junit.Assert.assertNotNull(fraction65);
        org.junit.Assert.assertNotNull(fraction66);
        org.junit.Assert.assertNotNull(fraction68);
        org.junit.Assert.assertNotNull(fraction69);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
        org.junit.Assert.assertNotNull(fraction71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + float73 + "' != '" + 0.75f + "'", float73 == 0.75f);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(fraction75);
        org.junit.Assert.assertNotNull(fraction76);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(0, (int) (short) 100);
        short short3 = fraction2.shortValue();
        byte byte4 = fraction2.byteValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        int int8 = fraction3.compareTo(fraction6);
        int int9 = fraction6.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction6.add(fraction10);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction10.negate();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(9, 8);
        long long3 = fraction2.longValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.subtract(fraction9);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.abs();
        int int12 = fraction9.getProperNumerator();
        java.lang.Class<?> wildcardClass13 = fraction9.getClass();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction9.reduce();
        int int15 = fraction2.compareTo(fraction14);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("0");
        int int2 = fraction1.getProperWhole();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        int int20 = fraction2.getNumerator();
        java.lang.String str21 = fraction2.toProperString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3/4" + "'", str7.equals("3/4"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "3/4" + "'", str21.equals("3/4"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        int int8 = fraction3.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double15 = fraction14.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.abs();
        long long17 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction14);
        long long19 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction14.reduce();
        int int21 = fraction14.getProperWhole();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.01d + "'", double15 == 10.01d);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        int int4 = fraction2.getNumerator();
        java.lang.String str5 = fraction2.toString();
        short short6 = fraction2.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction7.subtract(fraction9);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.invert();
        double double12 = fraction11.doubleValue();
        short short13 = fraction11.shortValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 10, 4);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction11.divideBy(fraction17);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long20 = fraction19.longValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.negate();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction19.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction24 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction23.negate();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction26.invert();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction19.subtract(fraction26);
        short short29 = fraction26.shortValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction18.subtract(fraction26);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction2.add(fraction26);
        byte byte32 = fraction31.byteValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2/5" + "'", str5.equals("2/5"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 1 + "'", short13 == (short) 1);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + short29 + "' != '" + (short) -1 + "'", short29 == (short) -1);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + byte32 + "' != '" + (byte) 0 + "'", byte32 == (byte) 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction(10.01d);
        java.lang.Class<?> wildcardClass2 = fraction1.getClass();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction8.compareTo(fraction9);
        int int11 = fraction6.compareTo(fraction9);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.invert();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction13.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.negate();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction12.subtract(fraction17);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        double double20 = fraction19.doubleValue();
        int int21 = fraction19.getNumerator();
        java.lang.Class<?> wildcardClass22 = fraction19.getClass();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int24 = fraction23.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long27 = fraction26.longValue();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction26.reduce();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction25.subtract(fraction28);
        boolean boolean30 = fraction23.equals((java.lang.Object) fraction25);
        float float31 = fraction25.floatValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction19.add(fraction25);
        boolean boolean33 = fraction18.equals((java.lang.Object) fraction32);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction32.negate();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction1.multiplyBy(fraction32);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.75d + "'", double20 == 0.75d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double9 = fraction8.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.abs();
        long long11 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.pow((-4));
        short short16 = fraction13.shortValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.01d + "'", double9 == 10.01d);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.invert();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.invert();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int15 = fraction14.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long18 = fraction17.longValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.reduce();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction16.subtract(fraction19);
        boolean boolean21 = fraction14.equals((java.lang.Object) fraction16);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction13.subtract(fraction16);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction9.multiplyBy(fraction13);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction5.subtract(fraction13);
        int int25 = fraction13.intValue();
        int int26 = fraction13.getDenominator();
        int int27 = fraction13.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 35 + "'", int25 == 35);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) -1, (int) (byte) 4, 8);
        int int4 = fraction3.getProperWhole();
        int int5 = fraction3.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        byte byte7 = fraction6.byteValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction10.subtract(fraction13);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.abs();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction13.abs();
        byte byte17 = fraction16.byteValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long20 = fraction19.longValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.subtract(fraction21);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction27 = fraction22.add(fraction26);
        int int28 = fraction16.compareTo(fraction26);
        int int29 = fraction16.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction6.add(fraction16);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction30.negate();
        boolean boolean32 = fraction3.equals((java.lang.Object) fraction30);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 10 + "'", byte17 == (byte) 10);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 0, 5);
        java.lang.Class<?> wildcardClass3 = fraction2.getClass();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double8 = fraction7.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.abs();
        java.lang.Class<?> wildcardClass10 = fraction9.getClass();
        java.lang.String str11 = fraction9.toProperString();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction2.divideBy(fraction9);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction17.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int20 = fraction17.compareTo(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction14.subtract(fraction17);
        int int22 = fraction21.intValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction13.subtract(fraction21);
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.subtract(fraction24);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.01d + "'", double8 == 10.01d);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10 1/100" + "'", str11.equals("10 1/100"));
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction5.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction0.multiplyBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction12.abs();
        int int14 = fraction13.getProperWhole();
        float float15 = fraction13.floatValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.6f + "'", float15 == 0.6f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction23 = fraction20.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction19.multiplyBy(fraction23);
        int int25 = fraction19.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.ONE_QUARTER;
        java.lang.String str27 = fraction26.toString();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction19.multiplyBy(fraction26);
        long long29 = fraction19.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3/4" + "'", str7.equals("3/4"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1/4" + "'", str27.equals("1/4"));
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.subtract(fraction6);
        float float9 = fraction8.floatValue();
        double double10 = fraction8.doubleValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(5, (int) (short) 10, 4);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        boolean boolean12 = fraction5.equals((java.lang.Object) fraction7);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction4.subtract(fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int16 = fraction15.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long19 = fraction18.longValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.subtract(fraction20);
        boolean boolean22 = fraction15.equals((java.lang.Object) fraction17);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction14.subtract(fraction17);
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction26 = fraction24.pow((int) (short) 10);
        int int27 = fraction14.compareTo(fraction26);
        int int28 = fraction7.compareTo(fraction14);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction14.pow(3);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.getReducedFraction(3, 97);
        int int34 = fraction30.compareTo(fraction33);
        org.apache.commons.lang3.math.Fraction fraction35 = fraction3.subtract(fraction30);
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.getFraction(0, (int) (short) 100);
        short short39 = fraction38.shortValue();
        org.apache.commons.lang3.math.Fraction fraction42 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction44 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 32);
        org.apache.commons.lang3.math.Fraction fraction45 = fraction44.abs();
        org.apache.commons.lang3.math.Fraction fraction46 = fraction42.multiplyBy(fraction45);
        int int47 = fraction38.compareTo(fraction46);
        java.lang.String str48 = fraction38.toString();
        boolean boolean49 = fraction35.equals((java.lang.Object) fraction38);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertTrue("'" + short39 + "' != '" + (short) 0 + "'", short39 == (short) 0);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0/100" + "'", str48.equals("0/100"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double4 = fraction3.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        long long6 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction8.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.invert();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction3.multiplyBy(fraction7);
        int int15 = fraction14.intValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.01d + "'", double4 == 10.01d);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(5, (int) (short) 10, 4);
        int int4 = fraction3.getNumerator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 30 + "'", int4 == 30);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        int int5 = fraction3.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int8 = fraction6.compareTo(fraction7);
        int int9 = fraction7.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.multiplyBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = fraction11.subtract(fraction13);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.subtract(fraction14);
        java.lang.String str16 = fraction14.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1/4" + "'", str16.equals("1/4"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(1001, (int) ' ', (int) (byte) 10);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction(0.5d);
        java.lang.String str2 = fraction1.toProperString();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction1.pow((int) (short) 6);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1/2" + "'", str2.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction5.abs();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int11 = fraction8.compareTo(fraction10);
        float float12 = fraction10.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.multiplyBy(fraction10);
        int int14 = fraction13.getProperWhole();
        byte byte15 = fraction13.byteValue();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        double double17 = fraction16.doubleValue();
        int int18 = fraction16.getNumerator();
        java.lang.Class<?> wildcardClass19 = fraction16.getClass();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int21 = fraction20.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long24 = fraction23.longValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction22.subtract(fraction25);
        boolean boolean27 = fraction20.equals((java.lang.Object) fraction22);
        float float28 = fraction22.floatValue();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction16.add(fraction22);
        short short30 = fraction16.shortValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction16.negate();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction13.multiplyBy(fraction31);
        java.lang.String str33 = fraction31.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.4f + "'", float12 == 0.4f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 4 + "'", byte15 == (byte) 4);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.75d + "'", double17 == 0.75d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.5f + "'", float28 == 0.5f);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 0 + "'", short30 == (short) 0);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "-3/4" + "'", str33.equals("-3/4"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.negate();
        java.lang.Class<?> wildcardClass4 = fraction0.getClass();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction(10, 4);
        double double8 = fraction7.doubleValue();
        java.lang.Class<?> wildcardClass9 = fraction7.getClass();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction10.reduce();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int13 = fraction10.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        float float15 = fraction12.floatValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.invert();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction12.negate();
        int int18 = fraction7.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction0.add(fraction7);
        short short20 = fraction0.shortValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.5d + "'", double8 == 2.5d);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.4f + "'", float15 == 0.4f);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + short20 + "' != '" + (short) 1 + "'", short20 == (short) 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 10);
        byte byte3 = fraction2.byteValue();
        java.lang.String str4 = fraction2.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction2.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10/10" + "'", str4.equals("10/10"));
        org.junit.Assert.assertNotNull(fraction5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction0.compareTo(fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str4 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction0.multiplyBy(fraction3);
        java.lang.String str6 = fraction0.toProperString();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.reduce();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3/4" + "'", str4.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1/5" + "'", str6.equals("1/5"));
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -2, (int) (byte) 4);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (-1.0f));
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        double double1 = fraction0.doubleValue();
        int int2 = fraction0.getNumerator();
        java.lang.Class<?> wildcardClass3 = fraction0.getClass();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int5 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.subtract(fraction9);
        boolean boolean11 = fraction4.equals((java.lang.Object) fraction6);
        float float12 = fraction6.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction0.add(fraction6);
        short short14 = fraction0.shortValue();
        int int15 = fraction0.intValue();
        int int16 = fraction0.getProperWhole();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.75d + "'", double1 == 0.75d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        float float3 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.subtract(fraction9);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.abs();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.abs();
        byte byte13 = fraction12.byteValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction2.add(fraction12);
        float float15 = fraction12.floatValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-0.75f) + "'", float3 == (-0.75f));
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 10 + "'", byte13 == (byte) 10);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 10.0f + "'", float15 == 10.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(1001, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 1, (int) (short) 10);
        int int3 = fraction2.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        double double7 = fraction6.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long10 = fraction9.longValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.divideBy(fraction12);
        int int14 = fraction12.intValue();
        int int15 = fraction12.intValue();
        int int16 = fraction12.intValue();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction12.invert();
        int int18 = fraction6.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction20 = fraction12.add(fraction19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.reduce();
        java.lang.String str4 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int8 = fraction5.compareTo(fraction7);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        float float10 = fraction7.floatValue();
        byte byte11 = fraction7.byteValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.divideBy(fraction7);
        double double13 = fraction7.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        int int17 = fraction16.getProperWhole();
        short short18 = fraction16.shortValue();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float22 = fraction21.floatValue();
        boolean boolean23 = fraction20.equals((java.lang.Object) float22);
        boolean boolean24 = fraction16.equals((java.lang.Object) fraction20);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction16.abs();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction7.subtract(fraction25);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3/4" + "'", str4.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.4f + "'", float10 == 0.4f);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.4d + "'", double13 == 0.4d);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 1 + "'", short18 == (short) 1);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.75f + "'", float22 == 0.75f);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getReducedFraction(100, (int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction5.add(fraction9);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long12 = fraction11.longValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.subtract(fraction16);
        java.lang.String str18 = fraction13.toString();
        int int19 = fraction13.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int22 = fraction21.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long25 = fraction24.longValue();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction24.reduce();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction23.subtract(fraction26);
        boolean boolean28 = fraction21.equals((java.lang.Object) fraction23);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction20.subtract(fraction23);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction13.subtract(fraction23);
        long long31 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction9.divideBy(fraction13);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "3/4" + "'", str18.equals("3/4"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(fraction32);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.5f);
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        boolean boolean12 = fraction5.equals((java.lang.Object) fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction7.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction4.multiplyBy(fraction7);
        float float16 = fraction15.floatValue();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction15.invert();
        int int18 = fraction15.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.2f + "'", float16 == 0.2f);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        int int5 = fraction3.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((-52), 7);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.add(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction3.abs();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) -1, (int) (byte) 4, 8);
        int int4 = fraction3.getProperWhole();
        int int5 = fraction3.getDenominator();
        float float6 = fraction3.floatValue();
        int int7 = fraction3.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.5f) + "'", float6 == (-1.5f));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 32, (int) (short) -10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 1, (int) (short) 10);
        int int3 = fraction2.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        double double7 = fraction6.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.pow((int) (byte) 1);
        float float11 = fraction10.floatValue();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.negate();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.divideBy(fraction14);
        float float16 = fraction10.floatValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction("20/7");
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        int int20 = fraction19.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int25 = fraction24.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long28 = fraction27.longValue();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction27.reduce();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction26.subtract(fraction29);
        boolean boolean31 = fraction24.equals((java.lang.Object) fraction26);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction23.subtract(fraction26);
        boolean boolean33 = fraction19.equals((java.lang.Object) fraction26);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction18.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long37 = fraction36.longValue();
        org.apache.commons.lang3.math.Fraction fraction38 = fraction36.reduce();
        org.apache.commons.lang3.math.Fraction fraction39 = fraction35.subtract(fraction38);
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction44 = fraction39.add(fraction43);
        org.apache.commons.lang3.math.Fraction fraction46 = fraction43.pow(4);
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long48 = fraction47.longValue();
        org.apache.commons.lang3.math.Fraction fraction49 = fraction47.invert();
        int int50 = fraction46.compareTo(fraction47);
        java.lang.String str51 = fraction46.toString();
        org.apache.commons.lang3.math.Fraction fraction52 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        byte byte53 = fraction52.byteValue();
        org.apache.commons.lang3.math.Fraction fraction54 = fraction46.divideBy(fraction52);
        int int55 = fraction19.compareTo(fraction52);
        org.apache.commons.lang3.math.Fraction fraction56 = fraction10.divideBy(fraction52);
        org.apache.commons.lang3.math.Fraction fraction57 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long58 = fraction57.longValue();
        org.apache.commons.lang3.math.Fraction fraction59 = fraction57.reduce();
        org.apache.commons.lang3.math.Fraction fraction62 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction63 = fraction59.subtract(fraction62);
        org.apache.commons.lang3.math.Fraction fraction64 = fraction62.abs();
        org.apache.commons.lang3.math.Fraction fraction65 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction66 = fraction65.reduce();
        org.apache.commons.lang3.math.Fraction fraction67 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int68 = fraction65.compareTo(fraction67);
        float float69 = fraction67.floatValue();
        org.apache.commons.lang3.math.Fraction fraction70 = fraction64.multiplyBy(fraction67);
        int int71 = fraction70.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction72 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction73 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction74 = fraction73.reduce();
        org.apache.commons.lang3.math.Fraction fraction75 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction76 = fraction73.subtract(fraction75);
        org.apache.commons.lang3.math.Fraction fraction77 = fraction73.invert();
        org.apache.commons.lang3.math.Fraction fraction78 = fraction72.subtract(fraction77);
        org.apache.commons.lang3.math.Fraction fraction79 = fraction72.abs();
        org.apache.commons.lang3.math.Fraction fraction80 = fraction70.subtract(fraction79);
        org.apache.commons.lang3.math.Fraction fraction82 = fraction80.pow((int) (byte) -1);
        java.lang.String str83 = fraction82.toProperString();
        int int84 = fraction52.compareTo(fraction82);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "100000000/1" + "'", str51.equals("100000000/1"));
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertTrue("'" + byte53 + "' != '" + (byte) 0 + "'", byte53 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(fraction56);
        org.junit.Assert.assertNotNull(fraction57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertNotNull(fraction62);
        org.junit.Assert.assertNotNull(fraction63);
        org.junit.Assert.assertNotNull(fraction64);
        org.junit.Assert.assertNotNull(fraction65);
        org.junit.Assert.assertNotNull(fraction66);
        org.junit.Assert.assertNotNull(fraction67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + float69 + "' != '" + 0.4f + "'", float69 == 0.4f);
        org.junit.Assert.assertNotNull(fraction70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 4 + "'", int71 == 4);
        org.junit.Assert.assertNotNull(fraction72);
        org.junit.Assert.assertNotNull(fraction73);
        org.junit.Assert.assertNotNull(fraction74);
        org.junit.Assert.assertNotNull(fraction75);
        org.junit.Assert.assertNotNull(fraction76);
        org.junit.Assert.assertNotNull(fraction77);
        org.junit.Assert.assertNotNull(fraction78);
        org.junit.Assert.assertNotNull(fraction79);
        org.junit.Assert.assertNotNull(fraction80);
        org.junit.Assert.assertNotNull(fraction82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "5/17" + "'", str83.equals("5/17"));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        boolean boolean12 = fraction5.equals((java.lang.Object) fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction7.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction4.multiplyBy(fraction7);
        java.lang.String str16 = fraction4.toString();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction4.negate();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long19 = fraction18.longValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.subtract(fraction20);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction21.reduce();
        java.lang.String str23 = fraction21.toProperString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2/5" + "'", str16.equals("2/5"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-1 3/20" + "'", str23.equals("-1 3/20"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.reduce();
        java.lang.String str4 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int8 = fraction5.compareTo(fraction7);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        float float10 = fraction7.floatValue();
        byte byte11 = fraction7.byteValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.divideBy(fraction7);
        double double13 = fraction12.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction17 = fraction14.subtract(fraction16);
        int int18 = fraction17.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction12.add(fraction17);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction12.reduce();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3/4" + "'", str4.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.4f + "'", float10 == 0.4f);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.875d + "'", double13 == 1.875d);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 10);
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int5 = fraction2.compareTo(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int8 = fraction7.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long11 = fraction10.longValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.reduce();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.subtract(fraction12);
        boolean boolean14 = fraction7.equals((java.lang.Object) fraction9);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction9.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction6.multiplyBy(fraction9);
        float float18 = fraction17.floatValue();
        byte byte19 = fraction17.byteValue();
        byte byte20 = fraction17.byteValue();
        int int21 = fraction17.intValue();
        int int22 = fraction1.compareTo(fraction17);
        double double23 = fraction1.doubleValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.2f + "'", float18 == 0.2f);
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 0 + "'", byte19 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 0 + "'", byte20 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction(0.0d);
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long3 = fraction2.longValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        int int5 = fraction2.compareTo(fraction4);
        java.lang.String str6 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.multiplyBy(fraction14);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction10.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction2.subtract(fraction16);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction1.subtract(fraction16);
        float float19 = fraction1.floatValue();
        org.apache.commons.lang3.math.Fraction fraction20 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction21 = fraction1.multiplyBy(fraction20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3/4" + "'", str6.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        boolean boolean8 = fraction1.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int12 = fraction11.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long15 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.subtract(fraction16);
        boolean boolean18 = fraction11.equals((java.lang.Object) fraction13);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction10.subtract(fraction13);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.pow((int) (short) 10);
        int int23 = fraction10.compareTo(fraction22);
        int int24 = fraction3.compareTo(fraction10);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction10.pow(3);
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.getReducedFraction(3, 97);
        int int30 = fraction26.compareTo(fraction29);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction32 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long33 = fraction32.longValue();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction32.reduce();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction31.subtract(fraction34);
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction40 = fraction35.add(fraction39);
        org.apache.commons.lang3.math.Fraction fraction42 = fraction39.pow(4);
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long44 = fraction43.longValue();
        org.apache.commons.lang3.math.Fraction fraction45 = fraction43.invert();
        int int46 = fraction42.compareTo(fraction43);
        org.apache.commons.lang3.math.Fraction fraction50 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double51 = fraction50.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction52 = fraction50.abs();
        java.lang.Class<?> wildcardClass53 = fraction52.getClass();
        java.lang.String str54 = fraction52.toProperString();
        org.apache.commons.lang3.math.Fraction fraction55 = fraction52.negate();
        int int56 = fraction55.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction57 = fraction42.multiplyBy(fraction55);
        java.lang.String str58 = fraction55.toProperString();
        org.apache.commons.lang3.math.Fraction fraction59 = fraction29.add(fraction55);
        org.apache.commons.lang3.math.Fraction fraction60 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction61 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str62 = fraction61.toString();
        org.apache.commons.lang3.math.Fraction fraction63 = fraction61.invert();
        org.apache.commons.lang3.math.Fraction fraction64 = fraction60.subtract(fraction63);
        org.apache.commons.lang3.math.Fraction fraction65 = fraction64.reduce();
        org.apache.commons.lang3.math.Fraction fraction66 = fraction55.add(fraction64);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 10.01d + "'", double51 == 10.01d);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10 1/100" + "'", str54.equals("10 1/100"));
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 100 + "'", int56 == 100);
        org.junit.Assert.assertNotNull(fraction57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "-10 1/100" + "'", str58.equals("-10 1/100"));
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertNotNull(fraction60);
        org.junit.Assert.assertNotNull(fraction61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "3/4" + "'", str62.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction63);
        org.junit.Assert.assertNotNull(fraction64);
        org.junit.Assert.assertNotNull(fraction65);
        org.junit.Assert.assertNotNull(fraction66);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        float float5 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.invert();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.abs();
        java.lang.String str9 = fraction7.toProperString();
        java.lang.String str10 = fraction7.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.4f + "'", float5 == 0.4f);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-2/5" + "'", str9.equals("-2/5"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-2/5" + "'", str10.equals("-2/5"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction9 = fraction4.add(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction8.pow(4);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.invert();
        int int15 = fraction11.compareTo(fraction12);
        java.lang.String str16 = fraction11.toString();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 10, (int) 'a');
        org.apache.commons.lang3.math.Fraction fraction20 = fraction19.invert();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction11.add(fraction20);
        int int22 = fraction11.getDenominator();
        java.lang.String str23 = fraction11.toString();
        float float24 = fraction11.floatValue();
        short short25 = fraction11.shortValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100000000/1" + "'", str16.equals("100000000/1"));
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100000000/1" + "'", str23.equals("100000000/1"));
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0E8f + "'", float24 == 1.0E8f);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) -7936 + "'", short25 == (short) -7936);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        int int1 = fraction0.getNumerator();
        int int2 = fraction0.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction8.compareTo(fraction9);
        int int11 = fraction6.compareTo(fraction9);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.invert();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction13.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.negate();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction12.subtract(fraction17);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        double double20 = fraction19.doubleValue();
        int int21 = fraction19.getNumerator();
        java.lang.Class<?> wildcardClass22 = fraction19.getClass();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int24 = fraction23.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long27 = fraction26.longValue();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction26.reduce();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction25.subtract(fraction28);
        boolean boolean30 = fraction23.equals((java.lang.Object) fraction25);
        float float31 = fraction25.floatValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction19.add(fraction25);
        boolean boolean33 = fraction18.equals((java.lang.Object) fraction32);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction0.multiplyBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long36 = fraction35.longValue();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction35.reduce();
        int int38 = fraction37.getProperNumerator();
        long long39 = fraction37.longValue();
        java.lang.String str40 = fraction37.toProperString();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction18.divideBy(fraction37);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.75d + "'", double20 == 0.75d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "3/4" + "'", str40.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction41);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        int int5 = fraction3.intValue();
        int int6 = fraction3.intValue();
        int int7 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.invert();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.invert();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int13 = fraction11.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str15 = fraction14.toString();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction11.multiplyBy(fraction14);
        java.lang.String str17 = fraction11.toProperString();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction10.multiplyBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction9.add(fraction18);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction9.pow(5);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getFraction(100.0d);
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction25 = fraction24.reduce();
        int int26 = fraction23.compareTo(fraction25);
        int int27 = fraction25.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction21.add(fraction25);
        int int29 = fraction21.intValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3/4" + "'", str15.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1/5" + "'", str17.equals("1/5"));
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.reduce();
        short short4 = fraction0.shortValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 11, 4, 3);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        java.lang.String str4 = fraction0.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction0.invert();
        byte byte6 = fraction5.byteValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction5.pow(2);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1/1" + "'", str4.equals("1/1"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertNotNull(fraction8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        int int3 = fraction2.getProperNumerator();
        byte byte4 = fraction2.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction2.invert();
        double double6 = fraction2.doubleValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 35 + "'", byte4 == (byte) 35);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction9 = fraction4.add(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction8.pow(4);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.invert();
        int int15 = fraction11.compareTo(fraction12);
        java.lang.String str16 = fraction11.toString();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction17.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.reduce();
        int int20 = fraction19.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int24 = fraction22.compareTo(fraction23);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str26 = fraction25.toString();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction22.multiplyBy(fraction25);
        java.lang.String str28 = fraction22.toProperString();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction21.multiplyBy(fraction22);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction19.add(fraction22);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction11.add(fraction19);
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.getReducedFraction(9, 8);
        long long35 = fraction34.longValue();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction31.divideBy(fraction34);
        int int37 = fraction31.intValue();
        int int38 = fraction31.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100000000/1" + "'", str16.equals("100000000/1"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "3/4" + "'", str26.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1/5" + "'", str28.equals("1/5"));
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100000001 + "'", int37 == 100000001);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction2.invert();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-4), (int) (byte) -1, (int) (byte) -100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        boolean boolean12 = fraction5.equals((java.lang.Object) fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction7.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction4.multiplyBy(fraction7);
        float float16 = fraction15.floatValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long19 = fraction18.longValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.subtract(fraction20);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction26 = fraction21.add(fraction25);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction15.divideBy(fraction21);
        long long28 = fraction21.longValue();
        java.lang.String str29 = fraction21.toString();
        int int30 = fraction21.intValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.2f + "'", float16 == 0.2f);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-1/4" + "'", str29.equals("-1/4"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        double double1 = fraction0.doubleValue();
        java.lang.String str2 = fraction0.toProperString();
        double double3 = fraction0.doubleValue();
        byte byte4 = fraction0.byteValue();
        byte byte5 = fraction0.byteValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.75d + "'", double1 == 0.75d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3/4" + "'", str2.equals("3/4"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.75d + "'", double3 == 0.75d);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 3L);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        boolean boolean8 = fraction1.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.subtract(fraction3);
        int int10 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction3.abs();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.reduce();
        java.lang.String str13 = fraction12.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1/2" + "'", str13.equals("1/2"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        int int5 = fraction3.intValue();
        int int6 = fraction3.intValue();
        int int7 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.invert();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.invert();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int13 = fraction11.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str15 = fraction14.toString();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction11.multiplyBy(fraction14);
        java.lang.String str17 = fraction11.toProperString();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction10.multiplyBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction9.add(fraction18);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.abs();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3/4" + "'", str15.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1/5" + "'", str17.equals("1/5"));
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        int int8 = fraction3.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double15 = fraction14.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.abs();
        long long17 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction14);
        double double19 = fraction18.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.invert();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.01d + "'", double15 == 10.01d);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-10.76d) + "'", double19 == (-10.76d));
        org.junit.Assert.assertNotNull(fraction20);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.invert();
        java.lang.String str4 = fraction2.toString();
        java.lang.String str5 = fraction2.toProperString();
        float float6 = fraction2.floatValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1/1" + "'", str4.equals("1/1"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double4 = fraction3.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        byte byte6 = fraction5.byteValue();
        long long7 = fraction5.longValue();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction(1, (int) '#', (int) '#');
        int int12 = fraction11.getProperWhole();
        int int13 = fraction11.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction5.multiplyBy(fraction11);
        byte byte15 = fraction5.byteValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.01d + "'", double4 == 10.01d);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 10 + "'", byte15 == (byte) 10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        float float3 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction(0.5d);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.add(fraction5);
        int int7 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction5.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction("100000000/1");
        org.apache.commons.lang3.math.Fraction fraction11 = fraction10.reduce();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int14 = fraction12.compareTo(fraction13);
        int int15 = fraction13.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction17 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int19 = fraction16.compareTo(fraction18);
        int int20 = fraction18.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction13.multiplyBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction10.multiplyBy(fraction21);
        boolean boolean23 = fraction8.equals((java.lang.Object) fraction22);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-0.75f) + "'", float3 == (-0.75f));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.reduce();
        java.lang.String str4 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int8 = fraction5.compareTo(fraction7);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        float float10 = fraction7.floatValue();
        byte byte11 = fraction7.byteValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.divideBy(fraction7);
        double double13 = fraction12.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.multiplyBy(fraction15);
        org.apache.commons.lang3.math.Fraction fraction17 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction18 = fraction12.add(fraction17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3/4" + "'", str4.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.4f + "'", float10 == 0.4f);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.875d + "'", double13 == 1.875d);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ZERO;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        int int2 = fraction1.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction0.pow(5);
        int int7 = fraction0.getNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        int int4 = fraction2.getNumerator();
        java.lang.String str5 = fraction2.toString();
        short short6 = fraction2.shortValue();
        byte byte7 = fraction2.byteValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.invert();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction2.subtract(fraction9);
        try {
            org.apache.commons.lang3.math.Fraction fraction12 = fraction10.pow(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2/5" + "'", str5.equals("2/5"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        int int3 = fraction2.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str9 = fraction8.toString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction5.multiplyBy(fraction8);
        java.lang.String str11 = fraction5.toProperString();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction4.multiplyBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction2.add(fraction5);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction5.abs();
        int int15 = fraction5.getProperWhole();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3/4" + "'", str9.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1/5" + "'", str11.equals("1/5"));
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(0, (-1));
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        int int4 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int12 = fraction10.compareTo(fraction11);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str14 = fraction13.toString();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.multiplyBy(fraction13);
        java.lang.String str16 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction9.multiplyBy(fraction10);
        int int18 = fraction7.compareTo(fraction10);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 1, (int) (short) 10);
        int int22 = fraction21.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction24 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.reduce();
        double double26 = fraction25.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction21.subtract(fraction25);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str29 = fraction28.toString();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction28.invert();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction25.add(fraction30);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction10.divideBy(fraction25);
        try {
            org.apache.commons.lang3.math.Fraction fraction34 = fraction32.pow((int) (short) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mulPos");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "3/4" + "'", str14.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1/5" + "'", str16.equals("1/5"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "3/4" + "'", str29.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getReducedFraction(100, (int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction5.add(fraction9);
        java.lang.Class<?> wildcardClass11 = fraction9.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        float float3 = fraction2.floatValue();
        int int4 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long6 = fraction5.longValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int12 = fraction11.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long15 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.subtract(fraction16);
        boolean boolean18 = fraction11.equals((java.lang.Object) fraction13);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction10.subtract(fraction13);
        double double20 = fraction13.doubleValue();
        int int21 = fraction13.intValue();
        java.lang.Class<?> wildcardClass22 = fraction13.getClass();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction5.multiplyBy(fraction13);
        int int24 = fraction2.compareTo(fraction23);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction23.pow((int) (short) 1);
        long long27 = fraction26.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-0.75f) + "'", float3 == (-0.75f));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5d + "'", double20 == 0.5d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(32, (int) (short) 10);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        int int8 = fraction3.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction10.reduce();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = fraction10.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction10.negate();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction9.subtract(fraction14);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.abs();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        int int8 = fraction3.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.invert();
        java.lang.Class<?> wildcardClass10 = fraction6.getClass();
        java.lang.String str11 = fraction6.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction(1, (int) '#', (int) '#');
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.abs();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction6.add(fraction15);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long21 = fraction20.longValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction19.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction28 = fraction23.add(fraction27);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction18.subtract(fraction27);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction18.abs();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction15.subtract(fraction30);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3/4" + "'", str11.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction6.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long10 = fraction9.longValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.subtract(fraction11);
        boolean boolean13 = fraction6.equals((java.lang.Object) fraction8);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction5.subtract(fraction8);
        double double15 = fraction8.doubleValue();
        int int16 = fraction8.intValue();
        java.lang.Class<?> wildcardClass17 = fraction8.getClass();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction0.multiplyBy(fraction8);
        short short19 = fraction0.shortValue();
        java.lang.String str20 = fraction0.toProperString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "3/4" + "'", str20.equals("3/4"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 0, (int) (short) 10);
        long long3 = fraction2.longValue();
        int int4 = fraction2.getDenominator();
        long long5 = fraction2.longValue();
        int int6 = fraction2.getProperWhole();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (-1.5f));
        byte byte2 = fraction1.byteValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction5.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction0.multiplyBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction12.abs();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.5f);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        long long18 = fraction17.longValue();
        short short19 = fraction17.shortValue();
        java.lang.String str20 = fraction17.toProperString();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getFraction(10.0d);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction23.abs();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction17.subtract(fraction23);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction16.multiplyBy(fraction23);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1/2" + "'", str20.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction23 = fraction20.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction19.multiplyBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int27 = fraction25.compareTo(fraction26);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str29 = fraction28.toString();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction25.multiplyBy(fraction28);
        int int31 = fraction30.intValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction23.multiplyBy(fraction30);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction23.abs();
        short short34 = fraction33.shortValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3/4" + "'", str7.equals("3/4"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "3/4" + "'", str29.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + short34 + "' != '" + (short) 0 + "'", short34 == (short) 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(0, 1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.invert();
        int int6 = fraction4.getDenominator();
        int int7 = fraction4.getNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 33.9f);
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = fraction1.pow((int) (byte) -100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mulPos");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.subtract(fraction9);
        java.lang.String str11 = fraction6.toString();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.multiplyBy(fraction6);
        int int13 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction0.add(fraction3);
        int int15 = fraction3.intValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3/4" + "'", str11.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1 7/8");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        java.lang.String str5 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2/5" + "'", str5.equals("2/5"));
        org.junit.Assert.assertNotNull(fraction6);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(7, (int) (short) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The numerator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.pow((int) (short) 1);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        boolean boolean12 = fraction5.equals((java.lang.Object) fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction7.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction4.multiplyBy(fraction7);
        float float16 = fraction15.floatValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long19 = fraction18.longValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.subtract(fraction20);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction26 = fraction21.add(fraction25);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction15.divideBy(fraction21);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction29 = fraction28.reduce();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction28.reduce();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction28.negate();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction31.invert();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int37 = fraction36.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long40 = fraction39.longValue();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction39.reduce();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction38.subtract(fraction41);
        boolean boolean43 = fraction36.equals((java.lang.Object) fraction38);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction35.subtract(fraction38);
        org.apache.commons.lang3.math.Fraction fraction45 = fraction31.multiplyBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction46 = fraction27.divideBy(fraction35);
        double double47 = fraction35.doubleValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.2f + "'", float16 == 0.2f);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 35.0d + "'", double47 == 35.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        short short5 = fraction0.shortValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int4 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.subtract(fraction8);
        boolean boolean10 = fraction3.equals((java.lang.Object) fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.subtract(fraction5);
        int int12 = fraction11.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double17 = fraction16.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction16.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction11.divideBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0L);
        try {
            org.apache.commons.lang3.math.Fraction fraction22 = fraction18.divideBy(fraction21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The fraction to divide by must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.01d + "'", double17 == 10.01d);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction21);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double4 = fraction3.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        long long6 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction8.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.invert();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction3.multiplyBy(fraction7);
        java.lang.String str15 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction(0, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction16.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction3.subtract(fraction19);
        long long22 = fraction3.longValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.01d + "'", double4 == 10.01d);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1001/100" + "'", str15.equals("1001/100"));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction1.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.invert();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction0.subtract(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction8.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.invert();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.invert();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction0.add(fraction13);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction0.abs();
        java.lang.String str17 = fraction16.toString();
        byte byte18 = fraction16.byteValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "3/5" + "'", str17.equals("3/5"));
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 0 + "'", byte18 == (byte) 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1001/32");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 10, (int) 'a');
        int int3 = fraction2.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 32, 9);
        int int3 = fraction2.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (-0.4f));
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.abs();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1/5");
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.abs();
        boolean boolean9 = fraction1.equals((java.lang.Object) fraction6);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 11, (-10));
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 0, (int) (short) 10);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.add(fraction5);
        int int7 = fraction2.getProperNumerator();
        java.lang.Class<?> wildcardClass8 = fraction2.getClass();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.subtract(fraction11);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.invert();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.subtract(fraction17);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.invert();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction14.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction9.multiplyBy(fraction14);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction21.abs();
        int int23 = fraction2.compareTo(fraction22);
        int int24 = fraction2.getProperNumerator();
        int int25 = fraction2.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5 + "'", int25 == 5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(3, 9, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.invert();
        int int7 = fraction6.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.abs();
        float float4 = fraction0.floatValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long6 = fraction5.longValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.abs();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction10.abs();
        byte byte14 = fraction13.byteValue();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long17 = fraction16.longValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.subtract(fraction18);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction24 = fraction19.add(fraction23);
        int int25 = fraction13.compareTo(fraction23);
        boolean boolean26 = fraction0.equals((java.lang.Object) fraction23);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.75f + "'", float4 == 0.75f);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 10 + "'", byte14 == (byte) 10);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.reduce();
        java.lang.String str4 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int8 = fraction5.compareTo(fraction7);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        float float10 = fraction7.floatValue();
        byte byte11 = fraction7.byteValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.divideBy(fraction7);
        double double13 = fraction12.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction17 = fraction14.subtract(fraction16);
        int int18 = fraction17.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction12.add(fraction17);
        int int21 = fraction20.getNumerator();
        java.lang.Class<?> wildcardClass22 = fraction20.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3/4" + "'", str4.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.4f + "'", float10 == 0.4f);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.875d + "'", double13 == 1.875d);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 17 + "'", int21 == 17);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        int int4 = fraction2.getNumerator();
        java.lang.String str5 = fraction2.toString();
        short short6 = fraction2.shortValue();
        byte byte7 = fraction2.byteValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.invert();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction2.subtract(fraction9);
        int int11 = fraction9.getProperNumerator();
        int int12 = fraction9.getNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2/5" + "'", str5.equals("2/5"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', 17);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(100, (int) (short) 32);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-12), 100, 323);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long3 = fraction2.longValue();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.subtract(fraction4);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction10 = fraction5.add(fraction9);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction0.subtract(fraction9);
        java.lang.String str12 = fraction9.toString();
        java.lang.Class<?> wildcardClass13 = fraction9.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3500/35" + "'", str12.equals("3500/35"));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 4, 35);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.invert();
        try {
            org.apache.commons.lang3.math.Fraction fraction5 = fraction3.pow(323);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mulPos");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction1.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.invert();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction0.subtract(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction8.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.invert();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.invert();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction0.add(fraction13);
        int int16 = fraction0.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction0.negate();
        double double18 = fraction0.doubleValue();
        int int19 = fraction0.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.6d + "'", double18 == 0.6d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(1, 17);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-2), 0, 7);
        byte byte4 = fraction3.byteValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -2 + "'", byte4 == (byte) -2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction23 = fraction20.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction19.multiplyBy(fraction23);
        int int25 = fraction19.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.ONE_QUARTER;
        java.lang.String str27 = fraction26.toString();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction19.multiplyBy(fraction26);
        int int29 = fraction28.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3/4" + "'", str7.equals("3/4"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1/4" + "'", str27.equals("1/4"));
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 16 + "'", int29 == 16);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str1 = fraction0.toString();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float4 = fraction3.floatValue();
        int int5 = fraction3.getProperNumerator();
        int int6 = fraction3.getProperWhole();
        boolean boolean7 = fraction0.equals((java.lang.Object) fraction3);
        java.lang.String str8 = fraction3.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3/4" + "'", str1.equals("3/4"));
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.75f + "'", float4 == 0.75f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3/4" + "'", str8.equals("3/4"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction23 = fraction20.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction19.multiplyBy(fraction23);
        int int25 = fraction19.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.ONE_QUARTER;
        java.lang.String str27 = fraction26.toString();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction19.multiplyBy(fraction26);
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction30 = fraction29.reduce();
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction32 = fraction29.subtract(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction28.divideBy(fraction29);
        int int34 = fraction33.intValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3/4" + "'", str7.equals("3/4"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1/4" + "'", str27.equals("1/4"));
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }
}

