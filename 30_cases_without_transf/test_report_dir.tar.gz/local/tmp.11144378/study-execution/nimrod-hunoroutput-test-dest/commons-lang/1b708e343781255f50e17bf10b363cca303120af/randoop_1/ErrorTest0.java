import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test01");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        java.lang.String str8 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.multiplyBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction3.subtract(fraction10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction12", (fraction0.compareTo(fraction12) == 0) == fraction0.equals(fraction12));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test02");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.subtract(fraction8);
        java.lang.String str10 = fraction5.toString();
        int int11 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int14 = fraction13.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long17 = fraction16.longValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.subtract(fraction18);
        boolean boolean20 = fraction13.equals((java.lang.Object) fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction12.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction5.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction0.multiplyBy(fraction15);
        float float24 = fraction0.floatValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction15 and fraction23", (fraction15.compareTo(fraction23) == 0) == fraction15.equals(fraction23));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test03");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction9.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        boolean boolean16 = fraction9.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction11.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction8.multiplyBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction3.divideBy(fraction19);
        java.lang.String str21 = fraction19.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction3 and fraction4", (fraction3.compareTo(fraction4) == 0) == fraction3.equals(fraction4));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test04");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction9.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        boolean boolean16 = fraction9.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction11.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction8.multiplyBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction3.divideBy(fraction19);
        double double21 = fraction20.doubleValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction3 and fraction4", (fraction3.compareTo(fraction4) == 0) == fraction3.equals(fraction4));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test05");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        boolean boolean8 = fraction1.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.subtract(fraction3);
        int int10 = fraction3.getProperNumerator();
        int int11 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int19 = fraction17.compareTo(fraction18);
        int int20 = fraction15.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.subtract(fraction26);
        int int28 = fraction26.getNumerator();
        int int29 = fraction15.compareTo(fraction26);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction3.subtract(fraction26);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction27", (fraction0.compareTo(fraction27) == 0) == fraction0.equals(fraction27));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test06");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        int int4 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long10 = fraction9.longValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        java.lang.String str16 = fraction11.toString();
        int int17 = fraction11.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int20 = fraction19.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long23 = fraction22.longValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction22.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction21.subtract(fraction24);
        boolean boolean26 = fraction19.equals((java.lang.Object) fraction21);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction18.subtract(fraction21);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction11.subtract(fraction21);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction6.multiplyBy(fraction21);
        int int30 = fraction3.compareTo(fraction6);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction21 and fraction29", (fraction21.compareTo(fraction29) == 0) == fraction21.equals(fraction29));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test07");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction9.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        boolean boolean16 = fraction9.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction11.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction8.multiplyBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction3.divideBy(fraction19);
        java.lang.Class<?> wildcardClass21 = fraction20.getClass();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction3 and fraction4", (fraction3.compareTo(fraction4) == 0) == fraction3.equals(fraction4));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test08");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.negate();
        float float24 = fraction23.floatValue();
        java.lang.String str25 = fraction23.toProperString();
        short short26 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction20.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long29 = fraction28.longValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction28.reduce();
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.subtract(fraction33);
        org.apache.commons.lang3.math.Fraction fraction35 = fraction33.abs();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction33.abs();
        boolean boolean37 = fraction23.equals((java.lang.Object) fraction36);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction12 and fraction20", (fraction12.compareTo(fraction20) == 0) == fraction12.equals(fraction20));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test09");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        int int5 = fraction3.intValue();
        int int6 = fraction3.intValue();
        int int7 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.invert();
        int int9 = fraction8.intValue();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.subtract(fraction14);
        int int16 = fraction14.getNumerator();
        boolean boolean17 = fraction8.equals((java.lang.Object) fraction14);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction3 and fraction13", (fraction3.compareTo(fraction13) == 0) == fraction3.equals(fraction13));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test10");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        int int5 = fraction3.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int8 = fraction6.compareTo(fraction7);
        int int9 = fraction7.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.multiplyBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction14.subtract(fraction17);
        java.lang.String str19 = fraction14.toString();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction11.multiplyBy(fraction14);
        boolean boolean21 = fraction3.equals((java.lang.Object) fraction20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction11", (fraction0.compareTo(fraction11) == 0) == fraction0.equals(fraction11));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test11");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.subtract(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        int int9 = fraction6.compareTo(fraction8);
        int int10 = fraction6.intValue();
        java.lang.Class<?> wildcardClass11 = fraction6.getClass();
        boolean boolean12 = fraction4.equals((java.lang.Object) wildcardClass11);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.pow((int) (short) 10);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction4.divideBy(fraction15);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction5 and fraction13", (fraction5.compareTo(fraction13) == 0) == fraction5.equals(fraction13));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test12");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.negate();
        float float24 = fraction23.floatValue();
        java.lang.String str25 = fraction23.toProperString();
        short short26 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction20.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.getFraction(10.0d);
        boolean boolean30 = fraction27.equals((java.lang.Object) fraction29);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction12 and fraction20", (fraction12.compareTo(fraction20) == 0) == fraction12.equals(fraction20));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test13");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction9.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        boolean boolean16 = fraction9.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction11.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction8.multiplyBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction3.divideBy(fraction19);
        double double21 = fraction19.doubleValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction3 and fraction4", (fraction3.compareTo(fraction4) == 0) == fraction3.equals(fraction4));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test14");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.negate();
        float float24 = fraction23.floatValue();
        java.lang.String str25 = fraction23.toProperString();
        short short26 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction20.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long30 = fraction29.longValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.reduce();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction28.subtract(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int35 = fraction33.compareTo(fraction34);
        int int36 = fraction31.compareTo(fraction34);
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float38 = fraction37.floatValue();
        int int39 = fraction37.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction37.reduce();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction31.multiplyBy(fraction40);
        org.apache.commons.lang3.math.Fraction fraction42 = fraction20.divideBy(fraction31);
        org.apache.commons.lang3.math.Fraction fraction43 = fraction42.abs();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction12 and fraction20", (fraction12.compareTo(fraction20) == 0) == fraction12.equals(fraction20));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test15");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.subtract(fraction8);
        java.lang.String str10 = fraction5.toString();
        int int11 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int14 = fraction13.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long17 = fraction16.longValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.subtract(fraction18);
        boolean boolean20 = fraction13.equals((java.lang.Object) fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction12.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction5.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction0.multiplyBy(fraction15);
        int int24 = fraction0.getProperWhole();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction15 and fraction23", (fraction15.compareTo(fraction23) == 0) == fraction15.equals(fraction23));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test16");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction23 = fraction20.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction19.multiplyBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction24.abs();
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long27 = fraction26.longValue();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction26.negate();
        float float29 = fraction28.floatValue();
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction(0.5d);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction28.add(fraction31);
        int int33 = fraction25.compareTo(fraction32);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction12 and fraction31", (fraction12.compareTo(fraction31) == 0) == fraction12.equals(fraction31));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test17");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.subtract(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        int int9 = fraction6.compareTo(fraction8);
        int int10 = fraction6.intValue();
        java.lang.Class<?> wildcardClass11 = fraction6.getClass();
        boolean boolean12 = fraction4.equals((java.lang.Object) wildcardClass11);
        long long13 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int17 = fraction16.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long20 = fraction19.longValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.subtract(fraction21);
        boolean boolean23 = fraction16.equals((java.lang.Object) fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction15.subtract(fraction18);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int27 = fraction26.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long30 = fraction29.longValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.reduce();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction28.subtract(fraction31);
        boolean boolean33 = fraction26.equals((java.lang.Object) fraction28);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction25.subtract(fraction28);
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction37 = fraction35.pow((int) (short) 10);
        int int38 = fraction25.compareTo(fraction37);
        int int39 = fraction18.compareTo(fraction25);
        org.apache.commons.lang3.math.Fraction fraction40 = fraction25.negate();
        org.apache.commons.lang3.math.Fraction fraction44 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction46 = fraction44.subtract(fraction45);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction25.subtract(fraction46);
        org.apache.commons.lang3.math.Fraction fraction48 = fraction14.multiplyBy(fraction25);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction5 and fraction25", (fraction5.compareTo(fraction25) == 0) == fraction5.equals(fraction25));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test18");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.invert();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int9 = fraction8.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long12 = fraction11.longValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction10.subtract(fraction13);
        boolean boolean15 = fraction8.equals((java.lang.Object) fraction10);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction7.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction3.multiplyBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction17.multiplyBy(fraction22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction21", (fraction0.compareTo(fraction21) == 0) == fraction0.equals(fraction21));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test19");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        long long1 = fraction0.longValue();
        short short2 = fraction0.shortValue();
        java.lang.String str3 = fraction0.toProperString();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction8.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction0.subtract(fraction8);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction5", (fraction0.compareTo(fraction5) == 0) == fraction0.equals(fraction5));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test20");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long3 = fraction2.longValue();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.subtract(fraction4);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction10 = fraction5.add(fraction9);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction0.subtract(fraction9);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction17 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int19 = fraction16.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int22 = fraction21.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long25 = fraction24.longValue();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction24.reduce();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction23.subtract(fraction26);
        boolean boolean28 = fraction21.equals((java.lang.Object) fraction23);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction23.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction20.multiplyBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction15.divideBy(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int35 = fraction33.compareTo(fraction34);
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str37 = fraction36.toString();
        org.apache.commons.lang3.math.Fraction fraction38 = fraction33.multiplyBy(fraction36);
        java.lang.String str39 = fraction33.toProperString();
        int int40 = fraction33.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction15.subtract(fraction33);
        org.apache.commons.lang3.math.Fraction fraction42 = fraction9.subtract(fraction33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction15 and fraction16", (fraction15.compareTo(fraction16) == 0) == fraction15.equals(fraction16));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test21");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.subtract(fraction8);
        java.lang.String str10 = fraction5.toString();
        int int11 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int14 = fraction13.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long17 = fraction16.longValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.subtract(fraction18);
        boolean boolean20 = fraction13.equals((java.lang.Object) fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction12.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction5.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction0.multiplyBy(fraction15);
        int int24 = fraction0.getProperNumerator();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction15 and fraction23", (fraction15.compareTo(fraction23) == 0) == fraction15.equals(fraction23));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test22");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction9.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        boolean boolean16 = fraction9.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction11.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction8.multiplyBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction3.divideBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int23 = fraction21.compareTo(fraction22);
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str25 = fraction24.toString();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction21.multiplyBy(fraction24);
        java.lang.String str27 = fraction21.toProperString();
        int int28 = fraction21.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction3.subtract(fraction21);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction(0.5d);
        int int32 = fraction31.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction21.divideBy(fraction31);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction3 and fraction4", (fraction3.compareTo(fraction4) == 0) == fraction3.equals(fraction4));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test23");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.negate();
        float float24 = fraction23.floatValue();
        java.lang.String str25 = fraction23.toProperString();
        short short26 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction20.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long29 = fraction28.longValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction28.negate();
        float float31 = fraction30.floatValue();
        boolean boolean32 = fraction23.equals((java.lang.Object) float31);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction12 and fraction20", (fraction12.compareTo(fraction20) == 0) == fraction12.equals(fraction20));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test24");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.subtract(fraction8);
        java.lang.String str10 = fraction5.toString();
        int int11 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int14 = fraction13.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long17 = fraction16.longValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.subtract(fraction18);
        boolean boolean20 = fraction13.equals((java.lang.Object) fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction12.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction5.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction0.multiplyBy(fraction15);
        int int24 = fraction0.getNumerator();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction15 and fraction23", (fraction15.compareTo(fraction23) == 0) == fraction15.equals(fraction23));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test25");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction0.compareTo(fraction1);
        int int3 = fraction1.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long6 = fraction5.longValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction4.subtract(fraction7);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction9.compareTo(fraction10);
        int int12 = fraction7.compareTo(fraction10);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.negate();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.reduce();
        int int15 = fraction1.compareTo(fraction14);
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int18 = fraction17.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long21 = fraction20.longValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction19.subtract(fraction22);
        boolean boolean24 = fraction17.equals((java.lang.Object) fraction19);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction16.subtract(fraction19);
        double double26 = fraction19.doubleValue();
        int int27 = fraction19.intValue();
        java.lang.Class<?> wildcardClass28 = fraction19.getClass();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        long long30 = fraction29.longValue();
        short short31 = fraction29.shortValue();
        boolean boolean32 = fraction19.equals((java.lang.Object) short31);
        int int33 = fraction1.compareTo(fraction19);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction19 and fraction29", (fraction19.compareTo(fraction29) == 0) == fraction19.equals(fraction29));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test26");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction9.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        boolean boolean16 = fraction9.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction11.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction8.multiplyBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction3.divideBy(fraction19);
        int int21 = fraction20.intValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction3 and fraction4", (fraction3.compareTo(fraction4) == 0) == fraction3.equals(fraction4));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test27");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        boolean boolean8 = fraction1.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int12 = fraction11.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long15 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.subtract(fraction16);
        boolean boolean18 = fraction11.equals((java.lang.Object) fraction13);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction10.subtract(fraction13);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.pow((int) (short) 10);
        int int23 = fraction10.compareTo(fraction22);
        int int24 = fraction3.compareTo(fraction10);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction10.negate();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.subtract(fraction30);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction10.subtract(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long34 = fraction33.longValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction33.reduce();
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction37 = fraction33.divideBy(fraction36);
        int int38 = fraction36.intValue();
        int int39 = fraction36.intValue();
        int int40 = fraction36.intValue();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction36.invert();
        double double42 = fraction41.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction43 = fraction31.subtract(fraction41);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction29 and fraction36", (fraction29.compareTo(fraction36) == 0) == fraction29.equals(fraction36));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test28");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 0);
        short short2 = fraction1.shortValue();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int5 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.subtract(fraction9);
        boolean boolean11 = fraction4.equals((java.lang.Object) fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.pow((int) (short) 10);
        int int16 = fraction3.compareTo(fraction15);
        int int17 = fraction1.compareTo(fraction3);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction19 = fraction18.invert();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction3.divideBy(fraction18);
        int int21 = fraction3.getDenominator();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction6 and fraction18", (fraction6.compareTo(fraction18) == 0) == fraction6.equals(fraction18));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test29");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.invert();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int9 = fraction8.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long12 = fraction11.longValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction10.subtract(fraction13);
        boolean boolean15 = fraction8.equals((java.lang.Object) fraction10);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction7.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction3.multiplyBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long19 = fraction18.longValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction20.subtract(fraction23);
        java.lang.String str25 = fraction20.toString();
        int int26 = fraction20.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int29 = fraction28.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long32 = fraction31.longValue();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction31.reduce();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.subtract(fraction33);
        boolean boolean35 = fraction28.equals((java.lang.Object) fraction30);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction27.subtract(fraction30);
        org.apache.commons.lang3.math.Fraction fraction37 = fraction20.subtract(fraction30);
        org.apache.commons.lang3.math.Fraction fraction38 = fraction30.reduce();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long40 = fraction39.longValue();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction39.negate();
        float float42 = fraction41.floatValue();
        java.lang.String str43 = fraction41.toProperString();
        short short44 = fraction41.shortValue();
        org.apache.commons.lang3.math.Fraction fraction45 = fraction38.divideBy(fraction41);
        org.apache.commons.lang3.math.Fraction fraction46 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long48 = fraction47.longValue();
        org.apache.commons.lang3.math.Fraction fraction49 = fraction47.reduce();
        org.apache.commons.lang3.math.Fraction fraction50 = fraction46.subtract(fraction49);
        org.apache.commons.lang3.math.Fraction fraction51 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction52 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int53 = fraction51.compareTo(fraction52);
        int int54 = fraction49.compareTo(fraction52);
        org.apache.commons.lang3.math.Fraction fraction55 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float56 = fraction55.floatValue();
        int int57 = fraction55.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction58 = fraction55.reduce();
        org.apache.commons.lang3.math.Fraction fraction59 = fraction49.multiplyBy(fraction58);
        org.apache.commons.lang3.math.Fraction fraction60 = fraction38.divideBy(fraction49);
        org.apache.commons.lang3.math.Fraction fraction61 = fraction17.subtract(fraction60);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction10 and fraction38", (fraction10.compareTo(fraction38) == 0) == fraction10.equals(fraction38));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test30");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ZERO;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        int int5 = fraction4.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.divideBy(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long10 = fraction9.longValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        java.lang.String str16 = fraction11.toString();
        int int17 = fraction11.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int20 = fraction19.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long23 = fraction22.longValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction22.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction21.subtract(fraction24);
        boolean boolean26 = fraction19.equals((java.lang.Object) fraction21);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction18.subtract(fraction21);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction11.subtract(fraction21);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction21.reduce();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long31 = fraction30.longValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction30.negate();
        float float33 = fraction32.floatValue();
        java.lang.String str34 = fraction32.toProperString();
        short short35 = fraction32.shortValue();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction29.divideBy(fraction32);
        boolean boolean37 = fraction2.equals((java.lang.Object) fraction29);
        short short38 = fraction2.shortValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction21 and fraction29", (fraction21.compareTo(fraction29) == 0) == fraction21.equals(fraction29));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test31");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.invert();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.invert();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int15 = fraction14.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long18 = fraction17.longValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.reduce();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction16.subtract(fraction19);
        boolean boolean21 = fraction14.equals((java.lang.Object) fraction16);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction13.subtract(fraction16);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction9.multiplyBy(fraction13);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction5.subtract(fraction13);
        int int25 = fraction13.intValue();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction31 = fraction30.reduce();
        org.apache.commons.lang3.math.Fraction fraction32 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int33 = fraction30.compareTo(fraction32);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction32.reduce();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int36 = fraction35.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long39 = fraction38.longValue();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction38.reduce();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction37.subtract(fraction40);
        boolean boolean42 = fraction35.equals((java.lang.Object) fraction37);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction37.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction45 = fraction34.multiplyBy(fraction37);
        org.apache.commons.lang3.math.Fraction fraction46 = fraction29.divideBy(fraction45);
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction48 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int49 = fraction47.compareTo(fraction48);
        org.apache.commons.lang3.math.Fraction fraction50 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str51 = fraction50.toString();
        org.apache.commons.lang3.math.Fraction fraction52 = fraction47.multiplyBy(fraction50);
        java.lang.String str53 = fraction47.toProperString();
        int int54 = fraction47.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction55 = fraction29.subtract(fraction47);
        org.apache.commons.lang3.math.Fraction fraction56 = fraction13.subtract(fraction47);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction3 and fraction29", (fraction3.compareTo(fraction29) == 0) == fraction3.equals(fraction29));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test32");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        int int8 = fraction3.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float10 = fraction9.floatValue();
        int int11 = fraction9.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction3.multiplyBy(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int16 = fraction14.compareTo(fraction15);
        int int17 = fraction15.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction24 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int26 = fraction23.compareTo(fraction25);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.reduce();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int29 = fraction28.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long32 = fraction31.longValue();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction31.reduce();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.subtract(fraction33);
        boolean boolean35 = fraction28.equals((java.lang.Object) fraction30);
        org.apache.commons.lang3.math.Fraction fraction37 = fraction30.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction38 = fraction27.multiplyBy(fraction30);
        org.apache.commons.lang3.math.Fraction fraction39 = fraction22.divideBy(fraction38);
        org.apache.commons.lang3.math.Fraction fraction40 = fraction18.add(fraction22);
        org.apache.commons.lang3.math.Fraction fraction41 = fraction3.add(fraction22);
        double double42 = fraction3.doubleValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction22 and fraction23", (fraction22.compareTo(fraction23) == 0) == fraction22.equals(fraction23));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test33");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        int int4 = fraction2.getNumerator();
        java.lang.String str5 = fraction2.toString();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long10 = fraction9.longValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        java.lang.String str16 = fraction11.toString();
        int int17 = fraction11.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int20 = fraction19.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long23 = fraction22.longValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction22.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction21.subtract(fraction24);
        boolean boolean26 = fraction19.equals((java.lang.Object) fraction21);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction18.subtract(fraction21);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction11.subtract(fraction21);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction6.multiplyBy(fraction21);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction2.multiplyBy(fraction6);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction21 and fraction29", (fraction21.compareTo(fraction29) == 0) == fraction21.equals(fraction29));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test34");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        java.lang.Class<?> wildcardClass5 = fraction0.getClass();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.divideBy(fraction6);
        java.lang.Class<?> wildcardClass10 = fraction6.getClass();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction9", (fraction0.compareTo(fraction9) == 0) == fraction0.equals(fraction9));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test35");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int7 = fraction4.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction9.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        boolean boolean16 = fraction9.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction11.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction8.multiplyBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction3.divideBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int23 = fraction21.compareTo(fraction22);
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str25 = fraction24.toString();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction21.multiplyBy(fraction24);
        java.lang.String str27 = fraction21.toProperString();
        int int28 = fraction21.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction3.subtract(fraction21);
        java.lang.String str30 = fraction21.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction3 and fraction4", (fraction3.compareTo(fraction4) == 0) == fraction3.equals(fraction4));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test36");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        boolean boolean8 = fraction1.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int12 = fraction11.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long15 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.subtract(fraction16);
        boolean boolean18 = fraction11.equals((java.lang.Object) fraction13);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction10.subtract(fraction13);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.pow((int) (short) 10);
        int int23 = fraction10.compareTo(fraction22);
        int int24 = fraction3.compareTo(fraction10);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction10.negate();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.subtract(fraction30);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction10.subtract(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        double double34 = fraction33.doubleValue();
        java.lang.String str35 = fraction33.toProperString();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction32.add(fraction33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction31", (fraction0.compareTo(fraction31) == 0) == fraction0.equals(fraction31));
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test37");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.negate();
        float float24 = fraction23.floatValue();
        java.lang.String str25 = fraction23.toProperString();
        short short26 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction20.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long30 = fraction29.longValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.reduce();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction28.subtract(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int35 = fraction33.compareTo(fraction34);
        int int36 = fraction31.compareTo(fraction34);
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float38 = fraction37.floatValue();
        int int39 = fraction37.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction37.reduce();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction31.multiplyBy(fraction40);
        org.apache.commons.lang3.math.Fraction fraction42 = fraction20.divideBy(fraction31);
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction44 = fraction43.reduce();
        org.apache.commons.lang3.math.Fraction fraction45 = fraction43.reduce();
        int int46 = fraction45.getProperWhole();
        boolean boolean47 = fraction42.equals((java.lang.Object) fraction45);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction12 and fraction20", (fraction12.compareTo(fraction20) == 0) == fraction12.equals(fraction20));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test38");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int5 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.subtract(fraction9);
        boolean boolean11 = fraction4.equals((java.lang.Object) fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction6);
        int int13 = fraction12.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double18 = fraction17.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.abs();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction12.divideBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction12.pow((int) (byte) 0);
        int int23 = fraction0.compareTo(fraction22);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction29 = fraction28.reduce();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int31 = fraction28.compareTo(fraction30);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction30.reduce();
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int34 = fraction33.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long37 = fraction36.longValue();
        org.apache.commons.lang3.math.Fraction fraction38 = fraction36.reduce();
        org.apache.commons.lang3.math.Fraction fraction39 = fraction35.subtract(fraction38);
        boolean boolean40 = fraction33.equals((java.lang.Object) fraction35);
        org.apache.commons.lang3.math.Fraction fraction42 = fraction35.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction43 = fraction32.multiplyBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction27.divideBy(fraction43);
        org.apache.commons.lang3.math.Fraction fraction45 = fraction0.divideBy(fraction43);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction27", (fraction0.compareTo(fraction27) == 0) == fraction0.equals(fraction27));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test39");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction0.compareTo(fraction1);
        int int3 = fraction1.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int12 = fraction9.compareTo(fraction11);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int15 = fraction14.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long18 = fraction17.longValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.reduce();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction16.subtract(fraction19);
        boolean boolean21 = fraction14.equals((java.lang.Object) fraction16);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction16.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction13.multiplyBy(fraction16);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction8.divideBy(fraction24);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction4.add(fraction8);
        float float27 = fraction26.floatValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction8 and fraction9", (fraction8.compareTo(fraction9) == 0) == fraction8.equals(fraction9));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test40");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.negate();
        float float24 = fraction23.floatValue();
        java.lang.String str25 = fraction23.toProperString();
        short short26 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction20.divideBy(fraction23);
        java.lang.Object obj28 = null;
        boolean boolean29 = fraction20.equals(obj28);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction31 = fraction30.reduce();
        org.apache.commons.lang3.math.Fraction fraction32 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int33 = fraction30.compareTo(fraction32);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction32.reduce();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int36 = fraction35.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long39 = fraction38.longValue();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction38.reduce();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction37.subtract(fraction40);
        boolean boolean42 = fraction35.equals((java.lang.Object) fraction37);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction37.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction45 = fraction34.multiplyBy(fraction37);
        float float46 = fraction45.floatValue();
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction48 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long49 = fraction48.longValue();
        org.apache.commons.lang3.math.Fraction fraction50 = fraction48.reduce();
        org.apache.commons.lang3.math.Fraction fraction51 = fraction47.subtract(fraction50);
        org.apache.commons.lang3.math.Fraction fraction55 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction56 = fraction51.add(fraction55);
        org.apache.commons.lang3.math.Fraction fraction57 = fraction45.divideBy(fraction51);
        org.apache.commons.lang3.math.Fraction fraction58 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction59 = fraction58.reduce();
        org.apache.commons.lang3.math.Fraction fraction60 = fraction58.reduce();
        org.apache.commons.lang3.math.Fraction fraction61 = fraction58.negate();
        org.apache.commons.lang3.math.Fraction fraction62 = fraction61.invert();
        org.apache.commons.lang3.math.Fraction fraction65 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction66 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int67 = fraction66.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction68 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction69 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long70 = fraction69.longValue();
        org.apache.commons.lang3.math.Fraction fraction71 = fraction69.reduce();
        org.apache.commons.lang3.math.Fraction fraction72 = fraction68.subtract(fraction71);
        boolean boolean73 = fraction66.equals((java.lang.Object) fraction68);
        org.apache.commons.lang3.math.Fraction fraction74 = fraction65.subtract(fraction68);
        org.apache.commons.lang3.math.Fraction fraction75 = fraction61.multiplyBy(fraction65);
        org.apache.commons.lang3.math.Fraction fraction76 = fraction57.divideBy(fraction65);
        org.apache.commons.lang3.math.Fraction fraction77 = fraction20.subtract(fraction76);
        org.apache.commons.lang3.math.Fraction fraction78 = fraction76.negate();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction12 and fraction20", (fraction12.compareTo(fraction20) == 0) == fraction12.equals(fraction20));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test41");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        boolean boolean12 = fraction5.equals((java.lang.Object) fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction7.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction4.multiplyBy(fraction7);
        long long16 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int19 = fraction18.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.reduce();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction20.subtract(fraction23);
        boolean boolean25 = fraction18.equals((java.lang.Object) fraction20);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction17.subtract(fraction20);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int29 = fraction28.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long32 = fraction31.longValue();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction31.reduce();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.subtract(fraction33);
        boolean boolean35 = fraction28.equals((java.lang.Object) fraction30);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction27.subtract(fraction30);
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction39 = fraction37.pow((int) (short) 10);
        int int40 = fraction27.compareTo(fraction39);
        int int41 = fraction20.compareTo(fraction27);
        org.apache.commons.lang3.math.Fraction fraction42 = fraction27.negate();
        org.apache.commons.lang3.math.Fraction fraction46 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction48 = fraction46.subtract(fraction47);
        org.apache.commons.lang3.math.Fraction fraction49 = fraction27.subtract(fraction48);
        java.lang.Class<?> wildcardClass50 = fraction48.getClass();
        org.apache.commons.lang3.math.Fraction fraction51 = fraction7.add(fraction48);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction46", (fraction0.compareTo(fraction46) == 0) == fraction0.equals(fraction46));
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test42");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_THIRDS;
        int int1 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long3 = fraction2.longValue();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction4.subtract(fraction7);
        java.lang.String str9 = fraction4.toString();
        int int10 = fraction4.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int13 = fraction12.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long16 = fraction15.longValue();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction14.subtract(fraction17);
        boolean boolean19 = fraction12.equals((java.lang.Object) fraction14);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction11.subtract(fraction14);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction4.subtract(fraction14);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long24 = fraction23.longValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.negate();
        float float26 = fraction25.floatValue();
        java.lang.String str27 = fraction25.toProperString();
        short short28 = fraction25.shortValue();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction22.divideBy(fraction25);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long32 = fraction31.longValue();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction31.reduce();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.subtract(fraction33);
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int37 = fraction35.compareTo(fraction36);
        int int38 = fraction33.compareTo(fraction36);
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float40 = fraction39.floatValue();
        int int41 = fraction39.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction39.reduce();
        org.apache.commons.lang3.math.Fraction fraction43 = fraction33.multiplyBy(fraction42);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction22.divideBy(fraction33);
        org.apache.commons.lang3.math.Fraction fraction45 = fraction0.multiplyBy(fraction22);
        double double46 = fraction45.doubleValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction14 and fraction22", (fraction14.compareTo(fraction22) == 0) == fraction14.equals(fraction22));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test43");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        boolean boolean12 = fraction5.equals((java.lang.Object) fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction7.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction4.multiplyBy(fraction7);
        int int16 = fraction4.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction17.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int20 = fraction17.compareTo(fraction19);
        long long21 = fraction19.longValue();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int23 = fraction22.intValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction19.add(fraction22);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction4.subtract(fraction24);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction7 and fraction22", (fraction7.compareTo(fraction22) == 0) == fraction7.equals(fraction22));
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test44");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        long long20 = fraction2.longValue();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.negate();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.ZERO;
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        int int26 = fraction25.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.negate();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction24.divideBy(fraction27);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction23.subtract(fraction24);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long31 = fraction30.longValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction30.reduce();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction32.subtract(fraction35);
        java.lang.String str37 = fraction32.toString();
        int int38 = fraction32.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction40 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int41 = fraction40.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction42 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long44 = fraction43.longValue();
        org.apache.commons.lang3.math.Fraction fraction45 = fraction43.reduce();
        org.apache.commons.lang3.math.Fraction fraction46 = fraction42.subtract(fraction45);
        boolean boolean47 = fraction40.equals((java.lang.Object) fraction42);
        org.apache.commons.lang3.math.Fraction fraction48 = fraction39.subtract(fraction42);
        org.apache.commons.lang3.math.Fraction fraction49 = fraction32.subtract(fraction42);
        org.apache.commons.lang3.math.Fraction fraction50 = fraction42.reduce();
        org.apache.commons.lang3.math.Fraction fraction51 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long52 = fraction51.longValue();
        org.apache.commons.lang3.math.Fraction fraction53 = fraction51.negate();
        float float54 = fraction53.floatValue();
        java.lang.String str55 = fraction53.toProperString();
        short short56 = fraction53.shortValue();
        org.apache.commons.lang3.math.Fraction fraction57 = fraction50.divideBy(fraction53);
        boolean boolean58 = fraction23.equals((java.lang.Object) fraction50);
        org.apache.commons.lang3.math.Fraction fraction59 = fraction2.subtract(fraction23);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction12 and fraction50", (fraction12.compareTo(fraction50) == 0) == fraction12.equals(fraction50));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test45");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        java.lang.String str4 = fraction0.toString();
        float float5 = fraction0.floatValue();
        int int6 = fraction0.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.subtract(fraction12);
        java.lang.String str14 = fraction9.toString();
        int int15 = fraction9.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int18 = fraction17.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long21 = fraction20.longValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction19.subtract(fraction22);
        boolean boolean24 = fraction17.equals((java.lang.Object) fraction19);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction16.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction9.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction19.reduce();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long29 = fraction28.longValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction28.negate();
        float float31 = fraction30.floatValue();
        java.lang.String str32 = fraction30.toProperString();
        short short33 = fraction30.shortValue();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction27.divideBy(fraction30);
        java.lang.Object obj35 = null;
        boolean boolean36 = fraction27.equals(obj35);
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction38 = fraction37.reduce();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int40 = fraction37.compareTo(fraction39);
        org.apache.commons.lang3.math.Fraction fraction41 = fraction39.reduce();
        org.apache.commons.lang3.math.Fraction fraction42 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int43 = fraction42.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction44 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long46 = fraction45.longValue();
        org.apache.commons.lang3.math.Fraction fraction47 = fraction45.reduce();
        org.apache.commons.lang3.math.Fraction fraction48 = fraction44.subtract(fraction47);
        boolean boolean49 = fraction42.equals((java.lang.Object) fraction44);
        org.apache.commons.lang3.math.Fraction fraction51 = fraction44.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction52 = fraction41.multiplyBy(fraction44);
        float float53 = fraction52.floatValue();
        org.apache.commons.lang3.math.Fraction fraction54 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction55 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long56 = fraction55.longValue();
        org.apache.commons.lang3.math.Fraction fraction57 = fraction55.reduce();
        org.apache.commons.lang3.math.Fraction fraction58 = fraction54.subtract(fraction57);
        org.apache.commons.lang3.math.Fraction fraction62 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction63 = fraction58.add(fraction62);
        org.apache.commons.lang3.math.Fraction fraction64 = fraction52.divideBy(fraction58);
        org.apache.commons.lang3.math.Fraction fraction65 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction66 = fraction65.reduce();
        org.apache.commons.lang3.math.Fraction fraction67 = fraction65.reduce();
        org.apache.commons.lang3.math.Fraction fraction68 = fraction65.negate();
        org.apache.commons.lang3.math.Fraction fraction69 = fraction68.invert();
        org.apache.commons.lang3.math.Fraction fraction72 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction73 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int74 = fraction73.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction75 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction76 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long77 = fraction76.longValue();
        org.apache.commons.lang3.math.Fraction fraction78 = fraction76.reduce();
        org.apache.commons.lang3.math.Fraction fraction79 = fraction75.subtract(fraction78);
        boolean boolean80 = fraction73.equals((java.lang.Object) fraction75);
        org.apache.commons.lang3.math.Fraction fraction81 = fraction72.subtract(fraction75);
        org.apache.commons.lang3.math.Fraction fraction82 = fraction68.multiplyBy(fraction72);
        org.apache.commons.lang3.math.Fraction fraction83 = fraction64.divideBy(fraction72);
        org.apache.commons.lang3.math.Fraction fraction84 = fraction27.subtract(fraction83);
        org.apache.commons.lang3.math.Fraction fraction85 = fraction0.multiplyBy(fraction84);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction19 and fraction27", (fraction19.compareTo(fraction27) == 0) == fraction19.equals(fraction27));
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test46");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 0);
        short short2 = fraction1.shortValue();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int5 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.subtract(fraction9);
        boolean boolean11 = fraction4.equals((java.lang.Object) fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.pow((int) (short) 10);
        int int16 = fraction3.compareTo(fraction15);
        int int17 = fraction1.compareTo(fraction3);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction19 = fraction18.invert();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction3.divideBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction3.invert();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction6 and fraction18", (fraction6.compareTo(fraction18) == 0) == fraction6.equals(fraction18));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test47");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.invert();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.invert();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int15 = fraction14.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long18 = fraction17.longValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.reduce();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction16.subtract(fraction19);
        boolean boolean21 = fraction14.equals((java.lang.Object) fraction16);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction13.subtract(fraction16);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction9.multiplyBy(fraction13);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction5.subtract(fraction13);
        int int25 = fraction13.intValue();
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int28 = fraction26.compareTo(fraction27);
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str30 = fraction29.toString();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction26.multiplyBy(fraction29);
        org.apache.commons.lang3.math.Fraction fraction32 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long34 = fraction33.longValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction33.reduce();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction32.subtract(fraction35);
        java.lang.Class<?> wildcardClass37 = fraction32.getClass();
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction39 = fraction38.reduce();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction38.reduce();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction32.divideBy(fraction38);
        boolean boolean42 = fraction26.equals((java.lang.Object) fraction32);
        org.apache.commons.lang3.math.Fraction fraction43 = fraction13.multiplyBy(fraction26);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction16 and fraction41", (fraction16.compareTo(fraction41) == 0) == fraction16.equals(fraction41));
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test48");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        int int4 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        byte byte6 = fraction5.byteValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.divideBy(fraction10);
        int int12 = fraction10.intValue();
        int int13 = fraction10.intValue();
        int int14 = fraction10.intValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.invert();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int20 = fraction19.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long23 = fraction22.longValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction22.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction21.subtract(fraction24);
        boolean boolean26 = fraction19.equals((java.lang.Object) fraction21);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction18.subtract(fraction21);
        int int28 = fraction27.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction10.multiplyBy(fraction27);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction5.add(fraction29);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction30.reduce();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction27 and fraction29", (fraction27.compareTo(fraction29) == 0) == fraction27.equals(fraction29));
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test49");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        int int8 = fraction3.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.subtract(fraction14);
        int int16 = fraction14.getNumerator();
        int int17 = fraction3.compareTo(fraction14);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction18.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int23 = fraction20.compareTo(fraction22);
        java.lang.String str24 = fraction20.toString();
        float float25 = fraction20.floatValue();
        int int26 = fraction20.getDenominator();
        java.lang.String str27 = fraction20.toProperString();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction18.divideBy(fraction20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction13 and fraction20", (fraction13.compareTo(fraction20) == 0) == fraction13.equals(fraction20));
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test50");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        java.lang.Class<?> wildcardClass5 = fraction0.getClass();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.divideBy(fraction6);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction(100.0d);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction13 = fraction12.reduce();
        int int14 = fraction11.compareTo(fraction13);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int18 = fraction15.compareTo(fraction17);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.reduce();
        float float20 = fraction17.floatValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.invert();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction17.negate();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction13.subtract(fraction17);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction9.add(fraction13);
        java.lang.String str25 = fraction13.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction9", (fraction0.compareTo(fraction9) == 0) == fraction0.equals(fraction9));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test51");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double4 = fraction3.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long6 = fraction5.longValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        int int8 = fraction5.compareTo(fraction7);
        int int9 = fraction5.intValue();
        java.lang.String str10 = fraction5.toProperString();
        int int11 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction5);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long15 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction16.subtract(fraction19);
        java.lang.String str21 = fraction16.toString();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction13.multiplyBy(fraction16);
        float float23 = fraction16.floatValue();
        boolean boolean24 = fraction5.equals((java.lang.Object) fraction16);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getFraction(10.0d);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long29 = fraction28.longValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction28.reduce();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction27.subtract(fraction30);
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction36 = fraction31.add(fraction35);
        org.apache.commons.lang3.math.Fraction fraction38 = fraction35.pow(4);
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long40 = fraction39.longValue();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction39.invert();
        int int42 = fraction38.compareTo(fraction39);
        org.apache.commons.lang3.math.Fraction fraction43 = fraction26.multiplyBy(fraction39);
        org.apache.commons.lang3.math.Fraction fraction44 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction45 = fraction44.reduce();
        org.apache.commons.lang3.math.Fraction fraction46 = fraction44.reduce();
        org.apache.commons.lang3.math.Fraction fraction47 = fraction44.negate();
        org.apache.commons.lang3.math.Fraction fraction48 = fraction44.negate();
        org.apache.commons.lang3.math.Fraction fraction49 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction50 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction51 = fraction50.reduce();
        org.apache.commons.lang3.math.Fraction fraction52 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction53 = fraction50.subtract(fraction52);
        org.apache.commons.lang3.math.Fraction fraction54 = fraction50.invert();
        org.apache.commons.lang3.math.Fraction fraction55 = fraction49.subtract(fraction54);
        org.apache.commons.lang3.math.Fraction fraction56 = fraction49.abs();
        org.apache.commons.lang3.math.Fraction fraction57 = fraction44.multiplyBy(fraction56);
        int int58 = fraction43.compareTo(fraction44);
        org.apache.commons.lang3.math.Fraction fraction59 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction60 = fraction59.reduce();
        org.apache.commons.lang3.math.Fraction fraction61 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int62 = fraction59.compareTo(fraction61);
        org.apache.commons.lang3.math.Fraction fraction63 = fraction61.reduce();
        org.apache.commons.lang3.math.Fraction fraction64 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int65 = fraction64.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction66 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction67 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long68 = fraction67.longValue();
        org.apache.commons.lang3.math.Fraction fraction69 = fraction67.reduce();
        org.apache.commons.lang3.math.Fraction fraction70 = fraction66.subtract(fraction69);
        boolean boolean71 = fraction64.equals((java.lang.Object) fraction66);
        org.apache.commons.lang3.math.Fraction fraction73 = fraction66.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction74 = fraction63.multiplyBy(fraction66);
        boolean boolean75 = fraction44.equals((java.lang.Object) fraction66);
        org.apache.commons.lang3.math.Fraction fraction76 = fraction16.divideBy(fraction44);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction13 and fraction27", (fraction13.compareTo(fraction27) == 0) == fraction13.equals(fraction27));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test52");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(3, (int) 'a');
        int int3 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction4.compareTo(fraction5);
        int int7 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int10 = fraction9.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long13 = fraction12.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.subtract(fraction14);
        boolean boolean16 = fraction9.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction8.subtract(fraction11);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int20 = fraction19.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long23 = fraction22.longValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction22.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction21.subtract(fraction24);
        boolean boolean26 = fraction19.equals((java.lang.Object) fraction21);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction18.subtract(fraction21);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction30 = fraction28.pow((int) (short) 10);
        int int31 = fraction18.compareTo(fraction30);
        int int32 = fraction11.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        long long34 = fraction33.longValue();
        short short35 = fraction33.shortValue();
        java.lang.String str36 = fraction33.toProperString();
        int int37 = fraction11.compareTo(fraction33);
        boolean boolean38 = fraction2.equals((java.lang.Object) int37);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction11 and fraction33", (fraction11.compareTo(fraction33) == 0) == fraction11.equals(fraction33));
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test53");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction0.compareTo(fraction1);
        int int3 = fraction1.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int12 = fraction9.compareTo(fraction11);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int15 = fraction14.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long18 = fraction17.longValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.reduce();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction16.subtract(fraction19);
        boolean boolean21 = fraction14.equals((java.lang.Object) fraction16);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction16.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction13.multiplyBy(fraction16);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction8.divideBy(fraction24);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction4.add(fraction8);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction28 = fraction27.reduce();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int30 = fraction27.compareTo(fraction29);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.reduce();
        float float32 = fraction29.floatValue();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction29.invert();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction29.negate();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long36 = fraction35.longValue();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction35.negate();
        org.apache.commons.lang3.math.Fraction fraction38 = fraction35.reduce();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction40 = fraction39.reduce();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction39.reduce();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction39.negate();
        org.apache.commons.lang3.math.Fraction fraction43 = fraction42.invert();
        org.apache.commons.lang3.math.Fraction fraction44 = fraction35.subtract(fraction42);
        boolean boolean45 = fraction29.equals((java.lang.Object) fraction44);
        org.apache.commons.lang3.math.Fraction fraction46 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long48 = fraction47.longValue();
        org.apache.commons.lang3.math.Fraction fraction49 = fraction47.reduce();
        org.apache.commons.lang3.math.Fraction fraction50 = fraction46.subtract(fraction49);
        org.apache.commons.lang3.math.Fraction fraction54 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction55 = fraction50.add(fraction54);
        org.apache.commons.lang3.math.Fraction fraction57 = fraction54.pow(4);
        org.apache.commons.lang3.math.Fraction fraction58 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long59 = fraction58.longValue();
        org.apache.commons.lang3.math.Fraction fraction60 = fraction58.invert();
        int int61 = fraction57.compareTo(fraction58);
        java.lang.String str62 = fraction57.toString();
        org.apache.commons.lang3.math.Fraction fraction63 = fraction44.divideBy(fraction57);
        int int64 = fraction26.compareTo(fraction57);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction8 and fraction9", (fraction8.compareTo(fraction9) == 0) == fraction8.equals(fraction9));
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test54");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.subtract(fraction2);
        int int4 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        byte byte6 = fraction5.byteValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.divideBy(fraction10);
        int int12 = fraction10.intValue();
        int int13 = fraction10.intValue();
        int int14 = fraction10.intValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.invert();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int20 = fraction19.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long23 = fraction22.longValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction22.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction21.subtract(fraction24);
        boolean boolean26 = fraction19.equals((java.lang.Object) fraction21);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction18.subtract(fraction21);
        int int28 = fraction27.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction10.multiplyBy(fraction27);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction5.add(fraction29);
        java.lang.String str31 = fraction5.toProperString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction27 and fraction29", (fraction27.compareTo(fraction29) == 0) == fraction27.equals(fraction29));
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test55");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.subtract(fraction8);
        java.lang.String str10 = fraction5.toString();
        int int11 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int14 = fraction13.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long17 = fraction16.longValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.subtract(fraction18);
        boolean boolean20 = fraction13.equals((java.lang.Object) fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction12.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction5.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction0.multiplyBy(fraction15);
        java.lang.String str24 = fraction0.toProperString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction15 and fraction23", (fraction15.compareTo(fraction23) == 0) == fraction15.equals(fraction23));
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test56");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_THIRDS;
        int int1 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long3 = fraction2.longValue();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction4.subtract(fraction7);
        java.lang.String str9 = fraction4.toString();
        int int10 = fraction4.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int13 = fraction12.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long16 = fraction15.longValue();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction14.subtract(fraction17);
        boolean boolean19 = fraction12.equals((java.lang.Object) fraction14);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction11.subtract(fraction14);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction4.subtract(fraction14);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long24 = fraction23.longValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.negate();
        float float26 = fraction25.floatValue();
        java.lang.String str27 = fraction25.toProperString();
        short short28 = fraction25.shortValue();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction22.divideBy(fraction25);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long32 = fraction31.longValue();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction31.reduce();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.subtract(fraction33);
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int37 = fraction35.compareTo(fraction36);
        int int38 = fraction33.compareTo(fraction36);
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float40 = fraction39.floatValue();
        int int41 = fraction39.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction39.reduce();
        org.apache.commons.lang3.math.Fraction fraction43 = fraction33.multiplyBy(fraction42);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction22.divideBy(fraction33);
        org.apache.commons.lang3.math.Fraction fraction45 = fraction0.multiplyBy(fraction22);
        org.apache.commons.lang3.math.Fraction fraction46 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long47 = fraction46.longValue();
        org.apache.commons.lang3.math.Fraction fraction48 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        int int49 = fraction46.compareTo(fraction48);
        java.lang.String str50 = fraction46.toProperString();
        org.apache.commons.lang3.math.Fraction fraction54 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction58 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction59 = fraction54.multiplyBy(fraction58);
        org.apache.commons.lang3.math.Fraction fraction60 = fraction54.reduce();
        org.apache.commons.lang3.math.Fraction fraction61 = fraction46.subtract(fraction60);
        short short62 = fraction60.shortValue();
        org.apache.commons.lang3.math.Fraction fraction63 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction64 = fraction63.reduce();
        org.apache.commons.lang3.math.Fraction fraction65 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int66 = fraction63.compareTo(fraction65);
        java.lang.String str67 = fraction63.toString();
        float float68 = fraction63.floatValue();
        int int69 = fraction63.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction70 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction71 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long72 = fraction71.longValue();
        org.apache.commons.lang3.math.Fraction fraction73 = fraction71.reduce();
        org.apache.commons.lang3.math.Fraction fraction74 = fraction70.subtract(fraction73);
        org.apache.commons.lang3.math.Fraction fraction78 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction79 = fraction74.add(fraction78);
        org.apache.commons.lang3.math.Fraction fraction80 = fraction63.add(fraction74);
        int int81 = fraction60.compareTo(fraction63);
        int int82 = fraction0.compareTo(fraction63);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction14 and fraction22", (fraction14.compareTo(fraction22) == 0) == fraction14.equals(fraction22));
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test57");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.subtract(fraction8);
        java.lang.String str10 = fraction5.toString();
        int int11 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int14 = fraction13.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long17 = fraction16.longValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.subtract(fraction18);
        boolean boolean20 = fraction13.equals((java.lang.Object) fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction12.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction5.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction0.multiplyBy(fraction15);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction23.negate();
        double double25 = fraction24.doubleValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction15 and fraction23", (fraction15.compareTo(fraction23) == 0) == fraction15.equals(fraction23));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test58");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.subtract(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        int int9 = fraction6.compareTo(fraction8);
        int int10 = fraction6.intValue();
        java.lang.Class<?> wildcardClass11 = fraction6.getClass();
        boolean boolean12 = fraction4.equals((java.lang.Object) wildcardClass11);
        long long13 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int16 = fraction15.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long19 = fraction18.longValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.subtract(fraction20);
        boolean boolean22 = fraction15.equals((java.lang.Object) fraction17);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction14.subtract(fraction17);
        int int24 = fraction4.compareTo(fraction14);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getReducedFraction(3, (int) (short) 11);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long29 = fraction28.longValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction28.reduce();
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.subtract(fraction33);
        java.lang.String str35 = fraction30.toString();
        int int36 = fraction30.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int39 = fraction38.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction40 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction41 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long42 = fraction41.longValue();
        org.apache.commons.lang3.math.Fraction fraction43 = fraction41.reduce();
        org.apache.commons.lang3.math.Fraction fraction44 = fraction40.subtract(fraction43);
        boolean boolean45 = fraction38.equals((java.lang.Object) fraction40);
        org.apache.commons.lang3.math.Fraction fraction46 = fraction37.subtract(fraction40);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction30.subtract(fraction40);
        org.apache.commons.lang3.math.Fraction fraction48 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction49 = fraction48.reduce();
        org.apache.commons.lang3.math.Fraction fraction50 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction51 = fraction48.subtract(fraction50);
        org.apache.commons.lang3.math.Fraction fraction52 = fraction47.multiplyBy(fraction51);
        int int53 = fraction47.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction54 = org.apache.commons.lang3.math.Fraction.ONE_QUARTER;
        java.lang.String str55 = fraction54.toString();
        org.apache.commons.lang3.math.Fraction fraction56 = fraction47.multiplyBy(fraction54);
        org.apache.commons.lang3.math.Fraction fraction57 = fraction56.abs();
        org.apache.commons.lang3.math.Fraction fraction58 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction59 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction60 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long61 = fraction60.longValue();
        org.apache.commons.lang3.math.Fraction fraction62 = fraction60.reduce();
        org.apache.commons.lang3.math.Fraction fraction63 = fraction59.subtract(fraction62);
        org.apache.commons.lang3.math.Fraction fraction67 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction68 = fraction63.add(fraction67);
        org.apache.commons.lang3.math.Fraction fraction69 = fraction58.subtract(fraction67);
        org.apache.commons.lang3.math.Fraction fraction70 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float71 = fraction70.floatValue();
        org.apache.commons.lang3.math.Fraction fraction72 = fraction67.subtract(fraction70);
        org.apache.commons.lang3.math.Fraction fraction73 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        int int74 = fraction73.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction75 = fraction73.negate();
        org.apache.commons.lang3.math.Fraction fraction76 = fraction67.multiplyBy(fraction75);
        org.apache.commons.lang3.math.Fraction fraction77 = fraction57.subtract(fraction67);
        org.apache.commons.lang3.math.Fraction fraction78 = fraction27.divideBy(fraction77);
        org.apache.commons.lang3.math.Fraction fraction79 = fraction14.subtract(fraction27);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction3 and fraction48", (fraction3.compareTo(fraction48) == 0) == fraction3.equals(fraction48));
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test59");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 0);
        short short2 = fraction1.shortValue();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int5 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.subtract(fraction9);
        boolean boolean11 = fraction4.equals((java.lang.Object) fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.pow((int) (short) 10);
        int int16 = fraction3.compareTo(fraction15);
        int int17 = fraction1.compareTo(fraction3);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction19 = fraction18.invert();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction3.divideBy(fraction18);
        int int21 = fraction20.getNumerator();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction6 and fraction18", (fraction6.compareTo(fraction18) == 0) == fraction6.equals(fraction18));
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test60");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        boolean boolean8 = fraction1.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.pow((int) (short) 10);
        int int13 = fraction0.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.subtract(fraction18);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction0.multiplyBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction22 = fraction21.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction24 = fraction21.subtract(fraction23);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction21.invert();
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction28 = fraction27.reduce();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction30 = fraction27.subtract(fraction29);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction27.invert();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction26.subtract(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction21.multiplyBy(fraction26);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction33.abs();
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.getReducedFraction(10, 4);
        double double38 = fraction37.doubleValue();
        java.lang.Class<?> wildcardClass39 = fraction37.getClass();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction34.add(fraction37);
        int int41 = fraction19.compareTo(fraction40);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction17 and fraction21", (fraction17.compareTo(fraction21) == 0) == fraction17.equals(fraction21));
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test61");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int3 = fraction0.compareTo(fraction2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction5.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        boolean boolean12 = fraction5.equals((java.lang.Object) fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction7.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction4.multiplyBy(fraction7);
        float float16 = fraction15.floatValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long19 = fraction18.longValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.subtract(fraction20);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction26 = fraction21.add(fraction25);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction15.divideBy(fraction21);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction29 = fraction28.reduce();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction28.reduce();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction28.negate();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction31.invert();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int37 = fraction36.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long40 = fraction39.longValue();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction39.reduce();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction38.subtract(fraction41);
        boolean boolean43 = fraction36.equals((java.lang.Object) fraction38);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction35.subtract(fraction38);
        org.apache.commons.lang3.math.Fraction fraction45 = fraction31.multiplyBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction46 = fraction27.divideBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction48 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long49 = fraction48.longValue();
        org.apache.commons.lang3.math.Fraction fraction50 = fraction48.reduce();
        org.apache.commons.lang3.math.Fraction fraction53 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction54 = fraction50.subtract(fraction53);
        java.lang.String str55 = fraction50.toString();
        org.apache.commons.lang3.math.Fraction fraction56 = fraction47.multiplyBy(fraction50);
        java.lang.String str57 = fraction47.toString();
        boolean boolean58 = fraction27.equals((java.lang.Object) str57);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction7 and fraction47", (fraction7.compareTo(fraction47) == 0) == fraction7.equals(fraction47));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test62");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        int int20 = fraction19.intValue();
        boolean boolean22 = fraction19.equals((java.lang.Object) 10.01d);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long25 = fraction24.longValue();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction24.reduce();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction23.subtract(fraction26);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int30 = fraction28.compareTo(fraction29);
        int int31 = fraction26.compareTo(fraction29);
        org.apache.commons.lang3.math.Fraction fraction32 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float33 = fraction32.floatValue();
        int int34 = fraction32.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction32.reduce();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction26.multiplyBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int39 = fraction37.compareTo(fraction38);
        int int40 = fraction38.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction38.reduce();
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction46 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction47 = fraction46.reduce();
        org.apache.commons.lang3.math.Fraction fraction48 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int49 = fraction46.compareTo(fraction48);
        org.apache.commons.lang3.math.Fraction fraction50 = fraction48.reduce();
        org.apache.commons.lang3.math.Fraction fraction51 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int52 = fraction51.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction53 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction54 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long55 = fraction54.longValue();
        org.apache.commons.lang3.math.Fraction fraction56 = fraction54.reduce();
        org.apache.commons.lang3.math.Fraction fraction57 = fraction53.subtract(fraction56);
        boolean boolean58 = fraction51.equals((java.lang.Object) fraction53);
        org.apache.commons.lang3.math.Fraction fraction60 = fraction53.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction61 = fraction50.multiplyBy(fraction53);
        org.apache.commons.lang3.math.Fraction fraction62 = fraction45.divideBy(fraction61);
        org.apache.commons.lang3.math.Fraction fraction63 = fraction41.add(fraction45);
        org.apache.commons.lang3.math.Fraction fraction64 = fraction26.add(fraction45);
        org.apache.commons.lang3.math.Fraction fraction66 = fraction45.pow((int) (short) -11);
        boolean boolean67 = fraction19.equals((java.lang.Object) (short) -11);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction45 and fraction46", (fraction45.compareTo(fraction46) == 0) == fraction45.equals(fraction46));
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test63");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_THIRDS;
        int int1 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long3 = fraction2.longValue();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction4.subtract(fraction7);
        java.lang.String str9 = fraction4.toString();
        int int10 = fraction4.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int13 = fraction12.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long16 = fraction15.longValue();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction14.subtract(fraction17);
        boolean boolean19 = fraction12.equals((java.lang.Object) fraction14);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction11.subtract(fraction14);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction4.subtract(fraction14);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long24 = fraction23.longValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.negate();
        float float26 = fraction25.floatValue();
        java.lang.String str27 = fraction25.toProperString();
        short short28 = fraction25.shortValue();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction22.divideBy(fraction25);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long32 = fraction31.longValue();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction31.reduce();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.subtract(fraction33);
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int37 = fraction35.compareTo(fraction36);
        int int38 = fraction33.compareTo(fraction36);
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float40 = fraction39.floatValue();
        int int41 = fraction39.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction39.reduce();
        org.apache.commons.lang3.math.Fraction fraction43 = fraction33.multiplyBy(fraction42);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction22.divideBy(fraction33);
        org.apache.commons.lang3.math.Fraction fraction45 = fraction0.multiplyBy(fraction22);
        int int46 = fraction0.getNumerator();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction14 and fraction22", (fraction14.compareTo(fraction22) == 0) == fraction14.equals(fraction22));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test64");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        int int8 = fraction3.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.subtract(fraction14);
        int int16 = fraction14.getNumerator();
        int int17 = fraction3.compareTo(fraction14);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction19 = fraction18.reduce();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.reduce();
        int int21 = fraction20.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int25 = fraction23.compareTo(fraction24);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str27 = fraction26.toString();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction23.multiplyBy(fraction26);
        java.lang.String str29 = fraction23.toProperString();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction22.multiplyBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction20.add(fraction23);
        int int32 = fraction20.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction14.multiplyBy(fraction20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction13 and fraction20", (fraction13.compareTo(fraction20) == 0) == fraction13.equals(fraction20));
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test65");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long5 = fraction4.longValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.subtract(fraction6);
        boolean boolean8 = fraction1.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int12 = fraction11.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long15 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.subtract(fraction16);
        boolean boolean18 = fraction11.equals((java.lang.Object) fraction13);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction10.subtract(fraction13);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.pow((int) (short) 10);
        int int23 = fraction10.compareTo(fraction22);
        int int24 = fraction3.compareTo(fraction10);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        long long26 = fraction25.longValue();
        short short27 = fraction25.shortValue();
        java.lang.String str28 = fraction25.toProperString();
        int int29 = fraction3.compareTo(fraction25);
        int int30 = fraction3.getProperWhole();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction3 and fraction25", (fraction3.compareTo(fraction25) == 0) == fraction3.equals(fraction25));
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test66");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        java.lang.Class<?> wildcardClass5 = fraction0.getClass();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.divideBy(fraction6);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction(100.0d);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction13 = fraction12.reduce();
        int int14 = fraction11.compareTo(fraction13);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int18 = fraction15.compareTo(fraction17);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.reduce();
        float float20 = fraction17.floatValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.invert();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction17.negate();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction13.subtract(fraction17);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction9.add(fraction13);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        int int26 = fraction25.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.negate();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction27.pow(10);
        boolean boolean30 = fraction24.equals((java.lang.Object) fraction29);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction9", (fraction0.compareTo(fraction9) == 0) == fraction0.equals(fraction9));
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test67");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        float float3 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction(0.5d);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.add(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction16 = fraction11.add(fraction15);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.pow(4);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long20 = fraction19.longValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.invert();
        int int22 = fraction18.compareTo(fraction19);
        java.lang.String str23 = fraction18.toString();
        int int24 = fraction2.compareTo(fraction18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction5 and fraction7", (fraction5.compareTo(fraction7) == 0) == fraction5.equals(fraction7));
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test68");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int2 = fraction0.compareTo(fraction1);
        int int3 = fraction1.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int12 = fraction9.compareTo(fraction11);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int15 = fraction14.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long18 = fraction17.longValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.reduce();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction16.subtract(fraction19);
        boolean boolean21 = fraction14.equals((java.lang.Object) fraction16);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction16.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction13.multiplyBy(fraction16);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction8.divideBy(fraction24);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction4.add(fraction8);
        java.lang.String str27 = fraction4.toProperString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction8 and fraction9", (fraction8.compareTo(fraction9) == 0) == fraction8.equals(fraction9));
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test69");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        int int5 = fraction3.intValue();
        int int6 = fraction3.intValue();
        int int7 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long9 = fraction8.longValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction10.subtract(fraction13);
        java.lang.String str15 = fraction10.toString();
        int int16 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int19 = fraction18.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.reduce();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction20.subtract(fraction23);
        boolean boolean25 = fraction18.equals((java.lang.Object) fraction20);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction17.subtract(fraction20);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction10.subtract(fraction20);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long30 = fraction29.longValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.negate();
        float float32 = fraction31.floatValue();
        java.lang.String str33 = fraction31.toProperString();
        short short34 = fraction31.shortValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction28.divideBy(fraction31);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction3.multiplyBy(fraction35);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction20 and fraction28", (fraction20.compareTo(fraction28) == 0) == fraction20.equals(fraction28));
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test70");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.subtract(fraction5);
        java.lang.String str7 = fraction2.toString();
        int int8 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int11 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long14 = fraction13.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.subtract(fraction15);
        boolean boolean17 = fraction10.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.subtract(fraction12);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.negate();
        float float24 = fraction23.floatValue();
        java.lang.String str25 = fraction23.toProperString();
        short short26 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction20.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long30 = fraction29.longValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.reduce();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction28.subtract(fraction31);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int35 = fraction33.compareTo(fraction34);
        int int36 = fraction31.compareTo(fraction34);
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float38 = fraction37.floatValue();
        int int39 = fraction37.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction37.reduce();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction31.multiplyBy(fraction40);
        org.apache.commons.lang3.math.Fraction fraction42 = fraction20.divideBy(fraction31);
        org.apache.commons.lang3.math.Fraction fraction43 = fraction20.invert();
        org.apache.commons.lang3.math.Fraction fraction44 = fraction43.invert();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction12 and fraction20", (fraction12.compareTo(fraction20) == 0) == fraction12.equals(fraction20));
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test71");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 0);
        short short2 = fraction1.shortValue();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int5 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long8 = fraction7.longValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.subtract(fraction9);
        boolean boolean11 = fraction4.equals((java.lang.Object) fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.pow((int) (short) 10);
        int int16 = fraction3.compareTo(fraction15);
        int int17 = fraction1.compareTo(fraction3);
        short short18 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long21 = fraction20.longValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.reduce();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction19.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction28 = fraction23.add(fraction27);
        int int29 = fraction23.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction3.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction32 = fraction31.reduce();
        short short33 = fraction32.shortValue();
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction35 = fraction34.reduce();
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int37 = fraction34.compareTo(fraction36);
        long long38 = fraction36.longValue();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int40 = fraction39.intValue();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction36.add(fraction39);
        org.apache.commons.lang3.math.Fraction fraction42 = fraction32.subtract(fraction39);
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction44 = fraction43.reduce();
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction46 = fraction43.subtract(fraction45);
        int int47 = fraction46.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction48 = fraction46.negate();
        org.apache.commons.lang3.math.Fraction fraction49 = fraction48.negate();
        int int50 = fraction48.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction51 = fraction42.multiplyBy(fraction48);
        org.apache.commons.lang3.math.Fraction fraction52 = fraction23.add(fraction48);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction6 and fraction39", (fraction6.compareTo(fraction39) == 0) == fraction6.equals(fraction39));
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test72");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int9 = fraction6.compareTo(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int12 = fraction11.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long15 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.subtract(fraction16);
        boolean boolean18 = fraction11.equals((java.lang.Object) fraction13);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction13.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction10.multiplyBy(fraction13);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction5.divideBy(fraction21);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int25 = fraction23.compareTo(fraction24);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        java.lang.String str27 = fraction26.toString();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction23.multiplyBy(fraction26);
        java.lang.String str29 = fraction23.toProperString();
        int int30 = fraction23.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction5.subtract(fraction23);
        int int32 = fraction5.getProperNumerator();
        boolean boolean33 = fraction1.equals((java.lang.Object) fraction5);
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getFraction("10 1/100");
        java.lang.String str36 = fraction35.toProperString();
        int int37 = fraction1.compareTo(fraction35);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction5 and fraction6", (fraction5.compareTo(fraction6) == 0) == fraction5.equals(fraction6));
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test73");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.reduce();
        java.lang.String str4 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int8 = fraction5.compareTo(fraction7);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.reduce();
        float float10 = fraction7.floatValue();
        byte byte11 = fraction7.byteValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.divideBy(fraction7);
        java.lang.String str13 = fraction3.toProperString();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction3.abs();
        double double15 = fraction14.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 0);
        short short18 = fraction17.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int21 = fraction20.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long24 = fraction23.longValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction22.subtract(fraction25);
        boolean boolean27 = fraction20.equals((java.lang.Object) fraction22);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction19.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.pow((int) (short) 10);
        int int32 = fraction19.compareTo(fraction31);
        int int33 = fraction17.compareTo(fraction19);
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction35 = fraction34.invert();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction19.divideBy(fraction34);
        int int37 = fraction14.compareTo(fraction36);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction22 and fraction34", (fraction22.compareTo(fraction34) == 0) == fraction22.equals(fraction34));
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test74");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int7 = fraction5.compareTo(fraction6);
        int int8 = fraction3.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        float float10 = fraction9.floatValue();
        int int11 = fraction9.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.reduce();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction3.multiplyBy(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int16 = fraction14.compareTo(fraction15);
        int int17 = fraction15.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction24 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int26 = fraction23.compareTo(fraction25);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.reduce();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int29 = fraction28.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long32 = fraction31.longValue();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction31.reduce();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.subtract(fraction33);
        boolean boolean35 = fraction28.equals((java.lang.Object) fraction30);
        org.apache.commons.lang3.math.Fraction fraction37 = fraction30.pow((int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction38 = fraction27.multiplyBy(fraction30);
        org.apache.commons.lang3.math.Fraction fraction39 = fraction22.divideBy(fraction38);
        org.apache.commons.lang3.math.Fraction fraction40 = fraction18.add(fraction22);
        org.apache.commons.lang3.math.Fraction fraction41 = fraction3.add(fraction22);
        org.apache.commons.lang3.math.Fraction fraction42 = fraction3.abs();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction22 and fraction23", (fraction22.compareTo(fraction23) == 0) == fraction22.equals(fraction23));
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test75");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.subtract(fraction3);
        java.lang.Class<?> wildcardClass5 = fraction0.getClass();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction0.divideBy(fraction6);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction(100.0d);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction13 = fraction12.reduce();
        int int14 = fraction11.compareTo(fraction13);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int18 = fraction15.compareTo(fraction17);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.reduce();
        float float20 = fraction17.floatValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.invert();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction17.negate();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction13.subtract(fraction17);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction9.add(fraction13);
        int int25 = fraction24.intValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction9", (fraction0.compareTo(fraction9) == 0) == fraction0.equals(fraction9));
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test76");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.subtract(fraction8);
        java.lang.String str10 = fraction5.toString();
        int int11 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int14 = fraction13.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long17 = fraction16.longValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.subtract(fraction18);
        boolean boolean20 = fraction13.equals((java.lang.Object) fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction12.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction5.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction0.multiplyBy(fraction15);
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long25 = fraction24.longValue();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction24.reduce();
        long long27 = fraction24.longValue();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction0.multiplyBy(fraction24);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction15 and fraction23", (fraction15.compareTo(fraction23) == 0) == fraction15.equals(fraction23));
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test77");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.invert();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 1, (int) (short) 100);
        double double9 = fraction8.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.abs();
        java.lang.Class<?> wildcardClass11 = fraction10.getClass();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        long long15 = fraction14.longValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.subtract(fraction16);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int20 = fraction18.compareTo(fraction19);
        int int21 = fraction16.compareTo(fraction19);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction16.negate();
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction28 = fraction26.subtract(fraction27);
        int int29 = fraction27.getNumerator();
        int int30 = fraction16.compareTo(fraction27);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction27.abs();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction31.negate();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction3.add(fraction31);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction26", (fraction0.compareTo(fraction26) == 0) == fraction0.equals(fraction26));
    }
}

