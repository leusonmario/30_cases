import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test01");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat4 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str5 = fastDateFormat4.toString();
        boolean boolean7 = fastDateFormat4.equals((java.lang.Object) 'a');
        java.lang.String str8 = fastDateFormat4.getPattern();
        java.util.Locale locale9 = fastDateFormat4.getLocale();
        java.util.TimeZone timeZone10 = fastDateFormat4.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("dd/MM/yyyy", timeZone10);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str17 = fastDateFormat16.getPattern();
        java.util.TimeZone timeZone18 = fastDateFormat16.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone18);
        boolean boolean20 = fastDateFormat19.getTimeZoneOverridesCalendar();
        java.util.TimeZone timeZone21 = fastDateFormat19.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone21);
        java.util.TimeZone timeZone25 = null;
        java.util.Locale locale26 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone25, locale26);
        java.lang.String str29 = fastDateFormat27.format((long) 0);
        java.util.TimeZone timeZone30 = fastDateFormat27.getTimeZone();
        java.util.TimeZone timeZone33 = null;
        java.util.Locale locale34 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone33, locale34);
        java.lang.String str37 = fastDateFormat35.format((long) 0);
        java.lang.String str38 = fastDateFormat35.getPattern();
        java.util.Locale locale39 = fastDateFormat35.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat40 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale39);
        java.lang.Class<?> wildcardClass41 = locale39.getClass();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat42 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, timeZone30, locale39);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat43 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy H'h'm'min's's' z", timeZone21, locale39);
        java.util.Locale locale44 = fastDateFormat43.getLocale();
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat45 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) 'a', 40, timeZone10, locale44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 40");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "FastDateFormat[]" + "'", str5.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str29.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str37.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str38.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale39);
        org.junit.Assert.assertNotNull(fastDateFormat40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(fastDateFormat42);
        org.junit.Assert.assertNotNull(fastDateFormat43);
        org.junit.Assert.assertNotNull(locale44);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test02");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat2 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int3 = fastDateFormat2.getMaxLengthEstimate();
        java.util.TimeZone timeZone4 = fastDateFormat2.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone4);
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone8, locale9);
        java.lang.String str12 = fastDateFormat10.format((long) 0);
        java.lang.String str13 = fastDateFormat10.getPattern();
        java.util.Locale locale14 = fastDateFormat10.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale14);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, timeZone4, locale14);
        java.util.TimeZone timeZone17 = fastDateFormat16.getTimeZone();
        java.lang.String str19 = fastDateFormat16.format((long) (short) 10);
        java.lang.String str21 = fastDateFormat16.format((long) 0);
        org.junit.Assert.assertNotNull(fastDateFormat2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str12.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str13.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale14);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1h0min0s CET" + "'", str19.equals("1h0min0s CET"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1h0min0s CET" + "'", str21.equals("1h0min0s CET"));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test03");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat3 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone1, locale2);
        java.lang.String str5 = fastDateFormat3.format((long) 0);
        java.lang.String str7 = fastDateFormat3.format((long) 3);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat13 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str14 = fastDateFormat13.getPattern();
        java.util.TimeZone timeZone15 = fastDateFormat13.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone15);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat17 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone15);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone15);
        java.util.Locale locale19 = fastDateFormat18.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale19);
        boolean boolean21 = fastDateFormat3.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(fastDateFormat3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str5.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str7.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertNotNull(fastDateFormat13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertNotNull(fastDateFormat17);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertNotNull(locale19);
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test04");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale2 = fastDateFormat1.getLocale();
        java.lang.String str4 = fastDateFormat1.format((-1L));
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone6, locale7);
        java.lang.String str10 = fastDateFormat8.format((long) 0);
        java.lang.String str11 = fastDateFormat8.getPattern();
        java.util.Locale locale12 = fastDateFormat8.getLocale();
        boolean boolean13 = fastDateFormat1.equals((java.lang.Object) fastDateFormat8);
        java.lang.Object obj14 = null;
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator15 = fastDateFormat8.formatToCharacterIterator(obj14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown class: <null>");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertNotNull(locale2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str10.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str11.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test05");
        java.util.TimeZone timeZone2 = null;
        java.util.Locale locale3 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat4 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone2, locale3);
        java.lang.String str6 = fastDateFormat4.format((long) 0);
        java.lang.String str7 = fastDateFormat4.getPattern();
        java.util.Locale locale8 = fastDateFormat4.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale8);
        java.lang.String str11 = fastDateFormat9.format((long) (byte) 10);
        java.util.Locale locale12 = fastDateFormat9.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat14 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str15 = fastDateFormat14.toString();
        boolean boolean17 = fastDateFormat14.equals((java.lang.Object) 'a');
        boolean boolean18 = fastDateFormat9.equals((java.lang.Object) fastDateFormat14);
        java.util.Date date19 = null;
        try {
            java.lang.String str20 = fastDateFormat9.format(date19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str6.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str7.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1h0min0s CET" + "'", str11.equals("1h0min0s CET"));
        org.junit.Assert.assertNotNull(locale12);
        org.junit.Assert.assertNotNull(fastDateFormat14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "FastDateFormat[]" + "'", str15.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test06");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int2 = fastDateFormat1.getMaxLengthEstimate();
        java.util.TimeZone timeZone3 = fastDateFormat1.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat4 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone3);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int9 = fastDateFormat8.getMaxLengthEstimate();
        java.util.TimeZone timeZone10 = fastDateFormat8.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone10);
        java.util.TimeZone timeZone14 = null;
        java.util.Locale locale15 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone14, locale15);
        java.lang.String str18 = fastDateFormat16.format((long) 0);
        java.lang.String str19 = fastDateFormat16.getPattern();
        java.util.Locale locale20 = fastDateFormat16.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale20);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, timeZone10, locale20);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat23 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", locale20);
        boolean boolean24 = fastDateFormat4.equals((java.lang.Object) locale20);
        java.lang.String str25 = fastDateFormat4.toString();
        java.lang.String str26 = fastDateFormat4.getPattern();
        java.lang.Object obj27 = fastDateFormat4.clone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat33 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str34 = fastDateFormat33.toString();
        java.lang.Object obj35 = fastDateFormat33.clone();
        java.lang.StringBuffer stringBuffer37 = null;
        java.lang.StringBuffer stringBuffer38 = fastDateFormat33.format((long) 'a', stringBuffer37);
        java.lang.Object obj39 = fastDateFormat33.clone();
        java.util.TimeZone timeZone40 = fastDateFormat33.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat41 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(3, 1, timeZone40);
        java.util.TimeZone timeZone46 = null;
        java.util.Locale locale47 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat48 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone46, locale47);
        java.lang.String str49 = fastDateFormat48.getPattern();
        java.lang.String str50 = fastDateFormat48.toString();
        java.util.TimeZone timeZone51 = fastDateFormat48.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat52 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 1, timeZone51);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat53 = org.apache.commons.lang3.time.FastDateFormat.getInstance("d' de 'MMMM' de 'yyyy HH'h'mm'min'ss's' z", timeZone51);
        java.util.TimeZone timeZone56 = null;
        java.util.Locale locale57 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat58 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone56, locale57);
        java.lang.String str60 = fastDateFormat58.format((long) 0);
        java.lang.String str61 = fastDateFormat58.getPattern();
        java.util.Locale locale62 = fastDateFormat58.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat63 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale62);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat64 = org.apache.commons.lang3.time.FastDateFormat.getInstance("d' de 'MMMM' de 'yyyy HH'h'mm'min'ss's' z", timeZone51, locale62);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat65 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, timeZone40, locale62);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat66 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale62);
        java.lang.StringBuffer stringBuffer67 = null;
        java.text.FieldPosition fieldPosition68 = null;
        try {
            java.lang.StringBuffer stringBuffer69 = fastDateFormat4.format((java.lang.Object) locale62, stringBuffer67, fieldPosition68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown class: java.util.Locale");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(fastDateFormat4);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 14 + "'", int9 == 14);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str18.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str19.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale20);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]" + "'", str25.equals("FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str26.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(fastDateFormat33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "FastDateFormat[]" + "'", str34.equals("FastDateFormat[]"));
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(stringBuffer38);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(fastDateFormat41);
        org.junit.Assert.assertNotNull(fastDateFormat48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str49.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]" + "'", str50.equals("FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]"));
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNotNull(fastDateFormat52);
        org.junit.Assert.assertNotNull(fastDateFormat53);
        org.junit.Assert.assertNotNull(fastDateFormat58);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str60.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str61.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale62);
        org.junit.Assert.assertNotNull(fastDateFormat63);
        org.junit.Assert.assertNotNull(fastDateFormat64);
        org.junit.Assert.assertNotNull(fastDateFormat65);
        org.junit.Assert.assertNotNull(fastDateFormat66);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test07");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str2 = fastDateFormat1.toString();
        java.lang.Object obj3 = fastDateFormat1.clone();
        java.lang.StringBuffer stringBuffer5 = null;
        java.lang.StringBuffer stringBuffer6 = fastDateFormat1.format((long) 'a', stringBuffer5);
        java.lang.Object obj7 = fastDateFormat1.clone();
        java.util.TimeZone timeZone8 = fastDateFormat1.getTimeZone();
        java.lang.Object obj9 = fastDateFormat1.clone();
        java.lang.String str10 = fastDateFormat1.toString();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat14 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale15 = fastDateFormat14.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, locale15);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat17 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", locale15);
        boolean boolean18 = fastDateFormat1.equals((java.lang.Object) locale15);
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "FastDateFormat[]" + "'", str2.equals("FastDateFormat[]"));
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(stringBuffer6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "FastDateFormat[]" + "'", str10.equals("FastDateFormat[]"));
        org.junit.Assert.assertNotNull(fastDateFormat14);
        org.junit.Assert.assertNotNull(locale15);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertNotNull(fastDateFormat17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test08");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str2 = fastDateFormat1.toString();
        boolean boolean4 = fastDateFormat1.equals((java.lang.Object) 'a');
        int int5 = fastDateFormat1.getMaxLengthEstimate();
        int int6 = fastDateFormat1.getMaxLengthEstimate();
        java.util.Date date7 = null;
        java.lang.StringBuffer stringBuffer8 = null;
        try {
            java.lang.StringBuffer stringBuffer9 = fastDateFormat1.format(date7, stringBuffer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "FastDateFormat[]" + "'", str2.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test09");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat4 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str5 = fastDateFormat4.getPattern();
        java.util.TimeZone timeZone6 = fastDateFormat4.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone6);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone6);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone6);
        java.lang.Class<?> wildcardClass10 = fastDateFormat9.getClass();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.Class<?> wildcardClass13 = fastDateFormat12.getClass();
        java.lang.String str15 = fastDateFormat12.format((-1L));
        java.util.Locale locale16 = fastDateFormat12.getLocale();
        boolean boolean17 = fastDateFormat9.equals((java.lang.Object) locale16);
        org.junit.Assert.assertNotNull(fastDateFormat4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test10");
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("Quinta-feira, 1 de Janeiro de 1970 01h00min00s CET");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: Q");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test11");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str9 = fastDateFormat8.getPattern();
        java.util.TimeZone timeZone10 = fastDateFormat8.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone10);
        java.util.TimeZone timeZone15 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat17 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale18 = fastDateFormat17.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone15, locale18);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale18);
        java.util.Locale locale21 = fastDateFormat20.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, timeZone10, locale21);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str29 = fastDateFormat28.getPattern();
        java.util.TimeZone timeZone30 = fastDateFormat28.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat31 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone30);
        java.util.TimeZone timeZone33 = null;
        java.util.Locale locale34 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone33, locale34);
        java.lang.String str37 = fastDateFormat35.format((long) 0);
        java.lang.String str38 = fastDateFormat35.getPattern();
        java.util.Locale locale39 = fastDateFormat35.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat40 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone30, locale39);
        java.util.TimeZone timeZone43 = null;
        java.util.Locale locale44 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat45 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone43, locale44);
        java.lang.String str47 = fastDateFormat45.format((long) 0);
        java.lang.String str48 = fastDateFormat45.getPattern();
        java.util.Locale locale49 = fastDateFormat45.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat50 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale49);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat51 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone30, locale49);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat52 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 3, timeZone10, locale49);
        java.util.TimeZone timeZone58 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat60 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale61 = fastDateFormat60.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat62 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone58, locale61);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat63 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale61);
        java.util.Locale locale64 = fastDateFormat63.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat65 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(2, 0, locale64);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat66 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 0, timeZone10, locale64);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat67 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(1, timeZone10);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat69 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int70 = fastDateFormat69.getMaxLengthEstimate();
        java.util.TimeZone timeZone71 = fastDateFormat69.getTimeZone();
        java.util.TimeZone timeZone73 = null;
        java.util.Locale locale74 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat75 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone73, locale74);
        java.util.Locale locale76 = fastDateFormat75.getLocale();
        java.util.TimeZone timeZone77 = fastDateFormat75.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat79 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0);
        boolean boolean80 = fastDateFormat75.equals((java.lang.Object) fastDateFormat79);
        java.lang.String str81 = fastDateFormat75.toString();
        java.util.Locale locale82 = fastDateFormat75.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat83 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(2, timeZone71, locale82);
        boolean boolean84 = fastDateFormat67.equals((java.lang.Object) timeZone71);
        int int85 = fastDateFormat67.getMaxLengthEstimate();
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat17);
        org.junit.Assert.assertNotNull(locale18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertNotNull(locale21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(fastDateFormat31);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str37.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str38.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale39);
        org.junit.Assert.assertNotNull(fastDateFormat40);
        org.junit.Assert.assertNotNull(fastDateFormat45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str47.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str48.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale49);
        org.junit.Assert.assertNotNull(fastDateFormat50);
        org.junit.Assert.assertNotNull(fastDateFormat51);
        org.junit.Assert.assertNotNull(fastDateFormat52);
        org.junit.Assert.assertNotNull(fastDateFormat60);
        org.junit.Assert.assertNotNull(locale61);
        org.junit.Assert.assertNotNull(fastDateFormat62);
        org.junit.Assert.assertNotNull(fastDateFormat63);
        org.junit.Assert.assertNotNull(locale64);
        org.junit.Assert.assertNotNull(fastDateFormat65);
        org.junit.Assert.assertNotNull(fastDateFormat66);
        org.junit.Assert.assertNotNull(fastDateFormat67);
        org.junit.Assert.assertNotNull(fastDateFormat69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 14 + "'", int70 == 14);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNotNull(fastDateFormat75);
        org.junit.Assert.assertNotNull(locale76);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(fastDateFormat79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]" + "'", str81.equals("FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]"));
        org.junit.Assert.assertNotNull(locale82);
        org.junit.Assert.assertNotNull(fastDateFormat83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 25 + "'", int85 == 25);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test12");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str8 = fastDateFormat7.getPattern();
        java.util.TimeZone timeZone9 = fastDateFormat7.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str20 = fastDateFormat19.getPattern();
        java.util.TimeZone timeZone21 = fastDateFormat19.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone21);
        java.util.TimeZone timeZone24 = null;
        java.util.Locale locale25 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone24, locale25);
        java.lang.String str28 = fastDateFormat26.format((long) 0);
        java.lang.String str29 = fastDateFormat26.getPattern();
        java.util.Locale locale30 = fastDateFormat26.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat31 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone21, locale30);
        java.util.TimeZone timeZone34 = null;
        java.util.Locale locale35 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat36 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone34, locale35);
        java.lang.String str38 = fastDateFormat36.format((long) 0);
        java.lang.String str39 = fastDateFormat36.getPattern();
        java.util.Locale locale40 = fastDateFormat36.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat41 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat42 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone21, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat43 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat44 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (byte) 0, 1, timeZone9, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat45 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 1, timeZone9);
        java.lang.Object obj46 = fastDateFormat45.clone();
        boolean boolean47 = fastDateFormat45.getTimeZoneOverridesCalendar();
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str28.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str29.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertNotNull(fastDateFormat31);
        org.junit.Assert.assertNotNull(fastDateFormat36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str38.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str39.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale40);
        org.junit.Assert.assertNotNull(fastDateFormat41);
        org.junit.Assert.assertNotNull(fastDateFormat42);
        org.junit.Assert.assertNotNull(fastDateFormat43);
        org.junit.Assert.assertNotNull(fastDateFormat44);
        org.junit.Assert.assertNotNull(fastDateFormat45);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test13");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str9 = fastDateFormat8.getPattern();
        java.util.TimeZone timeZone10 = fastDateFormat8.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone10);
        java.util.TimeZone timeZone15 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat17 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale18 = fastDateFormat17.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone15, locale18);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale18);
        java.util.Locale locale21 = fastDateFormat20.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, timeZone10, locale21);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str29 = fastDateFormat28.getPattern();
        java.util.TimeZone timeZone30 = fastDateFormat28.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat31 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone30);
        java.util.TimeZone timeZone33 = null;
        java.util.Locale locale34 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone33, locale34);
        java.lang.String str37 = fastDateFormat35.format((long) 0);
        java.lang.String str38 = fastDateFormat35.getPattern();
        java.util.Locale locale39 = fastDateFormat35.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat40 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone30, locale39);
        java.util.TimeZone timeZone43 = null;
        java.util.Locale locale44 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat45 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone43, locale44);
        java.lang.String str47 = fastDateFormat45.format((long) 0);
        java.lang.String str48 = fastDateFormat45.getPattern();
        java.util.Locale locale49 = fastDateFormat45.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat50 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale49);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat51 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone30, locale49);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat52 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 3, timeZone10, locale49);
        java.util.TimeZone timeZone54 = null;
        java.util.Locale locale55 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat56 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone54, locale55);
        java.util.Locale locale57 = fastDateFormat56.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat58 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(1, timeZone10, locale57);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat59 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (byte) 0, 40, locale57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 40");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat17);
        org.junit.Assert.assertNotNull(locale18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertNotNull(locale21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(fastDateFormat31);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str37.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str38.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale39);
        org.junit.Assert.assertNotNull(fastDateFormat40);
        org.junit.Assert.assertNotNull(fastDateFormat45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str47.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str48.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale49);
        org.junit.Assert.assertNotNull(fastDateFormat50);
        org.junit.Assert.assertNotNull(fastDateFormat51);
        org.junit.Assert.assertNotNull(fastDateFormat52);
        org.junit.Assert.assertNotNull(fastDateFormat56);
        org.junit.Assert.assertNotNull(locale57);
        org.junit.Assert.assertNotNull(fastDateFormat58);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test14");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat4 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str5 = fastDateFormat4.getPattern();
        java.util.TimeZone timeZone6 = fastDateFormat4.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone6);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone6);
        java.lang.StringBuffer stringBuffer10 = null;
        java.lang.StringBuffer stringBuffer11 = fastDateFormat8.format((long) 2, stringBuffer10);
        boolean boolean13 = fastDateFormat8.equals((java.lang.Object) 3);
        java.util.Locale locale14 = fastDateFormat8.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale14);
        java.lang.String str16 = fastDateFormat15.getPattern();
        java.util.TimeZone timeZone18 = null;
        java.util.Locale locale19 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone18, locale19);
        java.lang.String str22 = fastDateFormat20.format((long) 0);
        java.util.TimeZone timeZone23 = fastDateFormat20.getTimeZone();
        boolean boolean24 = fastDateFormat15.equals((java.lang.Object) timeZone23);
        org.junit.Assert.assertNotNull(fastDateFormat4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNull(stringBuffer11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(locale14);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "HH'h'mm'min'ss's' z" + "'", str16.equals("HH'h'mm'min'ss's' z"));
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str22.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test15");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat6 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str7 = fastDateFormat6.getPattern();
        java.util.TimeZone timeZone8 = fastDateFormat6.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone8);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone8);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str16 = fastDateFormat15.getPattern();
        java.util.TimeZone timeZone17 = fastDateFormat15.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone17);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone17);
        java.lang.StringBuffer stringBuffer21 = null;
        java.lang.StringBuffer stringBuffer22 = fastDateFormat19.format((long) 2, stringBuffer21);
        boolean boolean24 = fastDateFormat19.equals((java.lang.Object) 3);
        java.util.Locale locale25 = fastDateFormat19.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, (int) (short) 1, timeZone8, locale25);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(100, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal date style 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertNull(stringBuffer22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test16");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str8 = fastDateFormat7.getPattern();
        java.util.TimeZone timeZone9 = fastDateFormat7.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, (int) (byte) 0, timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat13 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str14 = fastDateFormat13.toString();
        boolean boolean16 = fastDateFormat13.equals((java.lang.Object) 'a');
        java.lang.String str17 = fastDateFormat13.getPattern();
        java.util.Locale locale18 = fastDateFormat13.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, timeZone9, locale18);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(10, (int) 'a', locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "FastDateFormat[]" + "'", str14.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(locale18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test17");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str2 = fastDateFormat1.getPattern();
        java.util.Calendar calendar3 = null;
        java.lang.String str4 = fastDateFormat1.format(calendar3);
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone6, locale7);
        java.util.Locale locale9 = fastDateFormat8.getLocale();
        java.util.TimeZone timeZone10 = fastDateFormat8.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0);
        boolean boolean13 = fastDateFormat8.equals((java.lang.Object) fastDateFormat12);
        boolean boolean14 = fastDateFormat1.equals((java.lang.Object) fastDateFormat8);
        java.lang.String str15 = fastDateFormat1.getPattern();
        java.util.Calendar calendar16 = null;
        java.lang.StringBuffer stringBuffer17 = null;
        java.lang.StringBuffer stringBuffer18 = fastDateFormat1.format(calendar16, stringBuffer17);
        java.lang.String str20 = fastDateFormat1.format((long) 42);
        java.lang.String str21 = fastDateFormat1.toString();
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNull(stringBuffer18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "FastDateFormat[]" + "'", str21.equals("FastDateFormat[]"));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test18");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str2 = fastDateFormat1.toString();
        boolean boolean4 = fastDateFormat1.equals((java.lang.Object) 'a');
        java.util.TimeZone timeZone5 = fastDateFormat1.getTimeZone();
        java.lang.Object obj6 = fastDateFormat1.clone();
        java.util.TimeZone timeZone8 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone8);
        java.lang.StringBuffer stringBuffer11 = null;
        java.text.FieldPosition fieldPosition12 = null;
        java.lang.StringBuffer stringBuffer13 = fastDateFormat9.format((java.lang.Object) 100L, stringBuffer11, fieldPosition12);
        java.util.Calendar calendar14 = null;
        java.lang.StringBuffer stringBuffer15 = null;
        java.lang.StringBuffer stringBuffer16 = fastDateFormat9.format(calendar14, stringBuffer15);
        java.lang.String str17 = fastDateFormat9.toString();
        int int18 = fastDateFormat9.getMaxLengthEstimate();
        java.util.Calendar calendar19 = null;
        java.lang.StringBuffer stringBuffer20 = null;
        java.lang.StringBuffer stringBuffer21 = fastDateFormat9.format(calendar19, stringBuffer20);
        try {
            java.lang.String str22 = fastDateFormat1.format((java.lang.Object) stringBuffer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown class: <null>");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "FastDateFormat[]" + "'", str2.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertNull(stringBuffer13);
        org.junit.Assert.assertNull(stringBuffer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "FastDateFormat[]" + "'", str17.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(stringBuffer21);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test19");
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("FastDateFormat[HH:mm]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test20");
        java.util.TimeZone timeZone2 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat3 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, 0, timeZone2);
        java.util.TimeZone timeZone4 = fastDateFormat3.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat6 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 1);
        java.lang.Object obj7 = fastDateFormat6.clone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str11 = fastDateFormat10.toString();
        boolean boolean13 = fastDateFormat10.equals((java.lang.Object) 'a');
        java.lang.String str14 = fastDateFormat10.getPattern();
        java.util.Locale locale15 = fastDateFormat10.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 1, locale15);
        java.lang.Object obj17 = fastDateFormat16.clone();
        java.lang.String str19 = fastDateFormat16.format((long) 1);
        boolean boolean20 = fastDateFormat6.equals((java.lang.Object) 1);
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator21 = fastDateFormat3.formatToCharacterIterator((java.lang.Object) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown class: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(fastDateFormat6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "FastDateFormat[]" + "'", str11.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(locale15);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1h0min0s CET" + "'", str19.equals("1h0min0s CET"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test21");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str6 = fastDateFormat5.getPattern();
        java.util.TimeZone timeZone7 = fastDateFormat5.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone7);
        java.util.TimeZone timeZone10 = null;
        java.util.Locale locale11 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone10, locale11);
        java.lang.String str14 = fastDateFormat12.format((long) 0);
        java.lang.String str15 = fastDateFormat12.getPattern();
        java.util.Locale locale16 = fastDateFormat12.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat17 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone7, locale16);
        java.util.TimeZone timeZone20 = null;
        java.util.Locale locale21 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone20, locale21);
        java.lang.String str24 = fastDateFormat22.format((long) 0);
        java.lang.String str25 = fastDateFormat22.getPattern();
        java.util.Locale locale26 = fastDateFormat22.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale26);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone7, locale26);
        java.lang.Class<?> wildcardClass29 = fastDateFormat28.getClass();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat34 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int35 = fastDateFormat34.getMaxLengthEstimate();
        java.util.TimeZone timeZone36 = fastDateFormat34.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat37 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone36);
        java.util.TimeZone timeZone40 = null;
        java.util.Locale locale41 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat42 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone40, locale41);
        java.lang.String str44 = fastDateFormat42.format((long) 0);
        java.lang.String str45 = fastDateFormat42.getPattern();
        java.util.Locale locale46 = fastDateFormat42.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat47 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale46);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat48 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, timeZone36, locale46);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat49 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", locale46);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat50 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(3, locale46);
        java.lang.String str51 = fastDateFormat50.getPattern();
        boolean boolean52 = fastDateFormat28.equals((java.lang.Object) fastDateFormat50);
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str14.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str15.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNotNull(fastDateFormat17);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str24.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str25.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(fastDateFormat34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 14 + "'", int35 == 14);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(fastDateFormat37);
        org.junit.Assert.assertNotNull(fastDateFormat42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str44.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str45.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale46);
        org.junit.Assert.assertNotNull(fastDateFormat47);
        org.junit.Assert.assertNotNull(fastDateFormat48);
        org.junit.Assert.assertNotNull(fastDateFormat49);
        org.junit.Assert.assertNotNull(fastDateFormat50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "HH:mm" + "'", str51.equals("HH:mm"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test22");
        java.util.TimeZone timeZone1 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat4 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str5 = fastDateFormat4.toString();
        java.lang.Object obj6 = fastDateFormat4.clone();
        java.util.Locale locale7 = fastDateFormat4.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(3, locale7);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("dd/MM/yy H'h'm'min's's' z", timeZone1, locale7);
        java.util.Date date10 = null;
        try {
            java.lang.String str11 = fastDateFormat9.format(date10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "FastDateFormat[]" + "'", str5.equals("FastDateFormat[]"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(locale7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test23");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat6 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str7 = fastDateFormat6.getPattern();
        java.util.TimeZone timeZone8 = fastDateFormat6.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone8);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone8);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str16 = fastDateFormat15.getPattern();
        java.util.TimeZone timeZone17 = fastDateFormat15.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone17);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone17);
        java.lang.StringBuffer stringBuffer21 = null;
        java.lang.StringBuffer stringBuffer22 = fastDateFormat19.format((long) 2, stringBuffer21);
        boolean boolean24 = fastDateFormat19.equals((java.lang.Object) 3);
        java.util.Locale locale25 = fastDateFormat19.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, (int) (short) 1, timeZone8, locale25);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(100, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertNull(stringBuffer22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test24");
        java.util.TimeZone timeZone2 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat3 = org.apache.commons.lang3.time.FastDateFormat.getInstance("d' de 'MMMM' de 'yyyy HH'h'mm'min'ss's' z", timeZone2);
        java.util.Locale locale4 = fastDateFormat3.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str16 = fastDateFormat15.getPattern();
        java.util.TimeZone timeZone17 = fastDateFormat15.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone17);
        java.util.TimeZone timeZone22 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat24 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale25 = fastDateFormat24.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone22, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale25);
        java.util.Locale locale28 = fastDateFormat27.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat29 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, timeZone17, locale28);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str36 = fastDateFormat35.getPattern();
        java.util.TimeZone timeZone37 = fastDateFormat35.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat38 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone37);
        java.util.TimeZone timeZone40 = null;
        java.util.Locale locale41 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat42 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone40, locale41);
        java.lang.String str44 = fastDateFormat42.format((long) 0);
        java.lang.String str45 = fastDateFormat42.getPattern();
        java.util.Locale locale46 = fastDateFormat42.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat47 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone37, locale46);
        java.util.TimeZone timeZone50 = null;
        java.util.Locale locale51 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat52 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone50, locale51);
        java.lang.String str54 = fastDateFormat52.format((long) 0);
        java.lang.String str55 = fastDateFormat52.getPattern();
        java.util.Locale locale56 = fastDateFormat52.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat57 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale56);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat58 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone37, locale56);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat59 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 3, timeZone17, locale56);
        java.util.TimeZone timeZone65 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat67 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale68 = fastDateFormat67.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat69 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone65, locale68);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat70 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale68);
        java.util.Locale locale71 = fastDateFormat70.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat72 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(2, 0, locale71);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat73 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 0, timeZone17, locale71);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat74 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone17);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat75 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (byte) 0, (int) (byte) 1, timeZone17);
        boolean boolean76 = fastDateFormat3.equals((java.lang.Object) fastDateFormat75);
        java.util.TimeZone timeZone77 = fastDateFormat75.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat82 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str83 = fastDateFormat82.getPattern();
        java.util.TimeZone timeZone84 = fastDateFormat82.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat85 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone84);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat86 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone84);
        java.lang.StringBuffer stringBuffer88 = null;
        java.lang.StringBuffer stringBuffer89 = fastDateFormat86.format((long) 2, stringBuffer88);
        boolean boolean91 = fastDateFormat86.equals((java.lang.Object) 3);
        java.util.Locale locale92 = fastDateFormat86.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat93 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale92);
        java.lang.String str95 = fastDateFormat93.format(0L);
        java.util.Locale locale96 = fastDateFormat93.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat97 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, timeZone77, locale96);
        org.junit.Assert.assertNotNull(fastDateFormat3);
        org.junit.Assert.assertNotNull(locale4);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertNotNull(fastDateFormat24);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
        org.junit.Assert.assertNotNull(locale28);
        org.junit.Assert.assertNotNull(fastDateFormat29);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(fastDateFormat38);
        org.junit.Assert.assertNotNull(fastDateFormat42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str44.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str45.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale46);
        org.junit.Assert.assertNotNull(fastDateFormat47);
        org.junit.Assert.assertNotNull(fastDateFormat52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str54.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str55.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale56);
        org.junit.Assert.assertNotNull(fastDateFormat57);
        org.junit.Assert.assertNotNull(fastDateFormat58);
        org.junit.Assert.assertNotNull(fastDateFormat59);
        org.junit.Assert.assertNotNull(fastDateFormat67);
        org.junit.Assert.assertNotNull(locale68);
        org.junit.Assert.assertNotNull(fastDateFormat69);
        org.junit.Assert.assertNotNull(fastDateFormat70);
        org.junit.Assert.assertNotNull(locale71);
        org.junit.Assert.assertNotNull(fastDateFormat72);
        org.junit.Assert.assertNotNull(fastDateFormat73);
        org.junit.Assert.assertNotNull(fastDateFormat74);
        org.junit.Assert.assertNotNull(fastDateFormat75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(fastDateFormat82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "" + "'", str83.equals(""));
        org.junit.Assert.assertNotNull(timeZone84);
        org.junit.Assert.assertNotNull(fastDateFormat85);
        org.junit.Assert.assertNotNull(fastDateFormat86);
        org.junit.Assert.assertNull(stringBuffer89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(locale92);
        org.junit.Assert.assertNotNull(fastDateFormat93);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "01h00min00s CET" + "'", str95.equals("01h00min00s CET"));
        org.junit.Assert.assertNotNull(locale96);
        org.junit.Assert.assertNotNull(fastDateFormat97);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test25");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str8 = fastDateFormat7.getPattern();
        java.util.TimeZone timeZone9 = fastDateFormat7.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str20 = fastDateFormat19.getPattern();
        java.util.TimeZone timeZone21 = fastDateFormat19.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone21);
        java.util.TimeZone timeZone24 = null;
        java.util.Locale locale25 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone24, locale25);
        java.lang.String str28 = fastDateFormat26.format((long) 0);
        java.lang.String str29 = fastDateFormat26.getPattern();
        java.util.Locale locale30 = fastDateFormat26.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat31 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone21, locale30);
        java.util.TimeZone timeZone34 = null;
        java.util.Locale locale35 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat36 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone34, locale35);
        java.lang.String str38 = fastDateFormat36.format((long) 0);
        java.lang.String str39 = fastDateFormat36.getPattern();
        java.util.Locale locale40 = fastDateFormat36.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat41 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat42 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone21, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat43 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat44 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (byte) 0, 1, timeZone9, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat50 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str51 = fastDateFormat50.getPattern();
        java.util.TimeZone timeZone52 = fastDateFormat50.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat53 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone52);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat54 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone52);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat55 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone52);
        java.util.Locale locale56 = fastDateFormat55.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat57 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale56);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat58 = org.apache.commons.lang3.time.FastDateFormat.getInstance("01:00", timeZone9, locale56);
        java.lang.Object obj59 = fastDateFormat58.clone();
        java.lang.String str60 = fastDateFormat58.getPattern();
        java.lang.Object obj61 = fastDateFormat58.clone();
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str28.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str29.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertNotNull(fastDateFormat31);
        org.junit.Assert.assertNotNull(fastDateFormat36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str38.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str39.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale40);
        org.junit.Assert.assertNotNull(fastDateFormat41);
        org.junit.Assert.assertNotNull(fastDateFormat42);
        org.junit.Assert.assertNotNull(fastDateFormat43);
        org.junit.Assert.assertNotNull(fastDateFormat44);
        org.junit.Assert.assertNotNull(fastDateFormat50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNotNull(fastDateFormat53);
        org.junit.Assert.assertNotNull(fastDateFormat54);
        org.junit.Assert.assertNotNull(fastDateFormat55);
        org.junit.Assert.assertNotNull(locale56);
        org.junit.Assert.assertNotNull(fastDateFormat57);
        org.junit.Assert.assertNotNull(fastDateFormat58);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "01:00" + "'", str60.equals("01:00"));
        org.junit.Assert.assertNotNull(obj61);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test26");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat3 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str4 = fastDateFormat3.toString();
        java.lang.Object obj5 = fastDateFormat3.clone();
        java.util.Locale locale6 = fastDateFormat3.getLocale();
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(14, (int) ' ', locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "FastDateFormat[]" + "'", str4.equals("FastDateFormat[]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(locale6);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test27");
        java.util.TimeZone timeZone1 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat2 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int3 = fastDateFormat2.getMaxLengthEstimate();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str13 = fastDateFormat12.getPattern();
        java.util.TimeZone timeZone14 = fastDateFormat12.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone14);
        java.util.TimeZone timeZone19 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale22 = fastDateFormat21.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat23 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone19, locale22);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat24 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale22);
        java.util.Locale locale25 = fastDateFormat24.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, timeZone14, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat32 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str33 = fastDateFormat32.getPattern();
        java.util.TimeZone timeZone34 = fastDateFormat32.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone34);
        java.util.TimeZone timeZone37 = null;
        java.util.Locale locale38 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat39 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone37, locale38);
        java.lang.String str41 = fastDateFormat39.format((long) 0);
        java.lang.String str42 = fastDateFormat39.getPattern();
        java.util.Locale locale43 = fastDateFormat39.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat44 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone34, locale43);
        java.util.TimeZone timeZone47 = null;
        java.util.Locale locale48 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat49 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone47, locale48);
        java.lang.String str51 = fastDateFormat49.format((long) 0);
        java.lang.String str52 = fastDateFormat49.getPattern();
        java.util.Locale locale53 = fastDateFormat49.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat54 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale53);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat55 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone34, locale53);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat56 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 3, timeZone14, locale53);
        java.util.TimeZone timeZone62 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat64 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale65 = fastDateFormat64.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat66 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone62, locale65);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat67 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale65);
        java.util.Locale locale68 = fastDateFormat67.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat69 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(2, 0, locale68);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat70 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 0, timeZone14, locale68);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat71 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone14);
        boolean boolean72 = fastDateFormat2.equals((java.lang.Object) fastDateFormat71);
        java.lang.String str74 = fastDateFormat71.format((long) 25);
        java.util.Locale locale75 = fastDateFormat71.getLocale();
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat76 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(42, timeZone1, locale75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 42");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertNotNull(locale22);
        org.junit.Assert.assertNotNull(fastDateFormat23);
        org.junit.Assert.assertNotNull(fastDateFormat24);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertNotNull(fastDateFormat32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertNotNull(fastDateFormat39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str41.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str42.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale43);
        org.junit.Assert.assertNotNull(fastDateFormat44);
        org.junit.Assert.assertNotNull(fastDateFormat49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str51.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str52.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale53);
        org.junit.Assert.assertNotNull(fastDateFormat54);
        org.junit.Assert.assertNotNull(fastDateFormat55);
        org.junit.Assert.assertNotNull(fastDateFormat56);
        org.junit.Assert.assertNotNull(fastDateFormat64);
        org.junit.Assert.assertNotNull(locale65);
        org.junit.Assert.assertNotNull(fastDateFormat66);
        org.junit.Assert.assertNotNull(fastDateFormat67);
        org.junit.Assert.assertNotNull(locale68);
        org.junit.Assert.assertNotNull(fastDateFormat69);
        org.junit.Assert.assertNotNull(fastDateFormat70);
        org.junit.Assert.assertNotNull(fastDateFormat71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str74.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertNotNull(locale75);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test28");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str6 = fastDateFormat5.getPattern();
        java.util.TimeZone timeZone7 = fastDateFormat5.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone7);
        java.util.Locale locale9 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone7, locale9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, timeZone7);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone7);
        boolean boolean13 = fastDateFormat12.getTimeZoneOverridesCalendar();
        int int14 = fastDateFormat12.getMaxLengthEstimate();
        try {
            java.lang.Object obj16 = fastDateFormat12.parseObject("HH:mm");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 40 + "'", int14 == 40);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test29");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat3 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone1, locale2);
        java.lang.Object obj4 = fastDateFormat3.clone();
        java.lang.String str5 = fastDateFormat3.getPattern();
        java.lang.String str6 = fastDateFormat3.toString();
        org.junit.Assert.assertNotNull(fastDateFormat3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str5.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]" + "'", str6.equals("FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]"));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test30");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(3);
        java.util.TimeZone timeZone2 = fastDateFormat1.getTimeZone();
        java.util.Date date3 = null;
        try {
            java.lang.String str4 = fastDateFormat1.format(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test31");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str8 = fastDateFormat7.getPattern();
        java.util.TimeZone timeZone9 = fastDateFormat7.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone9);
        java.util.TimeZone timeZone12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat14 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone12, locale13);
        java.lang.String str16 = fastDateFormat14.format((long) 0);
        java.lang.String str17 = fastDateFormat14.getPattern();
        java.util.Locale locale18 = fastDateFormat14.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone9, locale18);
        java.util.TimeZone timeZone22 = null;
        java.util.Locale locale23 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat24 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone22, locale23);
        java.lang.String str26 = fastDateFormat24.format((long) 0);
        java.lang.String str27 = fastDateFormat24.getPattern();
        java.util.Locale locale28 = fastDateFormat24.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat29 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale28);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat30 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone9, locale28);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat31 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, locale28);
        java.util.TimeZone timeZone32 = fastDateFormat31.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat33 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 1, timeZone32);
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str16.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str17.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertNotNull(fastDateFormat24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str26.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str27.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale28);
        org.junit.Assert.assertNotNull(fastDateFormat29);
        org.junit.Assert.assertNotNull(fastDateFormat30);
        org.junit.Assert.assertNotNull(fastDateFormat31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(fastDateFormat33);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test32");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 1);
        java.lang.Object obj2 = fastDateFormat1.clone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str6 = fastDateFormat5.toString();
        boolean boolean8 = fastDateFormat5.equals((java.lang.Object) 'a');
        java.lang.String str9 = fastDateFormat5.getPattern();
        java.util.Locale locale10 = fastDateFormat5.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 1, locale10);
        java.lang.Object obj12 = fastDateFormat11.clone();
        java.lang.String str14 = fastDateFormat11.format((long) 1);
        boolean boolean15 = fastDateFormat1.equals((java.lang.Object) 1);
        boolean boolean16 = fastDateFormat1.getTimeZoneOverridesCalendar();
        java.lang.String str17 = fastDateFormat1.getPattern();
        int int18 = fastDateFormat1.getMaxLengthEstimate();
        java.lang.String str19 = fastDateFormat1.getPattern();
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "FastDateFormat[]" + "'", str6.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1h0min0s CET" + "'", str14.equals("1h0min0s CET"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "H'h'm'min's's' z" + "'", str17.equals("H'h'm'min's's' z"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 22 + "'", int18 == 22);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "H'h'm'min's's' z" + "'", str19.equals("H'h'm'min's's' z"));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test33");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str6 = fastDateFormat5.getPattern();
        java.util.TimeZone timeZone7 = fastDateFormat5.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone7);
        java.util.TimeZone timeZone10 = null;
        java.util.Locale locale11 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone10, locale11);
        java.lang.String str14 = fastDateFormat12.format((long) 0);
        java.lang.String str15 = fastDateFormat12.getPattern();
        java.util.Locale locale16 = fastDateFormat12.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat17 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone7, locale16);
        java.util.TimeZone timeZone20 = null;
        java.util.Locale locale21 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone20, locale21);
        java.lang.String str24 = fastDateFormat22.format((long) 0);
        java.lang.String str25 = fastDateFormat22.getPattern();
        java.util.Locale locale26 = fastDateFormat22.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale26);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone7, locale26);
        java.lang.Class<?> wildcardClass29 = fastDateFormat28.getClass();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat38 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str39 = fastDateFormat38.getPattern();
        java.util.TimeZone timeZone40 = fastDateFormat38.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat41 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat42 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat43 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat50 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str51 = fastDateFormat50.getPattern();
        java.util.TimeZone timeZone52 = fastDateFormat50.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat53 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone52);
        java.util.TimeZone timeZone55 = null;
        java.util.Locale locale56 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat57 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone55, locale56);
        java.lang.String str59 = fastDateFormat57.format((long) 0);
        java.lang.String str60 = fastDateFormat57.getPattern();
        java.util.Locale locale61 = fastDateFormat57.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat62 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone52, locale61);
        java.util.TimeZone timeZone65 = null;
        java.util.Locale locale66 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat67 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone65, locale66);
        java.lang.String str69 = fastDateFormat67.format((long) 0);
        java.lang.String str70 = fastDateFormat67.getPattern();
        java.util.Locale locale71 = fastDateFormat67.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat72 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale71);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat73 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone52, locale71);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat74 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, locale71);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat75 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (byte) 0, 1, timeZone40, locale71);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat80 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str81 = fastDateFormat80.getPattern();
        java.util.TimeZone timeZone82 = fastDateFormat80.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat83 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone82);
        java.util.TimeZone timeZone85 = null;
        java.util.Locale locale86 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat87 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone85, locale86);
        java.lang.String str89 = fastDateFormat87.format((long) 0);
        java.lang.String str90 = fastDateFormat87.getPattern();
        java.util.Locale locale91 = fastDateFormat87.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat92 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone82, locale91);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat93 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", locale91);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat94 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (byte) 0, (int) (byte) 0, timeZone40, locale91);
        java.lang.Class<?> wildcardClass95 = locale91.getClass();
        java.lang.StringBuffer stringBuffer96 = null;
        java.text.FieldPosition fieldPosition97 = null;
        try {
            java.lang.StringBuffer stringBuffer98 = fastDateFormat28.format((java.lang.Object) wildcardClass95, stringBuffer96, fieldPosition97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown class: java.lang.Class");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str14.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str15.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale16);
        org.junit.Assert.assertNotNull(fastDateFormat17);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str24.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str25.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(fastDateFormat38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(fastDateFormat41);
        org.junit.Assert.assertNotNull(fastDateFormat42);
        org.junit.Assert.assertNotNull(fastDateFormat43);
        org.junit.Assert.assertNotNull(fastDateFormat50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNotNull(fastDateFormat53);
        org.junit.Assert.assertNotNull(fastDateFormat57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str59.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str60.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale61);
        org.junit.Assert.assertNotNull(fastDateFormat62);
        org.junit.Assert.assertNotNull(fastDateFormat67);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str69.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str70.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale71);
        org.junit.Assert.assertNotNull(fastDateFormat72);
        org.junit.Assert.assertNotNull(fastDateFormat73);
        org.junit.Assert.assertNotNull(fastDateFormat74);
        org.junit.Assert.assertNotNull(fastDateFormat75);
        org.junit.Assert.assertNotNull(fastDateFormat80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "" + "'", str81.equals(""));
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNotNull(fastDateFormat83);
        org.junit.Assert.assertNotNull(fastDateFormat87);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str89.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str90.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale91);
        org.junit.Assert.assertNotNull(fastDateFormat92);
        org.junit.Assert.assertNotNull(fastDateFormat93);
        org.junit.Assert.assertNotNull(fastDateFormat94);
        org.junit.Assert.assertNotNull(wildcardClass95);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test34");
        java.util.TimeZone timeZone1 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat2 = org.apache.commons.lang3.time.FastDateFormat.getInstance("d' de 'MMMM' de 'yyyy HH'h'mm'min'ss's' z", timeZone1);
        java.util.Locale locale3 = fastDateFormat2.getLocale();
        java.util.TimeZone timeZone4 = fastDateFormat2.getTimeZone();
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.junit.Assert.assertNotNull(fastDateFormat2);
        org.junit.Assert.assertNotNull(locale3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test35");
        java.util.TimeZone timeZone3 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale6 = fastDateFormat5.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone3, locale6);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale6);
        java.util.Locale locale9 = fastDateFormat8.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str16 = fastDateFormat15.getPattern();
        java.util.TimeZone timeZone17 = fastDateFormat15.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone17);
        java.util.TimeZone timeZone20 = null;
        java.util.Locale locale21 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone20, locale21);
        java.lang.String str24 = fastDateFormat22.format((long) 0);
        java.lang.String str25 = fastDateFormat22.getPattern();
        java.util.Locale locale26 = fastDateFormat22.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone17, locale26);
        java.util.TimeZone timeZone31 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat33 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale34 = fastDateFormat33.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone31, locale34);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat36 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale34);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat37 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, timeZone17, locale34);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat44 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str45 = fastDateFormat44.getPattern();
        java.util.TimeZone timeZone46 = fastDateFormat44.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat47 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone46);
        java.util.TimeZone timeZone49 = null;
        java.util.Locale locale50 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat51 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone49, locale50);
        java.lang.String str53 = fastDateFormat51.format((long) 0);
        java.lang.String str54 = fastDateFormat51.getPattern();
        java.util.Locale locale55 = fastDateFormat51.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat56 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone46, locale55);
        java.util.TimeZone timeZone59 = null;
        java.util.Locale locale60 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat61 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone59, locale60);
        java.lang.String str63 = fastDateFormat61.format((long) 0);
        java.lang.String str64 = fastDateFormat61.getPattern();
        java.util.Locale locale65 = fastDateFormat61.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat66 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale65);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat67 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone46, locale65);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat68 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, locale65);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat69 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 1, timeZone17, locale65);
        boolean boolean70 = fastDateFormat8.equals((java.lang.Object) timeZone17);
        java.lang.Object obj71 = fastDateFormat8.clone();
        java.lang.String str72 = fastDateFormat8.getPattern();
        java.text.ParsePosition parsePosition74 = null;
        try {
            java.lang.Object obj75 = fastDateFormat8.parseObject("d' de 'MMMM' de 'yyyy HH'h'mm'min'ss's' z", parsePosition74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str24.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str25.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
        org.junit.Assert.assertNotNull(fastDateFormat33);
        org.junit.Assert.assertNotNull(locale34);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertNotNull(fastDateFormat36);
        org.junit.Assert.assertNotNull(fastDateFormat37);
        org.junit.Assert.assertNotNull(fastDateFormat44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(fastDateFormat47);
        org.junit.Assert.assertNotNull(fastDateFormat51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str53.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str54.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale55);
        org.junit.Assert.assertNotNull(fastDateFormat56);
        org.junit.Assert.assertNotNull(fastDateFormat61);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str63.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str64.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale65);
        org.junit.Assert.assertNotNull(fastDateFormat66);
        org.junit.Assert.assertNotNull(fastDateFormat67);
        org.junit.Assert.assertNotNull(fastDateFormat68);
        org.junit.Assert.assertNotNull(fastDateFormat69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy H'h'm'min's's' z" + "'", str72.equals("EEEE, d' de 'MMMM' de 'yyyy H'h'm'min's's' z"));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test36");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str2 = fastDateFormat1.getPattern();
        java.util.TimeZone timeZone3 = fastDateFormat1.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str12 = fastDateFormat11.getPattern();
        java.util.TimeZone timeZone13 = fastDateFormat11.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat14 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone13);
        java.util.TimeZone timeZone16 = null;
        java.util.Locale locale17 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone16, locale17);
        java.lang.String str20 = fastDateFormat18.format((long) 0);
        java.lang.String str21 = fastDateFormat18.getPattern();
        java.util.Locale locale22 = fastDateFormat18.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat23 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone13, locale22);
        java.util.TimeZone timeZone26 = null;
        java.util.Locale locale27 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone26, locale27);
        java.lang.String str30 = fastDateFormat28.format((long) 0);
        java.lang.String str31 = fastDateFormat28.getPattern();
        java.util.Locale locale32 = fastDateFormat28.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat33 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale32);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat34 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone13, locale32);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat40 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str41 = fastDateFormat40.getPattern();
        java.util.TimeZone timeZone42 = fastDateFormat40.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat43 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone42);
        java.util.TimeZone timeZone45 = null;
        java.util.Locale locale46 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat47 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone45, locale46);
        java.lang.String str49 = fastDateFormat47.format((long) 0);
        java.lang.String str50 = fastDateFormat47.getPattern();
        java.util.Locale locale51 = fastDateFormat47.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat52 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone42, locale51);
        java.util.TimeZone timeZone55 = null;
        java.util.Locale locale56 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat57 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone55, locale56);
        java.lang.String str59 = fastDateFormat57.format((long) 0);
        java.lang.String str60 = fastDateFormat57.getPattern();
        java.util.Locale locale61 = fastDateFormat57.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat62 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale61);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat63 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone42, locale61);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat64 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone13, locale61);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat65 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy HH:mm:ss", locale61);
        boolean boolean66 = fastDateFormat1.equals((java.lang.Object) fastDateFormat65);
        java.util.Calendar calendar67 = null;
        java.lang.StringBuffer stringBuffer68 = null;
        try {
            java.lang.StringBuffer stringBuffer69 = fastDateFormat65.format(calendar67, stringBuffer68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(fastDateFormat14);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str20.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str21.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale22);
        org.junit.Assert.assertNotNull(fastDateFormat23);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str30.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str31.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale32);
        org.junit.Assert.assertNotNull(fastDateFormat33);
        org.junit.Assert.assertNotNull(fastDateFormat34);
        org.junit.Assert.assertNotNull(fastDateFormat40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(fastDateFormat43);
        org.junit.Assert.assertNotNull(fastDateFormat47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str49.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str50.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale51);
        org.junit.Assert.assertNotNull(fastDateFormat52);
        org.junit.Assert.assertNotNull(fastDateFormat57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str59.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str60.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale61);
        org.junit.Assert.assertNotNull(fastDateFormat62);
        org.junit.Assert.assertNotNull(fastDateFormat63);
        org.junit.Assert.assertNotNull(fastDateFormat64);
        org.junit.Assert.assertNotNull(fastDateFormat65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test37");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int2 = fastDateFormat1.getMaxLengthEstimate();
        java.util.TimeZone timeZone3 = fastDateFormat1.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat4 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone3);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int9 = fastDateFormat8.getMaxLengthEstimate();
        java.util.TimeZone timeZone10 = fastDateFormat8.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone10);
        java.util.TimeZone timeZone14 = null;
        java.util.Locale locale15 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone14, locale15);
        java.lang.String str18 = fastDateFormat16.format((long) 0);
        java.lang.String str19 = fastDateFormat16.getPattern();
        java.util.Locale locale20 = fastDateFormat16.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale20);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, timeZone10, locale20);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat23 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", locale20);
        boolean boolean24 = fastDateFormat4.equals((java.lang.Object) locale20);
        java.lang.String str25 = fastDateFormat4.toString();
        int int26 = fastDateFormat4.getMaxLengthEstimate();
        java.lang.Object obj27 = fastDateFormat4.clone();
        java.lang.Object obj28 = fastDateFormat4.clone();
        java.lang.String str29 = fastDateFormat4.toString();
        java.util.Calendar calendar30 = null;
        try {
            java.lang.String str31 = fastDateFormat4.format(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(fastDateFormat4);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 14 + "'", int9 == 14);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str18.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str19.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale20);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]" + "'", str25.equals("FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 40 + "'", int26 == 40);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]" + "'", str29.equals("FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]"));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test38");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str8 = fastDateFormat7.getPattern();
        java.util.TimeZone timeZone9 = fastDateFormat7.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str17 = fastDateFormat16.getPattern();
        java.util.TimeZone timeZone18 = fastDateFormat16.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone18);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone18);
        java.lang.StringBuffer stringBuffer22 = null;
        java.lang.StringBuffer stringBuffer23 = fastDateFormat20.format((long) 2, stringBuffer22);
        boolean boolean25 = fastDateFormat20.equals((java.lang.Object) 3);
        java.util.Locale locale26 = fastDateFormat20.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale26);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, (int) (short) 1, timeZone9, locale26);
        java.util.TimeZone timeZone30 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat32 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale33 = fastDateFormat32.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat34 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone30, locale33);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(16, (int) (byte) 0, timeZone9, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal date style 16");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertNull(stringBuffer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(locale26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertNotNull(fastDateFormat32);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertNotNull(fastDateFormat34);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test39");
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat2 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(31, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test40");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat2 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int3 = fastDateFormat2.getMaxLengthEstimate();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str13 = fastDateFormat12.getPattern();
        java.util.TimeZone timeZone14 = fastDateFormat12.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone14);
        java.util.TimeZone timeZone19 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale22 = fastDateFormat21.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat23 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone19, locale22);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat24 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale22);
        java.util.Locale locale25 = fastDateFormat24.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, timeZone14, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat32 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str33 = fastDateFormat32.getPattern();
        java.util.TimeZone timeZone34 = fastDateFormat32.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone34);
        java.util.TimeZone timeZone37 = null;
        java.util.Locale locale38 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat39 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone37, locale38);
        java.lang.String str41 = fastDateFormat39.format((long) 0);
        java.lang.String str42 = fastDateFormat39.getPattern();
        java.util.Locale locale43 = fastDateFormat39.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat44 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone34, locale43);
        java.util.TimeZone timeZone47 = null;
        java.util.Locale locale48 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat49 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone47, locale48);
        java.lang.String str51 = fastDateFormat49.format((long) 0);
        java.lang.String str52 = fastDateFormat49.getPattern();
        java.util.Locale locale53 = fastDateFormat49.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat54 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale53);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat55 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone34, locale53);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat56 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 3, timeZone14, locale53);
        java.util.TimeZone timeZone62 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat64 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale65 = fastDateFormat64.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat66 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone62, locale65);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat67 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale65);
        java.util.Locale locale68 = fastDateFormat67.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat69 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(2, 0, locale68);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat70 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 0, timeZone14, locale68);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat71 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone14);
        boolean boolean72 = fastDateFormat2.equals((java.lang.Object) fastDateFormat71);
        java.lang.String str74 = fastDateFormat71.format((long) 25);
        java.util.Locale locale75 = fastDateFormat71.getLocale();
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat76 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, 16, locale75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 16");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertNotNull(locale22);
        org.junit.Assert.assertNotNull(fastDateFormat23);
        org.junit.Assert.assertNotNull(fastDateFormat24);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertNotNull(fastDateFormat32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertNotNull(fastDateFormat39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str41.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str42.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale43);
        org.junit.Assert.assertNotNull(fastDateFormat44);
        org.junit.Assert.assertNotNull(fastDateFormat49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str51.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str52.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale53);
        org.junit.Assert.assertNotNull(fastDateFormat54);
        org.junit.Assert.assertNotNull(fastDateFormat55);
        org.junit.Assert.assertNotNull(fastDateFormat56);
        org.junit.Assert.assertNotNull(fastDateFormat64);
        org.junit.Assert.assertNotNull(locale65);
        org.junit.Assert.assertNotNull(fastDateFormat66);
        org.junit.Assert.assertNotNull(fastDateFormat67);
        org.junit.Assert.assertNotNull(locale68);
        org.junit.Assert.assertNotNull(fastDateFormat69);
        org.junit.Assert.assertNotNull(fastDateFormat70);
        org.junit.Assert.assertNotNull(fastDateFormat71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str74.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertNotNull(locale75);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test41");
        java.util.TimeZone timeZone2 = null;
        java.util.Locale locale3 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat4 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone2, locale3);
        java.lang.String str6 = fastDateFormat4.format((long) 0);
        java.lang.String str7 = fastDateFormat4.getPattern();
        java.util.Locale locale8 = fastDateFormat4.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale8);
        java.lang.String str11 = fastDateFormat9.format((long) (-1));
        java.lang.Class<?> wildcardClass12 = fastDateFormat9.getClass();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str19 = fastDateFormat18.getPattern();
        java.util.TimeZone timeZone20 = fastDateFormat18.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone20);
        java.util.TimeZone timeZone23 = null;
        java.util.Locale locale24 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat25 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone23, locale24);
        java.lang.String str27 = fastDateFormat25.format((long) 0);
        java.lang.String str28 = fastDateFormat25.getPattern();
        java.util.Locale locale29 = fastDateFormat25.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat30 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone20, locale29);
        java.util.TimeZone timeZone33 = null;
        java.util.Locale locale34 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone33, locale34);
        java.lang.String str37 = fastDateFormat35.format((long) 0);
        java.lang.String str38 = fastDateFormat35.getPattern();
        java.util.Locale locale39 = fastDateFormat35.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat40 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale39);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat41 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone20, locale39);
        java.lang.Class<?> wildcardClass42 = fastDateFormat41.getClass();
        boolean boolean43 = fastDateFormat9.equals((java.lang.Object) fastDateFormat41);
        java.lang.String str44 = fastDateFormat41.getPattern();
        org.junit.Assert.assertNotNull(fastDateFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str6.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str7.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0h59min59s CET" + "'", str11.equals("0h59min59s CET"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertNotNull(fastDateFormat25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str27.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str28.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertNotNull(fastDateFormat30);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str37.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str38.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale39);
        org.junit.Assert.assertNotNull(fastDateFormat40);
        org.junit.Assert.assertNotNull(fastDateFormat41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "d' de 'MMMM' de 'yyyy HH'h'mm'min'ss's' z" + "'", str44.equals("d' de 'MMMM' de 'yyyy HH'h'mm'min'ss's' z"));
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test42");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str2 = fastDateFormat1.toString();
        java.util.TimeZone timeZone3 = fastDateFormat1.getTimeZone();
        java.lang.StringBuffer stringBuffer5 = null;
        java.lang.StringBuffer stringBuffer6 = fastDateFormat1.format((long) ' ', stringBuffer5);
        java.lang.Object obj7 = fastDateFormat1.clone();
        java.util.Date date8 = null;
        try {
            java.lang.String str9 = fastDateFormat1.format(date8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "FastDateFormat[]" + "'", str2.equals("FastDateFormat[]"));
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(stringBuffer6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test43");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat3 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str4 = fastDateFormat3.getPattern();
        java.util.TimeZone timeZone5 = fastDateFormat3.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat6 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone5);
        java.util.Locale locale7 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone5, locale7);
        boolean boolean9 = fastDateFormat8.getTimeZoneOverridesCalendar();
        java.lang.Object obj10 = fastDateFormat8.clone();
        org.junit.Assert.assertNotNull(fastDateFormat3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(fastDateFormat6);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test44");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str9 = fastDateFormat8.getPattern();
        java.util.TimeZone timeZone10 = fastDateFormat8.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone10);
        java.util.TimeZone timeZone15 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat17 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale18 = fastDateFormat17.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone15, locale18);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale18);
        java.util.Locale locale21 = fastDateFormat20.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, timeZone10, locale21);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str29 = fastDateFormat28.getPattern();
        java.util.TimeZone timeZone30 = fastDateFormat28.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat31 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone30);
        java.util.TimeZone timeZone33 = null;
        java.util.Locale locale34 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone33, locale34);
        java.lang.String str37 = fastDateFormat35.format((long) 0);
        java.lang.String str38 = fastDateFormat35.getPattern();
        java.util.Locale locale39 = fastDateFormat35.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat40 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone30, locale39);
        java.util.TimeZone timeZone43 = null;
        java.util.Locale locale44 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat45 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone43, locale44);
        java.lang.String str47 = fastDateFormat45.format((long) 0);
        java.lang.String str48 = fastDateFormat45.getPattern();
        java.util.Locale locale49 = fastDateFormat45.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat50 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale49);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat51 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone30, locale49);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat52 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 3, timeZone10, locale49);
        java.util.TimeZone timeZone58 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat60 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale61 = fastDateFormat60.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat62 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone58, locale61);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat63 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale61);
        java.util.Locale locale64 = fastDateFormat63.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat65 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(2, 0, locale64);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat66 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 0, timeZone10, locale64);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat67 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone10);
        java.lang.Object obj68 = fastDateFormat67.clone();
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat17);
        org.junit.Assert.assertNotNull(locale18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertNotNull(locale21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(fastDateFormat31);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str37.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str38.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale39);
        org.junit.Assert.assertNotNull(fastDateFormat40);
        org.junit.Assert.assertNotNull(fastDateFormat45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str47.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str48.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale49);
        org.junit.Assert.assertNotNull(fastDateFormat50);
        org.junit.Assert.assertNotNull(fastDateFormat51);
        org.junit.Assert.assertNotNull(fastDateFormat52);
        org.junit.Assert.assertNotNull(fastDateFormat60);
        org.junit.Assert.assertNotNull(locale61);
        org.junit.Assert.assertNotNull(fastDateFormat62);
        org.junit.Assert.assertNotNull(fastDateFormat63);
        org.junit.Assert.assertNotNull(locale64);
        org.junit.Assert.assertNotNull(fastDateFormat65);
        org.junit.Assert.assertNotNull(fastDateFormat66);
        org.junit.Assert.assertNotNull(fastDateFormat67);
        org.junit.Assert.assertNotNull(obj68);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test45");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str2 = fastDateFormat1.getPattern();
        java.util.Calendar calendar3 = null;
        java.lang.String str4 = fastDateFormat1.format(calendar3);
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone6, locale7);
        java.util.Locale locale9 = fastDateFormat8.getLocale();
        java.util.TimeZone timeZone10 = fastDateFormat8.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0);
        boolean boolean13 = fastDateFormat8.equals((java.lang.Object) fastDateFormat12);
        boolean boolean14 = fastDateFormat1.equals((java.lang.Object) fastDateFormat8);
        java.lang.String str15 = fastDateFormat1.getPattern();
        java.util.TimeZone timeZone16 = fastDateFormat1.getTimeZone();
        java.lang.String str17 = fastDateFormat1.getPattern();
        java.lang.StringBuffer stringBuffer19 = null;
        java.lang.StringBuffer stringBuffer20 = fastDateFormat1.format((long) 3, stringBuffer19);
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(locale9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNull(stringBuffer20);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test46");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat6 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str7 = fastDateFormat6.getPattern();
        java.util.TimeZone timeZone8 = fastDateFormat6.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone8);
        java.util.TimeZone timeZone11 = null;
        java.util.Locale locale12 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat13 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone11, locale12);
        java.lang.String str15 = fastDateFormat13.format((long) 0);
        java.lang.String str16 = fastDateFormat13.getPattern();
        java.util.Locale locale17 = fastDateFormat13.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone8, locale17);
        java.util.TimeZone timeZone22 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat24 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale25 = fastDateFormat24.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone22, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, timeZone8, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str36 = fastDateFormat35.getPattern();
        java.util.TimeZone timeZone37 = fastDateFormat35.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat38 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone37);
        java.util.TimeZone timeZone40 = null;
        java.util.Locale locale41 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat42 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone40, locale41);
        java.lang.String str44 = fastDateFormat42.format((long) 0);
        java.lang.String str45 = fastDateFormat42.getPattern();
        java.util.Locale locale46 = fastDateFormat42.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat47 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone37, locale46);
        java.util.TimeZone timeZone50 = null;
        java.util.Locale locale51 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat52 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone50, locale51);
        java.lang.String str54 = fastDateFormat52.format((long) 0);
        java.lang.String str55 = fastDateFormat52.getPattern();
        java.util.Locale locale56 = fastDateFormat52.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat57 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale56);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat58 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone37, locale56);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat59 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, locale56);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat60 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 1, timeZone8, locale56);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat62 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str63 = fastDateFormat62.toString();
        boolean boolean65 = fastDateFormat62.equals((java.lang.Object) 'a');
        java.lang.String str66 = fastDateFormat62.getPattern();
        java.util.Locale locale67 = fastDateFormat62.getLocale();
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat68 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(42, timeZone8, locale67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal date style 42");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertNotNull(fastDateFormat13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str15.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str16.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale17);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertNotNull(fastDateFormat24);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(fastDateFormat38);
        org.junit.Assert.assertNotNull(fastDateFormat42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str44.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str45.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale46);
        org.junit.Assert.assertNotNull(fastDateFormat47);
        org.junit.Assert.assertNotNull(fastDateFormat52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str54.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str55.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale56);
        org.junit.Assert.assertNotNull(fastDateFormat57);
        org.junit.Assert.assertNotNull(fastDateFormat58);
        org.junit.Assert.assertNotNull(fastDateFormat59);
        org.junit.Assert.assertNotNull(fastDateFormat60);
        org.junit.Assert.assertNotNull(fastDateFormat62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "FastDateFormat[]" + "'", str63.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "" + "'", str66.equals(""));
        org.junit.Assert.assertNotNull(locale67);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test47");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat3 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str4 = fastDateFormat3.getPattern();
        java.util.TimeZone timeZone5 = fastDateFormat3.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat6 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone5);
        java.lang.String str8 = fastDateFormat6.format((long) 0);
        java.lang.Object obj9 = fastDateFormat6.clone();
        java.util.Locale locale10 = fastDateFormat6.getLocale();
        int int11 = fastDateFormat6.getMaxLengthEstimate();
        java.util.Locale locale12 = fastDateFormat6.getLocale();
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat13 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(42, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 42");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(fastDateFormat6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str8.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 40 + "'", int11 == 40);
        org.junit.Assert.assertNotNull(locale12);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test48");
        java.util.TimeZone timeZone2 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str10 = fastDateFormat9.getPattern();
        java.util.TimeZone timeZone11 = fastDateFormat9.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone11);
        java.util.TimeZone timeZone14 = null;
        java.util.Locale locale15 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone14, locale15);
        java.lang.String str18 = fastDateFormat16.format((long) 0);
        java.lang.String str19 = fastDateFormat16.getPattern();
        java.util.Locale locale20 = fastDateFormat16.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone11, locale20);
        java.util.TimeZone timeZone24 = null;
        java.util.Locale locale25 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone24, locale25);
        java.lang.String str28 = fastDateFormat26.format((long) 0);
        java.lang.String str29 = fastDateFormat26.getPattern();
        java.util.Locale locale30 = fastDateFormat26.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat31 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale30);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat32 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone11, locale30);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat38 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str39 = fastDateFormat38.getPattern();
        java.util.TimeZone timeZone40 = fastDateFormat38.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat41 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone40);
        java.util.TimeZone timeZone43 = null;
        java.util.Locale locale44 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat45 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone43, locale44);
        java.lang.String str47 = fastDateFormat45.format((long) 0);
        java.lang.String str48 = fastDateFormat45.getPattern();
        java.util.Locale locale49 = fastDateFormat45.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat50 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone40, locale49);
        java.util.TimeZone timeZone53 = null;
        java.util.Locale locale54 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat55 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone53, locale54);
        java.lang.String str57 = fastDateFormat55.format((long) 0);
        java.lang.String str58 = fastDateFormat55.getPattern();
        java.util.Locale locale59 = fastDateFormat55.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat60 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale59);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat61 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone40, locale59);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat62 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(2, timeZone11, locale59);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat63 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(16, (int) (short) 10, timeZone2, locale59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str18.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str19.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale20);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str28.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str29.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertNotNull(fastDateFormat31);
        org.junit.Assert.assertNotNull(fastDateFormat32);
        org.junit.Assert.assertNotNull(fastDateFormat38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(fastDateFormat41);
        org.junit.Assert.assertNotNull(fastDateFormat45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str47.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str48.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale49);
        org.junit.Assert.assertNotNull(fastDateFormat50);
        org.junit.Assert.assertNotNull(fastDateFormat55);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str57.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str58.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale59);
        org.junit.Assert.assertNotNull(fastDateFormat60);
        org.junit.Assert.assertNotNull(fastDateFormat61);
        org.junit.Assert.assertNotNull(fastDateFormat62);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test49");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat3 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str4 = fastDateFormat3.toString();
        java.util.TimeZone timeZone5 = fastDateFormat3.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int12 = fastDateFormat11.getMaxLengthEstimate();
        java.util.TimeZone timeZone13 = fastDateFormat11.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat14 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone13);
        java.util.TimeZone timeZone17 = null;
        java.util.Locale locale18 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone17, locale18);
        java.lang.String str21 = fastDateFormat19.format((long) 0);
        java.lang.String str22 = fastDateFormat19.getPattern();
        java.util.Locale locale23 = fastDateFormat19.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat24 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale23);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat25 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, timeZone13, locale23);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", locale23);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(2, 1, locale23);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getInstance("01:00", timeZone5, locale23);
        java.util.TimeZone timeZone33 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale36 = fastDateFormat35.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat37 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone33, locale36);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat38 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale36);
        java.util.Locale locale39 = fastDateFormat38.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat40 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", locale39);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat41 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 100, timeZone5, locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "FastDateFormat[]" + "'", str4.equals("FastDateFormat[]"));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 14 + "'", int12 == 14);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(fastDateFormat14);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str21.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str22.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale23);
        org.junit.Assert.assertNotNull(fastDateFormat24);
        org.junit.Assert.assertNotNull(fastDateFormat25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertNotNull(locale36);
        org.junit.Assert.assertNotNull(fastDateFormat37);
        org.junit.Assert.assertNotNull(fastDateFormat38);
        org.junit.Assert.assertNotNull(locale39);
        org.junit.Assert.assertNotNull(fastDateFormat40);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test50");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int6 = fastDateFormat5.getMaxLengthEstimate();
        java.util.TimeZone timeZone7 = fastDateFormat5.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone7);
        java.util.TimeZone timeZone11 = null;
        java.util.Locale locale12 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat13 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone11, locale12);
        java.lang.String str15 = fastDateFormat13.format((long) 0);
        java.lang.String str16 = fastDateFormat13.getPattern();
        java.util.Locale locale17 = fastDateFormat13.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale17);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, timeZone7, locale17);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", locale17);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 1, 0, locale17);
        java.util.Locale locale22 = fastDateFormat21.getLocale();
        int int23 = fastDateFormat21.getMaxLengthEstimate();
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 14 + "'", int6 == 14);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(fastDateFormat13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str15.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str16.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale17);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertNotNull(locale22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 42 + "'", int23 == 42);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test51");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat4 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str5 = fastDateFormat4.getPattern();
        java.util.TimeZone timeZone6 = fastDateFormat4.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone6);
        java.util.TimeZone timeZone11 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat13 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale14 = fastDateFormat13.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone11, locale14);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale14);
        java.util.Locale locale17 = fastDateFormat16.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, timeZone6, locale17);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("HH'h'mm'min'ss's' z", timeZone6);
        java.lang.String str21 = fastDateFormat19.format((long) (short) 100);
        java.util.Date date22 = null;
        java.lang.StringBuffer stringBuffer23 = null;
        try {
            java.lang.StringBuffer stringBuffer24 = fastDateFormat19.format(date22, stringBuffer23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertNotNull(fastDateFormat13);
        org.junit.Assert.assertNotNull(locale14);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertNotNull(locale17);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "01h00min00s CET" + "'", str21.equals("01h00min00s CET"));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test52");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str2 = fastDateFormat1.getPattern();
        java.util.Calendar calendar3 = null;
        java.lang.String str4 = fastDateFormat1.format(calendar3);
        java.lang.StringBuffer stringBuffer6 = null;
        java.lang.StringBuffer stringBuffer7 = fastDateFormat1.format((long) (-1), stringBuffer6);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat14 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str15 = fastDateFormat14.getPattern();
        java.util.TimeZone timeZone16 = fastDateFormat14.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat17 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone16);
        java.util.TimeZone timeZone19 = null;
        java.util.Locale locale20 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone19, locale20);
        java.lang.String str23 = fastDateFormat21.format((long) 0);
        java.lang.String str24 = fastDateFormat21.getPattern();
        java.util.Locale locale25 = fastDateFormat21.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone16, locale25);
        java.util.TimeZone timeZone30 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat32 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale33 = fastDateFormat32.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat34 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone30, locale33);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale33);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat36 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, timeZone16, locale33);
        java.util.TimeZone timeZone37 = fastDateFormat36.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat43 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str44 = fastDateFormat43.getPattern();
        java.util.TimeZone timeZone45 = fastDateFormat43.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat46 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone45);
        java.util.TimeZone timeZone48 = null;
        java.util.Locale locale49 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat50 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone48, locale49);
        java.lang.String str52 = fastDateFormat50.format((long) 0);
        java.lang.String str53 = fastDateFormat50.getPattern();
        java.util.Locale locale54 = fastDateFormat50.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat55 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone45, locale54);
        java.util.TimeZone timeZone58 = null;
        java.util.Locale locale59 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat60 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone58, locale59);
        java.lang.String str62 = fastDateFormat60.format((long) 0);
        java.lang.String str63 = fastDateFormat60.getPattern();
        java.util.Locale locale64 = fastDateFormat60.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat65 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale64);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat66 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone45, locale64);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat67 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(1, timeZone37, locale64);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat68 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone37);
        boolean boolean69 = fastDateFormat1.equals((java.lang.Object) timeZone37);
        java.util.Locale locale70 = fastDateFormat1.getLocale();
        java.lang.String str71 = fastDateFormat1.toString();
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(stringBuffer7);
        org.junit.Assert.assertNotNull(fastDateFormat14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(fastDateFormat17);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str23.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str24.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertNotNull(fastDateFormat32);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertNotNull(fastDateFormat34);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertNotNull(fastDateFormat36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(fastDateFormat43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(fastDateFormat46);
        org.junit.Assert.assertNotNull(fastDateFormat50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str52.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str53.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale54);
        org.junit.Assert.assertNotNull(fastDateFormat55);
        org.junit.Assert.assertNotNull(fastDateFormat60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str62.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str63.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale64);
        org.junit.Assert.assertNotNull(fastDateFormat65);
        org.junit.Assert.assertNotNull(fastDateFormat66);
        org.junit.Assert.assertNotNull(fastDateFormat67);
        org.junit.Assert.assertNotNull(fastDateFormat68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(locale70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "FastDateFormat[]" + "'", str71.equals("FastDateFormat[]"));
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test53");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat6 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str7 = fastDateFormat6.getPattern();
        java.util.TimeZone timeZone8 = fastDateFormat6.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone8);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone8);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone8);
        java.util.Locale locale12 = fastDateFormat11.getLocale();
        java.util.TimeZone timeZone13 = fastDateFormat11.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str16 = fastDateFormat15.toString();
        boolean boolean18 = fastDateFormat15.equals((java.lang.Object) 'a');
        java.lang.String str19 = fastDateFormat15.getPattern();
        java.util.Locale locale20 = fastDateFormat15.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getInstance("d' de 'MMMM' de 'yyyy HH'h'mm'min'ss's' z", timeZone13, locale20);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getInstance("FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy H'h'm'min's's' z]", locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(locale12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "FastDateFormat[]" + "'", str16.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(locale20);
        org.junit.Assert.assertNotNull(fastDateFormat21);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test54");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int8 = fastDateFormat7.getMaxLengthEstimate();
        java.util.TimeZone timeZone9 = fastDateFormat7.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone9);
        java.util.TimeZone timeZone13 = null;
        java.util.Locale locale14 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone13, locale14);
        java.lang.String str17 = fastDateFormat15.format((long) 0);
        java.lang.String str18 = fastDateFormat15.getPattern();
        java.util.Locale locale19 = fastDateFormat15.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale19);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, timeZone9, locale19);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", locale19);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat23 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 1, 0, locale19);
        java.util.Locale locale24 = fastDateFormat23.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat25 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale24);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, locale24);
        int int27 = fastDateFormat26.getMaxLengthEstimate();
        java.lang.Class<?> wildcardClass28 = fastDateFormat26.getClass();
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14 + "'", int8 == 14);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str17.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str18.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale19);
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat23);
        org.junit.Assert.assertNotNull(locale24);
        org.junit.Assert.assertNotNull(fastDateFormat25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 40 + "'", int27 == 40);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test55");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat2 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, 3);
        java.lang.Class<?> wildcardClass3 = fastDateFormat2.getClass();
        org.junit.Assert.assertNotNull(fastDateFormat2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test56");
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone3, locale4);
        java.lang.String str6 = fastDateFormat5.getPattern();
        java.lang.String str7 = fastDateFormat5.toString();
        java.util.TimeZone timeZone8 = fastDateFormat5.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 1, timeZone8);
        java.util.Locale locale10 = fastDateFormat9.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("HH:mm", locale10);
        java.lang.String str12 = fastDateFormat11.getPattern();
        java.text.ParsePosition parsePosition14 = null;
        try {
            java.lang.Object obj15 = fastDateFormat11.parseObject("FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy HH:mm:ss]", parsePosition14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str6.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]" + "'", str7.equals("FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "HH:mm" + "'", str12.equals("HH:mm"));
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test57");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str6 = fastDateFormat5.getPattern();
        java.util.TimeZone timeZone7 = fastDateFormat5.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone7);
        java.util.Locale locale9 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone7, locale9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, timeZone7);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getInstance("FastDateFormat[dd/MM/yyyy HH'h'mm'min'ss's' z]", timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test58");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str8 = fastDateFormat7.getPattern();
        java.util.TimeZone timeZone9 = fastDateFormat7.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone9);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str20 = fastDateFormat19.getPattern();
        java.util.TimeZone timeZone21 = fastDateFormat19.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone21);
        java.util.TimeZone timeZone24 = null;
        java.util.Locale locale25 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone24, locale25);
        java.lang.String str28 = fastDateFormat26.format((long) 0);
        java.lang.String str29 = fastDateFormat26.getPattern();
        java.util.Locale locale30 = fastDateFormat26.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat31 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone21, locale30);
        java.util.TimeZone timeZone34 = null;
        java.util.Locale locale35 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat36 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone34, locale35);
        java.lang.String str38 = fastDateFormat36.format((long) 0);
        java.lang.String str39 = fastDateFormat36.getPattern();
        java.util.Locale locale40 = fastDateFormat36.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat41 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat42 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone21, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat43 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat44 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (byte) 0, 1, timeZone9, locale40);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat51 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str52 = fastDateFormat51.getPattern();
        java.util.TimeZone timeZone53 = fastDateFormat51.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat54 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone53);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat55 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, (int) (byte) 0, timeZone53);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat57 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str58 = fastDateFormat57.toString();
        boolean boolean60 = fastDateFormat57.equals((java.lang.Object) 'a');
        java.lang.String str61 = fastDateFormat57.getPattern();
        java.util.Locale locale62 = fastDateFormat57.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat63 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, timeZone53, locale62);
        java.util.TimeZone timeZone66 = null;
        java.util.Locale locale67 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat68 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone66, locale67);
        java.lang.String str70 = fastDateFormat68.format((long) 0);
        java.lang.String str71 = fastDateFormat68.getPattern();
        java.util.Locale locale72 = fastDateFormat68.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat73 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale72);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat74 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone53, locale72);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat75 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone9, locale72);
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str28.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str29.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertNotNull(fastDateFormat31);
        org.junit.Assert.assertNotNull(fastDateFormat36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str38.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str39.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale40);
        org.junit.Assert.assertNotNull(fastDateFormat41);
        org.junit.Assert.assertNotNull(fastDateFormat42);
        org.junit.Assert.assertNotNull(fastDateFormat43);
        org.junit.Assert.assertNotNull(fastDateFormat44);
        org.junit.Assert.assertNotNull(fastDateFormat51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(fastDateFormat54);
        org.junit.Assert.assertNotNull(fastDateFormat55);
        org.junit.Assert.assertNotNull(fastDateFormat57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "FastDateFormat[]" + "'", str58.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
        org.junit.Assert.assertNotNull(locale62);
        org.junit.Assert.assertNotNull(fastDateFormat63);
        org.junit.Assert.assertNotNull(fastDateFormat68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str70.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str71.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale72);
        org.junit.Assert.assertNotNull(fastDateFormat73);
        org.junit.Assert.assertNotNull(fastDateFormat74);
        org.junit.Assert.assertNotNull(fastDateFormat75);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test59");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str6 = fastDateFormat5.getPattern();
        java.util.TimeZone timeZone7 = fastDateFormat5.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone7);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone7);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone7);
        java.util.Locale locale11 = fastDateFormat10.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale11);
        java.text.ParsePosition parsePosition14 = null;
        try {
            java.lang.Object obj15 = fastDateFormat12.parseObject("FastDateFormat[dd/MM/yyyy]", parsePosition14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(locale11);
        org.junit.Assert.assertNotNull(fastDateFormat12);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test60");
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat2 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test61");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int8 = fastDateFormat7.getMaxLengthEstimate();
        java.util.TimeZone timeZone9 = fastDateFormat7.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone9);
        java.util.TimeZone timeZone13 = null;
        java.util.Locale locale14 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone13, locale14);
        java.lang.String str17 = fastDateFormat15.format((long) 0);
        java.lang.String str18 = fastDateFormat15.getPattern();
        java.util.Locale locale19 = fastDateFormat15.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale19);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, timeZone9, locale19);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", locale19);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat23 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 1, 0, locale19);
        java.util.Locale locale24 = fastDateFormat23.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat25 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale24);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, locale24);
        java.text.ParsePosition parsePosition28 = null;
        try {
            java.lang.Object obj29 = fastDateFormat26.parseObject("1 de Janeiro de 1970 01h00min00s CET", parsePosition28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14 + "'", int8 == 14);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(fastDateFormat10);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str17.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str18.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale19);
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat23);
        org.junit.Assert.assertNotNull(locale24);
        org.junit.Assert.assertNotNull(fastDateFormat25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test62");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str9 = fastDateFormat8.getPattern();
        java.util.TimeZone timeZone10 = fastDateFormat8.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone10);
        java.util.TimeZone timeZone13 = null;
        java.util.Locale locale14 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat15 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone13, locale14);
        java.lang.String str17 = fastDateFormat15.format((long) 0);
        java.lang.String str18 = fastDateFormat15.getPattern();
        java.util.Locale locale19 = fastDateFormat15.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone10, locale19);
        java.util.TimeZone timeZone23 = null;
        java.util.Locale locale24 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat25 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone23, locale24);
        java.lang.String str27 = fastDateFormat25.format((long) 0);
        java.lang.String str28 = fastDateFormat25.getPattern();
        java.util.Locale locale29 = fastDateFormat25.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat30 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale29);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat31 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone10, locale29);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat32 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, locale29);
        java.util.TimeZone timeZone33 = fastDateFormat32.getTimeZone();
        java.util.TimeZone timeZone35 = null;
        java.util.Locale locale36 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat37 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone35, locale36);
        java.lang.String str39 = fastDateFormat37.format((long) 0);
        java.lang.String str40 = fastDateFormat37.getPattern();
        java.util.Locale locale41 = fastDateFormat37.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat42 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone33, locale41);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat43 = org.apache.commons.lang3.time.FastDateFormat.getInstance("01:00", timeZone33);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str17.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str18.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale19);
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertNotNull(fastDateFormat25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str27.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str28.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertNotNull(fastDateFormat30);
        org.junit.Assert.assertNotNull(fastDateFormat31);
        org.junit.Assert.assertNotNull(fastDateFormat32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(fastDateFormat37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str39.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str40.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale41);
        org.junit.Assert.assertNotNull(fastDateFormat42);
        org.junit.Assert.assertNotNull(fastDateFormat43);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test63");
        java.util.TimeZone timeZone3 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale6 = fastDateFormat5.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone3, locale6);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, locale6);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", locale6);
        boolean boolean10 = fastDateFormat9.getTimeZoneOverridesCalendar();
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertNotNull(locale6);
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test64");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0);
        try {
            java.lang.Object obj3 = fastDateFormat1.parseObject("HH'h'mm'min'ss's' z");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat1);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test65");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat2 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str3 = fastDateFormat2.getPattern();
        java.util.TimeZone timeZone4 = fastDateFormat2.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone4);
        java.lang.Object obj6 = fastDateFormat5.clone();
        java.util.Locale locale9 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 2, locale9);
        try {
            java.lang.String str11 = fastDateFormat5.format((java.lang.Object) locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown class: <null>");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(fastDateFormat10);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test66");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat6 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str7 = fastDateFormat6.getPattern();
        java.util.TimeZone timeZone8 = fastDateFormat6.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone8);
        java.util.TimeZone timeZone11 = null;
        java.util.Locale locale12 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat13 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone11, locale12);
        java.lang.String str15 = fastDateFormat13.format((long) 0);
        java.lang.String str16 = fastDateFormat13.getPattern();
        java.util.Locale locale17 = fastDateFormat13.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone8, locale17);
        java.util.TimeZone timeZone22 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat24 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale25 = fastDateFormat24.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone22, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, timeZone8, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat29 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone8);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat30 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(8, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal date style 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertNotNull(fastDateFormat13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str15.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str16.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale17);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertNotNull(fastDateFormat24);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertNotNull(fastDateFormat29);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test67");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str2 = fastDateFormat1.toString();
        java.lang.Object obj3 = fastDateFormat1.clone();
        java.lang.String str5 = fastDateFormat1.format((long) 8);
        java.util.Calendar calendar6 = null;
        java.lang.String str7 = fastDateFormat1.format(calendar6);
        java.util.TimeZone timeZone8 = fastDateFormat1.getTimeZone();
        boolean boolean9 = fastDateFormat1.getTimeZoneOverridesCalendar();
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "FastDateFormat[]" + "'", str2.equals("FastDateFormat[]"));
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test68");
        java.util.TimeZone timeZone3 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat4 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone3);
        java.lang.String str5 = fastDateFormat4.getPattern();
        java.lang.StringBuffer stringBuffer7 = null;
        java.lang.StringBuffer stringBuffer8 = fastDateFormat4.format((long) (short) 0, stringBuffer7);
        java.util.Locale locale9 = fastDateFormat4.getLocale();
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) 'a', 2, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal date style 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(stringBuffer8);
        org.junit.Assert.assertNotNull(locale9);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test69");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat6 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str7 = fastDateFormat6.getPattern();
        java.util.TimeZone timeZone8 = fastDateFormat6.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone8);
        java.util.TimeZone timeZone11 = null;
        java.util.Locale locale12 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat13 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone11, locale12);
        java.lang.String str15 = fastDateFormat13.format((long) 0);
        java.lang.String str16 = fastDateFormat13.getPattern();
        java.util.Locale locale17 = fastDateFormat13.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone8, locale17);
        java.util.TimeZone timeZone22 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat24 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale25 = fastDateFormat24.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone22, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, timeZone8, locale25);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat29 = org.apache.commons.lang3.time.FastDateFormat.getInstance("d' de 'MMMM' de 'yyyy HH'h'mm'min'ss's' z", timeZone8);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat30 = org.apache.commons.lang3.time.FastDateFormat.getInstance("dd/MM/yyyy", timeZone8);
        org.junit.Assert.assertNotNull(fastDateFormat6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertNotNull(fastDateFormat13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str15.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str16.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale17);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertNotNull(fastDateFormat24);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertNotNull(fastDateFormat29);
        org.junit.Assert.assertNotNull(fastDateFormat30);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test70");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getInstance();
        int int6 = fastDateFormat5.getMaxLengthEstimate();
        java.util.TimeZone timeZone7 = fastDateFormat5.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone7);
        java.util.TimeZone timeZone11 = null;
        java.util.Locale locale12 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat13 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone11, locale12);
        java.lang.String str15 = fastDateFormat13.format((long) 0);
        java.lang.String str16 = fastDateFormat13.getPattern();
        java.util.Locale locale17 = fastDateFormat13.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat18 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale17);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, timeZone7, locale17);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", locale17);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(2, 1, locale17);
        boolean boolean22 = fastDateFormat21.getTimeZoneOverridesCalendar();
        boolean boolean23 = fastDateFormat21.getTimeZoneOverridesCalendar();
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 14 + "'", int6 == 14);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertNotNull(fastDateFormat13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str15.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str16.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale17);
        org.junit.Assert.assertNotNull(fastDateFormat18);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test71");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str2 = fastDateFormat1.toString();
        java.util.Calendar calendar3 = null;
        java.lang.String str4 = fastDateFormat1.format(calendar3);
        java.util.Calendar calendar5 = null;
        java.lang.String str6 = fastDateFormat1.format(calendar5);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat13 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str14 = fastDateFormat13.getPattern();
        java.util.TimeZone timeZone15 = fastDateFormat13.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone15);
        java.util.TimeZone timeZone20 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.util.Locale locale23 = fastDateFormat22.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat24 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone20, locale23);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat25 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 0, (int) (byte) 1, locale23);
        java.util.Locale locale26 = fastDateFormat25.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat27 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (short) 0, timeZone15, locale26);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat33 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str34 = fastDateFormat33.getPattern();
        java.util.TimeZone timeZone35 = fastDateFormat33.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat36 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone35);
        java.util.TimeZone timeZone38 = null;
        java.util.Locale locale39 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat40 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone38, locale39);
        java.lang.String str42 = fastDateFormat40.format((long) 0);
        java.lang.String str43 = fastDateFormat40.getPattern();
        java.util.Locale locale44 = fastDateFormat40.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat45 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone35, locale44);
        java.util.TimeZone timeZone48 = null;
        java.util.Locale locale49 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat50 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone48, locale49);
        java.lang.String str52 = fastDateFormat50.format((long) 0);
        java.lang.String str53 = fastDateFormat50.getPattern();
        java.util.Locale locale54 = fastDateFormat50.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat55 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale54);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat56 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone35, locale54);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat57 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, 3, timeZone15, locale54);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat58 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", locale54);
        boolean boolean59 = fastDateFormat1.equals((java.lang.Object) fastDateFormat58);
        java.util.Date date60 = null;
        try {
            java.lang.String str61 = fastDateFormat1.format(date60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "FastDateFormat[]" + "'", str2.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(fastDateFormat13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(locale23);
        org.junit.Assert.assertNotNull(fastDateFormat24);
        org.junit.Assert.assertNotNull(fastDateFormat25);
        org.junit.Assert.assertNotNull(locale26);
        org.junit.Assert.assertNotNull(fastDateFormat27);
        org.junit.Assert.assertNotNull(fastDateFormat33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(fastDateFormat36);
        org.junit.Assert.assertNotNull(fastDateFormat40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str42.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str43.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale44);
        org.junit.Assert.assertNotNull(fastDateFormat45);
        org.junit.Assert.assertNotNull(fastDateFormat50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str52.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str53.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale54);
        org.junit.Assert.assertNotNull(fastDateFormat55);
        org.junit.Assert.assertNotNull(fastDateFormat56);
        org.junit.Assert.assertNotNull(fastDateFormat57);
        org.junit.Assert.assertNotNull(fastDateFormat58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test72");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat8 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str9 = fastDateFormat8.getPattern();
        java.util.TimeZone timeZone10 = fastDateFormat8.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat11 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone10);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone10);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat17 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str18 = fastDateFormat17.getPattern();
        java.util.TimeZone timeZone19 = fastDateFormat17.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat20 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone19);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone19);
        java.lang.StringBuffer stringBuffer23 = null;
        java.lang.StringBuffer stringBuffer24 = fastDateFormat21.format((long) 2, stringBuffer23);
        boolean boolean26 = fastDateFormat21.equals((java.lang.Object) 3);
        java.util.Locale locale27 = fastDateFormat21.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat28 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale27);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat29 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(0, (int) (short) 1, timeZone10, locale27);
        java.util.TimeZone timeZone33 = null;
        java.util.Locale locale34 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat35 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone33, locale34);
        java.util.Locale locale36 = fastDateFormat35.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat37 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(3, locale36);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat38 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy HH:mm:ss", locale36);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat39 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone10, locale36);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat45 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str46 = fastDateFormat45.toString();
        java.lang.Object obj47 = fastDateFormat45.clone();
        java.lang.StringBuffer stringBuffer49 = null;
        java.lang.StringBuffer stringBuffer50 = fastDateFormat45.format((long) 'a', stringBuffer49);
        java.lang.Object obj51 = fastDateFormat45.clone();
        java.util.TimeZone timeZone52 = fastDateFormat45.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat53 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(3, 1, timeZone52);
        java.util.TimeZone timeZone58 = null;
        java.util.Locale locale59 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat60 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone58, locale59);
        java.lang.String str61 = fastDateFormat60.getPattern();
        java.lang.String str62 = fastDateFormat60.toString();
        java.util.TimeZone timeZone63 = fastDateFormat60.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat64 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 1, timeZone63);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat65 = org.apache.commons.lang3.time.FastDateFormat.getInstance("d' de 'MMMM' de 'yyyy HH'h'mm'min'ss's' z", timeZone63);
        java.util.TimeZone timeZone68 = null;
        java.util.Locale locale69 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat70 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone68, locale69);
        java.lang.String str72 = fastDateFormat70.format((long) 0);
        java.lang.String str73 = fastDateFormat70.getPattern();
        java.util.Locale locale74 = fastDateFormat70.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat75 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale74);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat76 = org.apache.commons.lang3.time.FastDateFormat.getInstance("d' de 'MMMM' de 'yyyy HH'h'mm'min'ss's' z", timeZone63, locale74);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat77 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, timeZone52, locale74);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat78 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale74);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat79 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(16, (int) (short) 1, timeZone10, locale74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal date style 16");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(fastDateFormat11);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertNotNull(fastDateFormat17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(fastDateFormat20);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertNull(stringBuffer24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertNotNull(fastDateFormat28);
        org.junit.Assert.assertNotNull(fastDateFormat29);
        org.junit.Assert.assertNotNull(fastDateFormat35);
        org.junit.Assert.assertNotNull(locale36);
        org.junit.Assert.assertNotNull(fastDateFormat37);
        org.junit.Assert.assertNotNull(fastDateFormat38);
        org.junit.Assert.assertNotNull(fastDateFormat39);
        org.junit.Assert.assertNotNull(fastDateFormat45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "FastDateFormat[]" + "'", str46.equals("FastDateFormat[]"));
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNull(stringBuffer50);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNotNull(fastDateFormat53);
        org.junit.Assert.assertNotNull(fastDateFormat60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str61.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]" + "'", str62.equals("FastDateFormat[EEEE, d' de 'MMMM' de 'yyyy]"));
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNotNull(fastDateFormat64);
        org.junit.Assert.assertNotNull(fastDateFormat65);
        org.junit.Assert.assertNotNull(fastDateFormat70);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str72.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str73.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale74);
        org.junit.Assert.assertNotNull(fastDateFormat75);
        org.junit.Assert.assertNotNull(fastDateFormat76);
        org.junit.Assert.assertNotNull(fastDateFormat77);
        org.junit.Assert.assertNotNull(fastDateFormat78);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test73");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat1 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str2 = fastDateFormat1.toString();
        java.lang.Object obj3 = fastDateFormat1.clone();
        java.lang.StringBuffer stringBuffer5 = null;
        java.lang.StringBuffer stringBuffer6 = fastDateFormat1.format((long) 'a', stringBuffer5);
        java.lang.Object obj7 = fastDateFormat1.clone();
        java.util.Calendar calendar8 = null;
        java.lang.StringBuffer stringBuffer9 = null;
        java.lang.StringBuffer stringBuffer10 = fastDateFormat1.format(calendar8, stringBuffer9);
        java.lang.String str11 = fastDateFormat1.toString();
        java.lang.String str12 = fastDateFormat1.getPattern();
        java.util.TimeZone timeZone13 = fastDateFormat1.getTimeZone();
        org.junit.Assert.assertNotNull(fastDateFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "FastDateFormat[]" + "'", str2.equals("FastDateFormat[]"));
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(stringBuffer6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(stringBuffer10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "FastDateFormat[]" + "'", str11.equals("FastDateFormat[]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test74");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat4 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str5 = fastDateFormat4.getPattern();
        java.util.TimeZone timeZone6 = fastDateFormat4.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat7 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone6);
        java.util.Locale locale8 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone6, locale8);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat10 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(22, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal date style 22");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(fastDateFormat7);
        org.junit.Assert.assertNotNull(fastDateFormat9);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test75");
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat5 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone3, locale4);
        java.lang.String str7 = fastDateFormat5.format((long) 0);
        java.util.TimeZone timeZone8 = fastDateFormat5.getTimeZone();
        java.util.TimeZone timeZone9 = fastDateFormat5.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat19 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str20 = fastDateFormat19.getPattern();
        java.util.TimeZone timeZone21 = fastDateFormat19.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat22 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone21);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat23 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone21);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat24 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance(0, timeZone21);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat31 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str32 = fastDateFormat31.getPattern();
        java.util.TimeZone timeZone33 = fastDateFormat31.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat34 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone33);
        java.util.TimeZone timeZone36 = null;
        java.util.Locale locale37 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat38 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone36, locale37);
        java.lang.String str40 = fastDateFormat38.format((long) 0);
        java.lang.String str41 = fastDateFormat38.getPattern();
        java.util.Locale locale42 = fastDateFormat38.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat43 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone33, locale42);
        java.util.TimeZone timeZone46 = null;
        java.util.Locale locale47 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat48 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone46, locale47);
        java.lang.String str50 = fastDateFormat48.format((long) 0);
        java.lang.String str51 = fastDateFormat48.getPattern();
        java.util.Locale locale52 = fastDateFormat48.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat53 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale52);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat54 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone33, locale52);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat55 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, locale52);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat56 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (byte) 0, 1, timeZone21, locale52);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat57 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 1, timeZone21);
        java.util.TimeZone timeZone58 = fastDateFormat57.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat59 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 1, timeZone58);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat64 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str65 = fastDateFormat64.getPattern();
        java.util.TimeZone timeZone66 = fastDateFormat64.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat67 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone66);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat68 = org.apache.commons.lang3.time.FastDateFormat.getInstance("", timeZone66);
        java.lang.StringBuffer stringBuffer70 = null;
        java.lang.StringBuffer stringBuffer71 = fastDateFormat68.format((long) 2, stringBuffer70);
        boolean boolean73 = fastDateFormat68.equals((java.lang.Object) 3);
        java.util.Locale locale74 = fastDateFormat68.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat75 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance(0, locale74);
        java.lang.Class<?> wildcardClass76 = locale74.getClass();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat77 = org.apache.commons.lang3.time.FastDateFormat.getInstance("01:00", timeZone58, locale74);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat78 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (byte) 0, 33, timeZone9, locale74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 33");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str7.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(fastDateFormat19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(fastDateFormat22);
        org.junit.Assert.assertNotNull(fastDateFormat23);
        org.junit.Assert.assertNotNull(fastDateFormat24);
        org.junit.Assert.assertNotNull(fastDateFormat31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(fastDateFormat34);
        org.junit.Assert.assertNotNull(fastDateFormat38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str40.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str41.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale42);
        org.junit.Assert.assertNotNull(fastDateFormat43);
        org.junit.Assert.assertNotNull(fastDateFormat48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str50.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str51.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale52);
        org.junit.Assert.assertNotNull(fastDateFormat53);
        org.junit.Assert.assertNotNull(fastDateFormat54);
        org.junit.Assert.assertNotNull(fastDateFormat55);
        org.junit.Assert.assertNotNull(fastDateFormat56);
        org.junit.Assert.assertNotNull(fastDateFormat57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(fastDateFormat59);
        org.junit.Assert.assertNotNull(fastDateFormat64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "" + "'", str65.equals(""));
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNotNull(fastDateFormat67);
        org.junit.Assert.assertNotNull(fastDateFormat68);
        org.junit.Assert.assertNull(stringBuffer71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(locale74);
        org.junit.Assert.assertNotNull(fastDateFormat75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNotNull(fastDateFormat77);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test76");
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat9 = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
        java.lang.String str10 = fastDateFormat9.getPattern();
        java.util.TimeZone timeZone11 = fastDateFormat9.getTimeZone();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat12 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone11);
        java.util.TimeZone timeZone14 = null;
        java.util.Locale locale15 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat16 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone14, locale15);
        java.lang.String str18 = fastDateFormat16.format((long) 0);
        java.lang.String str19 = fastDateFormat16.getPattern();
        java.util.Locale locale20 = fastDateFormat16.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat21 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (short) 0, timeZone11, locale20);
        java.util.TimeZone timeZone24 = null;
        java.util.Locale locale25 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat26 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone24, locale25);
        java.lang.String str28 = fastDateFormat26.format((long) 0);
        java.lang.String str29 = fastDateFormat26.getPattern();
        java.util.Locale locale30 = fastDateFormat26.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat31 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 1, locale30);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat32 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance(1, (int) (short) 0, timeZone11, locale30);
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat33 = org.apache.commons.lang3.time.FastDateFormat.getTimeInstance((int) (byte) 0, locale30);
        java.util.TimeZone timeZone34 = fastDateFormat33.getTimeZone();
        java.util.TimeZone timeZone36 = null;
        java.util.Locale locale37 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat38 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone36, locale37);
        java.lang.String str40 = fastDateFormat38.format((long) 0);
        java.lang.String str41 = fastDateFormat38.getPattern();
        java.util.Locale locale42 = fastDateFormat38.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat43 = org.apache.commons.lang3.time.FastDateFormat.getInstance("EEEE, d' de 'MMMM' de 'yyyy", timeZone34, locale42);
        java.util.TimeZone timeZone46 = null;
        java.util.Locale locale47 = null;
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat48 = org.apache.commons.lang3.time.FastDateFormat.getDateInstance((int) (byte) 0, timeZone46, locale47);
        boolean boolean50 = fastDateFormat48.equals((java.lang.Object) "Quinta-feira, 1 de Janeiro de 1970");
        java.util.Locale locale51 = fastDateFormat48.getLocale();
        org.apache.commons.lang3.time.FastDateFormat fastDateFormat52 = org.apache.commons.lang3.time.FastDateFormat.getInstance("H'h'm'min's's' z", locale51);
        try {
            org.apache.commons.lang3.time.FastDateFormat fastDateFormat53 = org.apache.commons.lang3.time.FastDateFormat.getDateTimeInstance((int) (short) 100, 33, timeZone34, locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal time style 33");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fastDateFormat9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(fastDateFormat12);
        org.junit.Assert.assertNotNull(fastDateFormat16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str18.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str19.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale20);
        org.junit.Assert.assertNotNull(fastDateFormat21);
        org.junit.Assert.assertNotNull(fastDateFormat26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str28.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str29.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertNotNull(fastDateFormat31);
        org.junit.Assert.assertNotNull(fastDateFormat32);
        org.junit.Assert.assertNotNull(fastDateFormat33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(fastDateFormat38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Quinta-feira, 1 de Janeiro de 1970" + "'", str40.equals("Quinta-feira, 1 de Janeiro de 1970"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "EEEE, d' de 'MMMM' de 'yyyy" + "'", str41.equals("EEEE, d' de 'MMMM' de 'yyyy"));
        org.junit.Assert.assertNotNull(locale42);
        org.junit.Assert.assertNotNull(fastDateFormat43);
        org.junit.Assert.assertNotNull(fastDateFormat48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(locale51);
        org.junit.Assert.assertNotNull(fastDateFormat52);
    }
}

