import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray14, (long) ' ');
        java.lang.Short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray25 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray25, 100L, (int) '4');
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray25, (long) (byte) 10);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray18, (java.lang.Object) longArray30);
        long[] longArray34 = org.apache.commons.lang3.ArrayUtils.subarray(longArray30, (int) (byte) 10, (int) (byte) 0);
        long[] longArray36 = org.apache.commons.lang3.ArrayUtils.remove(longArray30, 2);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray36);
        long[] longArray38 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray36);
        java.lang.Short[] shortArray39 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray46 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int49 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray46, 100L, (int) '4');
        long[] longArray51 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray46, (long) (byte) 10);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray39, (java.lang.Object) longArray51);
        long[] longArray55 = org.apache.commons.lang3.ArrayUtils.subarray(longArray51, (int) (byte) 10, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray55);
        java.lang.Long[] longArray57 = org.apache.commons.lang3.ArrayUtils.toObject(longArray55);
        boolean boolean58 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray14, longArray55);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray55);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(longArray38);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(longArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(longArray55);
        org.junit.Assert.assertNotNull(longArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (-1L), 0, (double) (-1));
        double[] doubleArray19 = new double[] {};
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.add(doubleArray19, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray21);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray21, doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray25);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray27, (double) (byte) 10, 1, 0.0d);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray27);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) '4', (double) 1);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 2, (double) (short) 100);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray41 = org.apache.commons.lang3.ArrayUtils.add(doubleArray39, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray41);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray45 = org.apache.commons.lang3.ArrayUtils.add(doubleArray43, (double) (byte) 10);
        double[] doubleArray46 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray41, doubleArray45);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray45, (double) 3, (int) (byte) 0);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray6, doubleArray45);
        double[] doubleArray51 = new double[] {};
        int int54 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray51, (double) (-1.0f), (double) 1L);
        int int56 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray51, (double) 0);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray59 = org.apache.commons.lang3.ArrayUtils.add(doubleArray57, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray59);
        double[] doubleArray61 = new double[] {};
        double[] doubleArray63 = org.apache.commons.lang3.ArrayUtils.add(doubleArray61, (double) (byte) 10);
        double[] doubleArray64 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray59, doubleArray63);
        double[] doubleArray65 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray63);
        double[] doubleArray67 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray65, (double) (byte) 0);
        boolean boolean68 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray51, doubleArray65);
        double[] doubleArray69 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray51);
        double[] doubleArray72 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray69, 0, (int) '#');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) 100, 100);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '#', 3);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, 10.0f);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray32, 1.0f, (int) (short) 1);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray32);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        long[] longArray4 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray9 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray14 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray19 = new long[] { (byte) 100, 4, 1L, 2 };
        long[][] longArray20 = new long[][] { longArray4, longArray9, longArray14, longArray19 };
        long[] longArray24 = new long[] { 'a', 10, 0 };
        long[] longArray28 = new long[] { 'a', 10, 0 };
        long[] longArray32 = new long[] { 'a', 10, 0 };
        long[] longArray36 = new long[] { 'a', 10, 0 };
        long[] longArray40 = new long[] { 'a', 10, 0 };
        long[] longArray44 = new long[] { 'a', 10, 0 };
        long[][] longArray45 = new long[][] { longArray24, longArray28, longArray32, longArray36, longArray40, longArray44 };
        long[][] longArray46 = org.apache.commons.lang3.ArrayUtils.addAll(longArray20, longArray45);
        long[][] longArray48 = org.apache.commons.lang3.ArrayUtils.remove(longArray46, (int) (short) 0);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertNotNull(longArray40);
        org.junit.Assert.assertNotNull(longArray44);
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertNotNull(longArray48);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        boolean[] booleanArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray0, true, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.clone(intArray13);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray13, 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.add(doubleArray9, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.add(doubleArray13, (double) (byte) 10);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray11, doubleArray15);
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray11, 0, 0);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray19, (double) (-1), (int) (short) 1);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray8, doubleArray19);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray19, (double) 10.0f, (double) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray15, 'a', (int) ' ');
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray15, 'a');
        char[] charArray26 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray26, '#');
        char[] charArray29 = new char[] {};
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray26, charArray29);
        char[] charArray31 = org.apache.commons.lang3.ArrayUtils.addAll(charArray20, charArray26);
        char[] charArray34 = org.apache.commons.lang3.ArrayUtils.add(charArray31, (int) (short) 0, '#');
        int int36 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray34, '#');
        char[] charArray39 = org.apache.commons.lang3.ArrayUtils.add(charArray34, 3, ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(charArray39);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 1.0f, 0, (double) '4');
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) '4', (double) (byte) 0);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (byte) 100, (int) '4', (double) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray2, 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray2, (double) (short) -1);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray14, (double) 10L);
        java.lang.Double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray14);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray19);
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray20);
        double[] doubleArray22 = null;
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray20, doubleArray22);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray10, false, (int) (short) 10);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        try {
            byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.add(byteArray2, (int) (short) 1, (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        char[][] charArray0 = new char[][] {};
        java.lang.Object[] objArray2 = null;
        java.lang.Character[] charArray6 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6);
        java.lang.Character[] charArray8 = org.apache.commons.lang3.ArrayUtils.toObject(charArray7);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray2, (java.lang.Object) charArray7);
        java.lang.Character[] charArray10 = org.apache.commons.lang3.ArrayUtils.toObject(charArray7);
        char[][] charArray11 = org.apache.commons.lang3.ArrayUtils.add(charArray0, 0, charArray7);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray7, ' ');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray4, (float) ' ', (int) 'a');
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.clone(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean[] booleanArray8 = new boolean[] {};
        boolean[] booleanArray13 = new boolean[] { true, false, false, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, true, 1);
        boolean[] booleanArray31 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) boolean33);
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 10);
        short[] shortArray37 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray37);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray11, (long) 3);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray11, (long) 4, (int) (short) 0);
        try {
            long[] longArray19 = org.apache.commons.lang3.ArrayUtils.add(longArray11, (int) '4', 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "1", "1" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = org.apache.commons.lang3.ArrayUtils.subarray((java.lang.Comparable<java.lang.String>[]) strArray4, 10, (int) (short) -1);
        java.lang.Byte[] byteArray13 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray19 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray25 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray31 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray37 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[][] byteArray38 = new java.lang.Byte[][] { byteArray13, byteArray19, byteArray25, byteArray31, byteArray37 };
        java.lang.Byte[] byteArray44 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray50 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray56 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray62 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray68 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[][] byteArray69 = new java.lang.Byte[][] { byteArray44, byteArray50, byteArray56, byteArray62, byteArray68 };
        java.lang.Byte[][][] byteArray70 = new java.lang.Byte[][][] { byteArray38, byteArray69 };
        java.lang.Byte[][][] byteArray72 = org.apache.commons.lang3.ArrayUtils.remove(byteArray70, (int) (byte) 1);
        boolean boolean73 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strArray4, (java.lang.Object[]) byteArray72);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertNotNull(byteArray62);
        org.junit.Assert.assertNotNull(byteArray68);
        org.junit.Assert.assertNotNull(byteArray69);
        org.junit.Assert.assertNotNull(byteArray70);
        org.junit.Assert.assertNotNull(byteArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) '4');
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 100);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) (byte) 1, (double) (-1L));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        java.lang.Double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 10L);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Long[] longArray3 = new java.lang.Long[] { 1L, 100L, 1L };
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray3);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray3);
        byte[] byteArray6 = new byte[] {};
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        byte[] byteArray8 = new byte[] {};
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray10);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray10);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray7, byteArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray7, (byte) -1);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.add(byteArray18, (byte) -1);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray18, (byte) 0);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray3, (java.lang.Object) byteArray22, 2);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.clone(byteArray22);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains(byteArray22, (byte) 10);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0, (int) (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray6, (byte) -1);
        int int14 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) byteArray6);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, 100, 100 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (short) 100);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        org.apache.commons.lang3.ArrayUtils.reverse(charArray15);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean[] booleanArray8 = new boolean[] {};
        boolean[] booleanArray13 = new boolean[] { true, false, false, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, true, 1);
        boolean[] booleanArray31 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) boolean33);
        byte[] byteArray37 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray38 = new byte[][] { byteArray37 };
        byte[][] byteArray39 = org.apache.commons.lang3.ArrayUtils.clone(byteArray38);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray5, (java.lang.Object) byteArray39);
        short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray43 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray41, (short) -1);
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray43);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertNotNull(shortArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray9, (byte) -1, (int) (short) -1);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray4, (float) ' ', (int) 'a');
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(floatArray4, (float) (byte) 1);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        java.lang.Integer[] intArray11 = org.apache.commons.lang3.ArrayUtils.toObject(intArray5);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray11);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        float[] floatArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray0, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.Long[] longArray3 = new java.lang.Long[] { 1L, 100L, 1L };
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray3);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray3);
        byte[] byteArray6 = new byte[] {};
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        byte[] byteArray8 = new byte[] {};
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray10);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray10);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray7, byteArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray7, (byte) -1);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.add(byteArray18, (byte) -1);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray18, (byte) 0);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray3, (java.lang.Object) byteArray22, 2);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.clone(byteArray22);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray22, (byte) 100);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray27);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray16);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray16);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray16);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray9);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray10, (short) -1);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) (byte) 100);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray12, shortArray17);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray12, (short) (byte) 10, (int) '#');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        try {
            int[] intArray23 = org.apache.commons.lang3.ArrayUtils.remove(intArray20, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.clone(longArray12);
        long[] longArray21 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray21, 100L, (int) '4');
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.subarray(longArray21, (int) (byte) 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray21);
        long[] longArray29 = org.apache.commons.lang3.ArrayUtils.addAll(longArray12, longArray21);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray29);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray0);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 3, 1, (double) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) '4');
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.subarray(intArray5, (int) (short) 0, 6);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.remove(intArray5, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) '4');
        java.lang.Double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray2);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray0);
        short[] shortArray2 = null;
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray2);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        java.lang.Long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toObject(longArray7);
        java.lang.Class<?> wildcardClass12 = longArray11.getClass();
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) shortArray0, (java.lang.Object[]) longArray11);
        java.lang.String str15 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) longArray11, "0");
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{10,-1,1,32,100,-1}" + "'", str15.equals("{10,-1,1,32,100,-1}"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray10.getClass();
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray12, true, 10);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) longArray10, (java.lang.Object) true);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10, (long) 3);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(longArray18);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        java.lang.String[] strArray10 = null;
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        java.lang.String[] strArray21 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray10, (java.lang.Object) intArray20);
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, (int) '4');
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains(intArray20, 1);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (short) 0, 3);
        java.lang.Integer[] intArray29 = org.apache.commons.lang3.ArrayUtils.toObject(intArray20);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNull(strArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray7, (short) 1, (int) 'a');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        short[] shortArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray0, (short) 100, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, false);
        java.lang.Boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray9);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray10, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray10, (int) (byte) 1);
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray12, (int) 'a', 100);
        boolean[] booleanArray16 = null;
        boolean[] booleanArray17 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray16);
        boolean[] booleanArray18 = new boolean[] {};
        boolean[] booleanArray23 = new boolean[] { true, false, false, true };
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray23);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray23, false);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray23);
        boolean[] booleanArray29 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray23, false);
        boolean[] booleanArray30 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray23);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray17, booleanArray30);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3);
        java.lang.Class<?> wildcardClass5 = byteArray3.getClass();
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3, (byte) 10);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray8, (int) (byte) 0, 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray7, byteArray11);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) (byte) 0);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray4);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray4, (short) (byte) 0, 2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.String str1 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) wildcardClassArray0);
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{}" + "'", str1.equals("{}"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray5);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray5, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray3 = new byte[][] { byteArray2 };
        byte[][] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray3);
        byte[][] byteArray7 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray4, 5, (int) (byte) 0);
        java.lang.String str9 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) byteArray4, "hi!");
        short[] shortArray14 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray14);
        int int16 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) shortArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) byteArray4, (java.lang.Object[]) shortArray15);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{{-1,1}}" + "'", str9.equals("{{-1,1}}"));
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray28 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray28, 100L, (int) '4');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray28, (long) (byte) 10);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray21, (java.lang.Object) longArray33);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray33, (int) (byte) 10, (int) (byte) 0);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.add(longArray37, (long) (byte) 1);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) 100, 100);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray37);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray45);
        long[] longArray49 = org.apache.commons.lang3.ArrayUtils.subarray(longArray45, 3, (int) (short) 1);
        boolean boolean51 = org.apache.commons.lang3.ArrayUtils.contains(longArray45, (long) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(longArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.Float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        int[] intArray7 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray7, 1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray7, (int) ' ', (int) (short) 100);
        int[] intArray18 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray18, 1);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.addAll(intArray18, intArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray7, intArray22);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray22, (int) (byte) 0);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray22, 1);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.add(intArray27, (int) '4');
        java.lang.Class<?> wildcardClass30 = intArray27.getClass();
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.remove(intArray27, 3);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray0, (java.lang.Object) intArray27, 1);
        float[] floatArray35 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(floatArray35);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray14, (long) ' ');
        java.lang.Short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray25 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray25, 100L, (int) '4');
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray25, (long) (byte) 10);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray18, (java.lang.Object) longArray30);
        long[] longArray34 = org.apache.commons.lang3.ArrayUtils.subarray(longArray30, (int) (byte) 10, (int) (byte) 0);
        long[] longArray36 = org.apache.commons.lang3.ArrayUtils.remove(longArray30, 2);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray36);
        long[] longArray38 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray36);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray14);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(longArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        float[] floatArray0 = new float[] {};
        float[] floatArray1 = new float[] {};
        float[] floatArray2 = new float[] {};
        float[] floatArray3 = new float[] {};
        float[][] floatArray4 = new float[][] { floatArray0, floatArray1, floatArray2, floatArray3 };
        float[] floatArray5 = new float[] {};
        float[] floatArray6 = new float[] {};
        float[] floatArray7 = new float[] {};
        float[] floatArray8 = new float[] {};
        float[][] floatArray9 = new float[][] { floatArray5, floatArray6, floatArray7, floatArray8 };
        float[] floatArray10 = new float[] {};
        float[] floatArray11 = new float[] {};
        float[] floatArray12 = new float[] {};
        float[] floatArray13 = new float[] {};
        float[][] floatArray14 = new float[][] { floatArray10, floatArray11, floatArray12, floatArray13 };
        float[] floatArray15 = new float[] {};
        float[] floatArray16 = new float[] {};
        float[] floatArray17 = new float[] {};
        float[] floatArray18 = new float[] {};
        float[][] floatArray19 = new float[][] { floatArray15, floatArray16, floatArray17, floatArray18 };
        float[][][] floatArray20 = new float[][][] { floatArray4, floatArray9, floatArray14, floatArray19 };
        float[][][] floatArray21 = new float[][][] {};
        float[][][] floatArray22 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray20, floatArray21);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) (byte) 0, (int) (short) 10);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.add(floatArray17, (float) 10L);
        java.lang.Class<?> wildcardClass20 = floatArray19.getClass();
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.add(floatArray19, 1, 0.0f);
        int int24 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) floatArray23);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.clone(intArray4);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, 1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        int[] intArray19 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray19, 1);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray19, (int) ' ', (int) (short) 100);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray19);
        try {
            int[] intArray28 = org.apache.commons.lang3.ArrayUtils.add(intArray19, (int) '4', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1, 4, 1, 3 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4, (int) (short) 1);
        java.lang.Byte[] byteArray9 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray9);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) intArray4, (java.lang.Object[]) byteArray9);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray9, (byte) 1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = new byte[] {};
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        java.lang.Byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray11);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 1);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray4, byteArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray12);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray10, 100, (int) (short) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray10, 10.0f, (int) (short) 1);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.clone(floatArray10);
        java.lang.Float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray17);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.subarray(longArray6, (int) (byte) 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray12);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray12);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        java.lang.Character[] charArray14 = org.apache.commons.lang3.ArrayUtils.toObject(charArray13);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.subarray(charArray13, (int) (short) 100, 2);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray17);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, true);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, 3, (int) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, true);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        short[] shortArray3 = new short[] { (byte) 100, (short) -1, (short) 1 };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray3, (short) 0, 1);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray3, (short) (byte) 0, 0);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray3, (short) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(shortArray11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray12, (long) (byte) 10);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.clone(longArray12);
        java.lang.Class<?> wildcardClass25 = longArray24.getClass();
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '4', '#' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3, ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean[] booleanArray28 = new boolean[] { true, false };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray28, true, (int) '4');
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray28, false, (int) (byte) 0);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray28, false);
        boolean[] booleanArray39 = new boolean[] { true, false };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray39, true, (int) '4');
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray28, booleanArray39);
        boolean[] booleanArray45 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray39, false);
        boolean[] booleanArray46 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray6, booleanArray45);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, false);
        boolean[] booleanArray49 = new boolean[] {};
        boolean[] booleanArray54 = new boolean[] { true, false, false, true };
        boolean[] booleanArray55 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray49, booleanArray54);
        int int57 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray54, false);
        boolean[] booleanArray58 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray54);
        boolean[] booleanArray60 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray54, false);
        boolean[] booleanArray61 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray54);
        boolean[] booleanArray62 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray6, booleanArray54);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(booleanArray45);
        org.junit.Assert.assertNotNull(booleanArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(booleanArray49);
        org.junit.Assert.assertNotNull(booleanArray54);
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(booleanArray58);
        org.junit.Assert.assertNotNull(booleanArray60);
        org.junit.Assert.assertNotNull(booleanArray61);
        org.junit.Assert.assertNotNull(booleanArray62);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray13 = new boolean[] { true, false };
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray13, true, (int) '4');
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray13, false, (int) (byte) 0);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray13, false);
        boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray13, true);
        int int27 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray13, false, 0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        try {
            float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (int) (byte) 100, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.reflect.GenericDeclaration[][] genericDeclarationArray0 = new java.lang.reflect.GenericDeclaration[][] {};
        try {
            java.lang.reflect.GenericDeclaration[][] genericDeclarationArray2 = org.apache.commons.lang3.ArrayUtils.remove(genericDeclarationArray0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(genericDeclarationArray0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) '4');
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, 0);
        java.lang.String[] strArray15 = null;
        int[] intArray21 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray21, 1);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.addAll(intArray21, intArray24);
        java.lang.String[] strArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray15, (java.lang.Object) intArray25);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray25);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNull(strArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray14, (long) ' ');
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.subarray(longArray14, (int) ' ', (int) (byte) 100);
        java.lang.Long[] longArray24 = new java.lang.Long[] { 1L, 100L, 1L };
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray24);
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray24);
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.clone(longArray26);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray14, longArray26);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 5, (int) 'a');
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.subarray(intArray13, (int) (byte) 0, 2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        byte[] byteArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray0, (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray22 = org.apache.commons.lang3.ArrayUtils.add(doubleArray20, (double) (byte) 10);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray18, doubleArray22);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray18);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (byte) 10, 6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray9, (float) 0L);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray9, (float) 1L, (int) (short) 100);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray9, (float) (byte) 0);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 1.0f, 0, (double) '4');
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) '4', (double) (byte) 0);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 100, (-1), (double) 5);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Class<?> wildcardClass28 = intArray25.getClass();
        int[] intArray34 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray34, 1);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray34, (int) ' ', (int) (short) 100);
        int[] intArray45 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int47 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray45, 1);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray49 = org.apache.commons.lang3.ArrayUtils.addAll(intArray45, intArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray34, intArray49);
        int int52 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray49, (int) (byte) 0);
        int[] intArray54 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray49, 1);
        int[] intArray56 = org.apache.commons.lang3.ArrayUtils.add(intArray54, (int) '4');
        java.lang.Integer[] intArray60 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray62 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray60, 2);
        int[] intArray63 = org.apache.commons.lang3.ArrayUtils.addAll(intArray54, intArray62);
        boolean boolean64 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray25, intArray62);
        int int67 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, 5, (int) (byte) 100);
        int int69 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray25, (int) (byte) 1);
        boolean boolean70 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray25);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.remove(intArray5, (int) (short) 0);
        int[] intArray17 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 1);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray17, (int) ' ', (int) (short) 100);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.add(intArray17, 1, (int) 'a');
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray25);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.subarray(intArray5, 6, (-1));
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray2, (byte) 1, (int) '4');
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.add(byteArray2, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(byteArray7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        short[] shortArray0 = null;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.clone(shortArray6);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.add(shortArray8, (short) 1);
        java.lang.Short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray10);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray11, (short) -1);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray0, shortArray13);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.Character[] charArray3 = new java.lang.Character[] { 'a', '#', '#' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray4);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 2);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, 10.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.remove(intArray25, 0);
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.clone(intArray29);
        java.lang.Integer[] intArray31 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray29, intArray32);
        try {
            int[] intArray36 = org.apache.commons.lang3.ArrayUtils.add(intArray32, (int) (short) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray11, (long) (short) 0);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.clone(intArray20);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray26, 0);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray26);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, 10.0d, (double) 3);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (double) '#');
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray17);
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray17, (double) 5, (double) 5);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = new byte[] {};
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = new byte[] {};
        byte[][] byteArray4 = new byte[][] { byteArray0, byteArray1, byteArray2, byteArray3 };
        byte[] byteArray5 = new byte[] {};
        byte[] byteArray6 = new byte[] {};
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = new byte[] {};
        byte[][] byteArray9 = new byte[][] { byteArray5, byteArray6, byteArray7, byteArray8 };
        byte[] byteArray10 = new byte[] {};
        byte[] byteArray11 = new byte[] {};
        byte[] byteArray12 = new byte[] {};
        byte[] byteArray13 = new byte[] {};
        byte[][] byteArray14 = new byte[][] { byteArray10, byteArray11, byteArray12, byteArray13 };
        byte[] byteArray15 = new byte[] {};
        byte[] byteArray16 = new byte[] {};
        byte[] byteArray17 = new byte[] {};
        byte[] byteArray18 = new byte[] {};
        byte[][] byteArray19 = new byte[][] { byteArray15, byteArray16, byteArray17, byteArray18 };
        byte[] byteArray20 = new byte[] {};
        byte[] byteArray21 = new byte[] {};
        byte[] byteArray22 = new byte[] {};
        byte[] byteArray23 = new byte[] {};
        byte[][] byteArray24 = new byte[][] { byteArray20, byteArray21, byteArray22, byteArray23 };
        byte[] byteArray25 = new byte[] {};
        byte[] byteArray26 = new byte[] {};
        byte[] byteArray27 = new byte[] {};
        byte[] byteArray28 = new byte[] {};
        byte[][] byteArray29 = new byte[][] { byteArray25, byteArray26, byteArray27, byteArray28 };
        byte[][][] byteArray30 = new byte[][][] { byteArray4, byteArray9, byteArray14, byteArray19, byteArray24, byteArray29 };
        byte[] byteArray36 = new byte[] { (byte) 10, (byte) 0, (byte) 10, (byte) -1, (byte) 100 };
        byte[] byteArray42 = new byte[] { (byte) 10, (byte) 0, (byte) 10, (byte) -1, (byte) 100 };
        byte[] byteArray48 = new byte[] { (byte) 10, (byte) 0, (byte) 10, (byte) -1, (byte) 100 };
        byte[][] byteArray49 = new byte[][] { byteArray36, byteArray42, byteArray48 };
        byte[] byteArray55 = new byte[] { (byte) 10, (byte) 0, (byte) 10, (byte) -1, (byte) 100 };
        byte[] byteArray61 = new byte[] { (byte) 10, (byte) 0, (byte) 10, (byte) -1, (byte) 100 };
        byte[] byteArray67 = new byte[] { (byte) 10, (byte) 0, (byte) 10, (byte) -1, (byte) 100 };
        byte[][] byteArray68 = new byte[][] { byteArray55, byteArray61, byteArray67 };
        byte[][][] byteArray69 = new byte[][][] { byteArray49, byteArray68 };
        byte[][][] byteArray70 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray30, byteArray69);
        boolean boolean71 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray70);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertNotNull(byteArray67);
        org.junit.Assert.assertNotNull(byteArray68);
        org.junit.Assert.assertNotNull(byteArray69);
        org.junit.Assert.assertNotNull(byteArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[] byteArray13 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[] byteArray20 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[][] byteArray21 = new java.lang.Byte[][] { byteArray6, byteArray13, byteArray20 };
        java.lang.Byte[][] byteArray23 = org.apache.commons.lang3.ArrayUtils.remove(byteArray21, 0);
        float[] floatArray28 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray28, (int) (byte) 100, (int) '4');
        float[] floatArray36 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray36, (int) (byte) 100, (int) '4');
        float[] floatArray46 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray48 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray46, (float) (short) 1);
        float[] floatArray50 = org.apache.commons.lang3.ArrayUtils.add(floatArray48, 0.0f);
        boolean boolean51 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray39, floatArray50);
        float[] floatArray52 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray28, floatArray50);
        int int53 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray21, (java.lang.Object) floatArray50);
        int int55 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray50, (float) (short) 1);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, (double) 2, 0.0d);
        java.lang.String str8 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) boolean7);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "false" + "'", str8.equals("false"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray10.getClass();
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10, (long) (byte) 100);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray14);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray18);
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.add(booleanArray18, false);
        boolean[] booleanArray23 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray21, (int) (short) 0);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray23);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1, 4, 1, 3 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4, (int) (short) 1);
        int[] intArray13 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray13, 1);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray13, (int) ' ', (int) (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray13);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray7, intArray13);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray13);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(charArray4, 'a');
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(charArray4, ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) 1, (int) (short) 100);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) 0, 0);
        try {
            int int14 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) -1, (byte) 1, (byte) 0 };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray4, (byte) 10, 1);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.add(byteArray4, (int) (byte) 1, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(byteArray10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 4);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.add(longArray7, 2, (long) (short) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, (long) (byte) 0);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        java.lang.Integer[] intArray11 = org.apache.commons.lang3.ArrayUtils.toObject(intArray5);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) intArray11);
        long[] longArray18 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.add(longArray18, (long) '4');
        long[] longArray22 = org.apache.commons.lang3.ArrayUtils.add(longArray20, (long) 4);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.subarray(longArray22, 6, 2);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray11, (java.lang.Object) longArray22);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray10, (int) (byte) 1);
        boolean[] booleanArray18 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray18);
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray19, true);
        boolean[] booleanArray22 = new boolean[] {};
        boolean[] booleanArray27 = new boolean[] { true, false, false, true };
        boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray22, booleanArray27);
        boolean[] booleanArray29 = new boolean[] {};
        boolean[] booleanArray34 = new boolean[] { true, false, false, true };
        boolean[] booleanArray35 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray29, booleanArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray28, booleanArray34);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray21, booleanArray28);
        boolean[] booleanArray38 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray12, booleanArray28);
        int int40 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray28, true);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertNotNull(booleanArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        java.lang.Short[] shortArray5 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray7 = new short[] {};
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray7);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray7);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 1);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray9);
        java.lang.Short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray9);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray13);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        float[] floatArray18 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, (int) (byte) 100, (int) '4');
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray9, floatArray18);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, (float) (byte) 0);
        int int27 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray9, (float) '4', (int) (short) 10);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) (byte) 0, (int) (short) 10);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray18 = null;
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray17, floatArray18);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.lang.String[] strArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray0, (java.lang.Object) intArray10);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray10, (int) '4');
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(intArray10, 1);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray10);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(intArray10, (-1));
        java.lang.String[] strArray19 = null;
        int[] intArray25 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, 1);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.addAll(intArray25, intArray28);
        java.lang.String[] strArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray19, (java.lang.Object) intArray29);
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray29, (int) '4');
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains(intArray29, 1);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray29);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray29);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNull(strArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNull(strArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 5, (int) 'a');
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, (int) (byte) 10);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        int int24 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) floatArray23);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 6, (int) (short) 100, (double) 10.0f);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (short) 100, (int) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Object[] objArray0 = null;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray8 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray8, 100L, (int) '4');
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray8, (long) (byte) 10);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray1, (java.lang.Object) longArray13);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.subarray(longArray13, (int) (byte) 10, (int) (byte) 0);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.add(longArray17, (long) (byte) 1);
        java.lang.Long[] longArray20 = org.apache.commons.lang3.ArrayUtils.toObject(longArray17);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(objArray0, (java.lang.Object) longArray17);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (byte) 1, 4);
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray15, ' ');
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', 4);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 7 + "'", int23 == 7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        double[] doubleArray3 = new double[] {};
        double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray5);
        java.lang.Double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray5);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray5, (-1.0d), (int) (short) 0, (double) 3);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray5);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray5);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray5, (double) 3);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6);
        java.lang.String str9 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) booleanArray7, "false");
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{false,true,true,false,false}" + "'", str9.equals("{false,true,true,false,false}"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        short[] shortArray5 = new short[] { (byte) 100, (byte) -1, (byte) 0, (byte) 0, (byte) 1 };
        try {
            short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.add(shortArray5, (int) (short) 100, (short) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray12);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        float[] floatArray0 = new float[] {};
        float[] floatArray1 = new float[] {};
        float[] floatArray2 = new float[] {};
        float[] floatArray3 = new float[] {};
        float[] floatArray4 = new float[] {};
        float[][] floatArray5 = new float[][] { floatArray0, floatArray1, floatArray2, floatArray3, floatArray4 };
        float[] floatArray6 = new float[] {};
        float[] floatArray7 = new float[] {};
        float[] floatArray8 = new float[] {};
        float[] floatArray9 = new float[] {};
        float[] floatArray10 = new float[] {};
        float[][] floatArray11 = new float[][] { floatArray6, floatArray7, floatArray8, floatArray9, floatArray10 };
        float[] floatArray12 = new float[] {};
        float[] floatArray13 = new float[] {};
        float[] floatArray14 = new float[] {};
        float[] floatArray15 = new float[] {};
        float[] floatArray16 = new float[] {};
        float[][] floatArray17 = new float[][] { floatArray12, floatArray13, floatArray14, floatArray15, floatArray16 };
        float[] floatArray18 = new float[] {};
        float[] floatArray19 = new float[] {};
        float[] floatArray20 = new float[] {};
        float[] floatArray21 = new float[] {};
        float[] floatArray22 = new float[] {};
        float[][] floatArray23 = new float[][] { floatArray18, floatArray19, floatArray20, floatArray21, floatArray22 };
        float[] floatArray24 = new float[] {};
        float[] floatArray25 = new float[] {};
        float[] floatArray26 = new float[] {};
        float[] floatArray27 = new float[] {};
        float[] floatArray28 = new float[] {};
        float[][] floatArray29 = new float[][] { floatArray24, floatArray25, floatArray26, floatArray27, floatArray28 };
        float[] floatArray30 = new float[] {};
        float[] floatArray31 = new float[] {};
        float[] floatArray32 = new float[] {};
        float[] floatArray33 = new float[] {};
        float[] floatArray34 = new float[] {};
        float[][] floatArray35 = new float[][] { floatArray30, floatArray31, floatArray32, floatArray33, floatArray34 };
        float[][][] floatArray36 = new float[][][] { floatArray5, floatArray11, floatArray17, floatArray23, floatArray29, floatArray35 };
        try {
            float[][][] floatArray38 = org.apache.commons.lang3.ArrayUtils.remove(floatArray36, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray4);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) 0);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray4);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shortArray13);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.String[] strArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray0, (java.lang.Object) intArray10);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.clone(intArray10);
        try {
            int[] intArray14 = org.apache.commons.lang3.ArrayUtils.remove(intArray12, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNull(strArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.add(booleanArray8, 0, false);
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray13, 2);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray15, (long) 2);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray15);
        try {
            long[] longArray20 = org.apache.commons.lang3.ArrayUtils.remove(longArray18, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int[] intArray0 = new int[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1));
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, 4, 2);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(intArray0, 2);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.clone(intArray0);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1), (int) 'a');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) 0, (byte) 0, (byte) -1, (byte) 10, (byte) 0 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = new byte[] {};
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        java.lang.Byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray11);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray8, byteArray13);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray8);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.add(intArray5, (int) '#');
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.subarray(intArray15, (int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.add(floatArray7, (float) 5);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray7, (float) '#');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) (byte) 0, (int) (short) 10);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.add(floatArray17, (float) 10L);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray17);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1L));
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 1.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(charArray4, 'a');
        char[] charArray7 = null;
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray4, charArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray4, '#', (int) (short) 0);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        java.lang.Character[] charArray5 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(charArray9, 'a');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray6, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray10.getClass();
        java.lang.Class<?>[] wildcardClassArray12 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16);
        short[] shortArray18 = new short[] {};
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray18);
        java.lang.Short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray17);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) -1);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray12, (java.lang.Object) (short) -1);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) longArray10, (java.lang.Object[]) wildcardClassArray12);
        java.lang.Byte[] byteArray31 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray31);
        java.lang.reflect.AnnotatedElement[] annotatedElementArray33 = org.apache.commons.lang3.ArrayUtils.removeElement((java.lang.reflect.AnnotatedElement[]) wildcardClassArray12, (java.lang.Object) byteArray32);
        byte[] byteArray34 = new byte[] {};
        byte[] byteArray35 = org.apache.commons.lang3.ArrayUtils.clone(byteArray34);
        byte[] byteArray36 = new byte[] {};
        byte[] byteArray37 = org.apache.commons.lang3.ArrayUtils.clone(byteArray36);
        byte[] byteArray38 = org.apache.commons.lang3.ArrayUtils.clone(byteArray36);
        java.lang.Byte[] byteArray39 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray38);
        byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.clone(byteArray38);
        byte[] byteArray41 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray35, byteArray40);
        int int43 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray35, (byte) -1);
        byte[] byteArray46 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray35, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray48 = org.apache.commons.lang3.ArrayUtils.add(byteArray46, (byte) -1);
        byte[] byteArray50 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray46, (byte) 0);
        java.lang.Class<?> wildcardClass51 = byteArray46.getClass();
        java.lang.Class<?>[] wildcardClassArray52 = org.apache.commons.lang3.ArrayUtils.add(wildcardClassArray12, wildcardClass51);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClassArray12);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(annotatedElementArray33);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(wildcardClassArray52);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (byte) 1, 4);
        char[] charArray23 = new char[] { 'a', ' ', '4', '#' };
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray23, 'a');
        char[] charArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray23, '4');
        char[] charArray33 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int35 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray33, '#');
        char[] charArray40 = new char[] { '#', ' ', '#', '4' };
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray33, charArray40);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray27, charArray33);
        char[] charArray45 = org.apache.commons.lang3.ArrayUtils.add(charArray27, 3, ' ');
        char[] charArray46 = org.apache.commons.lang3.ArrayUtils.addAll(charArray18, charArray45);
        java.lang.Character[] charArray47 = org.apache.commons.lang3.ArrayUtils.toObject(charArray46);
        int int49 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray46, '4');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(charArray46);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) '4');
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.add(doubleArray13, (double) (byte) 10);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray21 = new boolean[] {};
        boolean[] booleanArray26 = new boolean[] { true, false, false, true };
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray21, booleanArray26);
        boolean[] booleanArray28 = new boolean[] {};
        boolean[] booleanArray33 = new boolean[] { true, false, false, true };
        boolean[] booleanArray34 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray28, booleanArray33);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray27, booleanArray33);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray27, true);
        boolean[] booleanArray39 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray27, true);
        java.lang.Boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray39);
        boolean[] booleanArray41 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray20, booleanArray39);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray41, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertNotNull(booleanArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3);
        try {
            byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.add(byteArray5, (int) (short) 100, (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        try {
            long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray14, (int) (byte) 10, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) wildcardClassArray0);
        int[] intArray18 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray18, 1);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.addAll(intArray18, intArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray18);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray18);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) intArray18);
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        float[] floatArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray0, 0.0f, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray21, (float) 10);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray21, (float) 10L);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.clone(floatArray26);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) floatArray21);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray21, (-1.0f));
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        java.io.Serializable[] serializableArray10 = org.apache.commons.lang3.ArrayUtils.subarray((java.io.Serializable[]) byteArray6, 100, (int) (short) 0);
        long[] longArray15 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray20 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray25 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray30 = new long[] { (byte) 100, 4, 1L, 2 };
        long[][] longArray31 = new long[][] { longArray15, longArray20, longArray25, longArray30 };
        long[] longArray35 = new long[] { 'a', 10, 0 };
        long[] longArray39 = new long[] { 'a', 10, 0 };
        long[] longArray43 = new long[] { 'a', 10, 0 };
        long[] longArray47 = new long[] { 'a', 10, 0 };
        long[] longArray51 = new long[] { 'a', 10, 0 };
        long[] longArray55 = new long[] { 'a', 10, 0 };
        long[][] longArray56 = new long[][] { longArray35, longArray39, longArray43, longArray47, longArray51, longArray55 };
        long[][] longArray57 = org.apache.commons.lang3.ArrayUtils.addAll(longArray31, longArray56);
        boolean boolean58 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) serializableArray10, (java.lang.Object[]) longArray57);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(serializableArray10);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertNotNull(longArray31);
        org.junit.Assert.assertNotNull(longArray35);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertNotNull(longArray47);
        org.junit.Assert.assertNotNull(longArray51);
        org.junit.Assert.assertNotNull(longArray55);
        org.junit.Assert.assertNotNull(longArray56);
        org.junit.Assert.assertNotNull(longArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray22 = org.apache.commons.lang3.ArrayUtils.add(doubleArray20, (double) (byte) 10);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray18, doubleArray22);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray18);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 100.0d, (int) (short) -1, (double) '4');
        try {
            double[] doubleArray31 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, 100, (double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, 100, 100 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray5);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray14, (long) ' ');
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray14);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray14, (long) 4);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.Long[] longArray3 = new java.lang.Long[] { 1L, 100L, 1L };
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray3);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray3);
        byte[] byteArray6 = new byte[] {};
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        byte[] byteArray8 = new byte[] {};
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray10);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray10);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray7, byteArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray7, (byte) -1);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.add(byteArray18, (byte) -1);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray18, (byte) 0);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray3, (java.lang.Object) byteArray22, 2);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.clone(byteArray22);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains(byteArray25, (byte) 0);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray6, (float) 3, 5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "1", "1" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = org.apache.commons.lang3.ArrayUtils.subarray((java.lang.Comparable<java.lang.String>[]) strArray4, 10, (int) (short) -1);
        float[] floatArray14 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray14, (float) (short) 1);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.clone(floatArray14);
        java.lang.Float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray17);
        float[] floatArray25 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray25, (float) (short) 1);
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.clone(floatArray25);
        java.lang.Float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray28);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray18, (java.lang.Object[]) floatArray29);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) floatArray29);
        java.lang.CharSequence[] charSequenceArray32 = org.apache.commons.lang3.ArrayUtils.removeElement((java.lang.CharSequence[]) strArray4, (java.lang.Object) floatArray29);
        java.lang.CharSequence[] charSequenceArray35 = org.apache.commons.lang3.ArrayUtils.add((java.lang.CharSequence[]) strArray4, (int) (short) 0, (java.lang.CharSequence) "1");
        java.lang.Object obj36 = null;
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray4, obj36, (int) 'a');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(charSequenceArray32);
        org.junit.Assert.assertNotNull(charSequenceArray35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        short[] shortArray1 = new short[] { (byte) 100 };
        java.lang.Short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray1);
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray1, (int) (byte) 1, 6);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(shortArray5, (short) (byte) -1);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31, 2);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray25, intArray33);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.add(intArray33, (int) 'a');
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray33, (int) (short) 1, (int) (short) 10);
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray33, (int) ' ', (int) (short) 1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 6, (int) (short) 100, (double) 10.0f);
        double[] doubleArray15 = new double[] {};
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray15, (double) (-1.0f), (double) 1L);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray15, (double) 0);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.add(doubleArray21, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray23);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.add(doubleArray25, (double) (byte) 10);
        double[] doubleArray28 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray23, doubleArray27);
        double[] doubleArray29 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray27);
        double[] doubleArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray29, (double) (byte) 0);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray15, doubleArray29);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray15, (double) (short) 0, (double) (short) 0);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray6, doubleArray15);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        short[] shortArray0 = null;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.clone(shortArray6);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.add(shortArray8, (short) 1);
        java.lang.Short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray10);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray11, (short) -1);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray13);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray14);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        java.lang.Character[] charArray5 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5, 'a');
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray7, 'a', 10);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.clone(charArray7);
        try {
            char[] charArray13 = org.apache.commons.lang3.ArrayUtils.remove(charArray7, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        try {
            int int1 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        java.lang.Short[] shortArray5 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray7 = new short[] {};
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray7);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray7);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 1);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray9);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray12, 10, 100);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray12, (short) -1);
        short[] shortArray22 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray22);
        short[] shortArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray23, (short) 0);
        boolean[] booleanArray26 = new boolean[] {};
        boolean[] booleanArray31 = new boolean[] { true, false, false, true };
        boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray26, booleanArray31);
        boolean[] booleanArray33 = new boolean[] {};
        boolean[] booleanArray38 = new boolean[] { true, false, false, true };
        boolean[] booleanArray39 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray33, booleanArray38);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray32, booleanArray38);
        int int43 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray32, true, 1);
        boolean[] booleanArray49 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray50 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray49);
        boolean boolean51 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray32, booleanArray49);
        int int52 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray23, (java.lang.Object) boolean51);
        byte[] byteArray55 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray56 = new byte[][] { byteArray55 };
        byte[][] byteArray57 = org.apache.commons.lang3.ArrayUtils.clone(byteArray56);
        boolean boolean58 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray23, (java.lang.Object) byteArray57);
        short[] shortArray59 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray23);
        short[] shortArray61 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray59, (short) -1);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray12, shortArray59);
        short[] shortArray64 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray59, (short) 100);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray25);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(booleanArray49);
        org.junit.Assert.assertNotNull(booleanArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shortArray59);
        org.junit.Assert.assertNotNull(shortArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(shortArray64);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        java.lang.Double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray2);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 5, (int) '#');
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, 1.0d, (double) 1L);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray14, (long) ' ');
        java.lang.Short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray25 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray25, 100L, (int) '4');
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray25, (long) (byte) 10);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray18, (java.lang.Object) longArray30);
        long[] longArray34 = org.apache.commons.lang3.ArrayUtils.subarray(longArray30, (int) (byte) 10, (int) (byte) 0);
        int int37 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray30, (long) (short) 100, (int) (short) -1);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.contains(longArray30, (long) 1);
        int int42 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray30, (long) 4, (int) (byte) 1);
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.contains(longArray30, 100L);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray17, longArray30);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray6);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 0);
        java.lang.Short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray12, (java.lang.Object) "hi!");
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray12);
        java.lang.Short[] shortArray19 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray19);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray20, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray20);
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.add(shortArray20, (short) 0);
        short[] shortArray27 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray15, shortArray20);
        short[] shortArray29 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray20, (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray20);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray20, (short) 0);
        short[] shortArray33 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray9, shortArray20);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(shortArray33);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        float[] floatArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray0, (float) 6, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray7, (byte) -1, (int) (byte) 100);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray8, (short) 10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray4, (short) 1, (int) (short) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, '#');
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray2, 'a', 5);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.clone(charArray2);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(charArray6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray8, '4');
        char[] charArray11 = null;
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray11);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) '4');
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.subarray(intArray5, (int) (short) 0, 6);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, 100, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3);
        int[] intArray11 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray11, 1);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) byteArray3, (java.lang.Object) int13);
        short[] shortArray19 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray19);
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray20, (short) 0);
        boolean[] booleanArray23 = new boolean[] {};
        boolean[] booleanArray28 = new boolean[] { true, false, false, true };
        boolean[] booleanArray29 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray23, booleanArray28);
        boolean[] booleanArray30 = new boolean[] {};
        boolean[] booleanArray35 = new boolean[] { true, false, false, true };
        boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray30, booleanArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray29, booleanArray35);
        int int40 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray29, true, 1);
        boolean[] booleanArray46 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray47 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray46);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray29, booleanArray46);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray20, (java.lang.Object) boolean48);
        byte[] byteArray52 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray53 = new byte[][] { byteArray52 };
        byte[][] byteArray54 = org.apache.commons.lang3.ArrayUtils.clone(byteArray53);
        boolean boolean55 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray20, (java.lang.Object) byteArray54);
        java.lang.Object obj56 = null;
        int int58 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray54, obj56, 2);
        int int59 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray3, obj56);
        byte[] byteArray60 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertNotNull(booleanArray35);
        org.junit.Assert.assertNotNull(booleanArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(booleanArray46);
        org.junit.Assert.assertNotNull(booleanArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertNotNull(byteArray53);
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(byteArray60);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 4);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.add(longArray7, 2, (long) (short) 10);
        long[] longArray15 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (int) (short) 1, (long) 4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray15);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) 3, (int) (byte) 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, (double) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray6, (float) 0);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.remove(floatArray23, 5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        float[] floatArray5 = new float[] { (-1), (byte) 10, (short) 100, 1L, 1.0f };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (byte) 1, (int) '#');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray5, (float) 10);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray4, (byte) -1);
        try {
            byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.add(byteArray6, 3, (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, 10.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray32);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) 10L);
        java.lang.Float[] floatArray17 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray17);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray17);
        float[] floatArray26 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray26, (float) (short) 1);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.add(floatArray28, 0.0f);
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray30, 100, (int) (short) 100);
        float[] floatArray38 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray38, (int) (byte) 100, (int) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray38, (float) ' ', (int) 'a');
        float[] floatArray46 = org.apache.commons.lang3.ArrayUtils.add(floatArray38, (float) (short) 100);
        float[] floatArray47 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray30, floatArray46);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray19, floatArray30);
        float[] floatArray49 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray11, floatArray19);
        float[] floatArray51 = org.apache.commons.lang3.ArrayUtils.add(floatArray11, (float) 4);
        int int54 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray51, 0.0f, (-1));
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (short) 100, 0);
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray15, '#');
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, 3, (int) (byte) 100);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(charArray26);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        boolean[] booleanArray2 = new boolean[] { true, false };
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray2, true, (int) '4');
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray2, false, (int) (byte) 0);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray2, false);
        boolean[] booleanArray13 = new boolean[] { true, false };
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray13, true, (int) '4');
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray2, booleanArray13);
        boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray13, false);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray19, true);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = new byte[] {};
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        java.lang.Byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray11);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 1);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray4, byteArray12);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray12, 0, (-1));
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray12, (byte) 10, (int) (short) -1);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.clone(byteArray12);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(byteArray22);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31, 2);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray25, intArray33);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.add(intArray33, (int) 'a');
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray33, (int) (short) 1, (int) (short) 10);
        int[] intArray42 = org.apache.commons.lang3.ArrayUtils.subarray(intArray33, (int) '4', (int) (short) 0);
        int[] intArray43 = null;
        int[] intArray44 = org.apache.commons.lang3.ArrayUtils.addAll(intArray33, intArray43);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.contains(intArray43, (-1));
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.Object[] objArray0 = null;
        java.lang.Character[] charArray4 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        java.lang.Character[] charArray6 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray0, (java.lang.Object) charArray5);
        java.lang.Character[] charArray8 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray5, ' ');
        java.lang.Character[] charArray11 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray15, (int) (byte) 1, '4');
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.subarray(charArray21, (int) (short) 10, (int) (byte) 10);
        try {
            char[] charArray27 = org.apache.commons.lang3.ArrayUtils.add(charArray24, (int) '4', 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray24);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.String[] strArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray0, (java.lang.Object) intArray10);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray10, (int) '4');
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(intArray10, 1);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray10, (int) (short) 0, 3);
        java.lang.Integer[] intArray19 = org.apache.commons.lang3.ArrayUtils.toObject(intArray10);
        int[] intArray25 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, 1);
        int int30 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray25, (int) ' ', (int) (short) 100);
        int[] intArray36 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray36, 1);
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray40 = org.apache.commons.lang3.ArrayUtils.addAll(intArray36, intArray39);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray25, intArray40);
        int int43 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray40, (int) (byte) 0);
        int[] intArray45 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray40, 1);
        int[] intArray47 = org.apache.commons.lang3.ArrayUtils.add(intArray45, (int) '4');
        java.lang.Integer[] intArray51 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray53 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray51, 2);
        int[] intArray54 = org.apache.commons.lang3.ArrayUtils.addAll(intArray45, intArray53);
        boolean boolean55 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray45);
        int[] intArray56 = org.apache.commons.lang3.ArrayUtils.clone(intArray45);
        boolean boolean57 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray56);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNull(strArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 0.0d);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray4, (double) 'a', 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        java.lang.Short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray16 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, 100L, (int) '4');
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray16, (long) (byte) 10);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray9, (java.lang.Object) longArray21);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.subarray(longArray21, (int) (byte) 10, (int) (byte) 0);
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.add(longArray25, (long) (byte) 1);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray25, (long) '4');
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray5, longArray25);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray1, (byte) -1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray1, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray13 = new byte[] {};
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        byte[] byteArray15 = new byte[] {};
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        java.lang.Byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray17);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.clone(byteArray17);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray14, byteArray19);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray19);
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray19, (byte) 0);
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray19);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray24, 1, (int) (short) 0);
        int int29 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray27, (byte) 10);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray27, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(byteArray31);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray4, (byte) -1);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray4, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int[] intArray0 = new int[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1));
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, 4, 2);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(intArray0, 2);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.clone(intArray0);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray9, 5);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray9);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray6, 10.0f);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (float) 100L);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray10, (int) (byte) 1);
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray12, (int) 'a', 100);
        boolean[] booleanArray16 = null;
        boolean[] booleanArray17 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray16);
        boolean[] booleanArray18 = new boolean[] {};
        boolean[] booleanArray23 = new boolean[] { true, false, false, true };
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray18, booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray16, booleanArray24);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray9, 10.0f);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray9, 100.0f, (int) (byte) 1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray4, (byte) -1, (int) (byte) 10);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(byteArray4, (byte) 10);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray4, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0, (int) (short) 100);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) -1, 2);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.add(byteArray6, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.clone(longArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(longArray14, (long) (byte) -1);
        java.lang.Long[] longArray17 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(longArray17);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3);
        java.lang.Class<?> wildcardClass5 = byteArray3.getClass();
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray7, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray12, (long) (byte) 10);
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, 6, (int) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(longArray26);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray14 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '#');
        char[] charArray21 = new char[] { '#', ' ', '#', '4' };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray14, charArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.add(charArray8, 3, ' ');
        char[] charArray29 = org.apache.commons.lang3.ArrayUtils.add(charArray26, 3, 'a');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray29);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        float[] floatArray5 = new float[] { 4, (short) 1, (-1), (-1), 0L };
        float[] floatArray10 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray10, (int) (byte) 100, (int) '4');
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray10, (float) ' ', (int) 'a');
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray10, (float) (short) 100);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray5, floatArray18);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray5);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int[] intArray0 = null;
        int[] intArray3 = org.apache.commons.lang3.ArrayUtils.subarray(intArray0, 0, (int) (byte) 100);
        org.junit.Assert.assertNull(intArray3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) -1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray8, (short) 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int[] intArray4 = new int[] { ' ', '#', 0, '4' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray4, 0);
        try {
            int[] intArray8 = org.apache.commons.lang3.ArrayUtils.remove(intArray4, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray4);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, 2, (int) (short) 10);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, 'a');
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.subarray(charArray10, 4, (int) ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(charArray15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, (int) (byte) 1, (int) (short) 1);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, 10.0d, (double) 3);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, (double) 100);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        java.lang.Class<?> wildcardClass14 = floatArray9.getClass();
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray9, (float) (short) 0, 3);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(floatArray9, (float) (byte) 0);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int[] intArray0 = new int[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1));
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, 4, 2);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(intArray0, 2);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.clone(intArray0);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray9, 4);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray9, (int) (short) 0, (int) (short) 0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (-1L), 0, (double) (-1));
        double[] doubleArray19 = new double[] {};
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.add(doubleArray19, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray21);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray21, doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray25);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray27, (double) (byte) 10, 1, 0.0d);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray27);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) '4', (double) 1);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 2, (double) (short) 100);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray41 = org.apache.commons.lang3.ArrayUtils.add(doubleArray39, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray41);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray45 = org.apache.commons.lang3.ArrayUtils.add(doubleArray43, (double) (byte) 10);
        double[] doubleArray46 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray41, doubleArray45);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray45, (double) 3, (int) (byte) 0);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray6, doubleArray45);
        double[] doubleArray51 = new double[] {};
        int int54 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray51, (double) (-1.0f), (double) 1L);
        int int56 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray51, (double) 0);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray59 = org.apache.commons.lang3.ArrayUtils.add(doubleArray57, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray59);
        double[] doubleArray61 = new double[] {};
        double[] doubleArray63 = org.apache.commons.lang3.ArrayUtils.add(doubleArray61, (double) (byte) 10);
        double[] doubleArray64 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray59, doubleArray63);
        double[] doubleArray65 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray63);
        double[] doubleArray67 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray65, (double) (byte) 0);
        boolean boolean68 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray51, doubleArray65);
        double[] doubleArray69 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray51);
        int int72 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray51, (double) (short) 1, (int) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 0);
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray7);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.add(floatArray20, 3, (float) 100);
        float[] floatArray29 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray29, (int) (byte) 100, (int) '4');
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray20, floatArray29);
        float[] floatArray35 = org.apache.commons.lang3.ArrayUtils.add(floatArray20, (float) (byte) 0);
        int int37 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray10, (java.lang.Object) floatArray20, 4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) -1, (byte) 1, (byte) 0 };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray4, (byte) 10, 1);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray4);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray4, (byte) -1, 5);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        long[] longArray18 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray18, 100L, (int) '4');
        java.lang.Long[] longArray22 = org.apache.commons.lang3.ArrayUtils.toObject(longArray18);
        java.lang.Class<?> wildcardClass23 = longArray22.getClass();
        java.lang.Class<?>[] wildcardClassArray24 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray28 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray28);
        short[] shortArray30 = new short[] {};
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray29, shortArray30);
        java.lang.Short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray29);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray29, (short) -1);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray24, (java.lang.Object) (short) -1);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) longArray22, (java.lang.Object[]) wildcardClassArray24);
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray37 = org.apache.commons.lang3.ArrayUtils.addAll((java.lang.reflect.GenericDeclaration[]) wildcardClassArray0, (java.lang.reflect.GenericDeclaration[]) wildcardClassArray24);
        java.lang.Integer[] intArray41 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray43 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray41, 2);
        int[] intArray44 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray41);
        try {
            java.lang.Object[] objArray45 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) intArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayStoreException; message: [Ljava.lang.Integer;");
        } catch (java.lang.ArrayStoreException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClassArray24);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(genericDeclarationArray37);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray2, 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) ' ', (double) (short) 1);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray2);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray16, (double) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray15, (long) 2);
        java.lang.Long[] longArray18 = org.apache.commons.lang3.ArrayUtils.toObject(longArray17);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray18, 0L);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray20);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 10, (int) (short) 10);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 100);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, 1, (-1));
        try {
            byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.remove(byteArray6, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 0);
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray7);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10, (long) 4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        char[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        float[] floatArray5 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (byte) 100, (int) '4');
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(floatArray5, (float) 5);
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray5, (float) 10L);
        float[] floatArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray5, (float) (short) -1);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) charArray0, (java.lang.Object) (short) -1);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray11 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray17 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray23 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray29 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[][] byteArray30 = new java.lang.Byte[][] { byteArray5, byteArray11, byteArray17, byteArray23, byteArray29 };
        java.lang.Byte[] byteArray36 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray42 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray48 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray54 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray60 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[][] byteArray61 = new java.lang.Byte[][] { byteArray36, byteArray42, byteArray48, byteArray54, byteArray60 };
        java.lang.Byte[][][] byteArray62 = new java.lang.Byte[][][] { byteArray30, byteArray61 };
        java.lang.Byte[][][] byteArray64 = org.apache.commons.lang3.ArrayUtils.remove(byteArray62, (int) (byte) 1);
        java.lang.Byte[][][] byteArray67 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray62, 10, 3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertNotNull(byteArray60);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertNotNull(byteArray62);
        org.junit.Assert.assertNotNull(byteArray64);
        org.junit.Assert.assertNotNull(byteArray67);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.Boolean[] booleanArray1 = new java.lang.Boolean[] { false };
        boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray1);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray2, true);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.Byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_OBJECT_ARRAY;
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0, (byte) 100);
        try {
            byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.remove(byteArray3, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 100L);
        java.lang.Class<?> wildcardClass13 = floatArray8.getClass();
        float[] floatArray14 = org.apache.commons.lang3.ArrayUtils.clone(floatArray8);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        int[] intArray0 = new int[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1));
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, 4, 2);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(intArray0, 2);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.clone(intArray0);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray9, 5);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray11, 7);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray1, (byte) -1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray1, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray12, (byte) -1);
        try {
            byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.remove(byteArray12, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray14);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        java.lang.Short[] shortArray7 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.add(shortArray8, (short) 0);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray8);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 100);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray17, (short) (byte) -1);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray17);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray17);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        float[] floatArray7 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray7, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.clone(floatArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) '4', (java.lang.Object) floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray10, (float) 5);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray13);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        float[] floatArray4 = new float[] { 'a', '#', 3, 6 };
        float[] floatArray9 = new float[] { 'a', '#', 3, 6 };
        float[] floatArray14 = new float[] { 'a', '#', 3, 6 };
        float[][] floatArray15 = new float[][] { floatArray4, floatArray9, floatArray14 };
        float[] floatArray20 = new float[] { 'a', '#', 3, 6 };
        float[] floatArray25 = new float[] { 'a', '#', 3, 6 };
        float[] floatArray30 = new float[] { 'a', '#', 3, 6 };
        float[][] floatArray31 = new float[][] { floatArray20, floatArray25, floatArray30 };
        float[][][] floatArray32 = new float[][][] { floatArray15, floatArray31 };
        java.lang.Class<?>[] wildcardClassArray33 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray37 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray38 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray37);
        short[] shortArray39 = new short[] {};
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray38, shortArray39);
        java.lang.Short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray38);
        int int43 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray38, (short) -1);
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray33, (java.lang.Object) (short) -1);
        float[] floatArray51 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray53 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray51, (float) (short) 1);
        float[] floatArray56 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray53, (int) '#', (int) ' ');
        float[] floatArray63 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray65 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray63, (float) (short) 1);
        float[] floatArray66 = org.apache.commons.lang3.ArrayUtils.clone(floatArray63);
        java.lang.Float[] floatArray67 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray66);
        float[] floatArray74 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray76 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray74, (float) (short) 1);
        float[] floatArray77 = org.apache.commons.lang3.ArrayUtils.clone(floatArray74);
        java.lang.Float[] floatArray78 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray77);
        boolean boolean79 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray67, (java.lang.Object[]) floatArray78);
        float[] floatArray81 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray67, (float) (byte) 0);
        boolean boolean82 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray53, floatArray81);
        boolean boolean83 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) boolean44, (java.lang.Object) floatArray53);
        float[][][] floatArray84 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray32, (java.lang.Object) boolean83);
        java.lang.Short[] shortArray85 = new java.lang.Short[] {};
        java.lang.Short[] shortArray86 = new java.lang.Short[] {};
        java.lang.Short[] shortArray87 = new java.lang.Short[] {};
        java.lang.Short[] shortArray88 = new java.lang.Short[] {};
        java.lang.Short[][] shortArray89 = new java.lang.Short[][] { shortArray85, shortArray86, shortArray87, shortArray88 };
        java.lang.Short[][] shortArray92 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray89, (-1), (int) '#');
        try {
            java.io.Serializable[][] serializableArray93 = org.apache.commons.lang3.ArrayUtils.addAll((java.io.Serializable[][]) floatArray84, (java.io.Serializable[][]) shortArray89);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayStoreException; message: null");
        } catch (java.lang.ArrayStoreException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(wildcardClassArray33);
        org.junit.Assert.assertNotNull(shortArray37);
        org.junit.Assert.assertNotNull(shortArray38);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray74);
        org.junit.Assert.assertNotNull(floatArray76);
        org.junit.Assert.assertNotNull(floatArray77);
        org.junit.Assert.assertNotNull(floatArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(floatArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(floatArray84);
        org.junit.Assert.assertNotNull(shortArray85);
        org.junit.Assert.assertNotNull(shortArray86);
        org.junit.Assert.assertNotNull(shortArray87);
        org.junit.Assert.assertNotNull(shortArray88);
        org.junit.Assert.assertNotNull(shortArray89);
        org.junit.Assert.assertNotNull(shortArray92);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, true);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, 3, (int) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, false);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, true);
        boolean[] booleanArray16 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray5);
        java.lang.Boolean[] booleanArray17 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray17);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.clone(intArray20);
        int[] intArray32 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray32, 1);
        int int37 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray32, (int) ' ', (int) (short) 100);
        int[] intArray40 = org.apache.commons.lang3.ArrayUtils.add(intArray32, 1, (int) 'a');
        int[] intArray43 = org.apache.commons.lang3.ArrayUtils.subarray(intArray32, 0, 0);
        int[] intArray44 = org.apache.commons.lang3.ArrayUtils.addAll(intArray26, intArray32);
        int[] intArray46 = org.apache.commons.lang3.ArrayUtils.add(intArray32, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray46);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        char[] charArray5 = new char[] { 'a', 'a', '#', ' ', 'a' };
        org.apache.commons.lang3.ArrayUtils.reverse(charArray5);
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int[] intArray0 = new int[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1));
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, 4, 2);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(intArray0, 2);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(intArray0, 10);
        try {
            int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray0, (int) (short) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.Object obj0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.add(doubleArray1, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray3);
        double[] doubleArray5 = new double[] {};
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.add(doubleArray5, (double) (byte) 10);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray3, doubleArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray3, (double) 1.0f, 0, (double) '4');
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray3, (double) '4', (double) (byte) 0);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEquals(obj0, (java.lang.Object) doubleArray3);
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0, (double) 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        long[] longArray18 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray18, 100L, (int) '4');
        java.lang.Long[] longArray22 = org.apache.commons.lang3.ArrayUtils.toObject(longArray18);
        java.lang.Class<?> wildcardClass23 = longArray22.getClass();
        java.lang.Class<?>[] wildcardClassArray24 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray28 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray28);
        short[] shortArray30 = new short[] {};
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray29, shortArray30);
        java.lang.Short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray29);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray29, (short) -1);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray24, (java.lang.Object) (short) -1);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) longArray22, (java.lang.Object[]) wildcardClassArray24);
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray37 = org.apache.commons.lang3.ArrayUtils.addAll((java.lang.reflect.GenericDeclaration[]) wildcardClassArray0, (java.lang.reflect.GenericDeclaration[]) wildcardClassArray24);
        java.lang.Short[] shortArray41 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray42 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray41);
        short[] shortArray43 = new short[] {};
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray42, shortArray43);
        java.lang.Short[] shortArray45 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray42);
        int int47 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray42, (short) -1);
        short[] shortArray48 = org.apache.commons.lang3.ArrayUtils.clone(shortArray42);
        java.lang.Class<?> wildcardClass49 = shortArray48.getClass();
        java.lang.reflect.Type[] typeArray50 = org.apache.commons.lang3.ArrayUtils.removeElement((java.lang.reflect.Type[]) wildcardClassArray24, (java.lang.Object) wildcardClass49);
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClassArray24);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(genericDeclarationArray37);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertNotNull(shortArray42);
        org.junit.Assert.assertNotNull(shortArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(shortArray45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(shortArray48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(typeArray50);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray18, true);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray18);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray3, (int) (short) -1, (int) (short) 0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) (byte) 0);
        java.lang.Float[] floatArray30 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray30);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) (short) 0, (int) (byte) 10);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) 1L);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray24, floatArray31);
        float[] floatArray40 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray37, 5, (int) (byte) 1);
        int int42 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray37, (float) (short) 10);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray6 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray7 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray6);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray7, true);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray9, true);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray11, (int) (byte) 1);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) shortArray0);
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        java.lang.Short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray6, (java.lang.Object) "hi!");
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray6);
        java.lang.Short[] shortArray13 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray13);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray14, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray14);
        short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.add(shortArray14, (short) 0);
        short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray9, shortArray14);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray9);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray9, (short) (byte) -1, 6);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray15, (long) 2);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray15);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray15);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray8, '#');
        java.lang.Class<?> wildcardClass11 = charArray8.getClass();
        org.apache.commons.lang3.ArrayUtils.reverse(charArray8);
        java.lang.Character[] charArray16 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray16);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(charArray17, 'a');
        char[] charArray20 = null;
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray17, charArray20);
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.addAll(charArray8, charArray20);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(charArray22);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        char[] charArray9 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[] charArray15 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[][] charArray16 = new char[][] { charArray9, charArray15 };
        char[] charArray22 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[] charArray28 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[][] charArray29 = new char[][] { charArray22, charArray28 };
        char[] charArray35 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[] charArray41 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[][] charArray42 = new char[][] { charArray35, charArray41 };
        char[] charArray48 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[] charArray54 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[][] charArray55 = new char[][] { charArray48, charArray54 };
        char[][][] charArray56 = new char[][][] { charArray16, charArray29, charArray42, charArray55 };
        char[][][] charArray59 = org.apache.commons.lang3.ArrayUtils.subarray(charArray56, (int) 'a', 3);
        int int60 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray3, (java.lang.Object) 3);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertNotNull(charArray56);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.remove(shortArray4, (int) (byte) 0);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray9);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray9);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray9);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        java.io.Serializable[] serializableArray10 = org.apache.commons.lang3.ArrayUtils.subarray((java.io.Serializable[]) byteArray6, 100, (int) (short) 0);
        java.lang.Short[] shortArray14 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray14);
        short[] shortArray16 = new short[] {};
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray15, shortArray16);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray15, (short) (byte) 0);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray6, (java.lang.Object) shortArray15);
        java.lang.Integer[] intArray24 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray24, 2);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray24);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray24);
        int[] intArray34 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray34, 1);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray34, (int) ' ', (int) (short) 100);
        int[] intArray45 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int47 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray45, 1);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray49 = org.apache.commons.lang3.ArrayUtils.addAll(intArray45, intArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray34, intArray49);
        int int52 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray49, (int) (byte) 0);
        int[] intArray54 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray49, 1);
        int[] intArray55 = org.apache.commons.lang3.ArrayUtils.clone(intArray49);
        int[] intArray61 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int63 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray61, 1);
        int int66 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray61, (int) ' ', (int) (short) 100);
        int[] intArray69 = org.apache.commons.lang3.ArrayUtils.add(intArray61, 1, (int) 'a');
        int[] intArray72 = org.apache.commons.lang3.ArrayUtils.subarray(intArray61, 0, 0);
        int[] intArray73 = org.apache.commons.lang3.ArrayUtils.addAll(intArray55, intArray61);
        boolean boolean74 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray28, intArray55);
        int[] intArray76 = org.apache.commons.lang3.ArrayUtils.add(intArray55, (int) ' ');
        int int77 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray6, (java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(serializableArray10);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray11 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray17 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray23 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray29 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[][] byteArray30 = new java.lang.Byte[][] { byteArray5, byteArray11, byteArray17, byteArray23, byteArray29 };
        java.lang.Byte[] byteArray36 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray42 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray48 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray54 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[] byteArray60 = new java.lang.Byte[] { (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) -1 };
        java.lang.Byte[][] byteArray61 = new java.lang.Byte[][] { byteArray36, byteArray42, byteArray48, byteArray54, byteArray60 };
        java.lang.Byte[][][] byteArray62 = new java.lang.Byte[][][] { byteArray30, byteArray61 };
        java.lang.Byte[][][] byteArray64 = org.apache.commons.lang3.ArrayUtils.remove(byteArray62, (int) (byte) 1);
        boolean boolean65 = org.apache.commons.lang3.ArrayUtils.isEmpty((java.lang.Object[][][]) byteArray62);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertNotNull(byteArray60);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertNotNull(byteArray62);
        org.junit.Assert.assertNotNull(byteArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean[] booleanArray28 = new boolean[] { true, false };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray28, true, (int) '4');
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray28, false, (int) (byte) 0);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray28, false);
        boolean[] booleanArray39 = new boolean[] { true, false };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray39, true, (int) '4');
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray28, booleanArray39);
        boolean[] booleanArray45 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray39, false);
        boolean[] booleanArray46 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray6, booleanArray45);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, false);
        int int50 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray6, true);
        boolean[] booleanArray52 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, false);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray52);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(booleanArray45);
        org.junit.Assert.assertNotNull(booleanArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(booleanArray52);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) '#', (int) '#');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, 10.0d, (double) 3);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) 100, (double) 'a');
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double[] doubleArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 5, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        char[] charArray2 = new char[] { ' ', ' ' };
        char[] charArray5 = new char[] { ' ', ' ' };
        char[] charArray8 = new char[] { ' ', ' ' };
        char[][] charArray9 = new char[][] { charArray2, charArray5, charArray8 };
        char[] charArray14 = new char[] { 'a', '#', ' ', ' ' };
        char[] charArray19 = new char[] { 'a', '#', ' ', ' ' };
        char[][] charArray20 = new char[][] { charArray14, charArray19 };
        char[][] charArray21 = org.apache.commons.lang3.ArrayUtils.addAll(charArray9, charArray20);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray21);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray20);
        float[] floatArray28 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray28, (float) (short) 1);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.add(floatArray30, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray30);
        int int36 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray30, (float) (byte) 0, (int) (short) 10);
        int int38 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) booleanArray21, (java.lang.Object) (byte) 0, (int) (short) 0);
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray21, false);
        boolean[] booleanArray41 = null;
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray40, booleanArray41);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertNotNull(booleanArray42);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray1, false, 4);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray13 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray13, 1);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray13, (int) ' ', (int) (short) 100);
        int[] intArray24 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray24, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.addAll(intArray24, intArray27);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray13, intArray28);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray28, (int) (byte) 0);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray28, 1);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.clone(intArray28);
        int[] intArray40 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray40, 1);
        int int45 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray40, (int) ' ', (int) (short) 100);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.add(intArray40, 1, (int) 'a');
        int[] intArray51 = org.apache.commons.lang3.ArrayUtils.subarray(intArray40, 0, 0);
        int[] intArray52 = org.apache.commons.lang3.ArrayUtils.addAll(intArray34, intArray40);
        boolean boolean53 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray7, intArray34);
        int[] intArray54 = org.apache.commons.lang3.ArrayUtils.clone(intArray34);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(intArray54);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray11);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray11, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) (byte) 0, (int) (short) 10);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 10, (int) (byte) -1);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray17, (float) (byte) -1, (-1));
        float[] floatArray27 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray27, (float) (short) 1);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.clone(floatArray27);
        java.lang.Float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray30);
        float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.add(floatArray30, 3, (float) 100);
        float[] floatArray41 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray41, (float) (short) 1);
        float[] floatArray45 = org.apache.commons.lang3.ArrayUtils.add(floatArray43, 0.0f);
        int int47 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray43, (float) 100L);
        java.lang.Class<?> wildcardClass48 = floatArray43.getClass();
        java.lang.Float[] floatArray54 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray55 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray54);
        int int57 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray55, 1.0f);
        float[] floatArray58 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray43, floatArray55);
        boolean boolean59 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray34, floatArray55);
        boolean boolean60 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray17, floatArray55);
        try {
            float[] floatArray62 = org.apache.commons.lang3.ArrayUtils.remove(floatArray17, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 4);
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray9);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray9, (long) (short) 0);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        java.lang.Character[] charArray5 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, 'a');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray4, '#', 6);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray1 = new boolean[] {};
        boolean[] booleanArray6 = new boolean[] { true, false, false, true };
        boolean[] booleanArray7 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray1, booleanArray6);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray6, false);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray6);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray6);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.add(doubleArray1, (double) (byte) 10);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) (short) 100, (int) '#');
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray3, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray3, (double) 0.0f);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, (double) '4');
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray16, (double) 1L, (double) (byte) 10);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray23, true);
        boolean[] booleanArray29 = org.apache.commons.lang3.ArrayUtils.add(booleanArray27, true);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray29);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.Object[] objArray0 = null;
        java.lang.Character[] charArray4 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        java.lang.Character[] charArray6 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray0, (java.lang.Object) charArray5);
        java.lang.Character[] charArray8 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray8);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray8, ' ');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.remove(charArray11, (int) (byte) 1);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray13);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray0, (short) (byte) 100, 6);
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray0, (short) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(shortArray5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.clone(intArray4);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray4, (int) (byte) 100, 100);
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 5);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray4, (int) (byte) -1, (int) (short) -1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.add(booleanArray0, false);
        org.junit.Assert.assertNotNull(booleanArray2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(longArray6, (long) 1);
        java.lang.Short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray19 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray19, 100L, (int) '4');
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray19, (long) (byte) 10);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray12, (java.lang.Object) longArray24);
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.subarray(longArray24, (int) (byte) 10, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray28);
        java.lang.Long[] longArray30 = org.apache.commons.lang3.ArrayUtils.toObject(longArray28);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray6, longArray28);
        java.lang.Long[] longArray32 = org.apache.commons.lang3.ArrayUtils.toObject(longArray28);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray32);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray0, (short) (byte) 100, 6);
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.add(shortArray0, (short) (byte) 10);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray0, (-1), (-1));
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray4, (byte) -1);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray6, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 0.0d);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray4, (double) 1, 0, (double) (-1L));
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray4);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray9, (double) 100L, (int) (short) 1, (double) 2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        int[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.add(intArray0, 3);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        java.lang.Short[] shortArray7 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.add(shortArray8, (short) 0);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray8);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 100);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray17, (short) (byte) -1);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray19, (short) (byte) 1, 4);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray19);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.clone(intArray4);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, (int) 'a');
        int[] intArray13 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray13, 1);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray13, (int) ' ', (int) (short) 100);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.add(intArray13, 1, (int) 'a');
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.subarray(intArray13, 0, 0);
        int[] intArray25 = new int[] {};
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, 4, 2);
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray25, 3);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray13, intArray25);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray25);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.add(intArray5, (int) (byte) -1);
        try {
            int[] intArray38 = org.apache.commons.lang3.ArrayUtils.remove(intArray5, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.lang.Float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        float[] floatArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray4);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, 2, (int) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, ' ', 7);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        short[] shortArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        java.lang.Long[] longArray12 = org.apache.commons.lang3.ArrayUtils.toObject(longArray11);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray11);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '#');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        try {
            int[] intArray23 = org.apache.commons.lang3.ArrayUtils.remove(intArray20, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.remove(intArray5, (int) (short) 0);
        int[] intArray17 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 1);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray17, (int) ' ', (int) (short) 100);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.add(intArray17, 1, (int) 'a');
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray25);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.subarray(intArray25, (int) (short) 100, 4);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray29, (int) (byte) 10);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.add(intArray29, 5);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray33, (int) (short) 100, 3);
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.subarray(intArray33, (int) 'a', 10);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        int[] intArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (int) (byte) -1, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray15, 'a', (int) ' ');
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray15, 'a');
        char[] charArray26 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray26, '#');
        char[] charArray29 = new char[] {};
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray26, charArray29);
        char[] charArray31 = org.apache.commons.lang3.ArrayUtils.addAll(charArray20, charArray26);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray31);
        char[] charArray34 = org.apache.commons.lang3.ArrayUtils.add(charArray31, 'a');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(charArray34);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.lang.Float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        java.lang.Character[] charArray5 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5);
        char[] charArray12 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray12, '#');
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.addAll(charArray6, charArray12);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.add(charArray15, '4');
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.subarray(charArray17, (int) (byte) 1, 4);
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.subarray(charArray20, 2, (int) (byte) 0);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) floatArray0, (java.lang.Object) 2);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0, (float) (short) 100);
        java.lang.Character[] charArray30 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray31 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray30);
        char[] charArray37 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray37, '#');
        char[] charArray40 = org.apache.commons.lang3.ArrayUtils.addAll(charArray31, charArray37);
        char[] charArray42 = org.apache.commons.lang3.ArrayUtils.add(charArray40, '4');
        char[] charArray45 = org.apache.commons.lang3.ArrayUtils.subarray(charArray42, (int) (byte) 1, 4);
        int int46 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray0, (java.lang.Object) (byte) 1);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, 100, 100 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (short) 100);
        int[] intArray6 = new int[] {};
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, (-1));
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 4, 2);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray6, 3);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray6);
        int[] intArray20 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray20, 1);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) ' ', (int) (short) 100);
        int[] intArray31 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray31, 1);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray35 = org.apache.commons.lang3.ArrayUtils.addAll(intArray31, intArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray20, intArray35);
        int int38 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray35, (int) (byte) 0);
        int[] intArray40 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray35, 1);
        int[] intArray42 = org.apache.commons.lang3.ArrayUtils.add(intArray40, (int) '4');
        java.lang.Integer[] intArray46 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray46, 2);
        int[] intArray49 = org.apache.commons.lang3.ArrayUtils.addAll(intArray40, intArray48);
        int[] intArray51 = org.apache.commons.lang3.ArrayUtils.add(intArray48, (int) 'a');
        int int53 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray48, 0);
        int[] intArray56 = org.apache.commons.lang3.ArrayUtils.add(intArray48, 0, 7);
        boolean boolean57 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray6, intArray56);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray10, true);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16);
        short[] shortArray18 = new short[] {};
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray18);
        java.lang.Short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray17);
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray20, (short) (byte) 10);
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray22, (short) 0);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) booleanArray10, (java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray5);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) 10.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 5, (double) (short) 10);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray7, (double) '#', (int) ' ', (double) (-1L));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray28 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray28, 100L, (int) '4');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray28, (long) (byte) 10);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray21, (java.lang.Object) longArray33);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray33, (int) (byte) 10, (int) (byte) 0);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.add(longArray37, (long) (byte) 1);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) 100, 100);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray37);
        java.lang.Long[] longArray46 = org.apache.commons.lang3.ArrayUtils.toObject(longArray45);
        long[] longArray48 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray46, (long) 4);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertNotNull(longArray48);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray23, true);
        boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(booleanArray28);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray5);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray5, false);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.add(booleanArray11, true);
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.add(booleanArray11, true);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray11, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray16, (long) '#');
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray20);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray10.getClass();
        java.lang.Class<?>[] wildcardClassArray12 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16);
        short[] shortArray18 = new short[] {};
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray18);
        java.lang.Short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray17);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) -1);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray12, (java.lang.Object) (short) -1);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) longArray10, (java.lang.Object[]) wildcardClassArray12);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10);
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10, 0L);
        java.lang.Long[] longArray28 = org.apache.commons.lang3.ArrayUtils.toObject(longArray27);
        java.lang.Short[] shortArray29 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray36 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray36, 100L, (int) '4');
        long[] longArray41 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray36, (long) (byte) 10);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray29, (java.lang.Object) longArray41);
        long[] longArray43 = org.apache.commons.lang3.ArrayUtils.clone(longArray41);
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray43);
        long[] longArray51 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int54 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray51, 100L, (int) '4');
        long[] longArray56 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray51, (long) (byte) 10);
        java.lang.Long[] longArray57 = org.apache.commons.lang3.ArrayUtils.toObject(longArray56);
        long[] longArray58 = org.apache.commons.lang3.ArrayUtils.addAll(longArray43, longArray56);
        long[] longArray59 = org.apache.commons.lang3.ArrayUtils.addAll(longArray27, longArray56);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClassArray12);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(longArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(longArray51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 4 + "'", int54 == 4);
        org.junit.Assert.assertNotNull(longArray56);
        org.junit.Assert.assertNotNull(longArray57);
        org.junit.Assert.assertNotNull(longArray58);
        org.junit.Assert.assertNotNull(longArray59);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        float[] floatArray5 = new float[] { (-1), (byte) 10, (short) 100, 1L, 1.0f };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (byte) 1, (int) '#');
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray8, (float) (-1));
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 100);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray4, (short) 0, (int) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) (byte) 0, (int) (short) 10);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.add(floatArray17, (float) 10L);
        java.lang.Class<?> wildcardClass20 = floatArray19.getClass();
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.add(floatArray19, 1, 0.0f);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray19);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray14 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '#');
        char[] charArray21 = new char[] { '#', ' ', '#', '4' };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray14, charArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        java.lang.Character[] charArray24 = org.apache.commons.lang3.ArrayUtils.toObject(charArray8);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(charArray24);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, 100, 100 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (short) 100);
        int[] intArray6 = new int[] {};
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, (-1));
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 4, 2);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray6, 3);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray6);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray14, 1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        char[][] charArray0 = new char[][] {};
        java.lang.Object[] objArray2 = null;
        java.lang.Character[] charArray6 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6);
        java.lang.Character[] charArray8 = org.apache.commons.lang3.ArrayUtils.toObject(charArray7);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray2, (java.lang.Object) charArray7);
        java.lang.Character[] charArray10 = org.apache.commons.lang3.ArrayUtils.toObject(charArray7);
        char[][] charArray11 = org.apache.commons.lang3.ArrayUtils.add(charArray0, 0, charArray7);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray7, '4', (int) (byte) 10);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray7, '#', 10);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1, 4, 1, 3 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4, 5);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray7);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 0, (-1));
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 1, 5);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray14, (byte) 100, (int) (short) 0);
        try {
            byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.remove(byteArray14, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, 'a');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        boolean[] booleanArray2 = new boolean[] { true, false };
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray2, true, (int) '4');
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray2, false, (int) (byte) 0);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray2, false);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray2, false);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(longArray6, (long) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray0);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.Boolean[] booleanArray6 = new java.lang.Boolean[] { false, false, false, true, true, false };
        boolean[] booleanArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (byte) 1);
        double[] doubleArray3 = new double[] {};
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray3, (double) (-1.0f), (double) 1L);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) (short) 0, (int) (short) 100, (double) '4');
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray3);
        try {
            double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray11, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray10);
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.add(charArray10, ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray16);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        java.lang.Long[] longArray19 = org.apache.commons.lang3.ArrayUtils.toObject(longArray16);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray19);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(longArray20, (long) 4);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray0, (long) 'a');
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray0, (long) '4');
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray4, (long) 100);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0);
        java.lang.Short[] shortArray2 = new java.lang.Short[] {};
        java.lang.Short[] shortArray3 = new java.lang.Short[] {};
        java.lang.Short[] shortArray4 = new java.lang.Short[] {};
        java.lang.Short[] shortArray5 = new java.lang.Short[] {};
        java.lang.Short[][] shortArray6 = new java.lang.Short[][] { shortArray2, shortArray3, shortArray4, shortArray5 };
        java.lang.Short[][] shortArray9 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray6, (-1), (int) '#');
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) charArray0, (java.lang.Object) shortArray6, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray6);
        java.lang.Object obj13 = null;
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray6, obj13);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) -1, (byte) 1, (byte) 0 };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray4, (byte) 10, 1);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray4, (byte) -1);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray4, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        short[] shortArray1 = new short[] { (byte) 100 };
        int int4 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray1, (short) -1, (int) (byte) 100);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray1, (short) 1, (-1));
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray1);
        java.lang.Short[] shortArray12 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray12);
        short[] shortArray14 = new short[] {};
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray13, shortArray14);
        java.lang.Short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray13);
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) 10);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray8, (java.lang.Object) (short) 10, (int) '#');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "1", "1" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = org.apache.commons.lang3.ArrayUtils.subarray((java.lang.Comparable<java.lang.String>[]) strArray4, 10, (int) (short) -1);
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.remove(strArray4, (int) (short) 0);
        try {
            java.lang.String[] strArray12 = org.apache.commons.lang3.ArrayUtils.add(strArray4, (int) '4', "{10,-1,1,32,100,-1}");
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        float[] floatArray18 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray18, (float) (short) 1);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray20, (int) '#', (int) ' ');
        float[] floatArray30 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray30, (float) (short) 1);
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.clone(floatArray30);
        java.lang.Float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray33);
        float[] floatArray41 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray41, (float) (short) 1);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.clone(floatArray41);
        java.lang.Float[] floatArray45 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray44);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray34, (java.lang.Object[]) floatArray45);
        float[] floatArray48 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray34, (float) (byte) 0);
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) boolean11, (java.lang.Object) floatArray20);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.contains(floatArray20, (float) 10);
        int int55 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray20, (float) (short) 1, 4);
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        java.lang.Long[] longArray9 = org.apache.commons.lang3.ArrayUtils.toObject(longArray5);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) longArray9);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray4);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.Float[] floatArray0 = new java.lang.Float[] {};
        java.lang.Float[] floatArray1 = new java.lang.Float[] {};
        java.lang.Float[] floatArray2 = new java.lang.Float[] {};
        java.lang.Float[] floatArray3 = new java.lang.Float[] {};
        java.lang.Float[] floatArray4 = new java.lang.Float[] {};
        java.lang.Float[] floatArray5 = new java.lang.Float[] {};
        java.lang.Float[][] floatArray6 = new java.lang.Float[][] { floatArray0, floatArray1, floatArray2, floatArray3, floatArray4, floatArray5 };
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray6);
        java.lang.Float[] floatArray14 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray14);
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray14);
        float[] floatArray23 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray23, (float) (short) 1);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.add(floatArray25, 0.0f);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray27, 100, (int) (short) 100);
        float[] floatArray35 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray35, (int) (byte) 100, (int) '4');
        int int41 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray35, (float) ' ', (int) 'a');
        float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.add(floatArray35, (float) (short) 100);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray27, floatArray43);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray16, floatArray27);
        float[] floatArray46 = org.apache.commons.lang3.ArrayUtils.clone(floatArray16);
        java.lang.Float[] floatArray47 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray46);
        java.lang.Float[][] floatArray48 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, 6, floatArray47);
        float[] floatArray50 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray47, (float) 1);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray50);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, (int) '4', 4);
        java.lang.Character[] charArray11 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray11);
        char[] charArray18 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray18, '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.addAll(charArray12, charArray18);
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.add(charArray21, '4');
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.subarray(charArray23, (int) (byte) 1, 4);
        char[] charArray31 = new char[] { 'a', ' ', '4', '#' };
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray31, 'a');
        char[] charArray35 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray31, '4');
        char[] charArray41 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int43 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray41, '#');
        char[] charArray48 = new char[] { '#', ' ', '#', '4' };
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray41, charArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray35, charArray41);
        char[] charArray53 = org.apache.commons.lang3.ArrayUtils.add(charArray35, 3, ' ');
        char[] charArray54 = org.apache.commons.lang3.ArrayUtils.addAll(charArray26, charArray53);
        char[] charArray55 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray26);
        char[] charArray58 = org.apache.commons.lang3.ArrayUtils.add(charArray4, (int) (byte) 0, 'a');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertNotNull(charArray58);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) -1, (byte) 1, (byte) 0 };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray4, (byte) 10, 1);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray4, (byte) -1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray9, (byte) 10, 6);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray20);
        boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray21);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray22, true, 10);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.Float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        java.lang.Character[] charArray5 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5);
        char[] charArray12 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray12, '#');
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.addAll(charArray6, charArray12);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.add(charArray15, '4');
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.subarray(charArray17, (int) (byte) 1, 4);
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.subarray(charArray20, 2, (int) (byte) 0);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) floatArray0, (java.lang.Object) 2);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0, (float) (short) 100);
        float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.add(floatArray26, (int) (short) 0, (float) 100);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.remove(intArray5, (int) (short) 0);
        int[] intArray17 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 1);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray17, (int) ' ', (int) (short) 100);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.add(intArray17, 1, (int) 'a');
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray25);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.subarray(intArray25, (int) (short) 100, 4);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray29, (int) (byte) 10);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.add(intArray29, 5);
        java.lang.String str34 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) intArray33);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray33, 3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{5}" + "'", str34.equals("{5}"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray15, 'a', (int) ' ');
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray15, 'a');
        char[] charArray26 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray26, '#');
        char[] charArray29 = new char[] {};
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray26, charArray29);
        char[] charArray31 = org.apache.commons.lang3.ArrayUtils.addAll(charArray20, charArray26);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray31);
        char[] charArray37 = new char[] { 'a', ' ', '4', '#' };
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray37, 'a');
        char[] charArray41 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray37, '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray41, ' ', 3);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray31, charArray41);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        try {
            double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray2, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, false);
        java.lang.Boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.add(floatArray19, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray19);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray19, (float) (byte) 0, (int) (short) 10);
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray19, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.add(floatArray28, (float) 10L);
        float[] floatArray35 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray35, (int) (byte) 100, (int) '4');
        int int41 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray35, (float) ' ', (int) 'a');
        float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.add(floatArray35, (float) (short) 100);
        float[] floatArray46 = org.apache.commons.lang3.ArrayUtils.add(floatArray43, 0, (float) 0L);
        boolean boolean47 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray30, floatArray46);
        int int49 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) booleanArray9, (java.lang.Object) boolean47, 0);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (short) 100, 0);
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray21, '#', (-1));
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (byte) 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        java.lang.String[] strArray9 = null;
        int[] intArray15 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray15, 1);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray15, intArray18);
        java.lang.String[] strArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray9, (java.lang.Object) intArray19);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray19, (int) '4');
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.addAll(intArray8, intArray19);
        java.lang.Integer[] intArray24 = org.apache.commons.lang3.ArrayUtils.toObject(intArray8);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray24);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNull(strArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.add(longArray11, 1L);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, (int) (short) 10, (int) (byte) 1);
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray16, (long) (short) 10, 1);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double[] doubleArray0 = null;
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (-1L), (int) 'a', (double) 10L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray20);
        float[] floatArray28 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray28, (float) (short) 1);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.add(floatArray30, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray30);
        int int36 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray30, (float) (byte) 0, (int) (short) 10);
        int int38 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) booleanArray21, (java.lang.Object) (byte) 0, (int) (short) 0);
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray21, false);
        try {
            boolean[] booleanArray43 = org.apache.commons.lang3.ArrayUtils.add(booleanArray40, (int) (byte) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(booleanArray40);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray9, (float) (byte) 10, (int) (byte) 10);
        float[] floatArray18 = new float[] { (-1), (byte) 10, (short) 100, 1L, 1.0f };
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, (int) (byte) 1, (int) '#');
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray9, floatArray18);
        java.lang.Class<?> wildcardClass23 = floatArray18.getClass();
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.subarray(longArray6, (int) (byte) 0, 0);
        long[] longArray19 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray19, 100L, (int) '4');
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray19, (long) (byte) 10);
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.subarray(longArray24, 2, 1);
        java.lang.Long[] longArray28 = org.apache.commons.lang3.ArrayUtils.toObject(longArray27);
        long[] longArray29 = org.apache.commons.lang3.ArrayUtils.addAll(longArray6, longArray27);
        int int32 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray29, 0L, 4);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray15, (int) (byte) 1, '4');
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.subarray(charArray21, (int) (short) 10, (int) (byte) 10);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray21, 'a');
        char[] charArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray26, 'a');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray28);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1L));
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) 0, (byte) 0, (byte) -1, (byte) 10, (byte) 0 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = new byte[] {};
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        java.lang.Byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray11);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray8, byteArray13);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray8);
        byte[] byteArray16 = new byte[] {};
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.clone(byteArray16);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray17, 1, (int) (byte) -1);
        byte[] byteArray21 = new byte[] {};
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.clone(byteArray21);
        byte[] byteArray23 = new byte[] {};
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.clone(byteArray23);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.clone(byteArray23);
        java.lang.Byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray25);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.clone(byteArray25);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray22, byteArray27);
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray27, (byte) 10, (int) (short) 10);
        int int33 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray27, (byte) 100);
        byte[] byteArray36 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray27, 1, (-1));
        byte[] byteArray38 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray27, (byte) 1);
        byte[] byteArray39 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray20, byteArray38);
        java.lang.Byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray38);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray8, byteArray38);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        java.lang.Short[] shortArray5 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray7 = new short[] {};
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray7);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray7);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 1);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray9);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray12, 10, 100);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray12, (short) -1);
        short[] shortArray22 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray22);
        short[] shortArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray23, (short) 0);
        boolean[] booleanArray26 = new boolean[] {};
        boolean[] booleanArray31 = new boolean[] { true, false, false, true };
        boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray26, booleanArray31);
        boolean[] booleanArray33 = new boolean[] {};
        boolean[] booleanArray38 = new boolean[] { true, false, false, true };
        boolean[] booleanArray39 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray33, booleanArray38);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray32, booleanArray38);
        int int43 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray32, true, 1);
        boolean[] booleanArray49 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray50 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray49);
        boolean boolean51 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray32, booleanArray49);
        int int52 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray23, (java.lang.Object) boolean51);
        byte[] byteArray55 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray56 = new byte[][] { byteArray55 };
        byte[][] byteArray57 = org.apache.commons.lang3.ArrayUtils.clone(byteArray56);
        boolean boolean58 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray23, (java.lang.Object) byteArray57);
        short[] shortArray59 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray23);
        short[] shortArray61 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray59, (short) -1);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray12, shortArray59);
        short[] shortArray63 = null;
        short[] shortArray64 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray59, shortArray63);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray25);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(booleanArray49);
        org.junit.Assert.assertNotNull(booleanArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shortArray59);
        org.junit.Assert.assertNotNull(shortArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(shortArray64);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (short) 10, (int) '4');
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (double) (short) 1);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.add(doubleArray19, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray21);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray21, doubleArray25);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray25, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray30 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray25);
        int int31 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) doubleArray25);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray25);
        java.lang.String str33 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{10.0}" + "'", str33.equals("{10.0}"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray1, 1, (int) (byte) -1);
        byte[] byteArray5 = new byte[] {};
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        java.lang.Byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray11);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray11, (byte) 10, (int) (short) 10);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray11, (byte) 100);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray11, 1, (-1));
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray11, (byte) 1);
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray4, byteArray22);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains(byteArray23, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.lang.Long[] longArray3 = new java.lang.Long[] { 1L, 100L, 1L };
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray3);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray3);
        byte[] byteArray6 = new byte[] {};
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        byte[] byteArray8 = new byte[] {};
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray10);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray10);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray7, byteArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray7, (byte) -1);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.add(byteArray18, (byte) -1);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray18, (byte) 0);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray3, (java.lang.Object) byteArray22, 2);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.clone(byteArray22);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.add(byteArray22, (byte) 0);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray27);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7, (short) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray10);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        char[] charArray5 = new char[] { '4', '4', 'a', 'a', '4' };
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.add(charArray5, '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray5, 'a');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray8, (short) 10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray8, (short) 1, (int) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        short[] shortArray1 = new short[] { (byte) 100 };
        java.lang.Short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray1);
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray1, (int) (byte) 1, 6);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) 0, 0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        java.lang.Character[] charArray11 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray11);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(charArray12, 'a');
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray12);
        int int16 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) charArray12);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray12);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) intArray3, (java.lang.Object) boolean17);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 10, (int) (short) 10, (double) 'a');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[] shortArray7 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[] shortArray11 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[] shortArray15 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[][] shortArray16 = new java.lang.Short[][] { shortArray3, shortArray7, shortArray11, shortArray15 };
        java.lang.Short[] shortArray20 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[] shortArray24 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[] shortArray28 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[] shortArray32 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[][] shortArray33 = new java.lang.Short[][] { shortArray20, shortArray24, shortArray28, shortArray32 };
        java.lang.Short[] shortArray37 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[] shortArray41 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[] shortArray45 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[] shortArray49 = new java.lang.Short[] { (short) 100, (short) -1, (short) 0 };
        java.lang.Short[][] shortArray50 = new java.lang.Short[][] { shortArray37, shortArray41, shortArray45, shortArray49 };
        java.lang.Short[][][] shortArray51 = new java.lang.Short[][][] { shortArray16, shortArray33, shortArray50 };
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray51);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertNotNull(shortArray33);
        org.junit.Assert.assertNotNull(shortArray37);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertNotNull(shortArray45);
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(shortArray50);
        org.junit.Assert.assertNotNull(shortArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray13, (double) 0.0f, (int) (short) 10, (double) '#');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.clone(intArray20);
        int[] intArray32 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray32, 1);
        int int37 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray32, (int) ' ', (int) (short) 100);
        int[] intArray40 = org.apache.commons.lang3.ArrayUtils.add(intArray32, 1, (int) 'a');
        int[] intArray43 = org.apache.commons.lang3.ArrayUtils.subarray(intArray32, 0, 0);
        int[] intArray44 = org.apache.commons.lang3.ArrayUtils.addAll(intArray26, intArray32);
        int[] intArray46 = org.apache.commons.lang3.ArrayUtils.add(intArray32, 2);
        try {
            int[] intArray48 = org.apache.commons.lang3.ArrayUtils.remove(intArray46, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray46);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) -1, (byte) 1, (byte) 0 };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray4, (byte) 10, 1);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray4, (byte) -1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (int) (short) 0, (byte) 0);
        java.lang.Character[] charArray16 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray16);
        char[] charArray23 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray23, '#');
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.addAll(charArray17, charArray23);
        char[] charArray28 = org.apache.commons.lang3.ArrayUtils.add(charArray26, '4');
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray28, '#', (int) '#');
        char[] charArray34 = org.apache.commons.lang3.ArrayUtils.subarray(charArray28, (int) (short) 100, 0);
        char[] charArray36 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray28, '#');
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray28, 'a', 1);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) byteArray9, (java.lang.Object) 'a');
        byte[] byteArray42 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray9, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(byteArray42);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        java.lang.Short[] shortArray5 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray7 = new short[] {};
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray7);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray7);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 1);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray9);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray12, 10, 100);
        short[] shortArray20 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray20);
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray12, shortArray20);
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray12, (short) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(shortArray24);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (int) ' ', (int) (short) 100);
        byte[] byteArray14 = new byte[] {};
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray16);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.clone(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray16);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(byteArray19, (byte) -1);
        byte[] byteArray22 = new byte[] {};
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.clone(byteArray22);
        byte[] byteArray24 = new byte[] {};
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.clone(byteArray24);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.clone(byteArray24);
        java.lang.Byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray26);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.clone(byteArray26);
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray23, byteArray28);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray28, (byte) 0, (int) (short) 100);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray19, byteArray28);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.contains(byteArray28, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray1, (byte) -1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray1, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray13 = new byte[] {};
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        byte[] byteArray15 = new byte[] {};
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        java.lang.Byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray17);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.clone(byteArray17);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray14, byteArray19);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray19);
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray19, (byte) 0);
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray19);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains(byteArray19, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(longArray6, (long) 1);
        java.lang.Short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray19 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray19, 100L, (int) '4');
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray19, (long) (byte) 10);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray12, (java.lang.Object) longArray24);
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.subarray(longArray24, (int) (byte) 10, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray28);
        java.lang.Long[] longArray30 = org.apache.commons.lang3.ArrayUtils.toObject(longArray28);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray6, longArray28);
        long[] longArray34 = org.apache.commons.lang3.ArrayUtils.add(longArray6, 4, (long) 'a');
        long[] longArray35 = org.apache.commons.lang3.ArrayUtils.clone(longArray6);
        int int37 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 10L);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        java.lang.Short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray16 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, 100L, (int) '4');
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray16, (long) (byte) 10);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray9, (java.lang.Object) longArray21);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.subarray(longArray21, (int) (byte) 10, (int) (byte) 0);
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.add(longArray25, (long) (byte) 1);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray25, (long) '4');
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray5, longArray25);
        long[] longArray31 = org.apache.commons.lang3.ArrayUtils.clone(longArray25);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(longArray31);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) 100, 100);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray16, (long) 2, (int) (byte) 100);
        try {
            long[] longArray29 = org.apache.commons.lang3.ArrayUtils.add(longArray16, 1, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10, (long) 6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 10.0f, 100, (double) (byte) -1);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.add(doubleArray17, (double) (byte) 10);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray19, (double) (short) 100, (int) '#');
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray6, doubleArray19);
        try {
            double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (int) (byte) 10, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (byte) 100);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray10, (double) (byte) 10, (int) (byte) 0, (double) 100);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        java.lang.Short[] shortArray7 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.add(shortArray8, (short) 0);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray8);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 100);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray17, (short) (byte) -1);
        short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.clone(shortArray17);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) (byte) 100);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains(shortArray17, (short) 0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray15, (int) (byte) 1, '4');
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.subarray(charArray21, (int) (short) 10, (int) (byte) 10);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray21);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { (-1), (-1), 10 };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (short) 100);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        char[] charArray6 = new char[] { '4', ' ', 'a', '#', '#', '4' };
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray6, ' ');
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.subarray(charArray6, (int) (short) 100, (int) (short) 1);
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.clone(charArray6);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray6, '#', (int) 'a');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray10, (int) (byte) 1);
        boolean[] booleanArray18 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray18);
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray19, true);
        boolean[] booleanArray22 = new boolean[] {};
        boolean[] booleanArray27 = new boolean[] { true, false, false, true };
        boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray22, booleanArray27);
        boolean[] booleanArray29 = new boolean[] {};
        boolean[] booleanArray34 = new boolean[] { true, false, false, true };
        boolean[] booleanArray35 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray29, booleanArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray28, booleanArray34);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray21, booleanArray28);
        boolean[] booleanArray38 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray12, booleanArray28);
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.add(booleanArray38, false);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertNotNull(booleanArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray20);
        boolean[] booleanArray22 = new boolean[] {};
        boolean[] booleanArray27 = new boolean[] { true, false, false, true };
        boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray22, booleanArray27);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray27, true);
        boolean[] booleanArray33 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray27, 3, (int) (short) 10);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray33, false);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray20, booleanArray33);
        try {
            boolean[] booleanArray38 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray20, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (byte) 1, 4);
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.subarray(charArray18, 2, (int) (byte) 0);
        java.lang.String str23 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) (byte) 0, "");
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray10, 100, (int) (short) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray10, 10.0f, (int) (short) 1);
        java.lang.Float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray10);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        byte[] byteArray12 = new byte[] {};
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.clone(byteArray12);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.clone(byteArray12);
        java.lang.Byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray14);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray14, 0, 100);
        java.lang.Class<?> wildcardClass20 = byteArray14.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray21 = org.apache.commons.lang3.ArrayUtils.add((java.lang.reflect.GenericDeclaration[]) wildcardClassArray0, (java.lang.reflect.GenericDeclaration) wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(genericDeclarationArray21);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        int[] intArray4 = new int[] { ' ', '#', 0, '4' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray4, 0);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray4, (int) (short) 100);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) '4');
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.subarray(intArray5, (int) (short) 0, 6);
        java.lang.String[] strArray16 = null;
        int[] intArray22 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray22, 1);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.addAll(intArray22, intArray25);
        java.lang.String[] strArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray16, (java.lang.Object) intArray26);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.clone(intArray26);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray26, 0);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.addAll(intArray15, intArray26);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNull(strArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 10, (int) (short) 10);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray6, (byte) 100);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray20, 100);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, (int) (short) 10);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray5);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray5, false);
        java.lang.Boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray11);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray12, true);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray14);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray3 = new byte[][] { byteArray2 };
        byte[][] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray3);
        byte[][] byteArray7 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray4, 5, (int) (byte) 0);
        byte[][] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray7);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 0, (-1));
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 1, 5);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray14, 5, 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray17);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[] byteArray13 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[] byteArray20 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[][] byteArray21 = new java.lang.Byte[][] { byteArray6, byteArray13, byteArray20 };
        java.lang.Byte[][] byteArray23 = org.apache.commons.lang3.ArrayUtils.remove(byteArray21, 0);
        float[] floatArray28 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray28, (int) (byte) 100, (int) '4');
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray23, (java.lang.Object) '4');
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray23);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        float[] floatArray5 = new float[] { (-1), (byte) 10, (short) 100, 1L, 1.0f };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (byte) 1, (int) '#');
        float[] floatArray15 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray15, (float) (short) 1);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.add(floatArray17, 0.0f);
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray17, (float) 100L);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray5, floatArray17);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray4);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray10, (short) (byte) 1, 100);
        java.lang.Class<?> wildcardClass14 = shortArray10.getClass();
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) (short) 100);
        try {
            float[] floatArray14 = org.apache.commons.lang3.ArrayUtils.add(floatArray11, (int) 'a', (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, 10.0f);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray32, 1.0f, (int) (short) 1);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray32, (float) 100L, (-1));
        float[] floatArray40 = org.apache.commons.lang3.ArrayUtils.add(floatArray32, 1.0f);
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray32, (float) 4);
        java.lang.Float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray32);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(floatArray43);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 2);
        double[] doubleArray3 = null;
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray2, doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, '#');
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray2, 'a', 5);
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.subarray(charArray2, (int) (short) 100, (-1));
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(charArray8);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        char[][] charArray0 = new char[][] {};
        java.lang.Object[] objArray2 = null;
        java.lang.Character[] charArray6 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6);
        java.lang.Character[] charArray8 = org.apache.commons.lang3.ArrayUtils.toObject(charArray7);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray2, (java.lang.Object) charArray7);
        java.lang.Character[] charArray10 = org.apache.commons.lang3.ArrayUtils.toObject(charArray7);
        char[][] charArray11 = org.apache.commons.lang3.ArrayUtils.add(charArray0, 0, charArray7);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray7, '4', (int) (byte) 10);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray7, '4');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        char[] charArray5 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#');
        char[] charArray8 = new char[] {};
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray5, charArray8);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray5, 'a');
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#');
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(charArray5, 'a');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        float[] floatArray18 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray18, (float) (short) 1);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray20, (int) '#', (int) ' ');
        float[] floatArray30 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray30, (float) (short) 1);
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.clone(floatArray30);
        java.lang.Float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray33);
        float[] floatArray41 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray41, (float) (short) 1);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.clone(floatArray41);
        java.lang.Float[] floatArray45 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray44);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray34, (java.lang.Object[]) floatArray45);
        float[] floatArray48 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray34, (float) (byte) 0);
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) boolean11, (java.lang.Object) floatArray20);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.contains(floatArray20, (float) 10);
        boolean boolean54 = org.apache.commons.lang3.ArrayUtils.contains(floatArray20, 1.0f);
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray14, (long) ' ');
        java.lang.Short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray25 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray25, 100L, (int) '4');
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray25, (long) (byte) 10);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray18, (java.lang.Object) longArray30);
        long[] longArray34 = org.apache.commons.lang3.ArrayUtils.subarray(longArray30, (int) (byte) 10, (int) (byte) 0);
        long[] longArray36 = org.apache.commons.lang3.ArrayUtils.remove(longArray30, 2);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray36);
        long[] longArray38 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray36);
        int int41 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray14, (long) 6, (int) (byte) -1);
        long[] longArray42 = null;
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray14, longArray42);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(longArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        boolean[] booleanArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray0, true, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, 10.0f);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray35 = org.apache.commons.lang3.ArrayUtils.add(doubleArray33, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray35);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray39 = org.apache.commons.lang3.ArrayUtils.add(doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray35, doubleArray39);
        double[] doubleArray41 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray39);
        int int43 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) doubleArray39, (int) (short) 100);
        float[] floatArray45 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) (short) 0);
        java.lang.Class<?> wildcardClass46 = floatArray5.getClass();
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.lang.String[] strArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray0, (java.lang.Object) intArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 6);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray10);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNull(strArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.lang.Character[] charArray5 = new java.lang.Character[] { ' ', ' ', ' ', 'a', ' ' };
        java.lang.Character[] charArray11 = new java.lang.Character[] { ' ', ' ', ' ', 'a', ' ' };
        java.lang.Character[][] charArray12 = new java.lang.Character[][] { charArray5, charArray11 };
        java.lang.Character[] charArray18 = new java.lang.Character[] { '#', ' ', 'a', '#', ' ' };
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray18);
        java.lang.Character[][] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray12, charArray18);
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray18, 'a');
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray22, 'a', (int) (byte) -1);
        char[] charArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray22, '4');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(charArray27);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray10.getClass();
        java.lang.Short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray19 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray19, 100L, (int) '4');
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray19, (long) (byte) 10);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray12, (java.lang.Object) longArray24);
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.subarray(longArray24, (int) (byte) 10, (int) (byte) 0);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) longArray10, (java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.Object[] objArray0 = null;
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = new byte[] {};
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        java.lang.Byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray6);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray3, byteArray8);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray8, (byte) 0);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray1, byteArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray0, (java.lang.Object) byteArray1);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.add(byteArray1, (byte) 1);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.add(byteArray1, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray10, 100, (int) (short) 100);
        float[] floatArray18 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, (int) (byte) 100, (int) '4');
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray18, (float) ' ', (int) 'a');
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) (short) 100);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray10, floatArray26);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.contains(floatArray10, 1.0f);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean[] booleanArray8 = new boolean[] {};
        boolean[] booleanArray13 = new boolean[] { true, false, false, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, true, 1);
        boolean[] booleanArray31 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) boolean33);
        byte[] byteArray37 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray38 = new byte[][] { byteArray37 };
        byte[][] byteArray39 = org.apache.commons.lang3.ArrayUtils.clone(byteArray38);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray5, (java.lang.Object) byteArray39);
        short[] shortArray42 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) (byte) 10);
        short[] shortArray44 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) (byte) 10);
        try {
            short[] shortArray46 = org.apache.commons.lang3.ArrayUtils.remove(shortArray44, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shortArray42);
        org.junit.Assert.assertNotNull(shortArray44);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0, true);
        boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0, false);
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray6, true, 0);
        boolean[] booleanArray23 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, true);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray23, true, (int) (short) 1);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, 10.0f);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray32, 1.0f, (int) (short) 1);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray32, (float) 100L, (-1));
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray32);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray32);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.add(longArray11, 1L);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, (int) (short) 10, (int) (byte) 1);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray16, 100L);
        java.lang.Long[] longArray19 = org.apache.commons.lang3.ArrayUtils.toObject(longArray18);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        java.lang.Byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray11);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray13, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (byte) 1, 4);
        char[] charArray23 = new char[] { 'a', ' ', '4', '#' };
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray23, 'a');
        char[] charArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray23, '4');
        char[] charArray33 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int35 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray33, '#');
        char[] charArray40 = new char[] { '#', ' ', '#', '4' };
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray33, charArray40);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray27, charArray33);
        char[] charArray45 = org.apache.commons.lang3.ArrayUtils.add(charArray27, 3, ' ');
        char[] charArray46 = org.apache.commons.lang3.ArrayUtils.addAll(charArray18, charArray45);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray45, '4', (int) (byte) 10);
        int int52 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray45, ' ', (int) (byte) 0);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(charArray46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        float[] floatArray0 = null;
        float[] floatArray7 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray7, (float) (short) 1);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 0.0f);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray0, floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.clone(floatArray0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(floatArray13);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.clone(longArray9);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.subarray(longArray10, 0, 4);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray13, (long) (short) -1);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.subarray(intArray5, 0, 0);
        int[] intArray17 = new int[] {};
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, (-1));
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 4, 2);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray17, 3);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray17);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains(intArray5, (int) (short) 1);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.contains(intArray5, (int) (byte) 1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        char[] charArray0 = null;
        try {
            char[] charArray2 = org.apache.commons.lang3.ArrayUtils.remove(charArray0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray5);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray5, 1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (byte) 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        java.lang.String[] strArray9 = null;
        int[] intArray15 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray15, 1);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray15, intArray18);
        java.lang.String[] strArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray9, (java.lang.Object) intArray19);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray19, (int) '4');
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.addAll(intArray8, intArray19);
        int[] intArray29 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray29, 1);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray29, (int) ' ', (int) (short) 100);
        int[] intArray40 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray40, 1);
        int[] intArray43 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray44 = org.apache.commons.lang3.ArrayUtils.addAll(intArray40, intArray43);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray29, intArray44);
        int[] intArray46 = org.apache.commons.lang3.ArrayUtils.addAll(intArray8, intArray44);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNull(strArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(intArray46);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray12, (long) (byte) 10);
        java.lang.Long[] longArray24 = org.apache.commons.lang3.ArrayUtils.toObject(longArray12);
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray24, (long) 6);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray26);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray28 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray28, 100L, (int) '4');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray28, (long) (byte) 10);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray21, (java.lang.Object) longArray33);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray33, (int) (byte) 10, (int) (byte) 0);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.add(longArray37, (long) (byte) 1);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) 100, 100);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray37);
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) 4, (int) (short) -1);
        java.lang.Short[] shortArray49 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray56 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int59 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray56, 100L, (int) '4');
        long[] longArray61 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray56, (long) (byte) 10);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray49, (java.lang.Object) longArray61);
        long[] longArray65 = org.apache.commons.lang3.ArrayUtils.subarray(longArray61, (int) (byte) 10, (int) (byte) 0);
        long[] longArray67 = org.apache.commons.lang3.ArrayUtils.add(longArray65, (long) (byte) 1);
        int int69 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray65, (long) '4');
        java.lang.Short[] shortArray70 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray77 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int80 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray77, 100L, (int) '4');
        long[] longArray82 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray77, (long) (byte) 10);
        boolean boolean83 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray70, (java.lang.Object) longArray82);
        long[] longArray86 = org.apache.commons.lang3.ArrayUtils.subarray(longArray82, (int) (byte) 10, (int) (byte) 0);
        long[] longArray88 = org.apache.commons.lang3.ArrayUtils.add(longArray86, (long) (byte) 1);
        int int90 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray86, (long) '4');
        int int93 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray86, (long) 100, 100);
        long[] longArray94 = org.apache.commons.lang3.ArrayUtils.addAll(longArray65, longArray86);
        long[] longArray95 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray94);
        long[] longArray96 = org.apache.commons.lang3.ArrayUtils.clone(longArray94);
        long[] longArray97 = org.apache.commons.lang3.ArrayUtils.clone(longArray96);
        int int99 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray96, (long) '#');
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(longArray56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(longArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(longArray65);
        org.junit.Assert.assertNotNull(longArray67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(shortArray70);
        org.junit.Assert.assertNotNull(longArray77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 4 + "'", int80 == 4);
        org.junit.Assert.assertNotNull(longArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(longArray86);
        org.junit.Assert.assertNotNull(longArray88);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertNotNull(longArray94);
        org.junit.Assert.assertNotNull(longArray95);
        org.junit.Assert.assertNotNull(longArray96);
        org.junit.Assert.assertNotNull(longArray97);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + (-1) + "'", int99 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray5);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray5);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(intArray5, 6);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, false);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray10, false);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean[] booleanArray8 = new boolean[] {};
        boolean[] booleanArray13 = new boolean[] { true, false, false, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, true, 1);
        boolean[] booleanArray31 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) boolean33);
        byte[] byteArray37 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray38 = new byte[][] { byteArray37 };
        byte[][] byteArray39 = org.apache.commons.lang3.ArrayUtils.clone(byteArray38);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray5, (java.lang.Object) byteArray39);
        short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        java.lang.Object obj42 = null;
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, obj42, (-1));
        char[][] charArray45 = new char[][] {};
        java.lang.Object[] objArray47 = null;
        java.lang.Character[] charArray51 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray52 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray51);
        java.lang.Character[] charArray53 = org.apache.commons.lang3.ArrayUtils.toObject(charArray52);
        int int54 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray47, (java.lang.Object) charArray52);
        java.lang.Character[] charArray55 = org.apache.commons.lang3.ArrayUtils.toObject(charArray52);
        char[][] charArray56 = org.apache.commons.lang3.ArrayUtils.add(charArray45, 0, charArray52);
        java.lang.Object[] objArray57 = null;
        java.lang.Character[] charArray61 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray62 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray61);
        java.lang.Character[] charArray63 = org.apache.commons.lang3.ArrayUtils.toObject(charArray62);
        int int64 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray57, (java.lang.Object) charArray62);
        java.lang.Character[] charArray65 = org.apache.commons.lang3.ArrayUtils.toObject(charArray62);
        int int67 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray62, ' ');
        char[] charArray70 = org.apache.commons.lang3.ArrayUtils.subarray(charArray62, (int) (short) 1, 6);
        char[] charArray71 = org.apache.commons.lang3.ArrayUtils.addAll(charArray52, charArray62);
        boolean boolean73 = org.apache.commons.lang3.ArrayUtils.contains(charArray62, 'a');
        char[] charArray76 = org.apache.commons.lang3.ArrayUtils.add(charArray62, 0, 'a');
        int int77 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) shortArray5, (java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(charArray52);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertNotNull(charArray56);
        org.junit.Assert.assertNotNull(charArray61);
        org.junit.Assert.assertNotNull(charArray62);
        org.junit.Assert.assertNotNull(charArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(charArray65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(charArray70);
        org.junit.Assert.assertNotNull(charArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(charArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        java.lang.Short[] shortArray7 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.add(shortArray8, (short) 0);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray8);
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray16);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray17, (short) (byte) -1);
        java.lang.Short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray20, (java.lang.Object) "hi!");
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray20);
        java.lang.Short[] shortArray27 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray28 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray27);
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray28, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray28);
        short[] shortArray34 = org.apache.commons.lang3.ArrayUtils.add(shortArray28, (short) 0);
        short[] shortArray35 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray23, shortArray28);
        short[] shortArray37 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray28, (short) 100);
        short[] shortArray38 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray19, shortArray37);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray8, shortArray37);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertNotNull(shortArray37);
        org.junit.Assert.assertNotNull(shortArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, 10.0f);
        float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, 10.0f);
        java.lang.Integer[] intArray37 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray37, 0);
        int[] intArray40 = org.apache.commons.lang3.ArrayUtils.clone(intArray39);
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray40, (int) 'a');
        int[] intArray48 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int50 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray48, 1);
        int int53 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray48, (int) ' ', (int) (short) 100);
        int[] intArray56 = org.apache.commons.lang3.ArrayUtils.add(intArray48, 1, (int) 'a');
        int[] intArray59 = org.apache.commons.lang3.ArrayUtils.subarray(intArray48, 0, 0);
        int[] intArray60 = new int[] {};
        int int62 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray60, (-1));
        int int65 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray60, 4, 2);
        int[] intArray67 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray60, 3);
        boolean boolean68 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray48, intArray60);
        int[] intArray69 = org.apache.commons.lang3.ArrayUtils.addAll(intArray40, intArray60);
        int int70 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) intArray40);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray10.getClass();
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray12, true, 10);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) longArray10, (java.lang.Object) true);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(longArray17);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean[] booleanArray8 = new boolean[] {};
        boolean[] booleanArray13 = new boolean[] { true, false, false, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, true, 1);
        boolean[] booleanArray31 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) boolean33);
        byte[] byteArray37 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray38 = new byte[][] { byteArray37 };
        byte[][] byteArray39 = org.apache.commons.lang3.ArrayUtils.clone(byteArray38);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray5, (java.lang.Object) byteArray39);
        short[] shortArray42 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) -1);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shortArray42);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 10, (int) (short) 10);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 100);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, 1, (-1));
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray6);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        short[] shortArray3 = new short[] { (byte) 100, (short) -1, (short) 1 };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray3, (short) 0, 1);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray3, (short) (byte) 0, 0);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(shortArray3, (short) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) (byte) 100);
        float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) (byte) 1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) '4');
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, 0);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 100);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray15, 'a', (int) ' ');
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray15, 'a');
        char[] charArray26 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray26, '#');
        char[] charArray29 = new char[] {};
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray26, charArray29);
        char[] charArray31 = org.apache.commons.lang3.ArrayUtils.addAll(charArray20, charArray26);
        char[] charArray34 = org.apache.commons.lang3.ArrayUtils.add(charArray31, (int) (short) 0, '#');
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray34);
        char[] charArray38 = org.apache.commons.lang3.ArrayUtils.subarray(charArray34, 2, 3);
        char[] charArray39 = org.apache.commons.lang3.ArrayUtils.clone(charArray34);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(charArray39);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray10, (int) (byte) 1);
        boolean[] booleanArray18 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray18);
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray19, true);
        boolean[] booleanArray22 = new boolean[] {};
        boolean[] booleanArray27 = new boolean[] { true, false, false, true };
        boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray22, booleanArray27);
        boolean[] booleanArray29 = new boolean[] {};
        boolean[] booleanArray34 = new boolean[] { true, false, false, true };
        boolean[] booleanArray35 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray29, booleanArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray28, booleanArray34);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray21, booleanArray28);
        boolean[] booleanArray38 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray12, booleanArray28);
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.add(booleanArray38, false);
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.add(booleanArray40, false);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertNotNull(booleanArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertNotNull(booleanArray42);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        java.lang.Long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toObject(longArray7);
        java.lang.Class<?> wildcardClass12 = longArray11.getClass();
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) shortArray0, (java.lang.Object[]) longArray11);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) longArray11);
        long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray11);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray11, (long) 'a');
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) (byte) 0);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray4);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        java.lang.Short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray10, (short) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 2);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 10, (int) (byte) 1);
        java.lang.Double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray2);
        java.util.Map<java.lang.Object, java.lang.Object> objMap7 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objMap7);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.lang.Object[] objArray0 = null;
        java.lang.Character[] charArray4 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        java.lang.Character[] charArray6 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray0, (java.lang.Object) charArray5);
        java.lang.Character[] charArray8 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray8);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray8, ' ');
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray8);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray9);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray9);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(floatArray9, (float) 10);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray6, (short) 1, (int) ' ');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        char[] charArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '4', 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) (byte) 100);
        float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) '#');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray13 = new boolean[] { true, false };
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray13, true, (int) '4');
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray13, false, (int) (byte) 0);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray13, false);
        boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.add(booleanArray13, false);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray24);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray2, 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray2, (double) (short) -1);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, 0.0d, (int) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        long[] longArray15 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray15, (long) '4');
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.add(longArray17, (long) 4);
        long[] longArray22 = org.apache.commons.lang3.ArrayUtils.add(longArray17, 2, (long) (short) 10);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray9, longArray22);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray9, 10L, (int) ' ');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) -1);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray4, (short) -1, (int) (short) -1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray11, (long) 3);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray11, (long) 4, (int) (short) 0);
        long[] longArray23 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray23, 100L, (int) '4');
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray23, (long) (byte) 10);
        int int30 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray28, (long) 3);
        int int33 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray28, (long) 4, (int) (short) 0);
        long[] longArray34 = org.apache.commons.lang3.ArrayUtils.addAll(longArray11, longArray28);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, (int) (short) 10, (int) (short) 100);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray37);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) 0, (byte) 0, (byte) -1, (byte) 10, (byte) 0 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = new byte[] {};
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        java.lang.Byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray11);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray8, byteArray13);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray8);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.add(byteArray8, (byte) 1);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray17, (byte) 0);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray17, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray21);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) (byte) 0);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) -1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray4, (short) (byte) 100);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(shortArray4, (short) (byte) -1);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray4);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        long[] longArray0 = null;
        long[] longArray2 = org.apache.commons.lang3.ArrayUtils.add(longArray0, (long) 1);
        org.junit.Assert.assertNotNull(longArray2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray14 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '#');
        char[] charArray21 = new char[] { '#', ' ', '#', '4' };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray14, charArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.clone(charArray8);
        int int27 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray24, 'a', (int) '#');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(byteArray7, (byte) 1);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray7, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, true);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, 3, (int) (short) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray11, false);
        boolean[] booleanArray16 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray11, (int) (short) 1, (int) (short) -1);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray16, true);
        boolean[] booleanArray24 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray25 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray24);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray25, true);
        boolean[] booleanArray29 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray27, true);
        boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray29, (int) (byte) 1);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray16, booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray18, true);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray18);
        java.lang.Boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(booleanArray22);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, true);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, false);
        java.lang.Boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray11);
        java.lang.Boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray12);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray13);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray5, booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray23, true);
        boolean[] booleanArray29 = org.apache.commons.lang3.ArrayUtils.add(booleanArray27, true);
        boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray29, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray31);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 2);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 10, (int) (byte) 1);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 100.0d);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 100, 10, (double) ' ');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        java.lang.Character[] charArray5 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray8);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.remove(charArray8, (int) (byte) 0);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 0);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (short) 10, (-1.0d));
        java.lang.Double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, (double) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean[] booleanArray28 = new boolean[] { true, false };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray28, true, (int) '4');
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray28, false, (int) (byte) 0);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray28, false);
        boolean[] booleanArray39 = new boolean[] { true, false };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray39, true, (int) '4');
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray28, booleanArray39);
        boolean[] booleanArray45 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray39, false);
        boolean[] booleanArray46 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray6, booleanArray45);
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(booleanArray45);
        org.junit.Assert.assertNotNull(booleanArray46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        short[] shortArray6 = new short[] { (byte) 0, (byte) 0, (byte) 1, (byte) 1, (short) 100, (byte) 0 };
        short[] shortArray13 = new short[] { (byte) 0, (byte) 0, (byte) 1, (byte) 1, (short) 100, (byte) 0 };
        short[] shortArray20 = new short[] { (byte) 0, (byte) 0, (byte) 1, (byte) 1, (short) 100, (byte) 0 };
        short[] shortArray27 = new short[] { (byte) 0, (byte) 0, (byte) 1, (byte) 1, (short) 100, (byte) 0 };
        short[] shortArray34 = new short[] { (byte) 0, (byte) 0, (byte) 1, (byte) 1, (short) 100, (byte) 0 };
        short[] shortArray41 = new short[] { (byte) 0, (byte) 0, (byte) 1, (byte) 1, (short) 100, (byte) 0 };
        short[][] shortArray42 = new short[][] { shortArray6, shortArray13, shortArray20, shortArray27, shortArray34, shortArray41 };
        short[][] shortArray44 = org.apache.commons.lang3.ArrayUtils.remove(shortArray42, (int) (byte) 1);
        java.lang.Short[] shortArray46 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int48 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray46, (java.lang.Object) "hi!");
        short[] shortArray49 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray46);
        java.lang.Short[] shortArray53 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray54 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray53);
        int int57 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray54, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray54);
        short[] shortArray60 = org.apache.commons.lang3.ArrayUtils.add(shortArray54, (short) 0);
        short[] shortArray61 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray49, shortArray54);
        short[] shortArray63 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray54, (short) 100);
        short[] shortArray65 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray63, (short) (byte) -1);
        short[] shortArray66 = org.apache.commons.lang3.ArrayUtils.clone(shortArray63);
        java.lang.Short[] shortArray70 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray71 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray70);
        int int74 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray71, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray71);
        short[] shortArray77 = org.apache.commons.lang3.ArrayUtils.add(shortArray71, (short) 0);
        short[] shortArray78 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray66, shortArray71);
        short[][] shortArray79 = org.apache.commons.lang3.ArrayUtils.add(shortArray42, 4, shortArray71);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertNotNull(shortArray42);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertNotNull(shortArray46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(shortArray53);
        org.junit.Assert.assertNotNull(shortArray54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(shortArray60);
        org.junit.Assert.assertNotNull(shortArray61);
        org.junit.Assert.assertNotNull(shortArray63);
        org.junit.Assert.assertNotNull(shortArray65);
        org.junit.Assert.assertNotNull(shortArray66);
        org.junit.Assert.assertNotNull(shortArray70);
        org.junit.Assert.assertNotNull(shortArray71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(shortArray77);
        org.junit.Assert.assertNotNull(shortArray78);
        org.junit.Assert.assertNotNull(shortArray79);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 100.0f, (double) 1.0f);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, 0, (double) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (int) ' ', (int) (short) 100);
        byte[] byteArray14 = new byte[] {};
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray16);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.clone(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray16);
        byte[] byteArray20 = new byte[] {};
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.clone(byteArray20);
        byte[] byteArray22 = new byte[] {};
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.clone(byteArray22);
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.clone(byteArray22);
        java.lang.Byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray24);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.clone(byteArray24);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray21, byteArray26);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray26, (byte) 10, (int) (short) 10);
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray26, (byte) 0, 2);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray26);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray26);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray26);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.Object[] objArray0 = null;
        java.lang.Character[] charArray4 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        java.lang.Character[] charArray6 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray0, (java.lang.Object) charArray5);
        java.lang.Character[] charArray8 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray8);
        java.lang.Character[] charArray10 = org.apache.commons.lang3.ArrayUtils.toObject(charArray9);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray10);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray8, (short) 10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray8);
        try {
            short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.remove(shortArray8, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray0);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double[] doubleArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, 100.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { (-1), (-1), 10 };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (short) 1);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray0, true);
        org.junit.Assert.assertNull(booleanArray2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray15, (long) 2);
        java.lang.Long[] longArray18 = org.apache.commons.lang3.ArrayUtils.toObject(longArray17);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray17, (long) (short) 10);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray20);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray0);
        java.lang.Short[] shortArray5 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray7 = new short[] {};
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray7);
        java.lang.Short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray6);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray9, (short) (byte) 10);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray11, (short) 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray0, shortArray13);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray13);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray6, true, 0);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1, (byte) -1);
        java.lang.Boolean[] booleanArray8 = new java.lang.Boolean[] { false, true };
        java.lang.Boolean[] booleanArray11 = new java.lang.Boolean[] { false, true };
        java.lang.Boolean[] booleanArray14 = new java.lang.Boolean[] { false, true };
        java.lang.Boolean[] booleanArray17 = new java.lang.Boolean[] { false, true };
        java.lang.Boolean[] booleanArray20 = new java.lang.Boolean[] { false, true };
        java.lang.Boolean[] booleanArray23 = new java.lang.Boolean[] { false, true };
        java.lang.Boolean[][] booleanArray24 = new java.lang.Boolean[][] { booleanArray8, booleanArray11, booleanArray14, booleanArray17, booleanArray20, booleanArray23 };
        java.lang.Character[] charArray28 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray28);
        char[] charArray35 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int37 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray35, '#');
        char[] charArray38 = org.apache.commons.lang3.ArrayUtils.addAll(charArray29, charArray35);
        char[] charArray40 = org.apache.commons.lang3.ArrayUtils.add(charArray38, '4');
        int int43 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray40, 'a', (int) ' ');
        char[] charArray45 = org.apache.commons.lang3.ArrayUtils.add(charArray40, 'a');
        java.lang.Character[] charArray46 = org.apache.commons.lang3.ArrayUtils.toObject(charArray40);
        java.lang.Boolean[][] booleanArray47 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray24, (java.lang.Object) charArray46);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) byteArray1, (java.lang.Object[]) charArray46);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(charArray46);
        org.junit.Assert.assertNotNull(booleanArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.clone(longArray9);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.subarray(longArray10, 0, 4);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray10, (int) '4', (int) (short) -1);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray16);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(floatArray4, (float) 5);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray4, (float) 10L);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray11, (float) (byte) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) floatArray11);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray19 = null;
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray15, charArray19);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray15, '#', 0);
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.add(charArray15, 'a');
        char[] charArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray25, '#');
        int int29 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray25, 'a');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1, (byte) -1);
        byte[] byteArray6 = new byte[] {};
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        byte[] byteArray8 = new byte[] {};
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray10);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray10);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray7, byteArray12);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(byteArray13, (byte) 1);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray5, byteArray13);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (short) 10, (int) '4');
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, (double) (byte) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, (double) '4', (double) 2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.lang.Byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_OBJECT_ARRAY;
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0, (byte) 100);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray4, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray9);
        java.lang.Short[] shortArray14 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray14);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray15, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray15);
        short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.add(shortArray15, (short) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray9, shortArray21);
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray24);
        java.lang.Short[] shortArray29 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray29);
        short[] shortArray31 = new short[] {};
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray30, shortArray31);
        short[] shortArray33 = org.apache.commons.lang3.ArrayUtils.clone(shortArray31);
        short[] shortArray35 = org.apache.commons.lang3.ArrayUtils.add(shortArray33, (short) 1);
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray24, shortArray33);
        short[] shortArray39 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray36, 10, 100);
        short[] shortArray44 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray45 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray44);
        short[] shortArray46 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray36, shortArray44);
        short[] shortArray49 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray46, 1, 6);
        short[] shortArray50 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray21, shortArray46);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shortArray33);
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertNotNull(shortArray45);
        org.junit.Assert.assertNotNull(shortArray46);
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(shortArray50);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) 10L);
        java.lang.Float[] floatArray17 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray17);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray17);
        float[] floatArray26 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray26, (float) (short) 1);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.add(floatArray28, 0.0f);
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray30, 100, (int) (short) 100);
        float[] floatArray38 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray38, (int) (byte) 100, (int) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray38, (float) ' ', (int) 'a');
        float[] floatArray46 = org.apache.commons.lang3.ArrayUtils.add(floatArray38, (float) (short) 100);
        float[] floatArray47 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray30, floatArray46);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray19, floatArray30);
        float[] floatArray49 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray11, floatArray19);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray11);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray15);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.add(doubleArray17, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray19);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.add(doubleArray21, (double) (byte) 10);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray19, doubleArray23);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray23, (double) 1, (double) (byte) 0);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray30 = org.apache.commons.lang3.ArrayUtils.add(doubleArray28, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray30);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray23, doubleArray30);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray23, (double) (-1.0f));
        int int38 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray23, (double) 10.0f, 1, (double) 10.0f);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray15, (java.lang.Object) 10.0f);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (byte) 1, 4);
        java.lang.Character[] charArray22 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray22);
        java.lang.Character[] charArray24 = org.apache.commons.lang3.ArrayUtils.toObject(charArray23);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray23, 'a');
        char[] charArray27 = org.apache.commons.lang3.ArrayUtils.addAll(charArray15, charArray23);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray27);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.lang.Boolean[] booleanArray1 = new java.lang.Boolean[] { false };
        boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray1);
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray1);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        float[] floatArray8 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 100, (int) '4');
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray1, (java.lang.Object) (byte) 100, (-1));
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray16);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray16, (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.apache.commons.lang3.ArrayUtils arrayUtils0 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils1 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils2 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils3 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray4 = new org.apache.commons.lang3.ArrayUtils[] { arrayUtils0, arrayUtils1, arrayUtils2, arrayUtils3 };
        org.apache.commons.lang3.ArrayUtils arrayUtils5 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils6 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils7 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils8 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils9 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils10 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray11 = new org.apache.commons.lang3.ArrayUtils[] { arrayUtils5, arrayUtils6, arrayUtils7, arrayUtils8, arrayUtils9, arrayUtils10 };
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray12 = org.apache.commons.lang3.ArrayUtils.addAll(arrayUtilsArray4, arrayUtilsArray11);
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray13 = org.apache.commons.lang3.ArrayUtils.clone(arrayUtilsArray4);
        java.lang.Object[] objArray14 = null;
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) arrayUtilsArray4, objArray14);
        org.junit.Assert.assertNotNull(arrayUtilsArray4);
        org.junit.Assert.assertNotNull(arrayUtilsArray11);
        org.junit.Assert.assertNotNull(arrayUtilsArray12);
        org.junit.Assert.assertNotNull(arrayUtilsArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (byte) 1);
        double[] doubleArray3 = new double[] {};
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray3, (double) (-1.0f), (double) 1L);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) (short) 0, (int) (short) 100, (double) '4');
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray3);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray3, (double) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        char[] charArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(charArray0, '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray14, (long) ' ');
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.subarray(longArray14, (int) ' ', (int) (byte) 100);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.clone(longArray14);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray14, (long) 100);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray14, (long) (byte) 1, (int) (byte) 10);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 100L);
        java.lang.Class<?> wildcardClass13 = floatArray8.getClass();
        java.lang.Float[] floatArray19 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray20, 1.0f);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray8, floatArray20);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray8);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Class<?> wildcardClass28 = intArray25.getClass();
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray25, 1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        float[] floatArray14 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray14, (float) (short) 1);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray16, 0.0f);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray7, floatArray18);
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray7, (int) 'a', (int) (byte) -1);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray22, (float) 10);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        java.lang.Boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray1);
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray1);
        java.lang.Boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray3);
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray4, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray6);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        short[] shortArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(floatArray4, (float) 5);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray4, (float) 10L);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray4);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0);
        java.lang.Short[] shortArray2 = new java.lang.Short[] {};
        java.lang.Short[] shortArray3 = new java.lang.Short[] {};
        java.lang.Short[] shortArray4 = new java.lang.Short[] {};
        java.lang.Short[] shortArray5 = new java.lang.Short[] {};
        java.lang.Short[][] shortArray6 = new java.lang.Short[][] { shortArray2, shortArray3, shortArray4, shortArray5 };
        java.lang.Short[][] shortArray9 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray6, (-1), (int) '#');
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) charArray0, (java.lang.Object) shortArray6, (int) (byte) 1);
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0);
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, ' ');
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.clone(charArray14);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        short[] shortArray0 = null;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray0);
        org.junit.Assert.assertNull(shortArray1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray11 = new java.lang.Byte[] { (byte) 0, (byte) 0, (byte) -1, (byte) 10, (byte) 0 };
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray11);
        byte[] byteArray13 = new byte[] {};
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        byte[] byteArray15 = new byte[] {};
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        java.lang.Byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray17);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.clone(byteArray17);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray14, byteArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray12, byteArray14);
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.add(byteArray14, (byte) 1);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray23, (byte) 0);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray5, byteArray23);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 0);
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) longArray10);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        char[][] charArray0 = new char[][] {};
        java.lang.Object[] objArray2 = null;
        java.lang.Character[] charArray6 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6);
        java.lang.Character[] charArray8 = org.apache.commons.lang3.ArrayUtils.toObject(charArray7);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray2, (java.lang.Object) charArray7);
        java.lang.Character[] charArray10 = org.apache.commons.lang3.ArrayUtils.toObject(charArray7);
        char[][] charArray11 = org.apache.commons.lang3.ArrayUtils.add(charArray0, 0, charArray7);
        java.lang.Object[] objArray12 = null;
        java.lang.Character[] charArray16 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray16);
        java.lang.Character[] charArray18 = org.apache.commons.lang3.ArrayUtils.toObject(charArray17);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray12, (java.lang.Object) charArray17);
        java.lang.Character[] charArray20 = org.apache.commons.lang3.ArrayUtils.toObject(charArray17);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray17, ' ');
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.subarray(charArray17, (int) (short) 1, 6);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.addAll(charArray7, charArray17);
        int int29 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray7, 'a', (int) '#');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 100.0f, (double) 1.0f);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) '4', (double) 4);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray12, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray14, doubleArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) 1, (double) (byte) 0);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray18, doubleArray25);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) (-1.0f));
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray18);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray4);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) 0);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray4);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10, 7);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(shortArray15);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray0 = new java.lang.reflect.GenericDeclaration[] {};
        java.lang.Class<?>[] wildcardClassArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray2 = org.apache.commons.lang3.ArrayUtils.addAll(genericDeclarationArray0, (java.lang.reflect.GenericDeclaration[]) wildcardClassArray1);
        java.lang.Character[] charArray6 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6);
        char[] charArray13 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray13, '#');
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.addAll(charArray7, charArray13);
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.add(charArray16, '4');
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray18, '#', (int) '#');
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.subarray(charArray18, (int) (short) 100, 0);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray18, '#');
        char[] charArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray26, 'a');
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) genericDeclarationArray0, (java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(genericDeclarationArray0);
        org.junit.Assert.assertNotNull(wildcardClassArray1);
        org.junit.Assert.assertNotNull(genericDeclarationArray2);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray8, '4');
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray8, '#', 3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) (byte) 0);
        java.lang.Float[] floatArray30 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray30);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) (short) 0, (int) (byte) 10);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) 1L);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray24, floatArray31);
        java.lang.Float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray24);
        int int41 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray24, 10.0f, 10);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.clone(intArray4);
        int[] intArray11 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray11, 1);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.addAll(intArray11, intArray14);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray11, (int) '4');
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.add(intArray11, 1, 0);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray11);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray15, (int) (byte) 1, '4');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.clone(charArray15);
        java.lang.Character[] charArray26 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray26);
        java.lang.Character[] charArray28 = org.apache.commons.lang3.ArrayUtils.toObject(charArray27);
        char[] charArray30 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray28, 'a');
        char[] charArray31 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray28);
        char[] charArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray28);
        int int35 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray32, ' ', 5);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray22, charArray32);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.lang.Boolean[] booleanArray6 = new java.lang.Boolean[] { false, false, false, true, true, false };
        boolean[] booleanArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray7, 4, 100);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray11);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray16);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray16);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray16, (long) 'a');
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(longArray20);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        long[] longArray18 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray18, 100L, (int) '4');
        java.lang.Long[] longArray22 = org.apache.commons.lang3.ArrayUtils.toObject(longArray18);
        java.lang.Class<?> wildcardClass23 = longArray22.getClass();
        java.lang.Class<?>[] wildcardClassArray24 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray28 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray28);
        short[] shortArray30 = new short[] {};
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray29, shortArray30);
        java.lang.Short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray29);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray29, (short) -1);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray24, (java.lang.Object) (short) -1);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) longArray22, (java.lang.Object[]) wildcardClassArray24);
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray37 = org.apache.commons.lang3.ArrayUtils.addAll((java.lang.reflect.GenericDeclaration[]) wildcardClassArray0, (java.lang.reflect.GenericDeclaration[]) wildcardClassArray24);
        boolean[] booleanArray38 = new boolean[] {};
        boolean[] booleanArray43 = new boolean[] { true, false, false, true };
        boolean[] booleanArray44 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray38, booleanArray43);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray43, true);
        boolean[] booleanArray49 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray43, 3, (int) (short) 10);
        int int51 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray43, false);
        int int53 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray43, true);
        int int54 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) wildcardClassArray24, (java.lang.Object) booleanArray43);
        java.lang.Short[] shortArray55 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray62 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int65 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray62, 100L, (int) '4');
        java.lang.Long[] longArray66 = org.apache.commons.lang3.ArrayUtils.toObject(longArray62);
        java.lang.Class<?> wildcardClass67 = longArray66.getClass();
        boolean boolean68 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) shortArray55, (java.lang.Object[]) longArray66);
        long[] longArray70 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray66, (-1L));
        long[] longArray71 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray66);
        int int73 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) wildcardClassArray24, (java.lang.Object) longArray66, 5);
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClassArray24);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(genericDeclarationArray37);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(booleanArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(shortArray55);
        org.junit.Assert.assertNotNull(longArray62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 4 + "'", int65 == 4);
        org.junit.Assert.assertNotNull(longArray66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(longArray70);
        org.junit.Assert.assertNotNull(longArray71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0, true);
        boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray4);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) (byte) 10);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray4, 3, (int) (short) -1);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray7, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        float[] floatArray18 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, (int) (byte) 100, (int) '4');
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray9, floatArray18);
        java.lang.Class<?> wildcardClass23 = floatArray22.getClass();
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 2);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 10, (int) (byte) 1);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 100.0d);
        try {
            double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray7, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray15 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray19 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[][] intArray20 = new java.lang.Integer[][] { intArray3, intArray7, intArray11, intArray15, intArray19 };
        java.lang.Integer[] intArray24 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray28 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray32 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray36 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray40 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[][] intArray41 = new java.lang.Integer[][] { intArray24, intArray28, intArray32, intArray36, intArray40 };
        java.lang.Integer[] intArray45 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray49 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray53 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray57 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray61 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[][] intArray62 = new java.lang.Integer[][] { intArray45, intArray49, intArray53, intArray57, intArray61 };
        java.lang.Integer[] intArray66 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray70 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray74 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray78 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[] intArray82 = new java.lang.Integer[] { 100, 4, 4 };
        java.lang.Integer[][] intArray83 = new java.lang.Integer[][] { intArray66, intArray70, intArray74, intArray78, intArray82 };
        java.lang.Integer[][][] intArray84 = new java.lang.Integer[][][] { intArray20, intArray41, intArray62, intArray83 };
        java.lang.Integer[] intArray90 = new java.lang.Integer[] { 5, 0, 10, 10 };
        java.lang.Integer[][] intArray91 = new java.lang.Integer[][] { intArray90 };
        java.lang.Integer[][] intArray92 = org.apache.commons.lang3.ArrayUtils.clone(intArray91);
        java.lang.Integer[][] intArray95 = org.apache.commons.lang3.ArrayUtils.subarray(intArray92, 6, (int) (byte) -1);
        try {
            java.lang.Integer[][][] intArray96 = org.apache.commons.lang3.ArrayUtils.add(intArray84, (int) (byte) 10, intArray95);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertNotNull(intArray95);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.Float[] floatArray0 = new java.lang.Float[] {};
        java.lang.Float[] floatArray1 = new java.lang.Float[] {};
        java.lang.Float[] floatArray2 = new java.lang.Float[] {};
        java.lang.Float[] floatArray3 = new java.lang.Float[] {};
        java.lang.Float[] floatArray4 = new java.lang.Float[] {};
        java.lang.Float[] floatArray5 = new java.lang.Float[] {};
        java.lang.Float[][] floatArray6 = new java.lang.Float[][] { floatArray0, floatArray1, floatArray2, floatArray3, floatArray4, floatArray5 };
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray6);
        java.lang.Float[] floatArray14 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray14);
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray14);
        float[] floatArray23 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray23, (float) (short) 1);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.add(floatArray25, 0.0f);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray27, 100, (int) (short) 100);
        float[] floatArray35 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray35, (int) (byte) 100, (int) '4');
        int int41 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray35, (float) ' ', (int) 'a');
        float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.add(floatArray35, (float) (short) 100);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray27, floatArray43);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray16, floatArray27);
        float[] floatArray46 = org.apache.commons.lang3.ArrayUtils.clone(floatArray16);
        java.lang.Float[] floatArray47 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray46);
        java.lang.Float[][] floatArray48 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, 6, floatArray47);
        java.lang.Float[] floatArray55 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray56 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray55);
        int int59 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray55, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray60 = new double[] {};
        double[] doubleArray62 = org.apache.commons.lang3.ArrayUtils.add(doubleArray60, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray62);
        double[] doubleArray64 = new double[] {};
        double[] doubleArray66 = org.apache.commons.lang3.ArrayUtils.add(doubleArray64, (double) (byte) 10);
        double[] doubleArray67 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray62, doubleArray66);
        double[] doubleArray68 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray66);
        int int72 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray66, 10.0d, 1, 100.0d);
        double[] doubleArray74 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray66, (double) (-1));
        int int78 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray66, (double) (-1L), 0, (double) (-1));
        int int80 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray55, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray82 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray55, 10.0f);
        double[] doubleArray83 = new double[] {};
        double[] doubleArray85 = org.apache.commons.lang3.ArrayUtils.add(doubleArray83, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray85);
        double[] doubleArray87 = new double[] {};
        double[] doubleArray89 = org.apache.commons.lang3.ArrayUtils.add(doubleArray87, (double) (byte) 10);
        double[] doubleArray90 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray85, doubleArray89);
        double[] doubleArray91 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray89);
        int int93 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray55, (java.lang.Object) doubleArray89, (int) (short) 100);
        java.lang.Float[][] floatArray94 = org.apache.commons.lang3.ArrayUtils.add(floatArray48, (int) (short) 0, floatArray55);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertNotNull(floatArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertNotNull(floatArray94);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray6, (short) (byte) -1, 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }
}

