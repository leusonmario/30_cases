import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int[] intArray0 = null;
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.clone(intArray0);
        org.junit.Assert.assertNull(intArray1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.String str2 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) 1, "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        try {
            boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        try {
            double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (int) (byte) 100, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 100, (short) -1, (short) 1 };
        java.lang.Short[] shortArray9 = new java.lang.Short[] { (short) -1, (short) 100, (short) -1, (short) 1 };
        java.lang.Short[] shortArray14 = new java.lang.Short[] { (short) -1, (short) 100, (short) -1, (short) 1 };
        java.lang.Short[] shortArray19 = new java.lang.Short[] { (short) -1, (short) 100, (short) -1, (short) 1 };
        java.lang.Short[] shortArray24 = new java.lang.Short[] { (short) -1, (short) 100, (short) -1, (short) 1 };
        java.lang.Short[] shortArray29 = new java.lang.Short[] { (short) -1, (short) 100, (short) -1, (short) 1 };
        java.lang.Short[][] shortArray30 = new java.lang.Short[][] { shortArray4, shortArray9, shortArray14, shortArray19, shortArray24, shortArray29 };
        java.lang.Short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        try {
            java.lang.Short[][] shortArray33 = org.apache.commons.lang3.ArrayUtils.add(shortArray30, 100, shortArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray32);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 100 };
        try {
            byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.add(byteArray2, 10, (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(intArray0);
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        long[] longArray5 = new long[] { ' ', (byte) 1, (byte) 100, 'a', 0 };
        org.apache.commons.lang3.ArrayUtils.reverse(longArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray5, (long) 100, (int) (short) 10);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, '#');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray10.getClass();
        long[] longArray18 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray18, 100L, (int) '4');
        java.lang.Long[] longArray22 = org.apache.commons.lang3.ArrayUtils.toObject(longArray18);
        java.lang.Class<?> wildcardClass23 = longArray22.getClass();
        long[] longArray30 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray30, 100L, (int) '4');
        java.lang.Long[] longArray34 = org.apache.commons.lang3.ArrayUtils.toObject(longArray30);
        java.lang.Class<?> wildcardClass35 = longArray34.getClass();
        long[] longArray42 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int45 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray42, 100L, (int) '4');
        java.lang.Long[] longArray46 = org.apache.commons.lang3.ArrayUtils.toObject(longArray42);
        java.lang.Class<?> wildcardClass47 = longArray46.getClass();
        long[] longArray54 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int57 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray54, 100L, (int) '4');
        java.lang.Long[] longArray58 = org.apache.commons.lang3.ArrayUtils.toObject(longArray54);
        java.lang.Class<?> wildcardClass59 = longArray58.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray60 = new java.lang.reflect.AnnotatedElement[] { wildcardClass11, wildcardClass23, wildcardClass35, wildcardClass47, wildcardClass59 };
        java.lang.reflect.AnnotatedElement[] annotatedElementArray61 = org.apache.commons.lang3.ArrayUtils.clone(annotatedElementArray60);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap62 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) annotatedElementArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, 'class [Ljava.lang.Long;', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(longArray42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(longArray54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(longArray58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(annotatedElementArray60);
        org.junit.Assert.assertNotNull(annotatedElementArray61);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap5 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) charArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '4', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        float[] floatArray2 = new float[] { 1.0f, 10 };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray4);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int[] intArray0 = new int[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1));
        try {
            int[] intArray4 = org.apache.commons.lang3.ArrayUtils.remove(intArray0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int[] intArray0 = new int[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1));
        try {
            int[] intArray4 = org.apache.commons.lang3.ArrayUtils.remove(intArray0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        byte[] byteArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_OBJECT_ARRAY;
        org.junit.Assert.assertNotNull(longArray0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Object[] objArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_OBJECT_ARRAY;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.String[] strArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_STRING_ARRAY;
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        short[] shortArray3 = new short[] { (byte) 100, (short) -1, (short) 1 };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray3, (short) 0, 1);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray3, (short) (byte) 1, (int) (short) 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        short[] shortArray0 = null;
        try {
            short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.remove(shortArray0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        try {
            byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.remove(byteArray0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        java.lang.Character[] charArray5 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5, 'a');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) charArray5, (java.lang.Object) 'a', 1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray9, (float) '4', 0);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) floatArray10);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray3 = new byte[][] { byteArray2 };
        byte[][] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray3);
        java.lang.String str5 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) byteArray3);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{{-1,1}}" + "'", str5.equals("{{-1,1}}"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double[] doubleArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray13);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            int int1 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            int int1 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.clone(intArray4);
        try {
            int[] intArray7 = org.apache.commons.lang3.ArrayUtils.remove(intArray4, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.lang3.ArrayUtils.remove(intArray0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray5);
        try {
            boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) '4', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(booleanArray9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray14 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray14, 100L, (int) '4');
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray14, (long) (byte) 10);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) longArray7, (java.lang.Object) longArray19);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(longArray19, (long) 4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        long[] longArray0 = null;
        try {
            long[] longArray3 = org.apache.commons.lang3.ArrayUtils.add(longArray0, 1, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        try {
            long[] longArray9 = org.apache.commons.lang3.ArrayUtils.remove(longArray7, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(charArray4, 'a');
        try {
            char[] charArray8 = org.apache.commons.lang3.ArrayUtils.remove(charArray4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        long[] longArray0 = null;
        long[] longArray1 = org.apache.commons.lang3.ArrayUtils.clone(longArray0);
        org.junit.Assert.assertNull(longArray1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap12 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '10.0', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.Float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        try {
            float[] floatArray4 = org.apache.commons.lang3.ArrayUtils.add(floatArray1, 2, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray4, ' ', (int) (short) 1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        java.io.Serializable[] serializableArray10 = org.apache.commons.lang3.ArrayUtils.subarray((java.io.Serializable[]) byteArray6, 100, (int) (short) 0);
        java.lang.Short[] shortArray14 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray14);
        short[] shortArray16 = new short[] {};
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray15, shortArray16);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray15, (short) (byte) 0);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray6, (java.lang.Object) shortArray15);
        try {
            short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.remove(shortArray15, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(serializableArray10);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.Integer[] intArray0 = null;
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        org.junit.Assert.assertNull(intArray1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(charArray4, 'a');
        try {
            char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray4, (int) (byte) -1, 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        float[] floatArray20 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray20, (float) (short) 1);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.add(floatArray22, 0.0f);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray24, 100, (int) (short) 100);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) 'a', (java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        java.lang.Character[] charArray9 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        int int10 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) charArray9);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.String[] strArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray0, (java.lang.Object) intArray10);
        try {
            int[] intArray13 = org.apache.commons.lang3.ArrayUtils.remove(intArray10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNull(strArray11);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 'a');
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 0.0d);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray4, (double) 1, 0, (double) (-1L));
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray4, (double) 2);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray4, 0.0d, (double) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.Boolean[] booleanArray0 = null;
        boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0, true);
        org.junit.Assert.assertNull(booleanArray2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) byteArray3);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        java.lang.Object obj12 = null;
        try {
            boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) longArray11, obj12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.Float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray1);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.add(longArray12, 2, (long) (byte) 1);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray12, (-1L));
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray7);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray6, (float) (short) 0, (int) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray6);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.subarray(intArray5, 0, 0);
        try {
            int[] intArray18 = org.apache.commons.lang3.ArrayUtils.remove(intArray16, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        char[] charArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        java.lang.Class<?> wildcardClass14 = floatArray9.getClass();
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray9, (float) (short) 10, (int) (byte) 1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int[] intArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(intArray0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        short[] shortArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        boolean[] booleanArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray0, false, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray24 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray24);
        short[] shortArray26 = new short[] {};
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray25, shortArray26);
        short[] shortArray28 = org.apache.commons.lang3.ArrayUtils.clone(shortArray26);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.add(shortArray28, (short) 1);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) '4', (java.lang.Object) shortArray30);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray30);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray25);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray4, '#', 100);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Long[] longArray0 = null;
        long[] longArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0);
        org.junit.Assert.assertNull(longArray1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int[] intArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray6, 4, (int) (short) -1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(byteArray7, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, (double) 0.0f);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray0);
        java.lang.Double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (-1L), (double) (-1));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        boolean[] booleanArray0 = new boolean[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray0, true);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        int int5 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) byteArray4);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (int) ' ', (int) (short) 100);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.apache.commons.lang3.ArrayUtils.INDEX_NOT_FOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        try {
            float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.remove(floatArray8, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        try {
            boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray12, (double) 1.0f, 0, (double) '4');
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray12, (double) 100.0f, 4);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) floatArray5, (java.lang.Object) 100.0f);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        java.lang.Double[] doubleArray1 = new java.lang.Double[] {};
        java.lang.Double[] doubleArray2 = new java.lang.Double[] {};
        java.lang.Double[][] doubleArray3 = new java.lang.Double[][] { doubleArray0, doubleArray1, doubleArray2 };
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        java.lang.Double[][] doubleArray5 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (java.lang.Object) doubleArray4);
        try {
            java.lang.Object[][] objArray7 = org.apache.commons.lang3.ArrayUtils.remove((java.lang.Object[][]) doubleArray3, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray11, (long) 3);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray11, (long) 4, (int) (short) 0);
        try {
            long[] longArray19 = org.apache.commons.lang3.ArrayUtils.add(longArray11, (int) (short) -1, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 100L);
        java.lang.Class<?> wildcardClass13 = floatArray8.getClass();
        java.lang.Float[] floatArray19 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray20, 1.0f);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray8, floatArray20);
        try {
            float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.add(floatArray23, (int) (byte) -1, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 10");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Object[] objArray0 = null;
        byte[] byteArray1 = new byte[] {};
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray1);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray3, (byte) 1, (int) '4');
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(objArray0, (java.lang.Object) '4');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        char[] charArray5 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#');
        char[] charArray12 = new char[] { '#', ' ', '#', '4' };
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray5, charArray12);
        char[] charArray19 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray19, '#');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.addAll(charArray12, charArray19);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray19);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        short[] shortArray1 = new short[] { (byte) 1 };
        short[] shortArray3 = new short[] { (byte) 1 };
        short[] shortArray5 = new short[] { (byte) 1 };
        short[] shortArray7 = new short[] { (byte) 1 };
        short[][] shortArray8 = new short[][] { shortArray1, shortArray3, shortArray5, shortArray7 };
        short[] shortArray10 = new short[] { (byte) 1 };
        short[] shortArray12 = new short[] { (byte) 1 };
        short[] shortArray14 = new short[] { (byte) 1 };
        short[] shortArray16 = new short[] { (byte) 1 };
        short[][] shortArray17 = new short[][] { shortArray10, shortArray12, shortArray14, shortArray16 };
        short[] shortArray19 = new short[] { (byte) 1 };
        short[] shortArray21 = new short[] { (byte) 1 };
        short[] shortArray23 = new short[] { (byte) 1 };
        short[] shortArray25 = new short[] { (byte) 1 };
        short[][] shortArray26 = new short[][] { shortArray19, shortArray21, shortArray23, shortArray25 };
        short[] shortArray28 = new short[] { (byte) 1 };
        short[] shortArray30 = new short[] { (byte) 1 };
        short[] shortArray32 = new short[] { (byte) 1 };
        short[] shortArray34 = new short[] { (byte) 1 };
        short[][] shortArray35 = new short[][] { shortArray28, shortArray30, shortArray32, shortArray34 };
        short[][][] shortArray36 = new short[][][] { shortArray8, shortArray17, shortArray26, shortArray35 };
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray36);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray25);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        java.lang.String str26 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        char[] charArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(charArray0, '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 1.0f, 0, (double) '4');
        try {
            int int12 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(longArray6, (long) 1);
        try {
            long[] longArray14 = org.apache.commons.lang3.ArrayUtils.add(longArray6, 100, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray7);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 0, (-1));
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray7, (byte) 1, 4);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.String[] strArray3 = new java.lang.String[] { "hi!", "{{-1,1}}", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray5 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray3, (java.lang.Comparable<java.lang.String>) "{{-1,1}}");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strComparableArray5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray14, (double) ' ');
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray8);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        char[] charArray0 = null;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.add(charArray0, ' ');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray2, ' ');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.Short[] shortArray0 = new java.lang.Short[] {};
        java.lang.Short[] shortArray1 = new java.lang.Short[] {};
        java.lang.Short[] shortArray2 = new java.lang.Short[] {};
        java.lang.Short[] shortArray3 = new java.lang.Short[] {};
        java.lang.Short[][] shortArray4 = new java.lang.Short[][] { shortArray0, shortArray1, shortArray2, shortArray3 };
        java.lang.Short[][] shortArray7 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray4, (-1), (int) '#');
        java.lang.Short[] shortArray11 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray11);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray4, (java.lang.Object) shortArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray12, (short) (byte) 1);
        try {
            short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.add(shortArray12, (int) 'a', (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        try {
            int[] intArray7 = org.apache.commons.lang3.ArrayUtils.remove(intArray4, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray3 = new byte[][] { byteArray2 };
        byte[][] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray3);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap5 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) byteArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '[B@5bf5be5', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        java.lang.Short[] shortArray7 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.add(shortArray8, (short) 0);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray8);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 100);
        try {
            short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.add(shortArray17, (-1), (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray8, (double) (byte) 0);
        try {
            double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) (byte) 0);
        java.lang.Float[] floatArray30 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray30);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) (short) 0, (int) (byte) 10);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) 1L);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray24, floatArray31);
        try {
            float[] floatArray40 = org.apache.commons.lang3.ArrayUtils.add(floatArray37, (int) 'a', (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 11");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertNotNull(floatArray37);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        try {
            java.lang.Object[] objArray6 = org.apache.commons.lang3.ArrayUtils.remove((java.lang.Object[]) shortArray3, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        org.junit.Assert.assertNotNull(floatArray0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        java.io.Serializable[] serializableArray10 = org.apache.commons.lang3.ArrayUtils.subarray((java.io.Serializable[]) byteArray6, 100, (int) (short) 0);
        java.lang.Short[] shortArray14 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray14);
        short[] shortArray16 = new short[] {};
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray15, shortArray16);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray15, (short) (byte) 0);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray6, (java.lang.Object) shortArray15);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray15);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(serializableArray10);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        try {
            float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray7, (int) ' ', (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.String[] strArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray0, (java.lang.Object) intArray10);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray10, (int) '4');
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(intArray10, 1);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray10, (-1), (-1));
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNull(strArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 100L);
        java.lang.Class<?> wildcardClass13 = floatArray8.getClass();
        java.lang.Float[] floatArray19 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray20, 1.0f);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray8, floatArray20);
        try {
            float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.remove(floatArray23, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 10");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (int) ' ', (int) (short) 100);
        byte[] byteArray14 = new byte[] {};
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray16);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.clone(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray16);
        try {
            byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.remove(byteArray19, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray9);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray0);
        int int2 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) shortArray1);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray14 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '#');
        char[] charArray21 = new char[] { '#', ' ', '#', '4' };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray14, charArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        try {
            char[] charArray26 = org.apache.commons.lang3.ArrayUtils.add(charArray14, 100, ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        try {
            short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.add(shortArray0, 10, (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        char[] charArray5 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#');
        char[] charArray8 = new char[] {};
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray5, charArray8);
        java.lang.Character[] charArray13 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray13);
        char[] charArray20 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray20, '#');
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.addAll(charArray14, charArray20);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.clone(charArray8);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(charArray25);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        byte[] byteArray0 = null;
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray0, 2, (int) '#');
        org.junit.Assert.assertNull(byteArray3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        float[] floatArray2 = new float[] { 100, 0 };
        float[] floatArray5 = new float[] { 100, 0 };
        float[] floatArray8 = new float[] { 100, 0 };
        float[][] floatArray9 = new float[][] { floatArray2, floatArray5, floatArray8 };
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.add(floatArray20, 3, (float) 100);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray20, (float) 0L);
        try {
            float[][] floatArray27 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, (int) ' ', floatArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Object[] objArray0 = null;
        java.lang.Character[] charArray4 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        java.lang.Character[] charArray6 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray0, (java.lang.Object) charArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, 'a', (int) (short) -1);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, 4, (int) ' ');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 0, (byte) 100 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray3, 0, (int) (byte) -1);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 100L);
        java.lang.Class<?> wildcardClass13 = floatArray8.getClass();
        float[] floatArray20 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray20, (float) (short) 1);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.clone(floatArray20);
        java.lang.Float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray23);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.add(floatArray23, 3, (float) 100);
        java.lang.Class<?> wildcardClass28 = floatArray23.getClass();
        long[] longArray35 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray35, 100L, (int) '4');
        java.lang.Long[] longArray39 = org.apache.commons.lang3.ArrayUtils.toObject(longArray35);
        java.lang.Class<?> wildcardClass40 = longArray39.getClass();
        float[] floatArray47 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray49 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray47, (float) (short) 1);
        float[] floatArray51 = org.apache.commons.lang3.ArrayUtils.add(floatArray49, 0.0f);
        int int53 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray49, (float) 100L);
        java.lang.Class<?> wildcardClass54 = floatArray49.getClass();
        java.lang.Class[] classArray56 = new java.lang.Class[4];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray57 = (java.lang.Class<?>[]) classArray56;
        wildcardClassArray57[0] = wildcardClass13;
        wildcardClassArray57[1] = wildcardClass28;
        wildcardClassArray57[2] = wildcardClass40;
        wildcardClassArray57[3] = wildcardClass54;
        java.lang.Class<?>[] wildcardClassArray66 = org.apache.commons.lang3.ArrayUtils.clone(wildcardClassArray57);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(longArray35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(classArray56);
        org.junit.Assert.assertNotNull(wildcardClassArray57);
        org.junit.Assert.assertNotNull(wildcardClassArray66);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.Object[] objArray0 = null;
        java.lang.Character[] charArray4 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        java.lang.Character[] charArray6 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray0, (java.lang.Object) charArray5);
        java.lang.Character[] charArray8 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray5);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(charArray8);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray12, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray14, doubleArray18);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray18);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray18, 10.0d, 1, 100.0d);
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray18, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray26, (double) ' ');
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray6, doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        try {
            boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, 10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 1.0f, 0, (double) '4');
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) '4', (double) (byte) 0);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 1L, 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        try {
            long[] longArray23 = org.apache.commons.lang3.ArrayUtils.remove(longArray12, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray14 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '#');
        char[] charArray21 = new char[] { '#', ' ', '#', '4' };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray14, charArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.clone(charArray8);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray8, 'a');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray5);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray9, true);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray20, (int) (short) 1, (int) (short) 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray22 = org.apache.commons.lang3.ArrayUtils.add(doubleArray20, (double) (byte) 10);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray18, doubleArray22);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray18);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, 100.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 0.0d);
        try {
            double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, 4, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (byte) 1, 4);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray18, 'a');
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray18, 'a', 3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) wildcardClassArray0);
        java.lang.reflect.AnnotatedElement[] annotatedElementArray13 = org.apache.commons.lang3.ArrayUtils.clone((java.lang.reflect.AnnotatedElement[]) wildcardClassArray0);
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(annotatedElementArray13);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        float[] floatArray20 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray20, (float) (short) 1);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.add(floatArray22, 0.0f);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray22, (float) 100L);
        java.lang.Class<?> wildcardClass27 = floatArray22.getClass();
        java.lang.Float[] floatArray33 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray33);
        int int36 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray34, 1.0f);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray34);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray34);
        int int40 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray34, (float) 3);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray4, (float) ' ', (int) 'a');
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.add(floatArray4, (float) (short) 100);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray12, (int) '4', (int) ' ');
        try {
            float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray15, (int) 'a', (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray2, 0, 0);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 100, (int) (short) 1, (double) '#');
        java.lang.String str15 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        float[] floatArray7 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray7, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.clone(floatArray7);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) '4', (java.lang.Object) floatArray10);
        float[] floatArray18 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray18, (float) (short) 1);
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.add(floatArray20, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray20);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray20, (float) (byte) 0, (int) (short) 10);
        float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray20, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray35 = new float[] { (-1), (byte) 10, (short) 100, 1L, 1.0f };
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray35, (int) (byte) 1, (int) '#');
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray29, floatArray38);
        float[] floatArray40 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray10, floatArray29);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(floatArray40);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray15, (int) (byte) 1, '4');
        try {
            char[] charArray24 = org.apache.commons.lang3.ArrayUtils.add(charArray15, (int) (byte) 100, 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 9");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, (double) 0.0f);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray0);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 'a', (double) 2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double[] doubleArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray15, (int) (byte) 1, '4');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.clone(charArray15);
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.remove(charArray15, (int) (short) 1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray24);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray0, (int) (byte) -1, 6);
        org.junit.Assert.assertNull(booleanArray3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Long[] longArray1 = new java.lang.Long[] { 0L };
        java.lang.Long[] longArray3 = new java.lang.Long[] { 0L };
        java.lang.Long[][] longArray4 = new java.lang.Long[][] { longArray1, longArray3 };
        java.lang.Long[][] longArray5 = org.apache.commons.lang3.ArrayUtils.clone(longArray4);
        java.lang.Byte[] byteArray11 = new java.lang.Byte[] { (byte) 0, (byte) 0, (byte) -1, (byte) 10, (byte) 0 };
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray11);
        try {
            java.io.Serializable[][] serializableArray13 = org.apache.commons.lang3.ArrayUtils.add((java.io.Serializable[][]) longArray4, (java.io.Serializable[]) byteArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayStoreException; message: [Ljava.lang.Byte;");
        } catch (java.lang.ArrayStoreException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray8, (double) (byte) 0);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray10, (double) 4, 6, (double) 10.0f);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        try {
            long[] longArray11 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (int) (byte) 10, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        java.lang.Double[] doubleArray1 = new java.lang.Double[] {};
        java.lang.Double[] doubleArray2 = new java.lang.Double[] {};
        java.lang.Double[][] doubleArray3 = new java.lang.Double[][] { doubleArray0, doubleArray1, doubleArray2 };
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        java.lang.Double[][] doubleArray5 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (java.lang.Object) doubleArray4);
        java.lang.Double[][] doubleArray7 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray5, (int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int[] intArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(intArray0, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray8, (double) (byte) 10, 1, 0.0d);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray8, 5, 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray28 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray28, 100L, (int) '4');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray28, (long) (byte) 10);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray21, (java.lang.Object) longArray33);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray33, (int) (byte) 10, (int) (byte) 0);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.add(longArray37, (long) (byte) 1);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) 100, 100);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray37);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray45);
        long[] longArray49 = org.apache.commons.lang3.ArrayUtils.subarray(longArray45, 3, (int) (short) 1);
        try {
            long[] longArray51 = org.apache.commons.lang3.ArrayUtils.remove(longArray45, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(longArray49);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long[] longArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray0, (long) 100, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray4, (float) ' ', (int) 'a');
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.add(floatArray4, (float) (short) 100);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.add(floatArray12, 3, (float) 3);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray15, (float) 'a', 100);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        try {
            double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, 6, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray8, ' ', 3);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray8);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray11, (long) 3);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) int13, (java.lang.Object) 10.0f);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) ' ', (double) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10, 0L);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        char[] charArray0 = null;
        java.lang.Character[] charArray1 = org.apache.commons.lang3.ArrayUtils.toObject(charArray0);
        org.junit.Assert.assertNull(charArray1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1L, (int) (byte) 100, (double) 10L);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray7);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 0, (-1));
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 1, 5);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) (byte) 0, (int) (short) 10);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray23 = new float[] { (-1), (byte) 10, (short) 100, 1L, 1.0f };
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray23, (int) (byte) 1, (int) '#');
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray17, floatArray26);
        float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.add(floatArray26, (float) (short) 100);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) (byte) 0, (int) (short) 10);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 10, (int) (byte) -1);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray17, (float) (byte) 10, (int) (short) 100);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.Integer[][] intArray0 = null;
        try {
            java.lang.Integer[][] intArray2 = org.apache.commons.lang3.ArrayUtils.remove(intArray0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.String[] strArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray0, (java.lang.Object) intArray10);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray10, (int) '4');
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(intArray10, 1);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray10);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray10);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNull(strArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, (double) 0.0f);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray0);
        java.lang.Double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double[] doubleArray5 = new double[] { 5, 4, (short) 100, 0.0f, (short) 100 };
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        java.lang.Long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toObject(longArray7);
        java.lang.Class<?> wildcardClass12 = longArray11.getClass();
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) shortArray0, (java.lang.Object[]) longArray11);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap14 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) longArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '10', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        short[] shortArray1 = new short[] { (byte) 100 };
        int int4 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray1, (short) -1, (int) (byte) 100);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray1, (short) -1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        java.lang.Short[] shortArray5 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray7 = new short[] {};
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray7);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray7);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 1);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray9);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray12, (short) (byte) 100, (int) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray14 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '#');
        char[] charArray21 = new char[] { '#', ' ', '#', '4' };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray14, charArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.clone(charArray8);
        char[] charArray29 = new char[] { 'a', ' ', '4', '#' };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray29, 'a');
        char[] charArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray29, '4');
        char[] charArray39 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int41 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray39, '#');
        char[] charArray46 = new char[] { '#', ' ', '#', '4' };
        boolean boolean47 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray39, charArray46);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray33, charArray39);
        char[] charArray49 = org.apache.commons.lang3.ArrayUtils.clone(charArray33);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray49);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(charArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int[] intArray4 = new int[] { ' ', '#', 0, '4' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray4, 0);
        try {
            int[] intArray8 = org.apache.commons.lang3.ArrayUtils.remove(intArray4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7, (short) (byte) 10);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7, (short) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, true);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, 3, (int) (short) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray11, false);
        boolean[] booleanArray16 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray11, (int) (short) 1, (int) (short) -1);
        boolean[] booleanArray17 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray17);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.String[] strArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray0, (java.lang.Object) intArray10);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.clone(intArray10);
        try {
            int[] intArray15 = org.apache.commons.lang3.ArrayUtils.add(intArray12, 6, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNull(strArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 0);
        double[] doubleArray6 = new double[] {};
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray8);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray8, doubleArray12);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray12);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray14, (double) (byte) 0);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray14);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray14, (double) (byte) 0, (double) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        try {
            int[] intArray9 = org.apache.commons.lang3.ArrayUtils.add(intArray6, (int) (byte) 100, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (short) 0, (int) (short) 100, (double) '4');
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, 0.0d, (double) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        java.lang.Float[] floatArray14 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray14);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray7, (java.lang.Object) floatArray14);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray5, (long) (byte) 100, 10);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray5, 3);
        try {
            int[] intArray25 = org.apache.commons.lang3.ArrayUtils.remove(intArray23, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray11);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray15, (int) (byte) 1, '4');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.clone(charArray15);
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray15, 'a');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray24);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double[] doubleArray0 = new double[] {};
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, (double) 100.0f, (double) 4);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 0);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.remove(shortArray11, 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray13);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (-1L), 0, (double) (-1));
        double[] doubleArray19 = new double[] {};
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.add(doubleArray19, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray21);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray21, doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray25);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray27, (double) (byte) 10, 1, 0.0d);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray27);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray32, (double) 5, (-1), 10.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        byte[] byteArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray0, (byte) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Class<?> wildcardClass28 = intArray25.getClass();
        int[] intArray34 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray34, 1);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray34, (int) ' ', (int) (short) 100);
        int[] intArray45 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int47 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray45, 1);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray49 = org.apache.commons.lang3.ArrayUtils.addAll(intArray45, intArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray34, intArray49);
        int int52 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray49, (int) (byte) 0);
        int[] intArray54 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray49, 1);
        int[] intArray56 = org.apache.commons.lang3.ArrayUtils.add(intArray54, (int) '4');
        java.lang.Integer[] intArray60 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray62 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray60, 2);
        int[] intArray63 = org.apache.commons.lang3.ArrayUtils.addAll(intArray54, intArray62);
        boolean boolean64 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray25, intArray62);
        int int67 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, 5, (int) (byte) 100);
        int int69 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray25, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2 + "'", int69 == 2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 0.0d);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray4, (double) 1, 0, (double) (-1L));
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray4);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray4, (double) 1, (int) (short) 1, (double) '4');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, (double) 2, 0.0d);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (short) 100, 6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (int) ' ', (int) (short) 100);
        byte[] byteArray14 = new byte[] {};
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray16);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.clone(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray16);
        java.lang.String str21 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) byteArray6, "hi!");
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.add(byteArray6, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{}" + "'", str21.equals("{}"));
        org.junit.Assert.assertNotNull(byteArray23);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray6, (byte) 0);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray6, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray12);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        try {
            int[] intArray7 = org.apache.commons.lang3.ArrayUtils.remove(intArray4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.lang.Byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_OBJECT_ARRAY;
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0, (byte) 100);
        byte[] byteArray4 = new byte[] {};
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray6 = new byte[] {};
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        java.lang.Byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray8);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray5, byteArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray5, (byte) -1);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray5, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.add(byteArray16, (byte) -1);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray3, byteArray18);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        short[] shortArray1 = new short[] { (byte) 100 };
        java.lang.Short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray1);
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray2, (short) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1, 4, 1, 3 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4, (int) (short) 1);
        float[] floatArray14 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray14, (float) (short) 1);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.clone(floatArray14);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray14, (float) 10L);
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray4, (java.lang.Object) floatArray19, (int) (byte) 1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (-1L), 0, (double) (-1));
        double[] doubleArray19 = new double[] {};
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.add(doubleArray19, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray21);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray21, doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray25);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray27, (double) (byte) 10, 1, 0.0d);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray27);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray32, (double) (short) 10, (double) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[] byteArray13 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[] byteArray20 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[][] byteArray21 = new java.lang.Byte[][] { byteArray6, byteArray13, byteArray20 };
        java.lang.Byte[][] byteArray23 = org.apache.commons.lang3.ArrayUtils.remove(byteArray21, 0);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray23);
        try {
            java.lang.Object[][] objArray26 = org.apache.commons.lang3.ArrayUtils.remove((java.lang.Object[][]) byteArray23, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 10, (int) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 0, 2);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.String str1 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) 100, (double) 3);
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (-1L), (double) '#');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray0);
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray1, (short) (byte) -1);
        java.lang.Short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray4, (java.lang.Object) "hi!");
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        java.lang.Short[] shortArray11 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray11);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray12, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray12);
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.add(shortArray12, (short) 0);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray7, shortArray12);
        short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray12, (short) 100);
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray21);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        short[] shortArray0 = null;
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.add(shortArray0, 0, (short) 100);
        org.junit.Assert.assertNotNull(shortArray3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray10, 100, (int) (short) 100);
        java.lang.Class<?> wildcardClass14 = floatArray10.getClass();
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.Integer[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (byte) 1);
        double[] doubleArray5 = new double[] {};
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray5, (double) (-1.0f), (double) 1L);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray5, (double) (short) 0, (int) (short) 100, (double) '4');
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray5);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) intArray1, (java.lang.Object) doubleArray13);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray8, false, 0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.Character[] charArray5 = new java.lang.Character[] { ' ', ' ', ' ', 'a', ' ' };
        java.lang.Character[] charArray11 = new java.lang.Character[] { ' ', ' ', ' ', 'a', ' ' };
        java.lang.Character[][] charArray12 = new java.lang.Character[][] { charArray5, charArray11 };
        java.lang.Character[] charArray18 = new java.lang.Character[] { '#', ' ', 'a', '#', ' ' };
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray18);
        java.lang.Character[][] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray12, charArray18);
        java.lang.Object[][] objArray21 = org.apache.commons.lang3.ArrayUtils.clone((java.lang.Object[][]) charArray20);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray2, (byte) -1, (-1));
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (int) ' ', (int) (short) 100);
        byte[] byteArray14 = new byte[] {};
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray16);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.clone(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray16);
        java.lang.Byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray19);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(byteArray19, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (byte) 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        java.lang.String[] strArray9 = null;
        int[] intArray15 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray15, 1);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray15, intArray18);
        java.lang.String[] strArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray9, (java.lang.Object) intArray19);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray19, (int) '4');
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.addAll(intArray8, intArray19);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray8);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNull(strArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean[] booleanArray8 = new boolean[] {};
        boolean[] booleanArray13 = new boolean[] { true, false, false, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, true, 1);
        boolean[] booleanArray31 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) boolean33);
        byte[] byteArray37 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray38 = new byte[][] { byteArray37 };
        byte[][] byteArray39 = org.apache.commons.lang3.ArrayUtils.clone(byteArray38);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray5, (java.lang.Object) byteArray39);
        short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray43 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray41, (short) -1);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.contains(shortArray43, (short) (byte) 0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertNotNull(shortArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.String[] strArray6 = new java.lang.String[] { "", "1", "", "", "1", "" };
        java.lang.String[] strArray7 = null;
        java.lang.String[] strArray8 = org.apache.commons.lang3.ArrayUtils.addAll(strArray6, strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.subarray(strArray6, (int) '#', 2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) '#', (int) ' ');
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) '#', (int) (byte) 1);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) (byte) 0, (int) '#');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) 3, (int) (byte) 0);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (-1.0d), (int) (byte) 100, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        byte[] byteArray1 = new byte[] {};
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray1);
        byte[] byteArray3 = new byte[] {};
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray3);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.clone(byteArray3);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray2, byteArray7);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray7, (byte) 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray0, byteArray7);
        try {
            byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.add(byteArray0, 6, (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.subarray(longArray6, (int) (byte) 0, 0);
        java.lang.String str14 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) 0, "{}");
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 4);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.subarray(longArray9, 6, 2);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) 5, 0);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray12, (long) (byte) 10);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray12);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.subarray(intArray5, 0, 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        boolean[] booleanArray2 = new boolean[] { true, false };
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray2, true, (int) '4');
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(booleanArray6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) 0, (byte) 0, (byte) -1, (byte) 10, (byte) 0 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.reflect.AnnotatedElement[] annotatedElementArray0 = null;
        byte[] byteArray1 = new byte[] {};
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray1);
        java.lang.Byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray3);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.clone(byteArray3);
        byte[] byteArray6 = new byte[] {};
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray8);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray3, byteArray8);
        java.lang.reflect.AnnotatedElement[] annotatedElementArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(annotatedElementArray0, (java.lang.Object) byteArray11);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNull(annotatedElementArray12);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray1, (byte) -1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray1, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.clone(byteArray12);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (short) 10, (int) '4');
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 10.0f, 0, (double) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        java.lang.Character[] charArray5 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(charArray6, 'a');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray4, (float) ' ', (int) 'a');
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.add(floatArray4, (float) (short) 100);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.clone(floatArray12);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray13, (float) 6, (int) ' ');
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(floatArray13, (float) (-1L));
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        float[] floatArray8 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 100, (int) '4');
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray1, (java.lang.Object) (byte) 100, (-1));
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray14, (byte) 100);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray14, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.Object[] objArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(objArray0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, (double) 0.0f);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray0);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray0, (double) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, 0, 10);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray7, (short) (byte) 10);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) -1);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(shortArray11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) (byte) 100);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) (byte) -1, (int) (short) 1);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, 3, (short) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(shortArray15);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 0.0d);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray4, (double) 1, 0, (double) (-1L));
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray4, (double) 1L, 6, (double) (-1));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        try {
            int[] intArray6 = org.apache.commons.lang3.ArrayUtils.remove(intArray4, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long[] longArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(longArray0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        byte[] byteArray0 = null;
        try {
            byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.remove(byteArray0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray13 = new boolean[] { true, false };
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray13, true, (int) '4');
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray13, false, (int) (byte) 0);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray13, false);
        boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray13, true);
        try {
            boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.add(booleanArray13, (int) (short) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray6, false, (int) (byte) -1);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "1", "1" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = org.apache.commons.lang3.ArrayUtils.subarray((java.lang.Comparable<java.lang.String>[]) strArray4, 10, (int) (short) -1);
        byte[] byteArray8 = new byte[] {};
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray10);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray10);
        java.lang.CharSequence[] charSequenceArray13 = org.apache.commons.lang3.ArrayUtils.removeElement((java.lang.CharSequence[]) strArray4, (java.lang.Object) byteArray12);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.clone(byteArray12);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(charSequenceArray13);
        org.junit.Assert.assertNotNull(byteArray14);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int[] intArray0 = new int[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1));
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, 4, 2);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(intArray0, (int) (short) 0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.subarray(longArray6, (int) (byte) 0, 0);
        try {
            long[] longArray14 = org.apache.commons.lang3.ArrayUtils.remove(longArray12, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 10, (int) (short) 10);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray15, (int) (byte) 1, '4');
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.subarray(charArray21, (int) (short) 10, (int) (byte) 10);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.add(charArray21, '4');
        org.apache.commons.lang3.ArrayUtils.reverse(charArray26);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray26);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        java.lang.Long[] longArray12 = org.apache.commons.lang3.ArrayUtils.toObject(longArray11);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray11, 0L);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray11, (long) (-1));
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.contains(byteArray0, (byte) -1);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray0, (byte) -1);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray0, (byte) 1, 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray18);
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.add(booleanArray18, false);
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray21, (int) (byte) 0, (int) (short) 10);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray21, true, 6);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) (byte) 0);
        java.lang.Float[] floatArray30 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray30);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) (short) 0, (int) (byte) 10);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) 1L);
        float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray24, floatArray31);
        float[] floatArray44 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray46 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray44, (float) (short) 1);
        float[] floatArray48 = org.apache.commons.lang3.ArrayUtils.add(floatArray46, 0.0f);
        float[] floatArray49 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray24, floatArray48);
        boolean boolean51 = org.apache.commons.lang3.ArrayUtils.contains(floatArray24, (float) (byte) 1);
        float[] floatArray56 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray59 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray56, (int) (byte) 100, (int) '4');
        int int62 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray56, (float) ' ', (int) 'a');
        int int65 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray56, (float) 3, (int) 'a');
        boolean boolean66 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray24, floatArray56);
        java.lang.Float[] floatArray67 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray24);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(floatArray67);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.String[] strArray6 = new java.lang.String[] { "{{-1,1}}", "1", "{{-1,1}}", "", "{{-1,1}}", "{{-1,1}}" };
        java.lang.Comparable[][] comparableArray8 = new java.lang.Comparable[1][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray9 = (java.lang.Comparable<java.lang.String>[][]) comparableArray8;
        strComparableArray9[0] = strArray6;
        java.lang.Comparable<java.lang.String>[][] strComparableArray14 = org.apache.commons.lang3.ArrayUtils.subarray(strComparableArray9, 4, (int) (byte) 0);
        java.lang.Short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray22 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray22, 100L, (int) '4');
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray22, (long) (byte) 10);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray15, (java.lang.Object) longArray27);
        long[] longArray31 = org.apache.commons.lang3.ArrayUtils.subarray(longArray27, (int) (byte) 10, (int) (byte) 0);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) strComparableArray9, (java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(strComparableArray9);
        org.junit.Assert.assertNotNull(strComparableArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(longArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.add(longArray12, 2, (long) (byte) 1);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (byte) 100, 5);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double[] doubleArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, 0.0d, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int[] intArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray1, (byte) -1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray1, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray12, (byte) -1);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray12, (byte) 0);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray16, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray9, (byte) 1, (int) '4');
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 10, 4);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray3, (java.lang.Object) byteArray15);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray15, (byte) 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(byteArray18);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        boolean[] booleanArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray0, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 0);
        java.lang.Short[] shortArray15 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray15);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray16, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray16);
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.add(shortArray16, (short) 0);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray16);
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray11, shortArray16);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray16, (short) 100, (int) '4');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        try {
            double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray6, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray22 = org.apache.commons.lang3.ArrayUtils.add(doubleArray20, (double) (byte) 10);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray18, doubleArray22);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray18);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.add(doubleArray25, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray27);
        double[] doubleArray29 = new double[] {};
        double[] doubleArray31 = org.apache.commons.lang3.ArrayUtils.add(doubleArray29, (double) (byte) 10);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray27, doubleArray31);
        double[] doubleArray33 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray31);
        double[] doubleArray35 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray33, (double) (byte) 0);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray24, doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, false);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray8, true);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.Boolean[] booleanArray1 = new java.lang.Boolean[] { false };
        boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray1);
        java.lang.Boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray2);
        try {
            boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.add(booleanArray2, (int) '4', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, (double) 4, (double) 0.0f);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        char[] charArray5 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#');
        char[] charArray12 = new char[] { '#', ' ', '#', '4' };
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray5, charArray12);
        char[] charArray19 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray19, '#');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.addAll(charArray12, charArray19);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains(charArray22, '#');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) '4');
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray14);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Class<?> wildcardClass28 = intArray25.getClass();
        int[] intArray34 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray34, 1);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray34, (int) ' ', (int) (short) 100);
        int[] intArray45 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int47 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray45, 1);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray49 = org.apache.commons.lang3.ArrayUtils.addAll(intArray45, intArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray34, intArray49);
        int int52 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray49, (int) (byte) 0);
        int[] intArray54 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray49, 1);
        int[] intArray56 = org.apache.commons.lang3.ArrayUtils.add(intArray54, (int) '4');
        java.lang.Integer[] intArray60 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray62 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray60, 2);
        int[] intArray63 = org.apache.commons.lang3.ArrayUtils.addAll(intArray54, intArray62);
        boolean boolean64 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray25, intArray62);
        int int67 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, 5, (int) (byte) 100);
        int int69 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray25, (int) (byte) 1);
        boolean boolean71 = org.apache.commons.lang3.ArrayUtils.contains(intArray25, (int) '#');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray4, (float) ' ', (int) 'a');
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.add(floatArray4, (float) (short) 100);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.add(floatArray12, 0, (float) 0L);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray15, (float) (byte) 0, 4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray11, (long) 3);
        try {
            long[] longArray15 = org.apache.commons.lang3.ArrayUtils.remove(longArray11, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray17 = null;
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray17);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray17, (long) '4', 5);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray0, (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray0, (byte) 0, (int) (short) 10);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.lang.Float[] floatArray0 = null;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        org.junit.Assert.assertNull(floatArray1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray9, (float) 0L);
        float[] floatArray22 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray22, (float) (short) 1);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.add(floatArray24, 0.0f);
        float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray26, 100, (int) (short) 100);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray26, 10.0f, (int) (short) 1);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray15, floatArray26);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray0);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray4, (double) 5);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray9, (float) 0L);
        float[] floatArray22 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray22, (float) (short) 1);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.clone(floatArray22);
        java.lang.Float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray25);
        float[] floatArray33 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray35 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray33, (float) (short) 1);
        float[] floatArray36 = org.apache.commons.lang3.ArrayUtils.clone(floatArray33);
        java.lang.Float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray36);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray26, (java.lang.Object[]) floatArray37);
        float[] floatArray40 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray37, (float) 10);
        float[] floatArray42 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray37, (float) 10L);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray9, floatArray42);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { (-1), 1 };
        int[] intArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2);
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (short) 10, (int) '4');
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (double) (short) 1);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray16);
        java.lang.Long[] longArray18 = org.apache.commons.lang3.ArrayUtils.toObject(longArray16);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray16, (long) (byte) 0, (int) '4');
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "1", "1" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = org.apache.commons.lang3.ArrayUtils.subarray((java.lang.Comparable<java.lang.String>[]) strArray4, 10, (int) (short) -1);
        float[] floatArray14 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray14, (float) (short) 1);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.clone(floatArray14);
        java.lang.Float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray17);
        float[] floatArray25 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray25, (float) (short) 1);
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.clone(floatArray25);
        java.lang.Float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray28);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray18, (java.lang.Object[]) floatArray29);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) floatArray29);
        java.lang.CharSequence[] charSequenceArray32 = org.apache.commons.lang3.ArrayUtils.removeElement((java.lang.CharSequence[]) strArray4, (java.lang.Object) floatArray29);
        java.lang.Character[] charArray36 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray37 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray36);
        char[] charArray43 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int45 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray43, '#');
        char[] charArray46 = org.apache.commons.lang3.ArrayUtils.addAll(charArray37, charArray43);
        char[] charArray48 = org.apache.commons.lang3.ArrayUtils.add(charArray46, '4');
        int int51 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray48, 'a', (int) ' ');
        char[] charArray53 = org.apache.commons.lang3.ArrayUtils.add(charArray48, 'a');
        char[] charArray59 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int61 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray59, '#');
        char[] charArray62 = new char[] {};
        boolean boolean63 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray59, charArray62);
        char[] charArray64 = org.apache.commons.lang3.ArrayUtils.addAll(charArray53, charArray59);
        boolean boolean65 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) strArray4, (java.lang.Object) charArray53);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(charSequenceArray32);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(charArray46);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 4 + "'", int61 == 4);
        org.junit.Assert.assertNotNull(charArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(charArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double[] doubleArray2 = new double[] { 10L, (-1.0f) };
        double[] doubleArray5 = new double[] { 10L, (-1.0f) };
        double[] doubleArray8 = new double[] { 10L, (-1.0f) };
        double[] doubleArray11 = new double[] { 10L, (-1.0f) };
        double[] doubleArray14 = new double[] { 10L, (-1.0f) };
        double[] doubleArray17 = new double[] { 10L, (-1.0f) };
        double[][] doubleArray18 = new double[][] { doubleArray2, doubleArray5, doubleArray8, doubleArray11, doubleArray14, doubleArray17 };
        double[][] doubleArray19 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray18);
        double[][] doubleArray20 = new double[][] {};
        double[][] doubleArray21 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray19, doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        float[] floatArray5 = new float[] { (-1), (byte) 10, (short) 100, 1L, 1.0f };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (byte) 1, (int) '#');
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, 2, (int) '4');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 100.0f, (double) 1.0f);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) '4', (double) 4);
        try {
            double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, 3, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray4, (float) ' ', (int) 'a');
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.add(floatArray4, (float) (short) 100);
        java.lang.Float[] floatArray18 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray18);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray18);
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray4, floatArray20);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray21);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (byte) 1, 4);
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.subarray(charArray18, 2, (int) (byte) 0);
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray21, 'a', (-1));
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.clone(charArray21);
        try {
            char[] charArray28 = org.apache.commons.lang3.ArrayUtils.add(charArray25, (int) '4', '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(charArray25);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) -1);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        try {
            short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.add(shortArray10, (int) (short) 100, (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(shortArray10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.remove(shortArray4, (int) (byte) 0);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray9);
        try {
            short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (-1), (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray4);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, 2, (int) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '4', 0);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "1", "1" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = org.apache.commons.lang3.ArrayUtils.subarray((java.lang.Comparable<java.lang.String>[]) strArray4, 10, (int) (short) -1);
        float[] floatArray14 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray14, (float) (short) 1);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.clone(floatArray14);
        java.lang.Float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray17);
        float[] floatArray25 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray25, (float) (short) 1);
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.clone(floatArray25);
        java.lang.Float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray28);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray18, (java.lang.Object[]) floatArray29);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) floatArray29);
        java.lang.CharSequence[] charSequenceArray32 = org.apache.commons.lang3.ArrayUtils.removeElement((java.lang.CharSequence[]) strArray4, (java.lang.Object) floatArray29);
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray29);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(charSequenceArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        boolean[] booleanArray2 = new boolean[] { true, false };
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray2, true, (int) '4');
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray2, false, (int) (byte) 0);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.Object obj0 = null;
        java.lang.String str1 = org.apache.commons.lang3.ArrayUtils.toString(obj0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{}" + "'", str1.equals("{}"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray0);
        java.lang.Float[] floatArray2 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY;
        float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray2);
        java.lang.Character[] charArray7 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7);
        char[] charArray14 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '#');
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.addAll(charArray8, charArray14);
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.add(charArray17, '4');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.subarray(charArray19, (int) (byte) 1, 4);
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.subarray(charArray22, 2, (int) (byte) 0);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) floatArray2, (java.lang.Object) 2);
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray2, (float) (short) 100);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) shortArray1, (java.lang.Object) floatArray28, (int) (byte) 100);
        short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray1, (short) 0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(shortArray32);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray14 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '#');
        char[] charArray21 = new char[] { '#', ' ', '#', '4' };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray14, charArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.subarray(charArray8, 5, (int) (short) 10);
        try {
            char[] charArray29 = org.apache.commons.lang3.ArrayUtils.add(charArray8, 10, '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(charArray26);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 10, (int) (byte) 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 100L);
        java.lang.Class<?> wildcardClass13 = floatArray8.getClass();
        java.lang.Float[] floatArray19 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray20, 1.0f);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray8, floatArray20);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray8);
        try {
            float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, (int) '#', (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "1", "1" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = org.apache.commons.lang3.ArrayUtils.subarray((java.lang.Comparable<java.lang.String>[]) strArray4, 10, (int) (short) -1);
        byte[] byteArray8 = new byte[] {};
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray10);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray10);
        java.lang.CharSequence[] charSequenceArray13 = org.apache.commons.lang3.ArrayUtils.removeElement((java.lang.CharSequence[]) strArray4, (java.lang.Object) byteArray12);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray12, (byte) 1);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(charSequenceArray13);
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 0, 100);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        java.lang.Short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray4, (java.lang.Object) "hi!");
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) shortArray0, (java.lang.Object[]) shortArray4);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4, (short) (byte) 100);
        boolean[] booleanArray16 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray17 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray16);
        boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray17, true);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) shortArray4, (java.lang.Object[]) booleanArray17);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        char[] charArray5 = new char[] { '4', '4', 'a', 'a', '4' };
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.add(charArray5, '#');
        org.apache.commons.lang3.ArrayUtils.reverse(charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, 1, (int) (byte) -1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31, 2);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray25, intArray33);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.add(intArray33, (int) 'a');
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray33, (int) (short) 1, (int) (short) 10);
        int int42 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray33, (int) (short) 0, (int) (short) -1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (int) ' ', (int) (short) 100);
        byte[] byteArray14 = new byte[] {};
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray16);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.clone(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray16);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(byteArray19, (byte) -1);
        byte[] byteArray22 = new byte[] {};
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.clone(byteArray22);
        byte[] byteArray24 = new byte[] {};
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.clone(byteArray24);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.clone(byteArray24);
        java.lang.Byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray26);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.clone(byteArray26);
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray23, byteArray28);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray28, (byte) 0, (int) (short) 100);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray19, byteArray28);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray28);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) '4');
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int[] intArray0 = null;
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.add(intArray0, (int) (byte) 0);
        try {
            int[] intArray5 = org.apache.commons.lang3.ArrayUtils.add(intArray0, (int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) '4');
        java.lang.Double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray2);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 'a', (double) 10L);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        long[][] longArray0 = new long[][] {};
        long[][] longArray1 = new long[][] {};
        long[][][] longArray2 = new long[][][] { longArray0, longArray1 };
        long[] longArray8 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray13 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray18 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray23 = new long[] { (byte) 100, 4, 1L, 2 };
        long[][] longArray24 = new long[][] { longArray8, longArray13, longArray18, longArray23 };
        long[] longArray28 = new long[] { 'a', 10, 0 };
        long[] longArray32 = new long[] { 'a', 10, 0 };
        long[] longArray36 = new long[] { 'a', 10, 0 };
        long[] longArray40 = new long[] { 'a', 10, 0 };
        long[] longArray44 = new long[] { 'a', 10, 0 };
        long[] longArray48 = new long[] { 'a', 10, 0 };
        long[][] longArray49 = new long[][] { longArray28, longArray32, longArray36, longArray40, longArray44, longArray48 };
        long[][] longArray50 = org.apache.commons.lang3.ArrayUtils.addAll(longArray24, longArray49);
        try {
            long[][][] longArray51 = org.apache.commons.lang3.ArrayUtils.add(longArray2, 5, longArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertNotNull(longArray40);
        org.junit.Assert.assertNotNull(longArray44);
        org.junit.Assert.assertNotNull(longArray48);
        org.junit.Assert.assertNotNull(longArray49);
        org.junit.Assert.assertNotNull(longArray50);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        byte[] byteArray0 = null;
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray0, (byte) 0);
        org.junit.Assert.assertNull(byteArray2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) '#', (int) (short) 10);
        long[] longArray20 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray20, 100L, (int) '4');
        java.lang.Long[] longArray24 = org.apache.commons.lang3.ArrayUtils.toObject(longArray20);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.addAll(longArray6, longArray20);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray25);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray1, (byte) -1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray1, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.add(byteArray12, (byte) -1);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray12, (byte) 0);
        byte[] byteArray17 = new byte[] {};
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.clone(byteArray17);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.clone(byteArray17);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray16, byteArray19);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0, true);
        boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray3);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray4, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (byte) 100);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, (double) 100);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        java.lang.Object obj11 = null;
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) floatArray9, obj11);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0, (int) (short) 100);
        byte[] byteArray11 = new byte[] {};
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        byte[] byteArray13 = new byte[] {};
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        java.lang.Byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray15);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray12, byteArray17);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray17);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray17, (byte) 0);
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.add(byteArray17, (byte) 100);
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray17);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.lang.Short[] shortArray0 = new java.lang.Short[] {};
        java.lang.Short[] shortArray1 = new java.lang.Short[] {};
        java.lang.Short[] shortArray2 = new java.lang.Short[] {};
        java.lang.Short[] shortArray3 = new java.lang.Short[] {};
        java.lang.Short[][] shortArray4 = new java.lang.Short[][] { shortArray0, shortArray1, shortArray2, shortArray3 };
        java.lang.Short[][] shortArray7 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray4, (-1), (int) '#');
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray11 = new byte[][] { byteArray10 };
        byte[][] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        byte[][] byteArray15 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray12, 5, (int) (byte) 0);
        try {
            java.lang.Object[][] objArray16 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Object[][]) shortArray4, (java.lang.Object[]) byteArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayStoreException; message: [[B");
        } catch (java.lang.ArrayStoreException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(floatArray4, (float) 5);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray4, (float) 10L);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray4, (float) (short) -1);
        float[] floatArray20 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray20, (float) (short) 1);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.clone(floatArray20);
        java.lang.Float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray23);
        float[] floatArray31 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray31, (float) (short) 1);
        float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.clone(floatArray31);
        java.lang.Float[] floatArray35 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray24, (java.lang.Object[]) floatArray35);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray24, (float) (byte) 0);
        java.lang.Float[] floatArray44 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray45 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray44);
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray45, (float) (short) 0, (int) (byte) 10);
        int int50 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray45, (float) 1L);
        float[] floatArray51 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray38, floatArray45);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray38);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray11, 0);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.clone(intArray13);
        int[] intArray20 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray20, 1);
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.addAll(intArray20, intArray23);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) '4');
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.add(intArray20, 1, 0);
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.addAll(intArray13, intArray20);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) '4', (java.lang.Object) intArray20);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (byte) 1, 4);
        char[] charArray23 = new char[] { 'a', ' ', '4', '#' };
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray23, 'a');
        char[] charArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray23, '4');
        char[] charArray33 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int35 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray33, '#');
        char[] charArray40 = new char[] { '#', ' ', '#', '4' };
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray33, charArray40);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray27, charArray33);
        char[] charArray45 = org.apache.commons.lang3.ArrayUtils.add(charArray27, 3, ' ');
        char[] charArray46 = org.apache.commons.lang3.ArrayUtils.addAll(charArray18, charArray45);
        java.lang.Character[] charArray50 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray51 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray50);
        java.lang.Character[] charArray52 = org.apache.commons.lang3.ArrayUtils.toObject(charArray51);
        char[] charArray54 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray52, 'a');
        int int57 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray54, 'a', 10);
        boolean boolean58 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray18, charArray54);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(charArray46);
        org.junit.Assert.assertNotNull(charArray50);
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(charArray52);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(floatArray4, (float) 5);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray4, (float) 10L);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray4, (float) (short) -1);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) '4');
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray13, (double) '4', 1, (double) 10L);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int[] intArray0 = new int[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1));
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, 4, 2);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray0, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray0, 100);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray13 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray13, 1);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray13, (int) ' ', (int) (short) 100);
        int[] intArray24 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray24, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.addAll(intArray24, intArray27);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray13, intArray28);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray28, (int) (byte) 0);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray28, 1);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.clone(intArray28);
        int[] intArray40 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray40, 1);
        int int45 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray40, (int) ' ', (int) (short) 100);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.add(intArray40, 1, (int) 'a');
        int[] intArray51 = org.apache.commons.lang3.ArrayUtils.subarray(intArray40, 0, 0);
        int[] intArray52 = org.apache.commons.lang3.ArrayUtils.addAll(intArray34, intArray40);
        boolean boolean53 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray7, intArray34);
        boolean boolean54 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray7);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (-1.0f));
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) 10.0f, 1, (double) 10.0f);
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, 100.0d, (int) (short) 1);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 2, (int) (short) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        float[][][] floatArray0 = new float[][][] {};
        float[] floatArray4 = new float[] { 100, 0.0f };
        float[] floatArray7 = new float[] { 100, 0.0f };
        float[] floatArray10 = new float[] { 100, 0.0f };
        float[] floatArray13 = new float[] { 100, 0.0f };
        float[][] floatArray14 = new float[][] { floatArray4, floatArray7, floatArray10, floatArray13 };
        float[] floatArray19 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray19, (int) (byte) 100, (int) '4');
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray19, (float) ' ', (int) 'a');
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.add(floatArray19, (float) (short) 100);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray27, (int) '4', (int) ' ');
        float[][] floatArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray14, (java.lang.Object) floatArray27);
        try {
            float[][][] floatArray32 = org.apache.commons.lang3.ArrayUtils.add(floatArray0, (int) (byte) 10, floatArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, false);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray10, true, (int) (byte) -1);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray1, (byte) -1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray1, (int) (byte) 0, (int) (short) 1);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray12, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        try {
            long[] longArray10 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (int) (byte) 10, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) '4');
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.add(doubleArray13, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        long[] longArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray0, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        java.lang.Short[] shortArray7 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.add(shortArray8, (short) 0);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray8);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 100);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray17, (short) (byte) -1);
        short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.clone(shortArray17);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) 1);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.String[] strArray6 = new java.lang.String[] { "{{-1,1}}", "1", "{{-1,1}}", "", "{{-1,1}}", "{{-1,1}}" };
        java.lang.Comparable[][] comparableArray8 = new java.lang.Comparable[1][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray9 = (java.lang.Comparable<java.lang.String>[][]) comparableArray8;
        strComparableArray9[0] = strArray6;
        java.lang.Comparable<java.lang.String>[][] strComparableArray14 = org.apache.commons.lang3.ArrayUtils.subarray(strComparableArray9, 4, (int) (byte) 0);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray15);
        java.lang.Short[] shortArray20 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray20);
        short[] shortArray22 = new short[] {};
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray21, shortArray22);
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.clone(shortArray22);
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.add(shortArray24, (short) 1);
        short[] shortArray27 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray15, shortArray24);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray27, 10, 100);
        java.lang.Object[][] objArray31 = org.apache.commons.lang3.ArrayUtils.removeElement((java.lang.Object[][]) strComparableArray14, (java.lang.Object) shortArray27);
        java.lang.Short[] shortArray35 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray35);
        short[] shortArray37 = new short[] {};
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray37);
        short[] shortArray39 = org.apache.commons.lang3.ArrayUtils.clone(shortArray37);
        short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.add(shortArray39, (short) 1);
        java.lang.Short[] shortArray42 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray41);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) objArray31, (java.lang.Object) shortArray42);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(strComparableArray9);
        org.junit.Assert.assertNotNull(strComparableArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertNotNull(shortArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray6);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0, 5);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 1, 5);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (int) ' ', (int) (short) 100);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        byte[] byteArray15 = new byte[] {};
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        byte[] byteArray17 = new byte[] {};
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.clone(byteArray17);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.clone(byteArray17);
        java.lang.Byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray19);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.clone(byteArray19);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray16, byteArray21);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray21);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray21, (byte) 0);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray14, byteArray21);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray14);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray20);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray20);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray21, (float) 10);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray21, (float) 10L);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray26);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 0);
        double[] doubleArray6 = new double[] {};
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray8);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray8, doubleArray12);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray12);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray14, (double) (byte) 0);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray14);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.add(doubleArray18, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray20);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.add(doubleArray22, (double) (byte) 10);
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray20, 0, 0);
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray28, (double) (-1), (int) (short) 1);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray28);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray14, doubleArray28);
        java.lang.Class<?> wildcardClass34 = doubleArray28.getClass();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray10.getClass();
        java.lang.Class<?>[] wildcardClassArray12 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16);
        short[] shortArray18 = new short[] {};
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray18);
        java.lang.Short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray17);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) -1);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray12, (java.lang.Object) (short) -1);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) longArray10, (java.lang.Object[]) wildcardClassArray12);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10);
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10, 0L);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray27);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClassArray12);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray27);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray9, (float) 0L);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray9, (int) '4', (int) 'a');
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray18);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        float[] floatArray5 = new float[] { 4, (short) 1, (-1), (-1), 0L };
        float[] floatArray10 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray10, (int) (byte) 100, (int) '4');
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray10, (float) ' ', (int) 'a');
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray10, (float) (short) 100);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray5, floatArray18);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray5);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray5, (float) 0L, 100);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 0.0d);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray4, (double) 1, 0, (double) (-1L));
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray4, (double) 2);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray4, 0.0d, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = new byte[] {};
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        java.lang.Byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray11);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 1);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray4, byteArray12);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray12, (byte) 1, (int) (short) 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Object obj0 = null;
        java.lang.String str2 = org.apache.commons.lang3.ArrayUtils.toString(obj0, "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        try {
            int[] intArray2 = org.apache.commons.lang3.ArrayUtils.remove(intArray0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray15, (long) 2);
        java.lang.Long[] longArray18 = org.apache.commons.lang3.ArrayUtils.toObject(longArray17);
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.clone(longArray17);
        try {
            long[] longArray22 = org.apache.commons.lang3.ArrayUtils.add(longArray17, (int) 'a', 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 4);
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray9);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray9, (long) 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray9);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) -1);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray4, (short) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray0, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double[] doubleArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray0, (-1), 5);
        org.junit.Assert.assertNull(booleanArray3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray10.getClass();
        java.lang.Class<?>[] wildcardClassArray12 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16);
        short[] shortArray18 = new short[] {};
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray18);
        java.lang.Short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray17);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) -1);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray12, (java.lang.Object) (short) -1);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) longArray10, (java.lang.Object[]) wildcardClassArray12);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10);
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10, 0L);
        try {
            int int28 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClassArray12);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertNotNull(longArray27);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        char[] charArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '4', 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean[] booleanArray8 = new boolean[] {};
        boolean[] booleanArray13 = new boolean[] { true, false, false, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, true, 1);
        boolean[] booleanArray31 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) boolean33);
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 10);
        short[] shortArray37 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray38 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap39 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) shortArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '0', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray37);
        org.junit.Assert.assertNotNull(shortArray38);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        float[] floatArray8 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 100, (int) '4');
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray1, (java.lang.Object) (byte) 100, (-1));
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray6, true, 0);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true);
        try {
            int int24 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int[] intArray0 = null;
        int[] intArray3 = org.apache.commons.lang3.ArrayUtils.subarray(intArray0, 2, 6);
        org.junit.Assert.assertNull(intArray3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray28 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray28, 100L, (int) '4');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray28, (long) (byte) 10);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray21, (java.lang.Object) longArray33);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray33, (int) (byte) 10, (int) (byte) 0);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.add(longArray37, (long) (byte) 1);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) 100, 100);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray37);
        java.lang.Long[] longArray46 = org.apache.commons.lang3.ArrayUtils.toObject(longArray45);
        long[] longArray48 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray46, (long) 5);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertNotNull(longArray48);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        java.lang.Character[] charArray5 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5, 'a');
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray7, 'a', 10);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.clone(charArray7);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray11);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) 100);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray20, (long) 2);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray8, (long) '#');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) 0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray0);
        double[] doubleArray2 = new double[] {};
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray4);
        double[] doubleArray6 = new double[] {};
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (double) (byte) 10);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray4, doubleArray8);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray10, (double) (byte) 10, 1, 0.0d);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray1, (java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        long[] longArray2 = new long[] { (byte) 10, (byte) 10 };
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.contains(longArray2, (long) (short) 10);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray14 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '#');
        char[] charArray21 = new char[] { '#', ' ', '#', '4' };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray14, charArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.subarray(charArray8, 5, (int) (short) 10);
        try {
            char[] charArray28 = org.apache.commons.lang3.ArrayUtils.remove(charArray26, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(charArray26);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        char[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        char[] charArray6 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray6, '#');
        char[] charArray13 = new char[] { '#', ' ', '#', '4' };
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray6, charArray13);
        char[] charArray20 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray20, '#');
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.addAll(charArray13, charArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray20, '#');
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray0, charArray20);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) 10L);
        java.lang.Float[] floatArray17 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray17);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray17);
        float[] floatArray26 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray26, (float) (short) 1);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.add(floatArray28, 0.0f);
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray30, 100, (int) (short) 100);
        float[] floatArray38 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray38, (int) (byte) 100, (int) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray38, (float) ' ', (int) 'a');
        float[] floatArray46 = org.apache.commons.lang3.ArrayUtils.add(floatArray38, (float) (short) 100);
        float[] floatArray47 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray30, floatArray46);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray19, floatArray30);
        float[] floatArray49 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray11, floatArray19);
        float[] floatArray50 = null;
        float[] floatArray51 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray19, floatArray50);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray51);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray2, 0, 0);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 'a');
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 2, (double) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(byteArray7, (byte) 1);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray7);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray0, false);
        org.junit.Assert.assertNull(booleanArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.subarray(intArray5, 0, 0);
        int[] intArray17 = new int[] {};
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, (-1));
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 4, 2);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray17, 3);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray17);
        int[] intArray26 = new int[] {};
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray26, (-1));
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray26, 4, 2);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray26, 3);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray26);
        int int36 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray26, (int) (short) 100);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 0, 100);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 100.0f, (int) (byte) 10, (double) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 0, 100);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray7, (byte) 100, 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean[] booleanArray14 = new boolean[] {};
        boolean[] booleanArray19 = new boolean[] { true, false, false, true };
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray14, booleanArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray13, booleanArray19);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray13, true);
        boolean[] booleanArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray13, true);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray13, true);
        java.lang.Boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray27);
        boolean[] booleanArray29 = new boolean[] {};
        boolean[] booleanArray34 = new boolean[] { true, false, false, true };
        boolean[] booleanArray35 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray29, booleanArray34);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray34, true);
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray34, 3, (int) (short) 10);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray40, false);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray27, booleanArray40);
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray40);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray40);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertNotNull(booleanArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 4);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.subarray(longArray7, (-1), (int) ' ');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.clone(longArray12);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray14);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray14);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (byte) 1);
        double[] doubleArray3 = new double[] {};
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray3, (double) (-1.0f), (double) 1L);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) (short) 0, (int) (short) 100, (double) '4');
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray3);
        try {
            double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray3, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray9, 10.0f);
        float[] floatArray20 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray20, (int) (byte) 100, (int) '4');
        float[] floatArray30 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray30, (float) (short) 1);
        float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.add(floatArray32, 0.0f);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray23, floatArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray9, floatArray23);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray6, true, 0);
        try {
            boolean[] booleanArray23 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray6, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        char[][][] charArray0 = new char[][][] {};
        char[][][] charArray1 = new char[][][] {};
        char[][][] charArray2 = new char[][][] {};
        char[][][] charArray3 = new char[][][] {};
        char[][][] charArray4 = new char[][][] {};
        char[][][][] charArray5 = new char[][][][] { charArray0, charArray1, charArray2, charArray3, charArray4 };
        char[] charArray12 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[] charArray18 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[][] charArray19 = new char[][] { charArray12, charArray18 };
        char[] charArray25 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[] charArray31 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[][] charArray32 = new char[][] { charArray25, charArray31 };
        char[] charArray38 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[] charArray44 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[][] charArray45 = new char[][] { charArray38, charArray44 };
        char[] charArray51 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[] charArray57 = new char[] { 'a', 'a', 'a', '#', ' ' };
        char[][] charArray58 = new char[][] { charArray51, charArray57 };
        char[][][] charArray59 = new char[][][] { charArray19, charArray32, charArray45, charArray58 };
        char[][][] charArray62 = org.apache.commons.lang3.ArrayUtils.subarray(charArray59, (int) 'a', 3);
        try {
            char[][][][] charArray63 = org.apache.commons.lang3.ArrayUtils.add(charArray5, (int) '#', charArray62);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(charArray44);
        org.junit.Assert.assertNotNull(charArray45);
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(charArray57);
        org.junit.Assert.assertNotNull(charArray58);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(charArray62);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        long[] longArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray0, (long) (-1), (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) (byte) 100);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray9, (short) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray9);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray12, (long) 4, (int) (byte) 1);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, 100L);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray12);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (-1L), 0, (double) (-1));
        double[] doubleArray19 = new double[] {};
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.add(doubleArray19, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray21);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray21, doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray25);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray27, (double) (byte) 10, 1, 0.0d);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray27);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) '4', (double) 1);
        int int38 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) 3, (double) (-1.0f));
        try {
            double[] doubleArray40 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray6, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (byte) 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.clone(intArray7);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean[] booleanArray8 = new boolean[] {};
        boolean[] booleanArray13 = new boolean[] { true, false, false, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, true, 1);
        boolean[] booleanArray31 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) boolean33);
        byte[] byteArray37 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray38 = new byte[][] { byteArray37 };
        byte[][] byteArray39 = org.apache.commons.lang3.ArrayUtils.clone(byteArray38);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray5, (java.lang.Object) byteArray39);
        short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray43 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray41, (short) -1);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.contains(shortArray41, (short) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertNotNull(shortArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray5);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray0);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray4, (double) 6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) (byte) 100);
        boolean[] booleanArray10 = new boolean[] {};
        boolean[] booleanArray15 = new boolean[] { true, false, false, true };
        boolean[] booleanArray16 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray10, booleanArray15);
        boolean[] booleanArray17 = new boolean[] {};
        boolean[] booleanArray22 = new boolean[] { true, false, false, true };
        boolean[] booleanArray23 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray17, booleanArray22);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray16, booleanArray22);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray16, true);
        boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray16, true);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray16, true, 0);
        int int32 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) shortArray5, (java.lang.Object) 0);
        char[] charArray39 = new char[] { '4', ' ', 'a', '#', '#', '4' };
        char[] charArray41 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray39, ' ');
        int int43 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) charArray39, (int) (short) 0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray20);
        boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray21);
        float[] floatArray29 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray29, (float) (short) 1);
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.add(floatArray31, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray31);
        int int37 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray31, (float) (byte) 0, (int) (short) 10);
        float[] floatArray40 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray31, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray46 = new float[] { (-1), (byte) 10, (short) 100, 1L, 1.0f };
        float[] floatArray49 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray46, (int) (byte) 1, (int) '#');
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray40, floatArray49);
        boolean boolean51 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) booleanArray22, (java.lang.Object) floatArray49);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        int int29 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray27, 5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (byte) 1, 4);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray18, 'a', (int) (byte) 10);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray18);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        java.io.Serializable[] serializableArray10 = org.apache.commons.lang3.ArrayUtils.subarray((java.io.Serializable[]) byteArray6, 100, (int) (short) 0);
        java.lang.Short[] shortArray14 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray14);
        short[] shortArray16 = new short[] {};
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray15, shortArray16);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray15, (short) (byte) 0);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray6, (java.lang.Object) shortArray15);
        double[] doubleArray23 = new double[] { 10L, (-1.0f) };
        double[] doubleArray26 = new double[] { 10L, (-1.0f) };
        double[] doubleArray29 = new double[] { 10L, (-1.0f) };
        double[] doubleArray32 = new double[] { 10L, (-1.0f) };
        double[] doubleArray35 = new double[] { 10L, (-1.0f) };
        double[] doubleArray38 = new double[] { 10L, (-1.0f) };
        double[][] doubleArray39 = new double[][] { doubleArray23, doubleArray26, doubleArray29, doubleArray32, doubleArray35, doubleArray38 };
        double[][] doubleArray40 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray39);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) byteArray6, (java.lang.Object[]) doubleArray40);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(serializableArray10);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray5);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.remove(shortArray4, (int) (byte) 0);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray9);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray11);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray4);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, 5);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(shortArray4, (short) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 0);
        double[] doubleArray6 = new double[] {};
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray8);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray8, doubleArray12);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray12);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray14, (double) (byte) 0);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray14);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.add(doubleArray18, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray20);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.add(doubleArray22, (double) (byte) 10);
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray20, 0, 0);
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray28, (double) (-1), (int) (short) 1);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray28);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray14, doubleArray28);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, (int) '4', 4);
        java.lang.Character[] charArray11 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray11);
        char[] charArray18 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray18, '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.addAll(charArray12, charArray18);
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.add(charArray21, '4');
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.subarray(charArray23, (int) (byte) 1, 4);
        char[] charArray31 = new char[] { 'a', ' ', '4', '#' };
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray31, 'a');
        char[] charArray35 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray31, '4');
        char[] charArray41 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int43 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray41, '#');
        char[] charArray48 = new char[] { '#', ' ', '#', '4' };
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray41, charArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray35, charArray41);
        char[] charArray53 = org.apache.commons.lang3.ArrayUtils.add(charArray35, 3, ' ');
        char[] charArray54 = org.apache.commons.lang3.ArrayUtils.addAll(charArray26, charArray53);
        char[] charArray55 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray26);
        java.lang.Character[] charArray59 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray60 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray59);
        char[] charArray66 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int68 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray66, '#');
        char[] charArray69 = org.apache.commons.lang3.ArrayUtils.addAll(charArray60, charArray66);
        char[] charArray71 = org.apache.commons.lang3.ArrayUtils.add(charArray69, '4');
        int int74 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray71, '#', (int) '#');
        char[] charArray75 = null;
        boolean boolean76 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray71, charArray75);
        char[] charArray77 = org.apache.commons.lang3.ArrayUtils.addAll(charArray55, charArray71);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(charArray60);
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(charArray69);
        org.junit.Assert.assertNotNull(charArray71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(charArray77);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean[] booleanArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(booleanArray16);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray14 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '#');
        char[] charArray21 = new char[] { '#', ' ', '#', '4' };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray14, charArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.subarray(charArray8, 5, (int) (short) 10);
        java.lang.Character[] charArray30 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray31 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray30);
        java.lang.Character[] charArray32 = org.apache.commons.lang3.ArrayUtils.toObject(charArray31);
        char[] charArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray32);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray33);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        int[] intArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray6, (int) ' ', (int) (short) 100);
        int[] intArray17 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 1);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.addAll(intArray17, intArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray6, intArray21);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray21, (int) (byte) 0);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray21, 1);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.add(intArray26, (int) '4');
        java.lang.Class<?> wildcardClass29 = intArray26.getClass();
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray0, intArray26);
        java.lang.Integer[] intArray31 = org.apache.commons.lang3.ArrayUtils.toObject(intArray26);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int[] intArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray6, (int) ' ', (int) (short) 100);
        int[] intArray17 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 1);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.addAll(intArray17, intArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray6, intArray21);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray21, (int) (byte) 0);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray21, 1);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.add(intArray26, (int) '4');
        java.lang.Class<?> wildcardClass29 = intArray26.getClass();
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray0, intArray26);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.clone(intArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(intArray31);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3);
        java.lang.Class<?> wildcardClass5 = byteArray3.getClass();
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3, (byte) 10);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray3);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        boolean[] booleanArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray0, false, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        char[] charArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray0, '4', (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        char[] charArray0 = null;
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.clone(charArray0);
        org.junit.Assert.assertNull(charArray1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        char[] charArray10 = new char[] { 'a', ' ', '4', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray10, 'a');
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray10, '4');
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray14, '4');
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) intArray3, (java.lang.Object) '4');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        try {
            java.lang.reflect.AnnotatedElement[] annotatedElementArray13 = org.apache.commons.lang3.ArrayUtils.remove((java.lang.reflect.AnnotatedElement[]) wildcardClassArray0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) (byte) 100);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray9, (short) (byte) 10);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.clone(shortArray11);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray16);
        java.lang.Long[] longArray18 = org.apache.commons.lang3.ArrayUtils.toObject(longArray16);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray18, (long) (byte) -1);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(longArray20, 10L);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (-1L), 0, (double) (-1));
        double[] doubleArray19 = new double[] {};
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.add(doubleArray19, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray21);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray21, doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray25);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray27, (double) (byte) 10, 1, 0.0d);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray27);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) '4', (double) 1);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 2, (double) (short) 100);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray41 = org.apache.commons.lang3.ArrayUtils.add(doubleArray39, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray41);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray45 = org.apache.commons.lang3.ArrayUtils.add(doubleArray43, (double) (byte) 10);
        double[] doubleArray46 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray41, doubleArray45);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray45, (double) 3, (int) (byte) 0);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray6, doubleArray45);
        try {
            double[] doubleArray52 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray45, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int[] intArray0 = new int[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1));
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, 4, 2);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(intArray0, 2);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.clone(intArray0);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray9, (int) (byte) 1, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray9);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        java.lang.Long[] longArray9 = org.apache.commons.lang3.ArrayUtils.toObject(longArray5);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray9, 1L);
        float[] floatArray18 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray18, (float) (short) 1);
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.clone(floatArray18);
        java.lang.Float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray21);
        float[] floatArray29 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray29, (float) (short) 1);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.clone(floatArray29);
        java.lang.Float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray32);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray22, (java.lang.Object[]) floatArray33);
        float[] floatArray35 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray22);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) longArray9, (java.lang.Object) floatArray22);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray0);
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) 10);
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray0, 6, 0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(shortArray6);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.lang3.ArrayUtils arrayUtils0 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils1 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils2 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils3 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray4 = new org.apache.commons.lang3.ArrayUtils[] { arrayUtils0, arrayUtils1, arrayUtils2, arrayUtils3 };
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray7 = org.apache.commons.lang3.ArrayUtils.subarray(arrayUtilsArray4, (int) '4', 0);
        org.apache.commons.lang3.ArrayUtils arrayUtils9 = new org.apache.commons.lang3.ArrayUtils();
        try {
            org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray10 = org.apache.commons.lang3.ArrayUtils.add(arrayUtilsArray4, 100, arrayUtils9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(arrayUtilsArray4);
        org.junit.Assert.assertNotNull(arrayUtilsArray7);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        int[] intArray0 = null;
        int[] intArray3 = org.apache.commons.lang3.ArrayUtils.add(intArray0, (int) (byte) 0, (int) (short) 0);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray0, 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.add(floatArray7, (float) 5);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray7);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray4);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray4, (short) (byte) 100, (int) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray28 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray28, 100L, (int) '4');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray28, (long) (byte) 10);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray21, (java.lang.Object) longArray33);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray33, (int) (byte) 10, (int) (byte) 0);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.add(longArray37, (long) (byte) 1);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) 100, 100);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray37);
        java.lang.Long[] longArray46 = org.apache.commons.lang3.ArrayUtils.toObject(longArray45);
        java.lang.String str47 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) longArray46);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "{}" + "'", str47.equals("{}"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray28 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray28, 100L, (int) '4');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray28, (long) (byte) 10);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray21, (java.lang.Object) longArray33);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray33, (int) (byte) 10, (int) (byte) 0);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.add(longArray37, (long) (byte) 1);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) 100, 100);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray37);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray45);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray45);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray45, (long) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1, (byte) -1);
        boolean[] booleanArray11 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray11);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray12, true);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean[] booleanArray22 = new boolean[] {};
        boolean[] booleanArray27 = new boolean[] { true, false, false, true };
        boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray22, booleanArray27);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray21, booleanArray27);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray21);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray1, (java.lang.Object) booleanArray21);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.remove(intArray5, (int) (short) 0);
        int[] intArray17 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 1);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray17, (int) ' ', (int) (short) 100);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.add(intArray17, 1, (int) 'a');
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray25);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.subarray(intArray25, (int) (short) 100, 4);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray29, (int) (byte) 10);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.add(intArray29, 5);
        try {
            int[] intArray36 = org.apache.commons.lang3.ArrayUtils.add(intArray29, (int) '#', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        try {
            double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray25, (int) (short) -1);
        java.lang.Integer[] intArray28 = org.apache.commons.lang3.ArrayUtils.toObject(intArray25);
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray28, (int) (short) 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0);
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray2);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray10.getClass();
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10, (long) (byte) 100);
        long[] longArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray13, (long) (-1));
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 0);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray17 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray17, 100L, (int) '4');
        long[] longArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray17, (long) (byte) 10);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray10, (java.lang.Object) longArray22);
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.subarray(longArray22, (int) (byte) 10, (int) (byte) 0);
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.add(longArray26, (long) (byte) 1);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray26, (long) '4');
        java.lang.Short[] shortArray31 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray38 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray38, 100L, (int) '4');
        long[] longArray43 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray38, (long) (byte) 10);
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray31, (java.lang.Object) longArray43);
        long[] longArray47 = org.apache.commons.lang3.ArrayUtils.subarray(longArray43, (int) (byte) 10, (int) (byte) 0);
        long[] longArray49 = org.apache.commons.lang3.ArrayUtils.add(longArray47, (long) (byte) 1);
        int int51 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray47, (long) '4');
        int int54 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray47, (long) 100, 100);
        long[] longArray55 = org.apache.commons.lang3.ArrayUtils.addAll(longArray26, longArray47);
        long[] longArray56 = org.apache.commons.lang3.ArrayUtils.addAll(longArray9, longArray55);
        boolean boolean57 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray9);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertNotNull(longArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(longArray47);
        org.junit.Assert.assertNotNull(longArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(longArray55);
        org.junit.Assert.assertNotNull(longArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray24 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray24);
        short[] shortArray26 = new short[] {};
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray25, shortArray26);
        short[] shortArray28 = org.apache.commons.lang3.ArrayUtils.clone(shortArray26);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.add(shortArray28, (short) 1);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) '4', (java.lang.Object) shortArray30);
        short[] shortArray34 = org.apache.commons.lang3.ArrayUtils.add(shortArray30, (int) (byte) 1, (short) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray25);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shortArray34);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        boolean[] booleanArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray0, true, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) 10L);
        java.lang.Float[] floatArray17 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray17);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray17);
        float[] floatArray26 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray26, (float) (short) 1);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.add(floatArray28, 0.0f);
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray30, 100, (int) (short) 100);
        float[] floatArray38 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray38, (int) (byte) 100, (int) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray38, (float) ' ', (int) 'a');
        float[] floatArray46 = org.apache.commons.lang3.ArrayUtils.add(floatArray38, (float) (short) 100);
        float[] floatArray47 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray30, floatArray46);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray19, floatArray30);
        float[] floatArray49 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray11, floatArray19);
        float[] floatArray51 = org.apache.commons.lang3.ArrayUtils.add(floatArray11, (float) 4);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray51);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray51);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        short[] shortArray6 = new short[] { (byte) 100, (byte) -1, (byte) 100, (short) -1, (short) 100, (short) 0 };
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) 3, 0);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) -1, (double) (-1L));
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 100L, 6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0, (short) (byte) 1);
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.add(shortArray2, (short) (byte) -1);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.contains(shortArray2, (short) 100);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        short[] shortArray1 = new short[] { (byte) 100 };
        java.lang.Short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray1);
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray2);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray2, 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray2, (double) (short) -1);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray14, (double) 10L);
        java.lang.Double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray14);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray19);
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray21, (double) 0.0f, (int) (byte) -1, (double) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray2, 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, 0.0d, 3);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 0);
        java.lang.Short[] shortArray15 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray15);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray16, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray16);
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.add(shortArray16, (short) 0);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray16);
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray11, shortArray16);
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.add(shortArray11, (short) -1);
        short[] shortArray27 = org.apache.commons.lang3.ArrayUtils.clone(shortArray26);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertNotNull(shortArray27);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = new byte[] {};
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray2, byteArray7);
        byte[] byteArray11 = new byte[] {};
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        byte[] byteArray13 = new byte[] {};
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        java.lang.Byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray15);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray12, byteArray17);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray12, (byte) -1);
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray12, (int) (byte) 0, (int) (short) 1);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray10, byteArray12);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 10.0f);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31, 2);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray25, intArray33);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.contains(intArray33, (int) '4');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(byteArray9, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (short) 10, (int) '4');
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (double) (short) 1);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, (double) (byte) 100);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        float[] floatArray0 = null;
        java.lang.Float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray0);
        org.junit.Assert.assertNull(floatArray1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray1, (byte) -1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray1, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray1, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray14);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.Byte[] byteArray0 = new java.lang.Byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) 10, 0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        try {
            byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.add(byteArray4, (int) (byte) 100, (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        long[] longArray0 = null;
        long[] longArray2 = org.apache.commons.lang3.ArrayUtils.add(longArray0, (long) 3);
        org.junit.Assert.assertNotNull(longArray2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray0, (int) (byte) 0, (int) (short) 100);
        org.junit.Assert.assertNull(booleanArray3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray4, (byte) -1);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray20);
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray20, 4, (int) (short) -1);
        try {
            boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray24, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray24);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, true);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, 3, (int) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, false);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, true, 0);
        boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, 100, (int) (short) 10);
        java.lang.Boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray19);
        try {
            boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray19, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray20);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.remove(intArray5, (int) (short) 0);
        int[] intArray17 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 1);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray17, (int) ' ', (int) (short) 100);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.add(intArray17, 1, (int) 'a');
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray25);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.subarray(intArray25, (int) (short) 100, 4);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray29, (int) (byte) 10);
        int[] intArray37 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray37, 1);
        int int42 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray37, (int) ' ', (int) (short) 100);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray37);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.contains(intArray37, 3);
        int[] intArray46 = org.apache.commons.lang3.ArrayUtils.addAll(intArray29, intArray37);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(intArray46);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        char[] charArray5 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#');
        char[] charArray8 = new char[] {};
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray5, charArray8);
        java.lang.Character[] charArray13 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray13);
        char[] charArray20 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray20, '#');
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.addAll(charArray14, charArray20);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        char[] charArray27 = org.apache.commons.lang3.ArrayUtils.subarray(charArray14, 6, (int) (byte) -1);
        try {
            char[] charArray30 = org.apache.commons.lang3.ArrayUtils.add(charArray27, (int) '#', '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(charArray27);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray3, (byte) 1, (int) (byte) 0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { (-1), (-1), 10 };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray10 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 1);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray10, (int) ' ', (int) (short) 100);
        int[] intArray21 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray21, 1);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.addAll(intArray21, intArray24);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray25);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray25, (int) (byte) 0);
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray25, 1);
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.add(intArray30, (int) '4');
        java.lang.Integer[] intArray36 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray38 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray36, 2);
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.addAll(intArray30, intArray38);
        int[] intArray41 = org.apache.commons.lang3.ArrayUtils.add(intArray38, (int) 'a');
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray38, (int) (short) 1, (int) (short) 10);
        int[] intArray47 = org.apache.commons.lang3.ArrayUtils.subarray(intArray38, (int) '4', (int) (short) 0);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray38);
        try {
            int[] intArray50 = org.apache.commons.lang3.ArrayUtils.remove(intArray48, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY;
        float[] floatArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0, (float) (short) -1);
        float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        byte[] byteArray4 = new byte[] {};
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        java.lang.Byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray6);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray7);
        int[] intArray15 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray15, 1);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) byteArray7, (java.lang.Object) int17);
        short[] shortArray23 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray23);
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray24, (short) 0);
        boolean[] booleanArray27 = new boolean[] {};
        boolean[] booleanArray32 = new boolean[] { true, false, false, true };
        boolean[] booleanArray33 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray27, booleanArray32);
        boolean[] booleanArray34 = new boolean[] {};
        boolean[] booleanArray39 = new boolean[] { true, false, false, true };
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray34, booleanArray39);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray33, booleanArray39);
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray33, true, 1);
        boolean[] booleanArray50 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray51 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray50);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray33, booleanArray50);
        int int53 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray24, (java.lang.Object) boolean52);
        byte[] byteArray56 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray57 = new byte[][] { byteArray56 };
        byte[][] byteArray58 = org.apache.commons.lang3.ArrayUtils.clone(byteArray57);
        boolean boolean59 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray24, (java.lang.Object) byteArray58);
        java.lang.Object obj60 = null;
        int int62 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray58, obj60, 2);
        int int63 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray7, obj60);
        int int65 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray0, (java.lang.Object) byteArray7, (int) (byte) 0);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(booleanArray50);
        org.junit.Assert.assertNotNull(booleanArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertNotNull(byteArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 4);
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray9);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10, (long) '#');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray6);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (int) ' ', (int) (short) 100);
        byte[] byteArray14 = new byte[] {};
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray16);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.clone(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray16);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(byteArray19, (byte) -1);
        byte[] byteArray22 = new byte[] {};
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.clone(byteArray22);
        byte[] byteArray24 = new byte[] {};
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.clone(byteArray24);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.clone(byteArray24);
        java.lang.Byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray26);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.clone(byteArray26);
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray23, byteArray28);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray28, (byte) 0, (int) (short) 100);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray19, byteArray28);
        byte[] byteArray36 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray19, (int) (short) 100, 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(byteArray36);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, '4', 0);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray0, (int) (byte) 0, 1);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray3, 5, 10);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray21 = new boolean[] {};
        boolean[] booleanArray26 = new boolean[] { true, false, false, true };
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray21, booleanArray26);
        boolean[] booleanArray28 = new boolean[] {};
        boolean[] booleanArray33 = new boolean[] { true, false, false, true };
        boolean[] booleanArray34 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray28, booleanArray33);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray27, booleanArray33);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray27, true);
        boolean[] booleanArray39 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray27, true);
        java.lang.Boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray39);
        boolean[] booleanArray41 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray20, booleanArray39);
        boolean[] booleanArray43 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray39, true);
        boolean[] booleanArray49 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray50 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray49);
        boolean[] booleanArray52 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray50, true);
        boolean[] booleanArray53 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray52);
        boolean boolean54 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray43, booleanArray52);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertNotNull(booleanArray41);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray49);
        org.junit.Assert.assertNotNull(booleanArray50);
        org.junit.Assert.assertNotNull(booleanArray52);
        org.junit.Assert.assertNotNull(booleanArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray2, 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray2, (double) (short) -1);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) 100.0f, (int) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray4);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) 0);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (short) 100);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray12);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) (byte) 100);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray12, 0L);
        try {
            long[] longArray23 = org.apache.commons.lang3.ArrayUtils.add(longArray12, (int) (short) 100, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        char[] charArray5 = new char[] { '4', '4', 'a', 'a', '4' };
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.add(charArray5, '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray7, 'a');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.remove(intArray5, (int) (short) 0);
        int[] intArray17 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 1);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray17, (int) ' ', (int) (short) 100);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.add(intArray17, 1, (int) 'a');
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray25);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.subarray(intArray25, (int) (short) 100, 4);
        try {
            int[] intArray31 = org.apache.commons.lang3.ArrayUtils.remove(intArray29, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Object obj0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray6, (int) ' ', (int) (short) 100);
        int[] intArray17 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 1);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.addAll(intArray17, intArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray6, intArray21);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray21, (int) (byte) 0);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray21, 1);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.add(intArray26, (int) '4');
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.remove(intArray26, 0);
        int[] intArray31 = org.apache.commons.lang3.ArrayUtils.clone(intArray30);
        java.lang.Integer[] intArray32 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray32);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray30, intArray33);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isEquals(obj0, (java.lang.Object) intArray30);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 100L);
        java.lang.Class<?> wildcardClass13 = floatArray8.getClass();
        java.lang.Float[] floatArray19 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray20, 1.0f);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray8, floatArray20);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.remove(floatArray20, (int) (short) 0);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.remove(floatArray20, 4);
        try {
            float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.remove(floatArray20, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        int[] intArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0, true);
        boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0, false);
        java.lang.Byte[] byteArray12 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray12);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray12, (byte) 10);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) booleanArray0, (java.lang.Object) byteArray15);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (short) 10, (int) '4');
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        try {
            double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.add(doubleArray17, (int) (short) 100, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { (-1), 1 };
        int[] intArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray3, (int) '#', (int) (short) 10);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        float[] floatArray0 = null;
        java.lang.Float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY;
        float[] floatArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray1);
        java.lang.Character[] charArray6 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6);
        char[] charArray13 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray13, '#');
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.addAll(charArray7, charArray13);
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.add(charArray16, '4');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.subarray(charArray18, (int) (byte) 1, 4);
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.subarray(charArray21, 2, (int) (byte) 0);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) floatArray1, (java.lang.Object) 2);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray1, (float) (short) 100);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray0, floatArray27);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 0);
        int int10 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) longArray7);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray7, (long) (byte) 1);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray12);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray12, false);
        boolean[] booleanArray18 = null;
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray12, booleanArray18);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.add(longArray12, 2, (long) (byte) 1);
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.remove(longArray24, (int) (short) 0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray26);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray22 = org.apache.commons.lang3.ArrayUtils.add(doubleArray20, (double) (byte) 10);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray18, doubleArray22);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray18);
        java.lang.Double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray18);
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.add(booleanArray18, false);
        java.lang.Boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray22);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray2, (byte) 1, (int) '4');
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(byteArray2, (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray2);
        byte[] byteArray9 = new byte[] {};
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray11 = new byte[] {};
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        java.lang.Byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray13);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray10, byteArray15);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.add(byteArray16, (byte) 1);
        java.lang.Byte[] byteArray20 = new java.lang.Byte[] {};
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray16, byteArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray2, byteArray21);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0, (int) (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray6, (byte) -1);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray6, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray15);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        long[] longArray18 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray18, 100L, (int) '4');
        java.lang.Long[] longArray22 = org.apache.commons.lang3.ArrayUtils.toObject(longArray18);
        java.lang.Class<?> wildcardClass23 = longArray22.getClass();
        java.lang.Class<?>[] wildcardClassArray24 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray28 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray28);
        short[] shortArray30 = new short[] {};
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray29, shortArray30);
        java.lang.Short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray29);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray29, (short) -1);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray24, (java.lang.Object) (short) -1);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) longArray22, (java.lang.Object[]) wildcardClassArray24);
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray37 = org.apache.commons.lang3.ArrayUtils.addAll((java.lang.reflect.GenericDeclaration[]) wildcardClassArray0, (java.lang.reflect.GenericDeclaration[]) wildcardClassArray24);
        byte[] byteArray38 = new byte[] {};
        byte[] byteArray39 = org.apache.commons.lang3.ArrayUtils.clone(byteArray38);
        byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.clone(byteArray38);
        java.lang.Byte[] byteArray41 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray40);
        byte[] byteArray42 = org.apache.commons.lang3.ArrayUtils.clone(byteArray40);
        byte[] byteArray43 = new byte[] {};
        byte[] byteArray44 = org.apache.commons.lang3.ArrayUtils.clone(byteArray43);
        byte[] byteArray45 = new byte[] {};
        byte[] byteArray46 = org.apache.commons.lang3.ArrayUtils.clone(byteArray45);
        byte[] byteArray47 = org.apache.commons.lang3.ArrayUtils.clone(byteArray45);
        java.lang.Byte[] byteArray48 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray47);
        byte[] byteArray49 = org.apache.commons.lang3.ArrayUtils.clone(byteArray47);
        byte[] byteArray50 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray44, byteArray49);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.contains(byteArray50, (byte) 1);
        boolean boolean53 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray42, byteArray50);
        byte[] byteArray56 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray50, 0, (-1));
        byte[] byteArray57 = new byte[] {};
        byte[] byteArray58 = org.apache.commons.lang3.ArrayUtils.clone(byteArray57);
        boolean boolean60 = org.apache.commons.lang3.ArrayUtils.contains(byteArray57, (byte) -1);
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray56, byteArray57);
        int int63 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray57, (byte) 0);
        int int64 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClassArray24);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(genericDeclarationArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertNotNull(byteArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { (-1.0d) };
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray5);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray5, false);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.add(booleanArray11, true);
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.add(booleanArray11, true);
        boolean[] booleanArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray11, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray17);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        short[][][] shortArray0 = new short[][][] {};
        short[][][] shortArray1 = org.apache.commons.lang3.ArrayUtils.clone(shortArray0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = new byte[] {};
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        java.lang.Byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray11);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 1);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray4, byteArray12);
        byte[] byteArray16 = null;
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray4, byteArray16);
        java.lang.Byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(byteArray18);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, 10.0f);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray35 = org.apache.commons.lang3.ArrayUtils.add(doubleArray33, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray35);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray39 = org.apache.commons.lang3.ArrayUtils.add(doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray35, doubleArray39);
        double[] doubleArray41 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray39);
        int int43 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) doubleArray39, (int) (short) 100);
        java.lang.Byte[] byteArray45 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray46 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray45);
        byte[] byteArray47 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray45);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) floatArray5, (java.lang.Object) byteArray45);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray6, 1.0f);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        char[] charArray5 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#');
        char[] charArray8 = new char[] {};
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray5, charArray8);
        java.lang.Character[] charArray10 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray10);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray6);
        try {
            boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray6, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31, 2);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray25, intArray33);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray34);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, '#');
        char[] charArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray14, (long) ' ');
        java.lang.Short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray25 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray25, 100L, (int) '4');
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray25, (long) (byte) 10);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray18, (java.lang.Object) longArray30);
        long[] longArray34 = org.apache.commons.lang3.ArrayUtils.subarray(longArray30, (int) (byte) 10, (int) (byte) 0);
        long[] longArray36 = org.apache.commons.lang3.ArrayUtils.remove(longArray30, 2);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray36);
        long[] longArray38 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray36);
        java.lang.Short[] shortArray39 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray46 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int49 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray46, 100L, (int) '4');
        long[] longArray51 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray46, (long) (byte) 10);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray39, (java.lang.Object) longArray51);
        long[] longArray55 = org.apache.commons.lang3.ArrayUtils.subarray(longArray51, (int) (byte) 10, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray55);
        java.lang.Long[] longArray57 = org.apache.commons.lang3.ArrayUtils.toObject(longArray55);
        boolean boolean58 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray14, longArray55);
        boolean boolean59 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray14);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(longArray38);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertNotNull(longArray46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(longArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(longArray55);
        org.junit.Assert.assertNotNull(longArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        java.lang.Long[] longArray19 = org.apache.commons.lang3.ArrayUtils.toObject(longArray16);
        java.lang.Long[] longArray20 = org.apache.commons.lang3.ArrayUtils.toObject(longArray16);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray21, (float) 10);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray21, (float) 10L);
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.add(floatArray26, (float) 4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        java.lang.Boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray1);
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray1);
        java.lang.Boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray1);
        boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray5);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, (int) '4', 4);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray4, ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        char[] charArray14 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '#');
        char[] charArray21 = new char[] { '#', ' ', '#', '4' };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray14, charArray21);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray14);
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.add(charArray8, 3, ' ');
        java.lang.Character[] charArray27 = org.apache.commons.lang3.ArrayUtils.toObject(charArray26);
        char[] charArray29 = org.apache.commons.lang3.ArrayUtils.remove(charArray26, 1);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray29);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.clone(intArray20);
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 1, 4, 1, 3 };
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31, (int) (short) 1);
        int[] intArray40 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray40, 1);
        int int45 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray40, (int) ' ', (int) (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray40);
        boolean boolean47 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray34, intArray40);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray20, intArray34);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 0, 100);
        try {
            byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.add(byteArray7, (int) (byte) 1, (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray7);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray9);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray10, (short) -1);
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { (-1), (-1), 10 };
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray16);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) shortArray10, (java.lang.Object[]) intArray16);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray16);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        boolean[] booleanArray3 = new boolean[] {};
        boolean[] booleanArray8 = new boolean[] { true, false, false, true };
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray3, booleanArray8);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray8, true);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray8, 3, (int) (short) 10);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray14, false);
        boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray14, (int) (short) 1, (int) (short) -1);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) (short) 1, 0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }
}

