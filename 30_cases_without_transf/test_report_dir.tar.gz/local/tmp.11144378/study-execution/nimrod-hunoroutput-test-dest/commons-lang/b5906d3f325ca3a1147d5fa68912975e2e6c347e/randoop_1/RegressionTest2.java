import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.Character[] charArray1 = new java.lang.Character[] { '#' };
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray1);
        char[] charArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        float[] floatArray11 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray11, (float) (short) 1);
        float[] floatArray14 = org.apache.commons.lang3.ArrayUtils.clone(floatArray11);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray2, (java.lang.Object) floatArray11);
        java.lang.Float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray11);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray11, (float) 100, (int) (byte) 1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray7, (short) 100);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray7, (short) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray13);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        java.lang.Short[] shortArray5 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray7 = new short[] {};
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray7);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray7);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 1);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray9);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray12, 10, 100);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray12, (short) -1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray12, (short) (byte) -1, (int) (short) -1);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31, 2);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray25, intArray33);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.add(intArray33, (int) 'a');
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray33, (int) (short) 1, (int) (short) 10);
        int[] intArray42 = org.apache.commons.lang3.ArrayUtils.subarray(intArray33, (int) '4', (int) (short) 0);
        int int45 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray33, 3, 3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String[] strArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray0, (java.lang.Object) intArray10);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray10, (int) (short) 0);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.subarray(intArray13, (int) (byte) 100, (int) '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray16, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNull(strArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        java.lang.Short[] shortArray5 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray7 = new short[] {};
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray7);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray7);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 1);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray9);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        try {
            short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.remove(shortArray0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 2);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 10, (int) (byte) 1);
        java.lang.Double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray2);
        java.util.Map<java.lang.Object, java.lang.Object> objMap7 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) doubleArray6);
        java.util.Map[] mapArray9 = new java.util.Map[1];
        @SuppressWarnings("unchecked") java.util.Map<java.lang.Object, java.lang.Object>[] objMapArray10 = (java.util.Map<java.lang.Object, java.lang.Object>[]) mapArray9;
        objMapArray10[0] = objMap7;
        java.util.Map<java.lang.Object, java.lang.Object>[] objMapArray13 = org.apache.commons.lang3.ArrayUtils.clone(objMapArray10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objMap7);
        org.junit.Assert.assertNotNull(mapArray9);
        org.junit.Assert.assertNotNull(objMapArray10);
        org.junit.Assert.assertNotNull(objMapArray13);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, (int) (short) -1, 2);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray15, 'a', (int) ' ');
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray15, 'a');
        char[] charArray26 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray26, '#');
        char[] charArray29 = new char[] {};
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray26, charArray29);
        char[] charArray31 = org.apache.commons.lang3.ArrayUtils.addAll(charArray20, charArray26);
        int int33 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray31, ' ');
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray31, ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 13 + "'", int35 == 13);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) '4');
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray13, (int) (byte) 0);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray13, (int) (short) -1, 6);
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray18, (int) (short) 100, (-1));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.CharSequence[] charSequenceArray2 = new java.lang.CharSequence[] { "{10.0}", "{false,true,true,false,false}" };
        java.lang.CharSequence[] charSequenceArray5 = new java.lang.CharSequence[] { "{10.0}", "{false,true,true,false,false}" };
        java.lang.CharSequence[][] charSequenceArray6 = new java.lang.CharSequence[][] { charSequenceArray2, charSequenceArray5 };
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(charSequenceArray6);
        org.junit.Assert.assertNotNull(charSequenceArray2);
        org.junit.Assert.assertNotNull(charSequenceArray5);
        org.junit.Assert.assertNotNull(charSequenceArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.clone(intArray4);
        int[] intArray11 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray11, 1);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.addAll(intArray11, intArray14);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray11, (int) '4');
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.add(intArray11, 1, 0);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray11);
        int[] intArray27 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray27, 1);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray27, (int) ' ', (int) (short) 100);
        int[] intArray38 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int40 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray38, 1);
        int[] intArray41 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray42 = org.apache.commons.lang3.ArrayUtils.addAll(intArray38, intArray41);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray27, intArray42);
        int int45 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray42, (int) (byte) 0);
        int[] intArray47 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray42, 1);
        int[] intArray49 = org.apache.commons.lang3.ArrayUtils.add(intArray47, (int) '4');
        java.lang.Integer[] intArray53 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray55 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray53, 2);
        int[] intArray56 = org.apache.commons.lang3.ArrayUtils.addAll(intArray47, intArray55);
        int[] intArray58 = org.apache.commons.lang3.ArrayUtils.add(intArray55, (int) 'a');
        int int60 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray55, 0);
        int[] intArray63 = org.apache.commons.lang3.ArrayUtils.add(intArray55, 0, 7);
        int[] intArray64 = org.apache.commons.lang3.ArrayUtils.addAll(intArray21, intArray63);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray64);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 0);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (short) 10, (-1.0d));
        java.lang.Double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray9, (double) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) (short) 0);
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) 100.0f, 7, (double) 10L);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 'a');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        boolean[] booleanArray6 = new boolean[] { true, false, true, true, true, false };
        boolean[] booleanArray13 = new boolean[] { true, false, true, true, true, false };
        boolean[] booleanArray20 = new boolean[] { true, false, true, true, true, false };
        boolean[] booleanArray27 = new boolean[] { true, false, true, true, true, false };
        boolean[] booleanArray34 = new boolean[] { true, false, true, true, true, false };
        boolean[] booleanArray41 = new boolean[] { true, false, true, true, true, false };
        boolean[][] booleanArray42 = new boolean[][] { booleanArray6, booleanArray13, booleanArray20, booleanArray27, booleanArray34, booleanArray41 };
        boolean[][][] booleanArray43 = new boolean[][][] { booleanArray42 };
        boolean[] booleanArray49 = new boolean[] { false, false, false, false };
        boolean[][] booleanArray50 = new boolean[][] { booleanArray49 };
        boolean[][] booleanArray51 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray50);
        boolean[][][] booleanArray52 = org.apache.commons.lang3.ArrayUtils.add(booleanArray43, (int) (short) 0, booleanArray50);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertNotNull(booleanArray41);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray49);
        org.junit.Assert.assertNotNull(booleanArray50);
        org.junit.Assert.assertNotNull(booleanArray51);
        org.junit.Assert.assertNotNull(booleanArray52);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0, true);
        boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0, false);
        try {
            boolean[] booleanArray7 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray5, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray5);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        float[][][] floatArray0 = new float[][][] {};
        float[][][][] floatArray1 = new float[][][][] { floatArray0 };
        float[] floatArray6 = new float[] { 'a', '#', 3, 6 };
        float[] floatArray11 = new float[] { 'a', '#', 3, 6 };
        float[] floatArray16 = new float[] { 'a', '#', 3, 6 };
        float[][] floatArray17 = new float[][] { floatArray6, floatArray11, floatArray16 };
        float[] floatArray22 = new float[] { 'a', '#', 3, 6 };
        float[] floatArray27 = new float[] { 'a', '#', 3, 6 };
        float[] floatArray32 = new float[] { 'a', '#', 3, 6 };
        float[][] floatArray33 = new float[][] { floatArray22, floatArray27, floatArray32 };
        float[][][] floatArray34 = new float[][][] { floatArray17, floatArray33 };
        java.lang.Class<?>[] wildcardClassArray35 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray39 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray40 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray39);
        short[] shortArray41 = new short[] {};
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray40, shortArray41);
        java.lang.Short[] shortArray43 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray40);
        int int45 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray40, (short) -1);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray35, (java.lang.Object) (short) -1);
        float[] floatArray53 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray55 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray53, (float) (short) 1);
        float[] floatArray58 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray55, (int) '#', (int) ' ');
        float[] floatArray65 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray67 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray65, (float) (short) 1);
        float[] floatArray68 = org.apache.commons.lang3.ArrayUtils.clone(floatArray65);
        java.lang.Float[] floatArray69 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray68);
        float[] floatArray76 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray78 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray76, (float) (short) 1);
        float[] floatArray79 = org.apache.commons.lang3.ArrayUtils.clone(floatArray76);
        java.lang.Float[] floatArray80 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray79);
        boolean boolean81 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray69, (java.lang.Object[]) floatArray80);
        float[] floatArray83 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray69, (float) (byte) 0);
        boolean boolean84 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray55, floatArray83);
        boolean boolean85 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) boolean46, (java.lang.Object) floatArray55);
        float[][][] floatArray86 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray34, (java.lang.Object) boolean85);
        float[] floatArray89 = new float[] { 1 };
        float[] floatArray91 = new float[] { 1 };
        float[][] floatArray92 = new float[][] { floatArray89, floatArray91 };
        float[][][] floatArray93 = org.apache.commons.lang3.ArrayUtils.add(floatArray34, 2, floatArray92);
        float[][][][] floatArray94 = org.apache.commons.lang3.ArrayUtils.add(floatArray1, floatArray93);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(wildcardClassArray35);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertNotNull(shortArray40);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(shortArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertNotNull(floatArray76);
        org.junit.Assert.assertNotNull(floatArray78);
        org.junit.Assert.assertNotNull(floatArray79);
        org.junit.Assert.assertNotNull(floatArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(floatArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(floatArray86);
        org.junit.Assert.assertNotNull(floatArray89);
        org.junit.Assert.assertNotNull(floatArray91);
        org.junit.Assert.assertNotNull(floatArray92);
        org.junit.Assert.assertNotNull(floatArray93);
        org.junit.Assert.assertNotNull(floatArray94);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.remove(intArray5, (int) (short) 0);
        int[] intArray17 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 1);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray17, (int) ' ', (int) (short) 100);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.add(intArray17, 1, (int) 'a');
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray25);
        try {
            int[] intArray29 = org.apache.commons.lang3.ArrayUtils.add(intArray5, (int) (byte) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        java.lang.Class<?> wildcardClass11 = longArray10.getClass();
        java.lang.Class<?>[] wildcardClassArray12 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16);
        short[] shortArray18 = new short[] {};
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray18);
        java.lang.Short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray17);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) -1);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray12, (java.lang.Object) (short) -1);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) longArray10, (java.lang.Object[]) wildcardClassArray12);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10);
        try {
            long[] longArray27 = org.apache.commons.lang3.ArrayUtils.remove(longArray25, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClassArray12);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(longArray25);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray18);
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.add(booleanArray18, false);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray21, true, (int) '#');
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 100.0f, (double) 1.0f);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) '4', (double) 4);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray12, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray14, doubleArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) 1, (double) (byte) 0);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray18, doubleArray25);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) (-1.0f));
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray18);
        double[] doubleArray31 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray18);
        int int35 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray18, 0.0d, (int) (short) 1, (double) 5);
        double[] doubleArray37 = org.apache.commons.lang3.ArrayUtils.add(doubleArray18, (double) 100L);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, '#');
        java.lang.Class<?> wildcardClass3 = charArray0.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[] byteArray13 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[] byteArray20 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 100, (byte) -1, (byte) 1, (byte) 1 };
        java.lang.Byte[][] byteArray21 = new java.lang.Byte[][] { byteArray6, byteArray13, byteArray20 };
        java.lang.Byte[][] byteArray23 = org.apache.commons.lang3.ArrayUtils.remove(byteArray21, 0);
        java.lang.Object[] objArray24 = null;
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) byteArray21, objArray24);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray2, 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) '#');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 10.0f, 100, (double) (byte) -1);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.add(doubleArray17, (double) (byte) 10);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray19, (double) (short) 100, (int) '#');
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray6, doubleArray19);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray19, (double) 100.0f, (int) '4', (double) 7);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray19, (double) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) 3, 0);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) -1, (double) (-1L));
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (-1.0f), 13);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, false);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, false);
        boolean[] booleanArray16 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray17 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray16);
        boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray17, true);
        boolean[] booleanArray20 = new boolean[] {};
        boolean[] booleanArray25 = new boolean[] { true, false, false, true };
        boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray20, booleanArray25);
        boolean[] booleanArray27 = new boolean[] {};
        boolean[] booleanArray32 = new boolean[] { true, false, false, true };
        boolean[] booleanArray33 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray27, booleanArray32);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray26, booleanArray32);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray19, booleanArray26);
        boolean[] booleanArray36 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray26);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(booleanArray36);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray2, 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray2, (double) (short) -1);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray13, 1.0d, 7);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        java.lang.Boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray1);
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray1);
        java.lang.Boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray3);
        java.lang.Boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) longArray15, (java.lang.Object) doubleArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, 1.0d);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray18);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { (-1), (-1), 10 };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.subarray(intArray4, (int) (byte) 0, (int) (byte) -1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 10, (int) (short) 10);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 100);
        try {
            byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.remove(byteArray6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) '#', (int) (short) 10);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray6, (long) 4);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 0);
        double[] doubleArray6 = new double[] {};
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray8);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray8, doubleArray12);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray12);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray14, (double) (byte) 0);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray14);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.add(doubleArray18, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray20);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.add(doubleArray22, (double) (byte) 10);
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray20, doubleArray24);
        double[] doubleArray28 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray20, 0, 0);
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray28, (double) (-1), (int) (short) 1);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray28);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray14, doubleArray28);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray28);
        double[] doubleArray37 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray28, 2, (int) '4');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        boolean[] booleanArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray0, true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.clone(shortArray3);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        java.lang.Short[] shortArray7 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.add(shortArray8, (short) 0);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray8);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 100);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray17, (short) (byte) -1);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray17, (short) 0, (int) (short) 10);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 2);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 10, (int) (byte) 1);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 100.0d);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray7, (double) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, (int) (byte) 10);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, (int) (byte) 1, (int) '4');
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 1, 4, 1, 3 };
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, (int) (short) 1);
        java.lang.Integer[] intArray18 = org.apache.commons.lang3.ArrayUtils.toObject(intArray17);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray17);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray4);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray10);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        float[] floatArray18 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, (int) (byte) 100, (int) '4');
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray9, floatArray18);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains(floatArray22, (float) 100);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray21, (float) 13);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        char[] charArray5 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#');
        char[] charArray12 = new char[] { '#', ' ', '#', '4' };
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray5, charArray12);
        char[] charArray18 = new char[] { 'a', ' ', '4', '#' };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray18, 'a');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray18, '4');
        char[] charArray28 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int30 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray28, '#');
        char[] charArray35 = new char[] { '#', ' ', '#', '4' };
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray28, charArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray22, charArray28);
        char[] charArray38 = org.apache.commons.lang3.ArrayUtils.addAll(charArray12, charArray22);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(charArray38);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray9);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray10, (short) -1);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray12, 3, 1);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray15);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) (byte) 100);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray32, 0.0f);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (int) ' ', (int) (short) 100);
        byte[] byteArray14 = new byte[] {};
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray16);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.clone(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray16);
        byte[] byteArray20 = new byte[] {};
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.clone(byteArray20);
        byte[] byteArray22 = new byte[] {};
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.clone(byteArray22);
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.clone(byteArray22);
        java.lang.Byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray24);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.clone(byteArray24);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray21, byteArray26);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray26, (byte) 10, (int) (short) 10);
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray26, (byte) 0, 2);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray26);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray26);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray26, (byte) 100, 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31, 2);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray25, intArray33);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.add(intArray33, (int) 'a');
        int int38 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray33, 0);
        try {
            int[] intArray40 = org.apache.commons.lang3.ArrayUtils.remove(intArray33, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, (double) 0.0f);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray0);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) ' ');
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray8, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.Byte[] byteArray0 = null;
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0, (byte) 1);
        org.junit.Assert.assertNull(byteArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray12, true);
        boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray12, 1, 10);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(booleanArray19);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double[] doubleArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 'a', (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray23, true);
        boolean[] booleanArray29 = org.apache.commons.lang3.ArrayUtils.add(booleanArray27, true);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray29);
        boolean[] booleanArray33 = org.apache.commons.lang3.ArrayUtils.add(booleanArray29, 0, true);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(booleanArray33);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, 1.0d, (double) 10.0f);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        char[] charArray5 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#');
        char[] charArray8 = new char[] {};
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray5, charArray8);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray8);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1, 4, 1, 3 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) (byte) 1, (int) (short) 10);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double[] doubleArray0 = new double[] {};
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (-1.0f), (double) 1L);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 0);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (short) 10, (-1.0d));
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (short) 0);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray10, (double) '#');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, true);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, 3, (int) (short) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray11, false);
        boolean[] booleanArray16 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray11, (int) (short) 1, (int) (short) -1);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray16, true);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray18, false);
        try {
            boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray20, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.remove(longArray12, 2);
        long[] longArray24 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.add(longArray24, (long) '4');
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.add(longArray26, (long) 0);
        int int29 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) longArray26);
        long[] longArray35 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.add(longArray35, (long) '4');
        long[] longArray38 = org.apache.commons.lang3.ArrayUtils.clone(longArray35);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.clone(longArray35);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.contains(longArray35, (long) 3);
        long[] longArray42 = org.apache.commons.lang3.ArrayUtils.clone(longArray35);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray26, longArray42);
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray12, longArray26);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(longArray35);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray38);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(longArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, false);
        java.lang.Boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray9);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray10, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.Character[] charArray5 = new java.lang.Character[] { ' ', ' ', ' ', 'a', ' ' };
        java.lang.Character[] charArray11 = new java.lang.Character[] { ' ', ' ', ' ', 'a', ' ' };
        java.lang.Character[][] charArray12 = new java.lang.Character[][] { charArray5, charArray11 };
        java.lang.Character[] charArray18 = new java.lang.Character[] { '#', ' ', 'a', '#', ' ' };
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray18);
        java.lang.Character[][] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray12, charArray18);
        int[] intArray26 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray26, 1);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray26, (int) ' ', (int) (short) 100);
        int[] intArray37 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray37, 1);
        int[] intArray40 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray41 = org.apache.commons.lang3.ArrayUtils.addAll(intArray37, intArray40);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray26, intArray41);
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray41, (int) (byte) 0);
        int[] intArray46 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray41, 1);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.add(intArray46, (int) '4');
        int[] intArray50 = org.apache.commons.lang3.ArrayUtils.remove(intArray46, 0);
        int[] intArray51 = org.apache.commons.lang3.ArrayUtils.clone(intArray50);
        java.lang.Integer[] intArray52 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        int[] intArray53 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray52);
        boolean boolean54 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray50, intArray53);
        java.lang.Character[][] charArray55 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray20, (java.lang.Object) intArray53);
        try {
            java.lang.Character[][] charArray57 = org.apache.commons.lang3.ArrayUtils.remove(charArray55, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(charArray55);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray3, (short) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        boolean[] booleanArray21 = new boolean[] {};
        boolean[] booleanArray26 = new boolean[] { true, false, false, true };
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray21, booleanArray26);
        boolean[] booleanArray28 = new boolean[] {};
        boolean[] booleanArray33 = new boolean[] { true, false, false, true };
        boolean[] booleanArray34 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray28, booleanArray33);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray27, booleanArray33);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray27, true);
        boolean[] booleanArray39 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray27, true);
        java.lang.Boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray39);
        boolean[] booleanArray41 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray20, booleanArray39);
        java.lang.Boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertNotNull(booleanArray41);
        org.junit.Assert.assertNotNull(booleanArray42);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray5);
        java.lang.String str7 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray6, (int) (byte) 0, 3);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{}" + "'", str7.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray0, (byte) 10);
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31, 2);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray25, intArray33);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.add(intArray33, (int) 'a');
        java.lang.String[] strArray41 = new java.lang.String[] { "hi!", "hi!", "1", "1" };
        java.lang.Comparable<java.lang.String>[] strComparableArray44 = org.apache.commons.lang3.ArrayUtils.subarray((java.lang.Comparable<java.lang.String>[]) strArray41, 10, (int) (short) -1);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) intArray36, (java.lang.Object) 10);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(strComparableArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { (-1), (-1), 10 };
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14);
        int[] intArray21 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray21, 1);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray21, (int) ' ', (int) (short) 100);
        int[] intArray32 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray32, 1);
        int[] intArray35 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.addAll(intArray32, intArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray21, intArray36);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray36, (int) (byte) 0);
        int[] intArray41 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray36, 1);
        int[] intArray43 = org.apache.commons.lang3.ArrayUtils.add(intArray41, (int) '4');
        java.lang.Integer[] intArray47 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray49 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray47, 2);
        int[] intArray50 = org.apache.commons.lang3.ArrayUtils.addAll(intArray41, intArray49);
        int[] intArray52 = org.apache.commons.lang3.ArrayUtils.add(intArray49, (int) 'a');
        int int55 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray49, (int) (short) 1, (int) (short) 10);
        int[] intArray58 = org.apache.commons.lang3.ArrayUtils.subarray(intArray49, (int) '4', (int) (short) 0);
        int[] intArray59 = org.apache.commons.lang3.ArrayUtils.addAll(intArray15, intArray49);
        boolean boolean60 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray49);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        java.lang.Character[] charArray5 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray8);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.clone(charArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray8, '4');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        java.lang.Long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toObject(longArray7);
        java.lang.Class<?> wildcardClass12 = longArray11.getClass();
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray11, (long) (byte) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray14, (-1L));
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) (-1), (java.lang.Object) longArray14);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1, 4, 1, 3 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4, (int) (short) 1);
        java.lang.Integer[] intArray8 = org.apache.commons.lang3.ArrayUtils.toObject(intArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray7, (int) 'a', 1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        boolean[] booleanArray2 = new boolean[] { true, false };
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray2, true, (int) '4');
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray2);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray2, 4, (int) (byte) 10);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray2, false);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray2, true);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray6, (byte) 100);
        byte[] byteArray13 = new byte[] {};
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        byte[] byteArray15 = new byte[] {};
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        java.lang.Byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray17);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.clone(byteArray17);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray14, byteArray19);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray20);
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.add(byteArray20, (byte) 1);
        java.lang.Byte[] byteArray24 = new java.lang.Byte[] {};
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray24);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray20, byteArray25);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray12, byteArray20);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray4, ' ', 1);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray4);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray4);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 2);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 10, (int) (byte) 1);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray6, 10.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray9);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray10, (short) -1);
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { (-1), (-1), 10 };
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray16);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) shortArray10, (java.lang.Object[]) intArray16);
        java.lang.Class<?> wildcardClass19 = shortArray10.getClass();
        short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(shortArray20);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.remove(intArray25, 0);
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.clone(intArray29);
        java.lang.Integer[] intArray31 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray29, intArray32);
        java.lang.Integer[] intArray34 = org.apache.commons.lang3.ArrayUtils.toObject(intArray32);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, true);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, 3, (int) (short) 10);
        java.lang.Boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray12);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        float[] floatArray5 = new float[] { (-1), (byte) 10, (short) 100, 1L, 1.0f };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (byte) 1, (int) '#');
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 10);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray5, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) (short) 0);
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) 100.0f, 7, (double) 10L);
        double[] doubleArray8 = new double[] {};
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.add(doubleArray8, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray10);
        java.lang.Double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray10);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray10, (-1.0d), (int) (short) 0, (double) 3);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray10);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray10);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) (byte) 1, (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.Byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_OBJECT_ARRAY;
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = new byte[] {};
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        java.lang.Byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray6);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray3, byteArray8);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray8, (byte) 0);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray8);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray8, (byte) 0, 5);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray0, (java.lang.Object) 5, (int) 'a');
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) (byte) 0);
        java.lang.Short[] shortArray28 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray28);
        short[] shortArray30 = new short[] {};
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray29, shortArray30);
        short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.clone(shortArray30);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray32, (short) 1);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) floatArray24, (java.lang.Object) int34);
        java.lang.Float[] floatArray36 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray24);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray24);
        float[] floatArray40 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray24, (int) (byte) 100, 3);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray40);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1L, (double) 1L);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) '4');
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray13, (int) (byte) 0);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray13, (int) (short) -1, 6);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 100.0f, (double) 1.0f);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) '4', (double) 4);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray12, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray14, doubleArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) 1, (double) (byte) 0);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray18, doubleArray25);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) (-1.0f));
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray18);
        double[] doubleArray31 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray18);
        double[] doubleArray32 = new double[] {};
        double[] doubleArray34 = org.apache.commons.lang3.ArrayUtils.add(doubleArray32, (double) (byte) 10);
        int int36 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray32, (double) 10L);
        java.lang.Double[] doubleArray37 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray32);
        double[] doubleArray38 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray37);
        double[] doubleArray40 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray37, 1.0d);
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray40, (double) '#', 0, (double) 100.0f);
        double[] doubleArray45 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray31, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1, 4, 1, 3 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4, (int) (short) 1);
        int[] intArray8 = new int[] {};
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray8, (-1));
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray8, 4, 2);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray8);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(intArray8, 2);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.clone(intArray8);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, (int) 'a', 10);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.addAll(intArray7, intArray17);
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray7, (int) (short) 100, 13);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray12, (long) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray12);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.clone(longArray12);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(longArray25);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray28 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray28, 100L, (int) '4');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray28, (long) (byte) 10);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray21, (java.lang.Object) longArray33);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray33, (int) (byte) 10, (int) (byte) 0);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.add(longArray37, (long) (byte) 1);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) 100, 100);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray37);
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) 4, (int) (short) -1);
        java.lang.Short[] shortArray49 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray56 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int59 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray56, 100L, (int) '4');
        long[] longArray61 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray56, (long) (byte) 10);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray49, (java.lang.Object) longArray61);
        long[] longArray65 = org.apache.commons.lang3.ArrayUtils.subarray(longArray61, (int) (byte) 10, (int) (byte) 0);
        long[] longArray67 = org.apache.commons.lang3.ArrayUtils.add(longArray65, (long) (byte) 1);
        int int69 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray65, (long) '4');
        java.lang.Short[] shortArray70 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray77 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int80 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray77, 100L, (int) '4');
        long[] longArray82 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray77, (long) (byte) 10);
        boolean boolean83 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray70, (java.lang.Object) longArray82);
        long[] longArray86 = org.apache.commons.lang3.ArrayUtils.subarray(longArray82, (int) (byte) 10, (int) (byte) 0);
        long[] longArray88 = org.apache.commons.lang3.ArrayUtils.add(longArray86, (long) (byte) 1);
        int int90 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray86, (long) '4');
        int int93 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray86, (long) 100, 100);
        long[] longArray94 = org.apache.commons.lang3.ArrayUtils.addAll(longArray65, longArray86);
        long[] longArray95 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray94);
        long[] longArray96 = org.apache.commons.lang3.ArrayUtils.clone(longArray94);
        boolean boolean98 = org.apache.commons.lang3.ArrayUtils.contains(longArray96, (long) ' ');
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(longArray56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(longArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(longArray65);
        org.junit.Assert.assertNotNull(longArray67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(shortArray70);
        org.junit.Assert.assertNotNull(longArray77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 4 + "'", int80 == 4);
        org.junit.Assert.assertNotNull(longArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(longArray86);
        org.junit.Assert.assertNotNull(longArray88);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertNotNull(longArray94);
        org.junit.Assert.assertNotNull(longArray95);
        org.junit.Assert.assertNotNull(longArray96);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 4);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.subarray(longArray9, 6, 2);
        long[] longArray15 = org.apache.commons.lang3.ArrayUtils.subarray(longArray9, 5, 3);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray15, 0L);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.subarray(intArray13, 4, (int) (byte) 10);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        java.lang.Double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray3, 100.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        try {
            byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.remove(byteArray0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray15 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray15, (float) (short) 1);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.add(floatArray17, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray17);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray17, (float) (byte) 0, (int) (short) 10);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray17, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray32 = new float[] { (-1), (byte) 10, (short) 100, 1L, 1.0f };
        float[] floatArray35 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray32, (int) (byte) 1, (int) '#');
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray26, floatArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray35);
        java.lang.Float[] floatArray43 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray43);
        float[] floatArray45 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray43);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray45);
        boolean boolean47 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray45);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray45);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) (byte) 0, (int) (short) 10);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.add(floatArray17, (float) 10L);
        java.lang.Float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray17);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        float[] floatArray14 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray14, (float) (short) 1);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray16, 0.0f);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray7, floatArray18);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray18, (float) (byte) 1);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.add(doubleArray9, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray11);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.add(doubleArray13, (double) (byte) 10);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray11, doubleArray15);
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray11, 0, 0);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray19, (double) (-1), (int) (short) 1);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray8, doubleArray19);
        try {
            double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray19, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) (byte) 1, 4);
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.subarray(charArray18, 2, (int) (byte) 0);
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray21, 'a', (-1));
        try {
            char[] charArray26 = org.apache.commons.lang3.ArrayUtils.remove(charArray21, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray19 = null;
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray15, charArray19);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray15, '#', 0);
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.add(charArray15, 'a');
        char[] charArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray25, '#');
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.contains(charArray25, '#');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray14, (double) ' ');
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray14, (double) 10L, (int) (byte) 0, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.Character[] charArray5 = new java.lang.Character[] { ' ', ' ', ' ', 'a', ' ' };
        java.lang.Character[] charArray11 = new java.lang.Character[] { ' ', ' ', ' ', 'a', ' ' };
        java.lang.Character[][] charArray12 = new java.lang.Character[][] { charArray5, charArray11 };
        java.lang.Character[] charArray18 = new java.lang.Character[] { '#', ' ', 'a', '#', ' ' };
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray18);
        java.lang.Character[][] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray12, charArray18);
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray18, 'a');
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray18);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray23);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, (int) '4', 4);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray7, 'a');
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.clone(charArray7);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray2, (byte) 1, (int) '4');
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, 4);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray8, (int) '4', 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray11);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        java.lang.Boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray1);
        long[] longArray7 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray12 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray17 = new long[] { (byte) 100, 4, 1L, 2 };
        long[] longArray22 = new long[] { (byte) 100, 4, 1L, 2 };
        long[][] longArray23 = new long[][] { longArray7, longArray12, longArray17, longArray22 };
        long[] longArray27 = new long[] { 'a', 10, 0 };
        long[] longArray31 = new long[] { 'a', 10, 0 };
        long[] longArray35 = new long[] { 'a', 10, 0 };
        long[] longArray39 = new long[] { 'a', 10, 0 };
        long[] longArray43 = new long[] { 'a', 10, 0 };
        long[] longArray47 = new long[] { 'a', 10, 0 };
        long[][] longArray48 = new long[][] { longArray27, longArray31, longArray35, longArray39, longArray43, longArray47 };
        long[][] longArray49 = org.apache.commons.lang3.ArrayUtils.addAll(longArray23, longArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) booleanArray2, (java.lang.Object[]) longArray23);
        boolean[] booleanArray51 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray31);
        org.junit.Assert.assertNotNull(longArray35);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertNotNull(longArray47);
        org.junit.Assert.assertNotNull(longArray48);
        org.junit.Assert.assertNotNull(longArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(booleanArray51);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 0, 100);
        java.lang.Byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray7);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray7, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String[] strArray6 = new java.lang.String[] { "{{-1,1}}", "1", "{{-1,1}}", "", "{{-1,1}}", "{{-1,1}}" };
        java.lang.Comparable[][] comparableArray8 = new java.lang.Comparable[1][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray9 = (java.lang.Comparable<java.lang.String>[][]) comparableArray8;
        strComparableArray9[0] = strArray6;
        java.lang.Comparable<java.lang.String>[][] strComparableArray14 = org.apache.commons.lang3.ArrayUtils.subarray(strComparableArray9, 4, (int) (byte) 0);
        java.lang.Comparable<java.lang.String>[][] strComparableArray15 = org.apache.commons.lang3.ArrayUtils.clone(strComparableArray14);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(strComparableArray9);
        org.junit.Assert.assertNotNull(strComparableArray14);
        org.junit.Assert.assertNotNull(strComparableArray15);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 2);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 10, (int) (byte) 1);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 100.0d);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray12, true);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray12, false, 2);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray12);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray12, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        java.lang.Character[] charArray5 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        java.lang.Double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray6, (double) (short) 0);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) charArray5, (java.lang.Object) doubleArray8);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        java.lang.Short[] shortArray5 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray7 = new short[] {};
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray7);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray7);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 1);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray9);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray12, 10, 100);
        short[] shortArray20 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray20);
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray12, shortArray20);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray22, (short) (byte) 100);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray22, (short) 0, (int) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.Boolean[][] booleanArray0 = new java.lang.Boolean[][] {};
        java.lang.Boolean[][] booleanArray1 = new java.lang.Boolean[][] {};
        java.lang.Boolean[][] booleanArray2 = new java.lang.Boolean[][] {};
        java.lang.Boolean[][] booleanArray3 = new java.lang.Boolean[][] {};
        java.lang.Boolean[][][] booleanArray4 = new java.lang.Boolean[][][] { booleanArray0, booleanArray1, booleanArray2, booleanArray3 };
        try {
            java.lang.Boolean[][][] booleanArray6 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray4, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean[] booleanArray8 = new boolean[] {};
        boolean[] booleanArray13 = new boolean[] { true, false, false, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, true, 1);
        boolean[] booleanArray31 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) boolean33);
        byte[] byteArray37 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray38 = new byte[][] { byteArray37 };
        byte[][] byteArray39 = org.apache.commons.lang3.ArrayUtils.clone(byteArray38);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray5, (java.lang.Object) byteArray39);
        short[] shortArray42 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) (byte) 10);
        short[] shortArray44 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) (byte) 10);
        short[] shortArray46 = org.apache.commons.lang3.ArrayUtils.add(shortArray44, (short) (byte) 0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shortArray42);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertNotNull(shortArray46);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.add(longArray11, 1L);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, (int) (short) 10, (int) (byte) 1);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray16, (long) (short) 10);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = new byte[] {};
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        java.lang.Byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray11);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 1);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray4, byteArray12);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray12, 0, (-1));
        byte[] byteArray19 = new byte[] {};
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.clone(byteArray19);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(byteArray19, (byte) -1);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray18, byteArray19);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray19, (byte) 0);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray19, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(byteArray27);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray14, (int) (short) 10, (int) (short) -1);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray17);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean[] booleanArray8 = new boolean[] {};
        boolean[] booleanArray13 = new boolean[] { true, false, false, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, true, 1);
        boolean[] booleanArray31 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) boolean33);
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 10);
        short[] shortArray38 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) (byte) 0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray38);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        int[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.add(intArray0, 3);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray0, 5, 4);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (int) (byte) 1, 7);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.add(intArray5, (int) '#');
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray18, 0);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.clone(intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray21, (int) 'a');
        int[] intArray29 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray29, 1);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray29, (int) ' ', (int) (short) 100);
        int[] intArray37 = org.apache.commons.lang3.ArrayUtils.add(intArray29, 1, (int) 'a');
        int[] intArray40 = org.apache.commons.lang3.ArrayUtils.subarray(intArray29, 0, 0);
        int[] intArray41 = new int[] {};
        int int43 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray41, (-1));
        int int46 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray41, 4, 2);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray41, 3);
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray29, intArray41);
        int[] intArray50 = org.apache.commons.lang3.ArrayUtils.addAll(intArray21, intArray41);
        int[] intArray51 = org.apache.commons.lang3.ArrayUtils.addAll(intArray15, intArray21);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        boolean[] booleanArray4 = new boolean[] { true, true, true, true };
        boolean[] booleanArray9 = new boolean[] { true, true, true, true };
        boolean[] booleanArray14 = new boolean[] { true, true, true, true };
        boolean[] booleanArray19 = new boolean[] { true, true, true, true };
        boolean[][] booleanArray20 = new boolean[][] { booleanArray4, booleanArray9, booleanArray14, booleanArray19 };
        boolean[][][] booleanArray21 = new boolean[][][] { booleanArray20 };
        boolean[][][][] booleanArray22 = new boolean[][][][] { booleanArray21 };
        try {
            boolean[][][][] booleanArray24 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray22, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertNotNull(booleanArray22);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray7, (long) 0);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray17 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray17, 100L, (int) '4');
        long[] longArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray17, (long) (byte) 10);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray10, (java.lang.Object) longArray22);
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.subarray(longArray22, (int) (byte) 10, (int) (byte) 0);
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.add(longArray26, (long) (byte) 1);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray26, (long) '4');
        java.lang.Short[] shortArray31 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray38 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray38, 100L, (int) '4');
        long[] longArray43 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray38, (long) (byte) 10);
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray31, (java.lang.Object) longArray43);
        long[] longArray47 = org.apache.commons.lang3.ArrayUtils.subarray(longArray43, (int) (byte) 10, (int) (byte) 0);
        long[] longArray49 = org.apache.commons.lang3.ArrayUtils.add(longArray47, (long) (byte) 1);
        int int51 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray47, (long) '4');
        int int54 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray47, (long) 100, 100);
        long[] longArray55 = org.apache.commons.lang3.ArrayUtils.addAll(longArray26, longArray47);
        long[] longArray56 = org.apache.commons.lang3.ArrayUtils.addAll(longArray9, longArray55);
        long[] longArray59 = org.apache.commons.lang3.ArrayUtils.subarray(longArray9, (int) '#', (int) (short) 1);
        int int61 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray9, 0L);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertNotNull(longArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(longArray47);
        org.junit.Assert.assertNotNull(longArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(longArray55);
        org.junit.Assert.assertNotNull(longArray56);
        org.junit.Assert.assertNotNull(longArray59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray5);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray5, (double) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray4, (float) ' ', (int) 'a');
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.add(floatArray4, (float) (short) 100);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.add(floatArray12, 3, (float) 3);
        java.lang.Float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray15);
        java.lang.Float[] floatArray22 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray22);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray23, (float) (short) 0, (int) (byte) 10);
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray23, (float) 1L);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.add(floatArray23, (float) 'a');
        float[] floatArray37 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray37, (float) (short) 1);
        float[] floatArray40 = org.apache.commons.lang3.ArrayUtils.clone(floatArray37);
        java.lang.Float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray40);
        float[] floatArray48 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray50 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray48, (float) (short) 1);
        float[] floatArray51 = org.apache.commons.lang3.ArrayUtils.clone(floatArray48);
        java.lang.Float[] floatArray52 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray51);
        boolean boolean53 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray41, (java.lang.Object[]) floatArray52);
        float[] floatArray55 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray52, (float) 10);
        float[] floatArray57 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray52, (float) 10L);
        boolean boolean58 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray23, floatArray57);
        boolean boolean59 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray15, floatArray23);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) '4');
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray13, (int) (byte) 0);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray13, (int) (short) -1, 6);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) 7, 3, (double) 1L);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, (int) '4', 4);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.add(charArray4, (int) (byte) 0, '4');
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray10);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) longArray15, (java.lang.Object) doubleArray18);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray15);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(longArray21);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0, true);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray3, false, (int) '#');
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray7);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.add(byteArray7, (byte) 1);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray7);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, true);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray5);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray5, 0);
        try {
            boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray5, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (byte) 1);
        double[] doubleArray3 = new double[] {};
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray3, (double) (-1.0f), (double) 1L);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) (short) 0, (int) (short) 100, (double) '4');
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray3);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray12, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray14, doubleArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) 1, (double) (byte) 0);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray18, doubleArray25);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) (-1.0f));
        int int33 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray18, (double) 10.0f, 1, (double) 10.0f);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray3, doubleArray18);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.clone(longArray12);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray14);
        long[] longArray22 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray22, 100L, (int) '4');
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray22, (long) (byte) 10);
        java.lang.Long[] longArray28 = org.apache.commons.lang3.ArrayUtils.toObject(longArray27);
        long[] longArray29 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray27);
        long[] longArray31 = org.apache.commons.lang3.ArrayUtils.add(longArray27, (long) 1);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertNotNull(longArray31);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) '#', (int) ' ');
        float[] floatArray14 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, 3, (int) (byte) 0);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) (short) 0);
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) 100.0f, 7, (double) 10L);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (byte) 10, (double) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 0.0d);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray4, (double) 1, 0, (double) (-1L));
        try {
            double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, 5, (double) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        float[] floatArray8 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 100, (int) '4');
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray1, (java.lang.Object) (byte) 100, (-1));
        java.lang.String str14 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) int13);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1" + "'", str14.equals("-1"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.String[] strArray2 = new java.lang.String[] { "{}", "-1" };
        java.lang.Comparable[][] comparableArray4 = new java.lang.Comparable[1][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray5 = (java.lang.Comparable<java.lang.String>[][]) comparableArray4;
        strComparableArray5[0] = strArray2;
        java.lang.Comparable[][][] comparableArray9 = new java.lang.Comparable[1][][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][][] strComparableArray10 = (java.lang.Comparable<java.lang.String>[][][]) comparableArray9;
        strComparableArray10[0] = strComparableArray5;
        java.lang.Comparable[][][] comparableArray14 = new java.lang.Comparable[0][][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][][] strComparableArray15 = (java.lang.Comparable<java.lang.String>[][][]) comparableArray14;
        java.lang.Comparable<java.lang.String>[][][] strComparableArray16 = org.apache.commons.lang3.ArrayUtils.addAll(strComparableArray10, strComparableArray15);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(strComparableArray5);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(strComparableArray10);
        org.junit.Assert.assertNotNull(comparableArray14);
        org.junit.Assert.assertNotNull(strComparableArray15);
        org.junit.Assert.assertNotNull(strComparableArray16);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        java.lang.Class<?> wildcardClass14 = floatArray9.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray15 = new java.lang.reflect.AnnotatedElement[] { wildcardClass14 };
        float[] floatArray22 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray22, (float) (short) 1);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.clone(floatArray22);
        java.lang.Float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray25);
        float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.add(floatArray25, 3, (float) 100);
        java.lang.Class<?> wildcardClass30 = floatArray25.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray31 = new java.lang.reflect.AnnotatedElement[] { wildcardClass30 };
        java.lang.reflect.AnnotatedElement[][] annotatedElementArray32 = new java.lang.reflect.AnnotatedElement[][] { annotatedElementArray15, annotatedElementArray31 };
        java.lang.reflect.AnnotatedElement[][] annotatedElementArray35 = org.apache.commons.lang3.ArrayUtils.subarray(annotatedElementArray32, (int) ' ', (int) (short) 0);
        java.lang.reflect.AnnotatedElement[][] annotatedElementArray38 = org.apache.commons.lang3.ArrayUtils.subarray(annotatedElementArray35, 10, (int) (byte) -1);
        java.lang.String str40 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) 10, "{false,true,true,false,false}");
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(annotatedElementArray15);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(annotatedElementArray31);
        org.junit.Assert.assertNotNull(annotatedElementArray32);
        org.junit.Assert.assertNotNull(annotatedElementArray35);
        org.junit.Assert.assertNotNull(annotatedElementArray38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10" + "'", str40.equals("10"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = new byte[] {};
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        java.lang.Byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray11);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 1);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray4, byteArray12);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.add(byteArray4, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(byteArray17);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray4);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10, (int) (short) 1);
        java.lang.Short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray4, (short) 100);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 10.0f, 100, (double) (byte) -1);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.add(doubleArray17, (double) (byte) 10);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray19, (double) (short) 100, (int) '#');
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray6, doubleArray19);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray19, (double) 100.0f, (int) '4', (double) 7);
        double[] doubleArray28 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray19);
        double[] doubleArray29 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        byte[] byteArray0 = null;
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        org.junit.Assert.assertNull(byteArray1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray9 = new boolean[] { true, false };
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray9, true, (int) '4');
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray9, false, (int) (byte) 0);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray9, false);
        boolean[] booleanArray20 = new boolean[] { true, false };
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray20, true, (int) '4');
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray9, booleanArray20);
        boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray20, false);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray5, booleanArray20);
        boolean[] booleanArray28 = new boolean[] {};
        boolean[] booleanArray33 = new boolean[] { true, false, false, true };
        boolean[] booleanArray34 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray28, booleanArray33);
        int int36 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray33, false);
        boolean[] booleanArray37 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray33);
        boolean[] booleanArray38 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray20, booleanArray33);
        boolean[] booleanArray40 = org.apache.commons.lang3.ArrayUtils.add(booleanArray38, true);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(booleanArray37);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray40);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray4);
        short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (short) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, 5);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) 10, (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray21, (float) 10);
        int[] intArray30 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int32 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray30, 1);
        int int35 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray30, (int) ' ', (int) (short) 100);
        int[] intArray41 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int43 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray41, 1);
        int[] intArray44 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray45 = org.apache.commons.lang3.ArrayUtils.addAll(intArray41, intArray44);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray30, intArray45);
        int int48 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray45, (int) (byte) 0);
        int[] intArray50 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray45, 1);
        int[] intArray52 = org.apache.commons.lang3.ArrayUtils.add(intArray50, (int) '4');
        java.lang.Class<?> wildcardClass53 = intArray50.getClass();
        int[] intArray55 = org.apache.commons.lang3.ArrayUtils.remove(intArray50, 3);
        boolean boolean56 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) 10, (java.lang.Object) 3);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 0);
        java.lang.Short[] shortArray15 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray15);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray16, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray16);
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.add(shortArray16, (short) 0);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray16);
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray11, shortArray16);
        int int27 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray16, (short) 1, 7);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        java.lang.String str11 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) longArray5, "10");
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{1,0,10,1,1}" + "'", str11.equals("{1,0,10,1,1}"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        short[] shortArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) floatArray21);
        java.lang.Character[] charArray27 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray28 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray27);
        java.lang.Character[] charArray29 = org.apache.commons.lang3.ArrayUtils.toObject(charArray28);
        char[] charArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray28, 'a');
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray28, 'a');
        java.lang.Character[] charArray34 = org.apache.commons.lang3.ArrayUtils.toObject(charArray28);
        int int36 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray21, (java.lang.Object) charArray28, (int) (byte) 10);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        java.lang.Byte[] byteArray15 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray15);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray15, (byte) 10);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.add(byteArray18, (byte) 1);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) (byte) 1);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) 0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray1);
        boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.add(booleanArray1, false);
        boolean[] booleanArray10 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray10);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray11, true);
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray13, true);
        boolean[] booleanArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray13, true);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray17, true);
        boolean[] booleanArray20 = new boolean[] {};
        boolean[] booleanArray25 = new boolean[] { true, false, false, true };
        boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray20, booleanArray25);
        boolean[] booleanArray29 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray26, (int) '4', 0);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray17, booleanArray26);
        java.lang.Boolean[] booleanArray31 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray17);
        boolean[] booleanArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray31, false);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray4, booleanArray33);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.add(longArray14, (long) ' ');
        java.lang.Short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray25 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray25, 100L, (int) '4');
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray25, (long) (byte) 10);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray18, (java.lang.Object) longArray30);
        long[] longArray34 = org.apache.commons.lang3.ArrayUtils.subarray(longArray30, (int) (byte) 10, (int) (byte) 0);
        long[] longArray36 = org.apache.commons.lang3.ArrayUtils.remove(longArray30, 2);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray36);
        long[] longArray38 = org.apache.commons.lang3.ArrayUtils.addAll(longArray14, longArray36);
        int int41 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray14, (long) 6, (int) (byte) -1);
        int int43 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray14, 0L);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(longArray38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, 10.0f);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray32, 1.0f, (int) (short) 1);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray32, (float) 100L, (-1));
        float[] floatArray40 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray32, 0.0f);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(floatArray40);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = new byte[] {};
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray2, byteArray7);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray2, (byte) 100, (int) (byte) 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 0, 100);
        java.lang.Byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray7);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray7, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray15, (int) (byte) 1, '4');
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.subarray(charArray15, (int) ' ', (int) ' ');
        java.lang.Character[] charArray25 = org.apache.commons.lang3.ArrayUtils.toObject(charArray15);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray25);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) '#', (int) ' ');
        float[] floatArray18 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray18, (float) (short) 1);
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.clone(floatArray18);
        java.lang.Float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray21);
        float[] floatArray29 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray29, (float) (short) 1);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.clone(floatArray29);
        java.lang.Float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray32);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray22, (java.lang.Object[]) floatArray33);
        float[] floatArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray22, (float) (byte) 0);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray8, floatArray36);
        java.lang.Float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray36);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray38);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double[] doubleArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, 10.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray6, (long) (byte) 10);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.subarray(longArray11, 2, 1);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.subarray(longArray14, (int) (byte) 100, 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray18, (long) 6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 0);
        java.lang.Short[] shortArray15 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray15);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray16, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray16);
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.add(shortArray16, (short) 0);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray16);
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray11, shortArray16);
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.add(shortArray11, (short) -1);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray11);
        int int29 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray11, (short) (byte) 100);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray11, (short) (byte) 0, (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, (double) 10);
        try {
            double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (int) '#', 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 100L);
        java.lang.Class<?> wildcardClass13 = floatArray8.getClass();
        java.lang.Float[] floatArray19 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray20, 1.0f);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray8, floatArray20);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray8);
        try {
            float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, (int) (short) 100, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        java.lang.Double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray2);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (-1.0d), (int) (short) 0, (double) 3);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 1.0f, (int) ' ');
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) (byte) 0, (int) (short) 10);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.add(floatArray17, (float) 10L);
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray19, 0.0f);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.add(floatArray19, 100.0f);
        int int24 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) floatArray23);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.clone(floatArray23);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains(floatArray25, (float) 1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 0.0d);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        float[] floatArray8 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 100, (int) '4');
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray1, (java.lang.Object) (byte) 100, (-1));
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray14, (byte) 100);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.add(byteArray14, (byte) -1);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray18, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray20);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0, (int) (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 1, (-1));
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, 0, (int) (short) 1);
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 1, (int) 'a');
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.subarray(intArray5, 0, 0);
        int[] intArray17 = new int[] {};
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, (-1));
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, 4, 2);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray17, 3);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray17);
        int[] intArray26 = new int[] {};
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray26, (-1));
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray26, 4, 2);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray26, 3);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray26);
        int[] intArray40 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray40, 1);
        int int45 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray40, (int) ' ', (int) (short) 100);
        int[] intArray51 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int53 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray51, 1);
        int[] intArray54 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray55 = org.apache.commons.lang3.ArrayUtils.addAll(intArray51, intArray54);
        boolean boolean56 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray40, intArray55);
        int int58 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray55, (int) (byte) 0);
        int[] intArray60 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray55, 1);
        int[] intArray62 = org.apache.commons.lang3.ArrayUtils.add(intArray60, (int) '4');
        java.lang.Integer[] intArray66 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray68 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray66, 2);
        int[] intArray69 = org.apache.commons.lang3.ArrayUtils.addAll(intArray60, intArray68);
        int[] intArray71 = org.apache.commons.lang3.ArrayUtils.add(intArray68, (int) 'a');
        int int74 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray68, (int) (short) 1, (int) (short) 10);
        int[] intArray77 = org.apache.commons.lang3.ArrayUtils.subarray(intArray68, (int) '4', (int) (short) 0);
        int[] intArray78 = null;
        int[] intArray79 = org.apache.commons.lang3.ArrayUtils.addAll(intArray68, intArray78);
        int[] intArray80 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray78);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray80);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 2);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, 0.0d, 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int[] intArray0 = new int[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, (-1));
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, 4, 2);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray0);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(intArray0, 2);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.clone(intArray0);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray9, (int) 'a', 10);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.clone(intArray9);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray13);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, 10);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 10, (int) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 10, 13);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray6);
        java.lang.Byte[] byteArray12 = new java.lang.Byte[] {};
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray13);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray11);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray11);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.ArrayUtils.add(strArray0, "{10.0}");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray1, (byte) -1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray1, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray13 = new byte[] {};
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        byte[] byteArray15 = new byte[] {};
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.clone(byteArray15);
        java.lang.Byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray17);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.clone(byteArray17);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray14, byteArray19);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray19);
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray19, (byte) 0);
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray19);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray24, 1, (int) (short) 0);
        java.lang.Byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray24);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.contains(byteArray24, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray12, (long) (short) 100, (int) (short) -1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (long) 1);
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.add(longArray12, 2, (long) (byte) 1);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, (-1L));
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        long[] longArray6 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 100L, (int) '4');
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray10);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray11, (long) (short) 100);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 1.0f, 0, (double) '4');
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) '4', (double) (byte) 0);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, 100.0d, 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray10 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray10, '#');
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray10);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray13, '4');
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray15, '#', (int) '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray15, (int) (byte) 1, '4');
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.clone(charArray15);
        java.lang.Object[] objArray23 = null;
        java.lang.Character[] charArray27 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray28 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray27);
        java.lang.Character[] charArray29 = org.apache.commons.lang3.ArrayUtils.toObject(charArray28);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(objArray23, (java.lang.Object) charArray28);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray22, charArray28);
        char[] charArray34 = org.apache.commons.lang3.ArrayUtils.subarray(charArray22, 100, 6);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(charArray34);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int[] intArray0 = null;
        int[] intArray3 = org.apache.commons.lang3.ArrayUtils.subarray(intArray0, 2, 5);
        org.junit.Assert.assertNull(intArray3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.clone(longArray12);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.subarray(longArray17, (int) 'a', 2);
        long[] longArray21 = org.apache.commons.lang3.ArrayUtils.clone(longArray20);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray21);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.Integer[] intArray0 = new java.lang.Integer[] {};
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0, 5);
        int[] intArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.remove(intArray25, 0);
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.clone(intArray29);
        java.lang.Integer[] intArray31 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray29, intArray32);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray32, 2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.Long[] longArray6 = new java.lang.Long[] { 100L, (-1L), 1L, (-1L), 10L, (-1L) };
        java.lang.Long[] longArray13 = new java.lang.Long[] { 100L, (-1L), 1L, (-1L), 10L, (-1L) };
        java.lang.Long[] longArray20 = new java.lang.Long[] { 100L, (-1L), 1L, (-1L), 10L, (-1L) };
        java.lang.Long[] longArray27 = new java.lang.Long[] { 100L, (-1L), 1L, (-1L), 10L, (-1L) };
        java.lang.Long[][] longArray28 = new java.lang.Long[][] { longArray6, longArray13, longArray20, longArray27 };
        java.lang.Long[] longArray30 = new java.lang.Long[] { 0L };
        java.lang.Long[] longArray32 = new java.lang.Long[] { 0L };
        java.lang.Long[][] longArray33 = new java.lang.Long[][] { longArray30, longArray32 };
        java.lang.Long[][] longArray34 = org.apache.commons.lang3.ArrayUtils.clone(longArray33);
        java.lang.Long[][] longArray35 = org.apache.commons.lang3.ArrayUtils.addAll(longArray28, longArray34);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray35);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray2, 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) 100, 3);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        boolean[] booleanArray7 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray7);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray8, true);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray10, true);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray12, true);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray1, booleanArray12);
        float[] floatArray22 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray22, (float) (short) 1);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.clone(floatArray22);
        java.lang.Float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray25);
        float[] floatArray33 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray35 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray33, (float) (short) 1);
        float[] floatArray36 = org.apache.commons.lang3.ArrayUtils.clone(floatArray33);
        java.lang.Float[] floatArray37 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray36);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray26, (java.lang.Object[]) floatArray37);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) floatArray37);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) booleanArray1, (java.lang.Object) floatArray37);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean[] booleanArray28 = new boolean[] { true, false };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray28, true, (int) '4');
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray28, false, (int) (byte) 0);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray28, false);
        boolean[] booleanArray39 = new boolean[] { true, false };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray39, true, (int) '4');
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray28, booleanArray39);
        boolean[] booleanArray45 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray39, false);
        boolean[] booleanArray46 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray6, booleanArray45);
        boolean[] booleanArray47 = new boolean[] {};
        boolean[] booleanArray52 = new boolean[] { true, false, false, true };
        boolean[] booleanArray53 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray47, booleanArray52);
        int int55 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray52, false);
        boolean[] booleanArray56 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray52);
        boolean[] booleanArray58 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray52, false);
        boolean[] booleanArray59 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray52);
        boolean boolean60 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray59);
        java.lang.Boolean[] booleanArray61 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray6);
        java.lang.Boolean[] booleanArray62 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(booleanArray45);
        org.junit.Assert.assertNotNull(booleanArray46);
        org.junit.Assert.assertNotNull(booleanArray47);
        org.junit.Assert.assertNotNull(booleanArray52);
        org.junit.Assert.assertNotNull(booleanArray53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(booleanArray56);
        org.junit.Assert.assertNotNull(booleanArray58);
        org.junit.Assert.assertNotNull(booleanArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(booleanArray61);
        org.junit.Assert.assertNotNull(booleanArray62);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 100L);
        java.lang.Class<?> wildcardClass13 = floatArray8.getClass();
        java.lang.Float[] floatArray19 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray20, 1.0f);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray8, floatArray20);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.remove(floatArray20, (int) (short) 0);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.remove(floatArray20, 4);
        java.lang.Class<?> wildcardClass28 = floatArray20.getClass();
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray28 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray28, 100L, (int) '4');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray28, (long) (byte) 10);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray21, (java.lang.Object) longArray33);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray33, (int) (byte) 10, (int) (byte) 0);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.add(longArray37, (long) (byte) 1);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) 100, 100);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray37);
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) 4, (int) (short) -1);
        java.lang.Short[] shortArray49 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray56 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int59 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray56, 100L, (int) '4');
        long[] longArray61 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray56, (long) (byte) 10);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray49, (java.lang.Object) longArray61);
        long[] longArray65 = org.apache.commons.lang3.ArrayUtils.subarray(longArray61, (int) (byte) 10, (int) (byte) 0);
        long[] longArray67 = org.apache.commons.lang3.ArrayUtils.add(longArray65, (long) (byte) 1);
        int int69 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray65, (long) '4');
        java.lang.Short[] shortArray70 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray77 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int80 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray77, 100L, (int) '4');
        long[] longArray82 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray77, (long) (byte) 10);
        boolean boolean83 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray70, (java.lang.Object) longArray82);
        long[] longArray86 = org.apache.commons.lang3.ArrayUtils.subarray(longArray82, (int) (byte) 10, (int) (byte) 0);
        long[] longArray88 = org.apache.commons.lang3.ArrayUtils.add(longArray86, (long) (byte) 1);
        int int90 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray86, (long) '4');
        int int93 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray86, (long) 100, 100);
        long[] longArray94 = org.apache.commons.lang3.ArrayUtils.addAll(longArray65, longArray86);
        long[] longArray95 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray94);
        long[] longArray96 = org.apache.commons.lang3.ArrayUtils.clone(longArray94);
        long[] longArray98 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray96, (long) (byte) 0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(longArray56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(longArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(longArray65);
        org.junit.Assert.assertNotNull(longArray67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(shortArray70);
        org.junit.Assert.assertNotNull(longArray77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 4 + "'", int80 == 4);
        org.junit.Assert.assertNotNull(longArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(longArray86);
        org.junit.Assert.assertNotNull(longArray88);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertNotNull(longArray94);
        org.junit.Assert.assertNotNull(longArray95);
        org.junit.Assert.assertNotNull(longArray96);
        org.junit.Assert.assertNotNull(longArray98);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        short[] shortArray4 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5, (short) 0);
        boolean[] booleanArray8 = new boolean[] {};
        boolean[] booleanArray13 = new boolean[] { true, false, false, true };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray8, booleanArray13);
        boolean[] booleanArray15 = new boolean[] {};
        boolean[] booleanArray20 = new boolean[] { true, false, false, true };
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray15, booleanArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray20);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, true, 1);
        boolean[] booleanArray31 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray14, booleanArray31);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) boolean33);
        byte[] byteArray37 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray38 = new byte[][] { byteArray37 };
        byte[][] byteArray39 = org.apache.commons.lang3.ArrayUtils.clone(byteArray38);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray5, (java.lang.Object) byteArray39);
        short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        java.lang.Object obj42 = null;
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, obj42, (-1));
        float[] floatArray51 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray53 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray51, (float) (short) 1);
        float[] floatArray54 = org.apache.commons.lang3.ArrayUtils.clone(floatArray51);
        java.lang.Float[] floatArray55 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray54);
        float[] floatArray58 = org.apache.commons.lang3.ArrayUtils.add(floatArray54, 3, (float) 100);
        java.lang.Class<?> wildcardClass59 = floatArray54.getClass();
        int int62 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray54, (float) (short) 0, 3);
        int int64 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray5, (java.lang.Object) int62, (-1));
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(booleanArray31);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 5 + "'", int62 == 5);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        short[] shortArray0 = null;
        try {
            short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.remove(shortArray0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 100L);
        java.lang.Class<?> wildcardClass13 = floatArray8.getClass();
        java.lang.Float[] floatArray19 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray20, 1.0f);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray8, floatArray20);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.remove(floatArray20, (int) (short) 0);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.clone(floatArray25);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 1.0f, 0, (double) '4');
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) 100.0f, 4);
        double[] doubleArray15 = new double[] {};
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.add(doubleArray15, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray17);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.add(doubleArray19, (double) (byte) 10);
        double[] doubleArray22 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray17, doubleArray21);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray21, (double) 1, (double) (byte) 0);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray21, (double) 6, (int) (short) 100, (double) 10.0f);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray2, doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 1, 4, 1, 3 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray4, (int) (short) 1);
        int[] intArray8 = new int[] {};
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray8, (-1));
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray8, 4, 2);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray8);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(intArray8, 2);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.clone(intArray8);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray17, (int) 'a', 10);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.addAll(intArray7, intArray17);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray21);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.Float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0);
        java.lang.Character[] charArray5 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray5);
        char[] charArray12 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray12, '#');
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.addAll(charArray6, charArray12);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.add(charArray15, '4');
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.subarray(charArray17, (int) (byte) 1, 4);
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.subarray(charArray20, 2, (int) (byte) 0);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) floatArray0, (java.lang.Object) 2);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray0, (float) (short) 100);
        boolean[] booleanArray32 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray33 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray32);
        boolean[] booleanArray35 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray33, true);
        boolean[] booleanArray37 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray35, true);
        boolean[] booleanArray39 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray35, true);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray39, true);
        boolean[] booleanArray42 = new boolean[] {};
        boolean[] booleanArray47 = new boolean[] { true, false, false, true };
        boolean[] booleanArray48 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray42, booleanArray47);
        boolean[] booleanArray51 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray48, (int) '4', 0);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray39, booleanArray48);
        java.lang.Boolean[] booleanArray53 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray39);
        boolean boolean54 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray0, (java.lang.Object[]) booleanArray53);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertNotNull(booleanArray35);
        org.junit.Assert.assertNotNull(booleanArray37);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(booleanArray47);
        org.junit.Assert.assertNotNull(booleanArray48);
        org.junit.Assert.assertNotNull(booleanArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(booleanArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        java.lang.Double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray2);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 4, (int) (short) 10, (double) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, 0, (double) 100L);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, '#');
        java.io.Serializable[] serializableArray5 = org.apache.commons.lang3.ArrayUtils.subarray((java.io.Serializable[]) charArray0, (int) (short) -1, (int) '#');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(serializableArray5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray18);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray22 = org.apache.commons.lang3.ArrayUtils.add(doubleArray20, (double) (byte) 10);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray18, doubleArray22);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray18);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 100.0d, (int) (short) -1, (double) '4');
        double[] doubleArray30 = org.apache.commons.lang3.ArrayUtils.add(doubleArray6, (double) 10.0f);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray30);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray30, (double) 6, 6, (double) 13);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, (int) '#');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray6, (int) ' ', (int) (short) 100);
        byte[] byteArray14 = new byte[] {};
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray14);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray16);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.clone(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 1, (int) '4');
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 1);
        byte[] byteArray29 = new byte[] { (byte) 10, (byte) -1, (byte) 1, (byte) 0 };
        int int32 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray29, (byte) 10, 1);
        byte[] byteArray34 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray29, (byte) -1);
        byte[] byteArray35 = org.apache.commons.lang3.ArrayUtils.clone(byteArray29);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray29);
        byte[] byteArray37 = new byte[] {};
        byte[] byteArray38 = org.apache.commons.lang3.ArrayUtils.clone(byteArray37);
        byte[] byteArray41 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray38, 1, (int) (byte) -1);
        byte[] byteArray42 = new byte[] {};
        byte[] byteArray43 = org.apache.commons.lang3.ArrayUtils.clone(byteArray42);
        byte[] byteArray44 = new byte[] {};
        byte[] byteArray45 = org.apache.commons.lang3.ArrayUtils.clone(byteArray44);
        byte[] byteArray46 = org.apache.commons.lang3.ArrayUtils.clone(byteArray44);
        java.lang.Byte[] byteArray47 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray46);
        byte[] byteArray48 = org.apache.commons.lang3.ArrayUtils.clone(byteArray46);
        byte[] byteArray49 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray43, byteArray48);
        int int52 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray48, (byte) 10, (int) (short) 10);
        int int54 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray48, (byte) 100);
        byte[] byteArray57 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray48, 1, (-1));
        byte[] byteArray59 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray48, (byte) 1);
        byte[] byteArray60 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray41, byteArray59);
        java.lang.Byte[] byteArray61 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray59);
        byte[] byteArray62 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray61);
        boolean boolean63 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray29, byteArray62);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertNotNull(byteArray59);
        org.junit.Assert.assertNotNull(byteArray60);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertNotNull(byteArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.lang.Byte[] byteArray0 = new java.lang.Byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0);
        float[] floatArray8 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray8, (float) (short) 1);
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.add(floatArray10, 0.0f);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray10, (float) 100L);
        java.lang.Class<?> wildcardClass15 = floatArray10.getClass();
        java.lang.Float[] floatArray21 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray21);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray22, 1.0f);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray10, floatArray22);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.remove(floatArray22, (int) (short) 0);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray0, (java.lang.Object) floatArray27);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(longArray5, (long) 3);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray5);
        long[] longArray13 = null;
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.addAll(longArray5, longArray13);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(longArray14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray4, (byte) -1);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = new byte[] {};
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        java.lang.Byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray11);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray8, byteArray13);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray13);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray13, (byte) 0);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray13, (int) ' ', (int) (short) 100);
        byte[] byteArray21 = new byte[] {};
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.clone(byteArray21);
        byte[] byteArray23 = org.apache.commons.lang3.ArrayUtils.clone(byteArray21);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray23);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.clone(byteArray23);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray13, byteArray23);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.contains(byteArray26, (byte) -1);
        byte[] byteArray29 = new byte[] {};
        byte[] byteArray30 = org.apache.commons.lang3.ArrayUtils.clone(byteArray29);
        byte[] byteArray31 = new byte[] {};
        byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.clone(byteArray31);
        byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.clone(byteArray31);
        java.lang.Byte[] byteArray34 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray33);
        byte[] byteArray35 = org.apache.commons.lang3.ArrayUtils.clone(byteArray33);
        byte[] byteArray36 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray30, byteArray35);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray35, (byte) 0, (int) (short) 100);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray26, byteArray35);
        byte[] byteArray41 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray35);
        byte[] byteArray43 = org.apache.commons.lang3.ArrayUtils.add(byteArray35, (byte) 10);
        int int46 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray35, (byte) 1, (int) (short) 10);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray9, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) (byte) 0);
        java.lang.Short[] shortArray28 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray28);
        short[] shortArray30 = new short[] {};
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray29, shortArray30);
        short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.clone(shortArray30);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray32, (short) 1);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) floatArray24, (java.lang.Object) int34);
        java.lang.Float[] floatArray36 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray24);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray24);
        float[] floatArray45 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray47 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray45, (float) (short) 1);
        float[] floatArray48 = org.apache.commons.lang3.ArrayUtils.clone(floatArray45);
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) '4', (java.lang.Object) floatArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray24, floatArray48);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray9);
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray9, (float) 10L);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        long[] longArray5 = new long[] { ' ', (byte) 1, (byte) 100, 'a', 0 };
        org.apache.commons.lang3.ArrayUtils.reverse(longArray5);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.subarray(longArray5, (int) (byte) 0, (int) (short) 100);
        java.lang.Long[] longArray10 = org.apache.commons.lang3.ArrayUtils.toObject(longArray9);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        java.lang.Long[] longArray9 = org.apache.commons.lang3.ArrayUtils.toObject(longArray5);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray9, 1L);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray9);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray9);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray13);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, (int) '4', 4);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.subarray(charArray7, 0, (int) (byte) -1);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.clone(charArray7);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray18, true);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.clone(intArray4);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, (int) 'a');
        int[] intArray13 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray13, 1);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray13, (int) ' ', (int) (short) 100);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.add(intArray13, 1, (int) 'a');
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.subarray(intArray13, 0, 0);
        int[] intArray25 = new int[] {};
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, 4, 2);
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray25, 3);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray13, intArray25);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray25);
        int int37 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray25, 6, 100);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) 10L);
        java.lang.Float[] floatArray17 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray17);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray17);
        float[] floatArray26 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray26, (float) (short) 1);
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.add(floatArray28, 0.0f);
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray30, 100, (int) (short) 100);
        float[] floatArray38 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray41 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray38, (int) (byte) 100, (int) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray38, (float) ' ', (int) 'a');
        float[] floatArray46 = org.apache.commons.lang3.ArrayUtils.add(floatArray38, (float) (short) 100);
        float[] floatArray47 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray30, floatArray46);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray19, floatArray30);
        float[] floatArray49 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray11, floatArray19);
        float[] floatArray56 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray58 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray56, (float) (short) 1);
        float[] floatArray60 = org.apache.commons.lang3.ArrayUtils.add(floatArray58, 0.0f);
        int int62 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray58, (float) 100L);
        java.lang.Class<?> wildcardClass63 = floatArray58.getClass();
        java.lang.Float[] floatArray69 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray70 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray69);
        int int72 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray70, 1.0f);
        float[] floatArray73 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray58, floatArray70);
        float[] floatArray74 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray11, floatArray70);
        int int77 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray70, (-1.0f), (int) (byte) 100);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(floatArray73);
        org.junit.Assert.assertNotNull(floatArray74);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) (byte) 0, (int) (short) 10);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 10, (int) (byte) -1);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray17, (float) (byte) -1, (-1));
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray17, (int) '#', (int) (short) -1);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray17, 5, 10);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray5 = new byte[] {};
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        java.lang.Byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray11);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 1);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray4, byteArray12);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray12, 0, (-1));
        byte[] byteArray19 = new byte[] {};
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.clone(byteArray19);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(byteArray19, (byte) -1);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray18, byteArray19);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray19);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        java.lang.Double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (-1.0f), 100);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 7);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray12, true);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray12, false, 2);
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray12, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.Byte[] byteArray6 = new java.lang.Byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 0, (byte) -1, (byte) 10 };
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        java.lang.Byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray11);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray12);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray12);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, true);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, 3, (int) (short) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, false);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray5, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray5, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray20);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.Boolean[][] booleanArray0 = new java.lang.Boolean[][] {};
        java.lang.Boolean[][] booleanArray1 = new java.lang.Boolean[][] {};
        java.lang.Boolean[][] booleanArray2 = new java.lang.Boolean[][] {};
        java.lang.Boolean[][] booleanArray3 = new java.lang.Boolean[][] {};
        java.lang.Boolean[][] booleanArray4 = new java.lang.Boolean[][] {};
        java.lang.Boolean[][][] booleanArray5 = new java.lang.Boolean[][][] { booleanArray0, booleanArray1, booleanArray2, booleanArray3, booleanArray4 };
        java.lang.Boolean[][][] booleanArray6 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.contains(intArray5, (int) (short) 0);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, (-1), (int) (byte) -1);
        java.lang.Integer[] intArray16 = org.apache.commons.lang3.ArrayUtils.toObject(intArray5);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray16);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray18, true);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray18);
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray18, 1, 1);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(booleanArray24);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray7);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 0, (-1));
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray3 = new byte[][] { byteArray2 };
        byte[][] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray3);
        byte[][] byteArray7 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray4, 5, (int) (byte) 0);
        byte[] byteArray13 = new byte[] { (byte) 10, (byte) -1, (byte) 1, (byte) 0 };
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray13, (byte) 10, 1);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray13, (byte) -1);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray18, (byte) 0);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray18);
        try {
            byte[][] byteArray22 = org.apache.commons.lang3.ArrayUtils.add(byteArray4, (int) (short) 10, byteArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        java.lang.Integer[] intArray7 = org.apache.commons.lang3.ArrayUtils.toObject(intArray6);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) intArray7);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (byte) 1);
        double[] doubleArray3 = new double[] {};
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray3, (double) (-1.0f), (double) 1L);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) (short) 0, (int) (short) 100, (double) '4');
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray3);
        java.lang.Double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray3);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray12, (double) 100L);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray12, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray12);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray9, 3, (float) 100);
        java.lang.Class<?> wildcardClass14 = floatArray9.getClass();
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray9, (float) (short) 0, 3);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.clone(floatArray9);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray6, (byte) 0, (int) (short) 100);
        java.lang.Class<?> wildcardClass11 = byteArray6.getClass();
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray4, (short) (byte) 10, (int) (short) -1);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.remove(shortArray4, (int) (byte) 0);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray9);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) -1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, (int) '4', 4);
        java.lang.Character[] charArray11 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray11);
        char[] charArray18 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray18, '#');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.addAll(charArray12, charArray18);
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.add(charArray21, '4');
        char[] charArray26 = org.apache.commons.lang3.ArrayUtils.subarray(charArray23, (int) (byte) 1, 4);
        char[] charArray31 = new char[] { 'a', ' ', '4', '#' };
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray31, 'a');
        char[] charArray35 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray31, '4');
        char[] charArray41 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int43 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray41, '#');
        char[] charArray48 = new char[] { '#', ' ', '#', '4' };
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray41, charArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray35, charArray41);
        char[] charArray53 = org.apache.commons.lang3.ArrayUtils.add(charArray35, 3, ' ');
        char[] charArray54 = org.apache.commons.lang3.ArrayUtils.addAll(charArray26, charArray53);
        char[] charArray55 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray26);
        char[] charArray61 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int63 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray61, '#');
        char[] charArray64 = new char[] {};
        boolean boolean65 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray61, charArray64);
        boolean boolean67 = org.apache.commons.lang3.ArrayUtils.contains(charArray64, '#');
        char[] charArray68 = org.apache.commons.lang3.ArrayUtils.addAll(charArray4, charArray64);
        char[] charArray70 = org.apache.commons.lang3.ArrayUtils.add(charArray4, 'a');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertNotNull(charArray61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 4 + "'", int63 == 4);
        org.junit.Assert.assertNotNull(charArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(charArray68);
        org.junit.Assert.assertNotNull(charArray70);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray11, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray13);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray13);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (-1.0f));
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) 10.0f, 1, (double) 10.0f);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 4, 4, (double) 4);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray6, 10.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, (int) '#');
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray6, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray2, (byte) 100, (int) (short) -1);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray6, (float) (short) 0, (int) (byte) 10);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray6, (float) 1L);
        java.lang.Character[] charArray15 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray15);
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.subarray(charArray16, (int) '4', 4);
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.add(charArray19, 'a');
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) floatArray6, (java.lang.Object) charArray19);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        java.lang.Long[] longArray11 = org.apache.commons.lang3.ArrayUtils.toObject(longArray7);
        java.lang.Class<?> wildcardClass12 = longArray11.getClass();
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) shortArray0, (java.lang.Object[]) longArray11);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) longArray11);
        long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray11);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray11, (long) (short) 10);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray17);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray5, true);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, 3, (int) (short) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray11, false);
        boolean[] booleanArray16 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray11, (int) (short) 1, (int) (short) -1);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray16, true);
        boolean[] booleanArray24 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray25 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray24);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray25, true);
        boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray27);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray18, booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) "hi!");
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        java.lang.Short[] shortArray7 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.add(shortArray8, (short) 0);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray3, shortArray8);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray8, (short) 0);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(shortArray8, (short) 0);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray4);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray7, (short) (byte) 10);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray9, (short) 0);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray11, (short) (byte) 1, 0);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.clone(shortArray11);
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray15, 100, 3);
        short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.add(shortArray15, (short) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray20);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, (int) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray6);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.remove(intArray6, (int) (short) 1);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.subarray(intArray6, 6, (int) (short) 1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        char[] charArray5 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#');
        char[] charArray8 = new char[] {};
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray5, charArray8);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray8, ' ');
        try {
            char[] charArray13 = org.apache.commons.lang3.ArrayUtils.remove(charArray8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        java.lang.Double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        char[] charArray0 = null;
        try {
            char[] charArray3 = org.apache.commons.lang3.ArrayUtils.add(charArray0, 10, ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        float[] floatArray4 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 100, (int) '4');
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray4, (float) ' ', (int) 'a');
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.add(floatArray4, (float) (short) 100);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray12, (int) '4', (int) ' ');
        float[] floatArray22 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray22, (float) (short) 1);
        float[] floatArray27 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray24, (int) '#', (int) ' ');
        int int29 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray27, (float) '#');
        float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.clone(floatArray27);
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray15, floatArray27);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray8, (float) (byte) 0, (int) (short) 10);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray8, (int) (byte) 10, (int) (byte) -1);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.add(floatArray17, (float) 10L);
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray19, 0.0f);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.add(floatArray19, 100.0f);
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray19, (float) 100);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, 0.0f);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 100L);
        java.lang.Class<?> wildcardClass13 = floatArray8.getClass();
        java.lang.Float[] floatArray19 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray20, 1.0f);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray8, floatArray20);
        float[] floatArray24 = null;
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray20, floatArray24);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray0, (short) (byte) 100, 6);
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.add(shortArray0, (short) (byte) 10);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray5, (-1), 2);
        short[] shortArray13 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray13);
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray14, (short) 0);
        boolean[] booleanArray17 = new boolean[] {};
        boolean[] booleanArray22 = new boolean[] { true, false, false, true };
        boolean[] booleanArray23 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray17, booleanArray22);
        boolean[] booleanArray24 = new boolean[] {};
        boolean[] booleanArray29 = new boolean[] { true, false, false, true };
        boolean[] booleanArray30 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray24, booleanArray29);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray23, booleanArray29);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray23, true, 1);
        boolean[] booleanArray40 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray41 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray40);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray23, booleanArray40);
        int int43 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray14, (java.lang.Object) boolean42);
        byte[] byteArray46 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray47 = new byte[][] { byteArray46 };
        byte[][] byteArray48 = org.apache.commons.lang3.ArrayUtils.clone(byteArray47);
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray14, (java.lang.Object) byteArray48);
        short[] shortArray51 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray14, (short) (byte) 10);
        short[] shortArray53 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray14, (short) (byte) 10);
        boolean boolean54 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray53);
        try {
            short[] shortArray57 = org.apache.commons.lang3.ArrayUtils.add(shortArray5, 7, (short) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertNotNull(booleanArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(shortArray51);
        org.junit.Assert.assertNotNull(shortArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        java.lang.Byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, (int) (byte) -1, (int) (short) 100);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, (int) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray6);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.remove(intArray6, (int) (short) 1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray6, (int) 'a', (int) (short) -1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (byte) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (short) 10, (int) '4');
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray18, (int) 'a', 5);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0, (double) 2);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 10, (int) (byte) 1);
        java.lang.Double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray2);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) 2, (double) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) 0, (byte) 0, (byte) -1, (byte) 10, (byte) 0 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        byte[] byteArray7 = new byte[] {};
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.clone(byteArray7);
        byte[] byteArray9 = new byte[] {};
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.clone(byteArray9);
        java.lang.Byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray11);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray8, byteArray13);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray8);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.add(byteArray6, 0, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(byteArray18);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { (-1), (-1), 10 };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        int[] intArray10 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray10, 1);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray10, (int) ' ', (int) (short) 100);
        int[] intArray21 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray21, 1);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.addAll(intArray21, intArray24);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray10, intArray25);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray25, (int) (byte) 0);
        int[] intArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray25, 1);
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.add(intArray30, (int) '4');
        java.lang.Integer[] intArray36 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray38 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray36, 2);
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.addAll(intArray30, intArray38);
        int[] intArray41 = org.apache.commons.lang3.ArrayUtils.add(intArray38, (int) 'a');
        int int44 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray38, (int) (short) 1, (int) (short) 10);
        int[] intArray47 = org.apache.commons.lang3.ArrayUtils.subarray(intArray38, (int) '4', (int) (short) 0);
        int[] intArray48 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray38);
        boolean[][] booleanArray49 = null;
        java.lang.Integer[] intArray52 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray54 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray52, 0);
        boolean[][] booleanArray55 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray49, (java.lang.Object) intArray54);
        int[] intArray56 = org.apache.commons.lang3.ArrayUtils.addAll(intArray38, intArray54);
        try {
            int[] intArray58 = org.apache.commons.lang3.ArrayUtils.remove(intArray38, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNull(booleanArray55);
        org.junit.Assert.assertNotNull(intArray56);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        java.lang.Character[] charArray5 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, 'a');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray7, 'a');
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray7, 'a');
        java.lang.Character[] charArray12 = org.apache.commons.lang3.ArrayUtils.toObject(charArray7);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(charArray12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray8, (float) 3, (int) (short) -1);
        try {
            float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, (int) ' ', (float) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.clone(longArray12);
        java.lang.Short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray25 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray25, 100L, (int) '4');
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray25, (long) (byte) 10);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray18, (java.lang.Object) longArray30);
        long[] longArray32 = org.apache.commons.lang3.ArrayUtils.clone(longArray30);
        long[] longArray39 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray39, 100L, (int) '4');
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.subarray(longArray39, (int) (byte) 0, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray39);
        long[] longArray47 = org.apache.commons.lang3.ArrayUtils.addAll(longArray30, longArray39);
        long[] longArray50 = org.apache.commons.lang3.ArrayUtils.add(longArray39, 3, (long) (byte) 10);
        long[] longArray51 = org.apache.commons.lang3.ArrayUtils.addAll(longArray17, longArray50);
        java.lang.Short[] shortArray52 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray59 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int62 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray59, 100L, (int) '4');
        long[] longArray64 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray59, (long) (byte) 10);
        boolean boolean65 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray52, (java.lang.Object) longArray64);
        long[] longArray68 = org.apache.commons.lang3.ArrayUtils.subarray(longArray64, (int) (byte) 10, (int) (byte) 0);
        int int71 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray64, (long) (short) 100, (int) (short) -1);
        boolean boolean73 = org.apache.commons.lang3.ArrayUtils.contains(longArray64, (long) 1);
        int int75 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray64, (long) (byte) 10);
        long[] longArray76 = org.apache.commons.lang3.ArrayUtils.clone(longArray64);
        boolean boolean77 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray64);
        long[] longArray78 = org.apache.commons.lang3.ArrayUtils.addAll(longArray17, longArray64);
        java.lang.Long[] longArray79 = org.apache.commons.lang3.ArrayUtils.toObject(longArray78);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(longArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertNotNull(longArray47);
        org.junit.Assert.assertNotNull(longArray50);
        org.junit.Assert.assertNotNull(longArray51);
        org.junit.Assert.assertNotNull(shortArray52);
        org.junit.Assert.assertNotNull(longArray59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertNotNull(longArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(longArray68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(longArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(longArray78);
        org.junit.Assert.assertNotNull(longArray79);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.Short[] shortArray0 = new java.lang.Short[] {};
        java.lang.Short[] shortArray1 = new java.lang.Short[] {};
        java.lang.Short[] shortArray2 = new java.lang.Short[] {};
        java.lang.Short[] shortArray3 = new java.lang.Short[] {};
        java.lang.Short[][] shortArray4 = new java.lang.Short[][] { shortArray0, shortArray1, shortArray2, shortArray3 };
        java.lang.Short[][] shortArray7 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray4, (-1), (int) '#');
        double[] doubleArray8 = new double[] {};
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.add(doubleArray8, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray10);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray12, (double) (byte) 10);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray10, doubleArray14);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray14, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray14);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray14, (double) (byte) 100);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray14, (double) (short) 10, (int) '4');
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (short) 1);
        java.lang.Short[][] shortArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray4, (java.lang.Object) (short) 1);
        java.lang.Short[] shortArray32 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray32);
        short[] shortArray34 = new short[] {};
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray33, shortArray34);
        java.lang.Short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray33);
        short[] shortArray37 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray36);
        try {
            java.lang.Short[][] shortArray38 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, 100, shortArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertNotNull(shortArray33);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray37);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray1);
        boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray1, false);
        boolean[] booleanArray7 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray4, (int) '4', 4);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray7, true);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray7, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (short) -1, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray6);
        java.lang.String str13 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) doubleArray6, "{5}");
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{10.0}" + "'", str13.equals("{10.0}"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.Character[] charArray5 = new java.lang.Character[] { ' ', ' ', ' ', 'a', ' ' };
        java.lang.Character[] charArray11 = new java.lang.Character[] { ' ', ' ', ' ', 'a', ' ' };
        java.lang.Character[][] charArray12 = new java.lang.Character[][] { charArray5, charArray11 };
        java.lang.Character[] charArray18 = new java.lang.Character[] { '#', ' ', 'a', '#', ' ' };
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray18);
        java.lang.Character[][] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray12, charArray18);
        char[] charArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray18, 'a');
        java.lang.Integer[] intArray27 = new java.lang.Integer[] { 1, 4, 1, 3 };
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray27);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) charArray18, (java.lang.Object[]) intArray27);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        long[] longArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray0, (long) (short) 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (-1.0d), (double) '#');
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) 10.0f);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.Character[] charArray3 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray3);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.subarray(charArray4, (int) '4', 4);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray7, 'a');
        java.lang.Byte[] byteArray15 = new java.lang.Byte[] { (byte) 0, (byte) 0, (byte) -1, (byte) 10, (byte) 0 };
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray15);
        java.lang.Character[] charArray17 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray17);
        java.lang.Character[] charArray22 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray22);
        char[] charArray29 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray29, '#');
        char[] charArray32 = org.apache.commons.lang3.ArrayUtils.addAll(charArray23, charArray29);
        char[] charArray34 = org.apache.commons.lang3.ArrayUtils.add(charArray32, '4');
        char[] charArray37 = org.apache.commons.lang3.ArrayUtils.subarray(charArray34, (int) (byte) 1, 4);
        char[] charArray39 = org.apache.commons.lang3.ArrayUtils.add(charArray34, ' ');
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray34);
        char[] charArray41 = org.apache.commons.lang3.ArrayUtils.addAll(charArray18, charArray34);
        int int42 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray15, (java.lang.Object) charArray18);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray9, charArray18);
        char[] charArray44 = org.apache.commons.lang3.ArrayUtils.clone(charArray18);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(charArray44);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        boolean[] booleanArray5 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray6, true);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray13, true);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray20, 100);
        java.lang.String[] strArray24 = null;
        int[] intArray30 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int32 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray30, 1);
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray30, intArray33);
        java.lang.String[] strArray35 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray24, (java.lang.Object) intArray34);
        int[] intArray37 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray34, (int) '4');
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.contains(intArray34, 1);
        int int42 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray34, (int) (short) 0, 3);
        int[] intArray43 = org.apache.commons.lang3.ArrayUtils.addAll(intArray20, intArray34);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.contains(intArray34, 7);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNull(strArray35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 3 + "'", int42 == 3);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        char[] charArray4 = new char[] { 'a', ' ', '4', '#' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray4, 'a');
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray4, '4');
        java.lang.Character[] charArray9 = org.apache.commons.lang3.ArrayUtils.toObject(charArray4);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray4, 'a');
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.add(charArray4, (int) (byte) 1, '#');
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, ' ', 0);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (short) -1, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray6);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray28 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray28, 100L, (int) '4');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray28, (long) (byte) 10);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray21, (java.lang.Object) longArray33);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray33, (int) (byte) 10, (int) (byte) 0);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.add(longArray37, (long) (byte) 1);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) 100, 100);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray37);
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) 4, (int) (short) -1);
        java.lang.Short[] shortArray49 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray56 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int59 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray56, 100L, (int) '4');
        long[] longArray61 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray56, (long) (byte) 10);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray49, (java.lang.Object) longArray61);
        long[] longArray65 = org.apache.commons.lang3.ArrayUtils.subarray(longArray61, (int) (byte) 10, (int) (byte) 0);
        long[] longArray67 = org.apache.commons.lang3.ArrayUtils.add(longArray65, (long) (byte) 1);
        int int69 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray65, (long) '4');
        java.lang.Short[] shortArray70 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray77 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int80 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray77, 100L, (int) '4');
        long[] longArray82 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray77, (long) (byte) 10);
        boolean boolean83 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray70, (java.lang.Object) longArray82);
        long[] longArray86 = org.apache.commons.lang3.ArrayUtils.subarray(longArray82, (int) (byte) 10, (int) (byte) 0);
        long[] longArray88 = org.apache.commons.lang3.ArrayUtils.add(longArray86, (long) (byte) 1);
        int int90 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray86, (long) '4');
        int int93 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray86, (long) 100, 100);
        long[] longArray94 = org.apache.commons.lang3.ArrayUtils.addAll(longArray65, longArray86);
        long[] longArray95 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray94);
        long[] longArray96 = org.apache.commons.lang3.ArrayUtils.clone(longArray94);
        int int99 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray94, 0L, 100);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(longArray56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(longArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(longArray65);
        org.junit.Assert.assertNotNull(longArray67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(shortArray70);
        org.junit.Assert.assertNotNull(longArray77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 4 + "'", int80 == 4);
        org.junit.Assert.assertNotNull(longArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(longArray86);
        org.junit.Assert.assertNotNull(longArray88);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertNotNull(longArray94);
        org.junit.Assert.assertNotNull(longArray95);
        org.junit.Assert.assertNotNull(longArray96);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + (-1) + "'", int99 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 1, (double) (byte) 0);
        java.lang.Double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray11);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray12, (double) 100L);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray0);
        java.lang.Short[] shortArray5 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray7 = new short[] {};
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray7);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.clone(shortArray7);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 1);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray9);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray12, 10, 100);
        short[] shortArray20 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray20);
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray12, shortArray20);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray20);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.clone(intArray20);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.contains(intArray26, 100);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray26);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.add(longArray16, (long) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) '4');
        java.lang.Short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray28 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray28, 100L, (int) '4');
        long[] longArray33 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray28, (long) (byte) 10);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray21, (java.lang.Object) longArray33);
        long[] longArray37 = org.apache.commons.lang3.ArrayUtils.subarray(longArray33, (int) (byte) 10, (int) (byte) 0);
        long[] longArray39 = org.apache.commons.lang3.ArrayUtils.add(longArray37, (long) (byte) 1);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) '4');
        int int44 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray37, (long) 100, 100);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.addAll(longArray16, longArray37);
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) 4, (int) (short) -1);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.contains(longArray16, (long) 0);
        int int52 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray16, (long) (-1));
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(longArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) (byte) 10, (int) (byte) 0);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.remove(longArray12, 2);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray12);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        long[] longArray0 = null;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray8 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray8, 100L, (int) '4');
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray8, (long) (byte) 10);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray1, (java.lang.Object) longArray13);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.subarray(longArray13, (int) (byte) 10, (int) (byte) 0);
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray13, (long) (short) 100, (int) (short) -1);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(longArray13, (long) 1);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray13, (long) (byte) 10);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.clone(longArray13);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray13);
        long[] longArray27 = org.apache.commons.lang3.ArrayUtils.addAll(longArray0, longArray13);
        long[] longArray30 = org.apache.commons.lang3.ArrayUtils.subarray(longArray27, 6, 1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(longArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray30);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray6, true);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray6, true);
        java.lang.Boolean[] booleanArray19 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray18);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray18, false);
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray18, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertNotNull(booleanArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(booleanArray24);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) 10L);
        java.lang.Double[] doubleArray5 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray0);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 100.0f, (double) 1.0f);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) '4', (double) 4);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray12, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray14);
        double[] doubleArray16 = new double[] {};
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) (byte) 10);
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray14, doubleArray18);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) 1, (double) (byte) 0);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray18, doubleArray25);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) (-1.0f));
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray0, doubleArray18);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray18, 1.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, 100, 100 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (short) 100);
        int[] intArray6 = new int[] {};
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, (-1));
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 4, 2);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray6, 3);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray6);
        java.lang.String str15 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) intArray5);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0,100,100}" + "'", str15.equals("{0,100,100}"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.add(shortArray9, (short) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray9);
        int int13 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) shortArray9);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, 2);
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3, (int) (byte) 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray3);
        java.lang.String[] strArray9 = null;
        int[] intArray15 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray15, 1);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray15, intArray18);
        java.lang.String[] strArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray9, (java.lang.Object) intArray19);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray19, (int) '4');
        int[] intArray23 = org.apache.commons.lang3.ArrayUtils.addAll(intArray8, intArray19);
        java.lang.Integer[] intArray24 = org.apache.commons.lang3.ArrayUtils.toObject(intArray8);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.subarray(intArray8, (int) (byte) 1, (int) '#');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNull(strArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        char[] charArray5 = new char[] { ' ', '4', ' ', ' ', '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray5, '#');
        char[] charArray8 = new char[] {};
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray5, charArray8);
        java.lang.Character[] charArray13 = new java.lang.Character[] { '4', '#', 'a' };
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray13);
        java.lang.Character[] charArray15 = org.apache.commons.lang3.ArrayUtils.toObject(charArray14);
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray15);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray8, charArray16);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        java.lang.Double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray2);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (-1.0d), (int) (short) 0, (double) 3);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray10, (double) 10L);
        java.lang.Double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray10);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray10, (double) 100.0f, (double) 1.0f);
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray10, (double) '4', (double) 4);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.add(doubleArray22, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray24);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray28 = org.apache.commons.lang3.ArrayUtils.add(doubleArray26, (double) (byte) 10);
        double[] doubleArray29 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray24, doubleArray28);
        int int32 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray28, (double) 1, (double) (byte) 0);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray35 = org.apache.commons.lang3.ArrayUtils.add(doubleArray33, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray35);
        double[] doubleArray37 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray28, doubleArray35);
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray28, (double) (-1.0f));
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray10, doubleArray28);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray2, doubleArray10);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        int int45 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) -1, (double) 2);
        try {
            int int46 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) int45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "1", "1" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = org.apache.commons.lang3.ArrayUtils.subarray((java.lang.Comparable<java.lang.String>[]) strArray4, 10, (int) (short) -1);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strArray4, (java.lang.Object) (short) 1);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        long[] longArray5 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) '4');
        long[] longArray14 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray14, 100L, (int) '4');
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray14, (long) (byte) 10);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) longArray7, (java.lang.Object) longArray19);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray19, (long) 4, (int) '#');
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray19);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray25, (int) '4');
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray31, 2);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray25, intArray33);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.add(intArray33, (int) 'a');
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray33, (int) (short) 1, (int) (short) 10);
        int[] intArray42 = org.apache.commons.lang3.ArrayUtils.subarray(intArray33, (int) '4', (int) (short) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray42);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray23, true);
        int int30 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray23, true, 0);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray23, false);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray23, true);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.Byte[] byteArray0 = new java.lang.Byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) ' ', (int) (short) 100);
        int[] intArray16 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 1);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray5, intArray20);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray20, (int) (byte) 0);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray20, 1);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.clone(intArray20);
        int[] intArray32 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray32, 1);
        int int37 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray32, (int) ' ', (int) (short) 100);
        int[] intArray40 = org.apache.commons.lang3.ArrayUtils.add(intArray32, 1, (int) 'a');
        int[] intArray43 = org.apache.commons.lang3.ArrayUtils.subarray(intArray32, 0, 0);
        int[] intArray44 = org.apache.commons.lang3.ArrayUtils.addAll(intArray26, intArray32);
        int[] intArray49 = new int[] { ' ', '#', 0, '4' };
        int int51 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray49, 0);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray49);
        int[] intArray58 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int60 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray58, 1);
        int int63 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray58, (int) ' ', (int) (short) 100);
        int[] intArray69 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int71 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray69, 1);
        int[] intArray72 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray73 = org.apache.commons.lang3.ArrayUtils.addAll(intArray69, intArray72);
        boolean boolean74 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray58, intArray73);
        int int76 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray73, (int) (byte) 0);
        int[] intArray78 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray73, 1);
        int[] intArray80 = org.apache.commons.lang3.ArrayUtils.add(intArray78, (int) '4');
        java.lang.Integer[] intArray84 = new java.lang.Integer[] { 0, (-1), 2 };
        int[] intArray86 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray84, 2);
        int[] intArray87 = org.apache.commons.lang3.ArrayUtils.addAll(intArray78, intArray86);
        int[] intArray89 = org.apache.commons.lang3.ArrayUtils.add(intArray86, (int) 'a');
        int int91 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray86, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray86);
        boolean boolean93 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray49, intArray86);
        boolean boolean95 = org.apache.commons.lang3.ArrayUtils.contains(intArray49, (int) (byte) -1);
        int[] intArray96 = org.apache.commons.lang3.ArrayUtils.addAll(intArray32, intArray49);
        int[] intArray98 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray49, 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2 + "'", int76 == 2);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(intArray96);
        org.junit.Assert.assertNotNull(intArray98);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        long[] longArray7 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray7, 100L, (int) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (long) (byte) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray0, (java.lang.Object) longArray12);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.clone(longArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(longArray12, 100L);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray2, (double) (short) 100, (int) '#');
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) (short) 1, (int) (short) -1, 100.0d);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray2, (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) '4');
        java.lang.Double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray2);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray2);
        try {
            double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray2, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.Integer[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0);
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.contains(intArray1, (int) ' ');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.Long[] longArray3 = new java.lang.Long[] { 1L, 100L, 1L };
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray3);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray3);
        byte[] byteArray6 = new byte[] {};
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        byte[] byteArray8 = new byte[] {};
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray10);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray10);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray7, byteArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray7, (byte) -1);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, (int) (byte) 0, (int) (short) 1);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.add(byteArray18, (byte) -1);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray18, (byte) 0);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray3, (java.lang.Object) byteArray22, 2);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray22, (byte) 1);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int[] intArray4 = new int[] { ' ', '#', 0, '4' };
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray4, 0);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray4);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray4, (int) (byte) 10, (int) (short) 10);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.add(intArray4, (int) (byte) 10);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 0 };
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (-1L), 0, (double) (-1));
        double[] doubleArray19 = new double[] {};
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.add(doubleArray19, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray21);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray21, doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray25);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray27, (double) (byte) 10, 1, 0.0d);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray27);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) '4', (double) 1);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 2, (double) (short) 100);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray41 = org.apache.commons.lang3.ArrayUtils.add(doubleArray39, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray41);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray45 = org.apache.commons.lang3.ArrayUtils.add(doubleArray43, (double) (byte) 10);
        double[] doubleArray46 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray41, doubleArray45);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray45, (double) 3, (int) (byte) 0);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray6, doubleArray45);
        int int54 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray45, 0.0d, 6, (double) 100.0f);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, 10.0f);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray35 = org.apache.commons.lang3.ArrayUtils.add(doubleArray33, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray35);
        double[] doubleArray37 = new double[] {};
        double[] doubleArray39 = org.apache.commons.lang3.ArrayUtils.add(doubleArray37, (double) (byte) 10);
        double[] doubleArray40 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray35, doubleArray39);
        double[] doubleArray41 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray39);
        int int43 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) doubleArray39, (int) (short) 100);
        double[] doubleArray45 = org.apache.commons.lang3.ArrayUtils.add(doubleArray39, (double) 10);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (short) -1, 0);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray6);
        java.lang.Double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray6);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray13, (double) 100);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        byte[] byteArray0 = new byte[] {};
        byte[] byteArray1 = org.apache.commons.lang3.ArrayUtils.clone(byteArray0);
        byte[] byteArray2 = new byte[] {};
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray2);
        java.lang.Byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray4);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray1, byteArray6);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(byteArray7, (byte) 1);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray7, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(byteArray11);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.clone(intArray4);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, (int) 'a');
        int[] intArray13 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray13, 1);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray13, (int) ' ', (int) (short) 100);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.add(intArray13, 1, (int) 'a');
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.subarray(intArray13, 0, 0);
        int[] intArray25 = new int[] {};
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray25, 4, 2);
        int[] intArray32 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray25, 3);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray13, intArray25);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray25);
        int[] intArray35 = org.apache.commons.lang3.ArrayUtils.clone(intArray34);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        java.lang.Short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray0);
        java.lang.Short[] shortArray5 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray5);
        short[] shortArray7 = new short[] {};
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray7);
        java.lang.Short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray6);
        short[] shortArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray9, (short) (byte) 10);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray11, (short) 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray0, shortArray13);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray0, 3, (int) (byte) 10);
        java.lang.Class<?> wildcardClass18 = shortArray17.getClass();
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        float[] floatArray2 = new float[] { 100, 0.0f };
        float[] floatArray5 = new float[] { 100, 0.0f };
        float[] floatArray8 = new float[] { 100, 0.0f };
        float[] floatArray11 = new float[] { 100, 0.0f };
        float[][] floatArray12 = new float[][] { floatArray2, floatArray5, floatArray8, floatArray11 };
        float[] floatArray17 = new float[] { 'a', ' ', 10, (short) -1 };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray17, (int) (byte) 100, (int) '4');
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray17, (float) ' ', (int) 'a');
        float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.add(floatArray17, (float) (short) 100);
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray25, (int) '4', (int) ' ');
        float[][] floatArray29 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray12, (java.lang.Object) floatArray25);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) floatArray12);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 0, (-1) };
        int[] intArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray2, 0);
        int[] intArray5 = org.apache.commons.lang3.ArrayUtils.clone(intArray4);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, (int) 'a');
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 10);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray9);
        java.lang.Class<?> wildcardClass11 = intArray9.getClass();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 10.0f, 1.0f, 10.0f, 1.0f, 100.0f };
        float[] floatArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0.0f, (int) (byte) 10);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray10, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        double[] doubleArray14 = new double[] {};
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (double) (byte) 10);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray12, doubleArray16);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray16);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, 10.0d, 1, 100.0d);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (-1));
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (-1L), 0, (double) (-1));
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) floatArray5, (java.lang.Object) 0, (int) (byte) 0);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, 10.0f);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.contains(floatArray32, (float) 2);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_ARRAY;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray0, (short) (byte) 100, 6);
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.add(shortArray0, (short) (byte) 10);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray5, (-1), 2);
        short[] shortArray13 = new short[] { (byte) 0, (short) -1, (short) 100, (short) 10 };
        java.lang.Short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray13);
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray14, (short) 0);
        boolean[] booleanArray17 = new boolean[] {};
        boolean[] booleanArray22 = new boolean[] { true, false, false, true };
        boolean[] booleanArray23 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray17, booleanArray22);
        boolean[] booleanArray24 = new boolean[] {};
        boolean[] booleanArray29 = new boolean[] { true, false, false, true };
        boolean[] booleanArray30 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray24, booleanArray29);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray23, booleanArray29);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray23, true, 1);
        boolean[] booleanArray40 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray41 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray40);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray23, booleanArray40);
        int int43 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray14, (java.lang.Object) boolean42);
        byte[] byteArray46 = new byte[] { (byte) -1, (byte) 1 };
        byte[][] byteArray47 = new byte[][] { byteArray46 };
        byte[][] byteArray48 = org.apache.commons.lang3.ArrayUtils.clone(byteArray47);
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) shortArray14, (java.lang.Object) byteArray48);
        short[] shortArray51 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray14, (short) (byte) 10);
        short[] shortArray53 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray14, (short) (byte) 10);
        boolean boolean54 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray53);
        try {
            short[] shortArray57 = org.apache.commons.lang3.ArrayUtils.add(shortArray5, (int) (short) 100, (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(booleanArray40);
        org.junit.Assert.assertNotNull(booleanArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(shortArray51);
        org.junit.Assert.assertNotNull(shortArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int[] intArray5 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray5, 1);
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray8);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) '4');
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray5);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.subarray(intArray5, (int) (short) 0, 6);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray5, (int) 'a');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        java.lang.Float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray9);
        float[] floatArray17 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray17, (float) (short) 1);
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.clone(floatArray17);
        java.lang.Float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray20);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray10, (java.lang.Object[]) floatArray21);
        float[] floatArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) (byte) 0);
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) (byte) 0);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        java.lang.String[] strArray0 = null;
        int[] intArray6 = new int[] { 4, (short) -1, 0, (byte) 0, '#' };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray6, 1);
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray0, (java.lang.Object) intArray10);
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray10, (int) '4');
        java.lang.String str15 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) intArray10, "{5}");
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNull(strArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{4,-1,0,0,35}" + "'", str15.equals("{4,-1,0,0,35}"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        float[] floatArray18 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray18, (float) (short) 1);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray20, (int) '#', (int) ' ');
        float[] floatArray30 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray30, (float) (short) 1);
        float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.clone(floatArray30);
        java.lang.Float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray33);
        float[] floatArray41 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray43 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray41, (float) (short) 1);
        float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.clone(floatArray41);
        java.lang.Float[] floatArray45 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray44);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray34, (java.lang.Object[]) floatArray45);
        float[] floatArray48 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray34, (float) (byte) 0);
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray20, floatArray48);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) boolean11, (java.lang.Object) floatArray20);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.contains(floatArray20, (float) 10);
        boolean boolean54 = org.apache.commons.lang3.ArrayUtils.contains(floatArray20, 100.0f);
        try {
            int int55 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) boolean54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) (-1L), 0, (double) (-1));
        double[] doubleArray19 = new double[] {};
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.add(doubleArray19, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray21);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 10);
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray21, doubleArray25);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray25);
        int int31 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray27, (double) (byte) 10, 1, 0.0d);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray6, doubleArray27);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 0L, (double) 4);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (-1));
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, (double) (short) 1, (int) '4', (double) 6);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        float[] floatArray6 = new float[] { 0L, (byte) 1, 1, 1, (byte) 1, (short) 0 };
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray6, (float) (short) 1);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray9, (float) (byte) 10, (int) (byte) 10);
        float[] floatArray18 = new float[] { (-1), (byte) 10, (short) 100, 1L, 1.0f };
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, (int) (byte) 1, (int) '#');
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray9, floatArray18);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray18, (-1.0f), 5);
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray18, (int) (short) 10, 4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(floatArray28);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray2);
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray2, (double) (byte) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        short[] shortArray6 = new short[] {};
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray6);
        java.lang.Short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray5, (short) -1);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray0, (java.lang.Object) (short) -1);
        long[] longArray18 = new long[] { (byte) 10, (short) -1, 1, ' ', 100L, (-1) };
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray18, 100L, (int) '4');
        java.lang.Long[] longArray22 = org.apache.commons.lang3.ArrayUtils.toObject(longArray18);
        java.lang.Class<?> wildcardClass23 = longArray22.getClass();
        java.lang.Class<?>[] wildcardClassArray24 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        java.lang.Short[] shortArray28 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray28);
        short[] shortArray30 = new short[] {};
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray29, shortArray30);
        java.lang.Short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray29);
        int int34 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray29, (short) -1);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) wildcardClassArray24, (java.lang.Object) (short) -1);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) longArray22, (java.lang.Object[]) wildcardClassArray24);
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray37 = org.apache.commons.lang3.ArrayUtils.addAll((java.lang.reflect.GenericDeclaration[]) wildcardClassArray0, (java.lang.reflect.GenericDeclaration[]) wildcardClassArray24);
        boolean[] booleanArray38 = new boolean[] {};
        boolean[] booleanArray43 = new boolean[] { true, false, false, true };
        boolean[] booleanArray44 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray38, booleanArray43);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray43, true);
        boolean[] booleanArray49 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray43, 3, (int) (short) 10);
        int int51 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray43, false);
        int int53 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray43, true);
        int int54 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) wildcardClassArray24, (java.lang.Object) booleanArray43);
        boolean[] booleanArray55 = new boolean[] {};
        boolean[] booleanArray60 = new boolean[] { true, false, false, true };
        boolean[] booleanArray61 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray55, booleanArray60);
        boolean[] booleanArray62 = new boolean[] {};
        boolean[] booleanArray67 = new boolean[] { true, false, false, true };
        boolean[] booleanArray68 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray62, booleanArray67);
        boolean boolean69 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray61, booleanArray67);
        boolean boolean71 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray61, true);
        boolean[] booleanArray73 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray61, true);
        java.lang.Boolean[] booleanArray74 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray73);
        boolean[] booleanArray76 = org.apache.commons.lang3.ArrayUtils.add(booleanArray73, false);
        boolean[] booleanArray79 = new boolean[] { true, false };
        int int82 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray79, true, (int) '4');
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray79);
        boolean[] booleanArray86 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray79, 4, (int) (byte) 10);
        boolean[] booleanArray88 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray79, false);
        boolean boolean89 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray76, booleanArray88);
        int int90 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) wildcardClassArray24, (java.lang.Object) booleanArray88);
        org.junit.Assert.assertNotNull(wildcardClassArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClassArray24);
        org.junit.Assert.assertNotNull(shortArray28);
        org.junit.Assert.assertNotNull(shortArray29);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(genericDeclarationArray37);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(booleanArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(booleanArray55);
        org.junit.Assert.assertNotNull(booleanArray60);
        org.junit.Assert.assertNotNull(booleanArray61);
        org.junit.Assert.assertNotNull(booleanArray62);
        org.junit.Assert.assertNotNull(booleanArray67);
        org.junit.Assert.assertNotNull(booleanArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(booleanArray73);
        org.junit.Assert.assertNotNull(booleanArray74);
        org.junit.Assert.assertNotNull(booleanArray76);
        org.junit.Assert.assertNotNull(booleanArray79);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(booleanArray86);
        org.junit.Assert.assertNotNull(booleanArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] { (byte) 10 };
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray1);
        byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.clone(byteArray3);
        long[] longArray10 = new long[] { (short) 1, (short) 0, (short) 10, 1, 1 };
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.add(longArray10, (long) '4');
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.add(longArray12, (long) 4);
        java.lang.Long[] longArray15 = org.apache.commons.lang3.ArrayUtils.toObject(longArray14);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray14, (long) 4);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) byteArray3, (java.lang.Object) 4);
        try {
            byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.remove(byteArray3, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) -1, (byte) 1, (byte) 0 };
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray4, (byte) 10, 1);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray4, (byte) 1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray4, (int) (byte) 1, (byte) 100);
        java.lang.Object obj13 = null;
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) byteArray4, obj13);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) 10, (short) 100 };
        short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3);
        short[] shortArray5 = new short[] {};
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray4, shortArray5);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray7, (short) 1);
        java.lang.Short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray9);
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray10, (short) -1);
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { (-1), (-1), 10 };
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray16);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) shortArray10, (java.lang.Object[]) intArray16);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray10);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray19);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        java.lang.Double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray2);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray2, (double) 5, (int) '#');
        try {
            double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray23, true);
        int int30 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray23, true, 0);
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray23, true, 3);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray23, true, (int) (short) 1);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray2);
        double[] doubleArray4 = new double[] {};
        double[] doubleArray6 = org.apache.commons.lang3.ArrayUtils.add(doubleArray4, (double) (byte) 10);
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray2, doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray6, 10.0d, 1, 100.0d);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 10.0f, 100, (double) (byte) -1);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.add(doubleArray17, (double) (byte) 10);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray19, (double) (short) 100, (int) '#');
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray6, doubleArray19);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray19, (double) 100.0f, (int) '4', (double) 7);
        double[] doubleArray28 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray19);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray19, (double) (short) 10, (double) 6);
        double[] doubleArray32 = new double[] {};
        double[] doubleArray34 = org.apache.commons.lang3.ArrayUtils.add(doubleArray32, (double) (byte) 10);
        int int36 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray32, (double) 10L);
        java.lang.Double[] doubleArray37 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray32);
        int int40 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray32, (double) 100.0f, (double) 1.0f);
        int int43 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray32, (double) '4', (double) 4);
        double[] doubleArray44 = new double[] {};
        double[] doubleArray46 = org.apache.commons.lang3.ArrayUtils.add(doubleArray44, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray46);
        double[] doubleArray48 = new double[] {};
        double[] doubleArray50 = org.apache.commons.lang3.ArrayUtils.add(doubleArray48, (double) (byte) 10);
        double[] doubleArray51 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray46, doubleArray50);
        int int54 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray50, (double) 1, (double) (byte) 0);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray57 = org.apache.commons.lang3.ArrayUtils.add(doubleArray55, (double) (byte) 10);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray57);
        double[] doubleArray59 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray50, doubleArray57);
        int int61 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray50, (double) (-1.0f));
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray32, doubleArray50);
        double[] doubleArray63 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray50);
        double[] doubleArray64 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray19, doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        boolean[] booleanArray0 = new boolean[] {};
        boolean[] booleanArray5 = new boolean[] { true, false, false, true };
        boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray0, booleanArray5);
        boolean[] booleanArray7 = new boolean[] {};
        boolean[] booleanArray12 = new boolean[] { true, false, false, true };
        boolean[] booleanArray13 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray7, booleanArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray12);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray6, true, 1);
        boolean[] booleanArray23 = new boolean[] { false, true, true, false, false };
        java.lang.Boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray23);
        boolean[] booleanArray28 = new boolean[] { true, false };
        int int31 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray28, true, (int) '4');
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray28, false, (int) (byte) 0);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray28, false);
        boolean[] booleanArray39 = new boolean[] { true, false };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray39, true, (int) '4');
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray28, booleanArray39);
        boolean[] booleanArray45 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray39, false);
        boolean[] booleanArray46 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray6, booleanArray45);
        boolean[] booleanArray47 = new boolean[] {};
        boolean[] booleanArray52 = new boolean[] { true, false, false, true };
        boolean[] booleanArray53 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray47, booleanArray52);
        int int55 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray52, false);
        boolean[] booleanArray56 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray52);
        boolean[] booleanArray58 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray52, false);
        boolean[] booleanArray59 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray52);
        boolean boolean60 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray6, booleanArray59);
        java.lang.Boolean[] booleanArray61 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray6);
        boolean[] booleanArray62 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray61);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray7);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(booleanArray45);
        org.junit.Assert.assertNotNull(booleanArray46);
        org.junit.Assert.assertNotNull(booleanArray47);
        org.junit.Assert.assertNotNull(booleanArray52);
        org.junit.Assert.assertNotNull(booleanArray53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(booleanArray56);
        org.junit.Assert.assertNotNull(booleanArray58);
        org.junit.Assert.assertNotNull(booleanArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(booleanArray61);
        org.junit.Assert.assertNotNull(booleanArray62);
    }
}

