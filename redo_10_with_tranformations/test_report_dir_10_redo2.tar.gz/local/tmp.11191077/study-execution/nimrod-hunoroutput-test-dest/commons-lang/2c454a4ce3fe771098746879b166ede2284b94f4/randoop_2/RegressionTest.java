import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ RegressionTest0.class, RegressionTest1.class, RegressionTest2.class, RegressionTest3.class, RegressionTest4.class, RegressionTest5.class, RegressionTest6.class, RegressionTest7.class, RegressionTest8.class, RegressionTest9.class, RegressionTest10.class, RegressionTest11.class, RegressionTest12.class, RegressionTest13.class, RegressionTest14.class, RegressionTest15.class, RegressionTest16.class })
public class RegressionTest {
}

