import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.Class<?> wildcardClass10 = strArray6.getClass();
        java.lang.String[][] strArray11 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.String[][] strArray11 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray10);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.ISO8859_1_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.Class<?> wildcardClass3 = strArray0.getClass();
        java.lang.Class<?> wildcardClass4 = strArray0.getClass();
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass6 = strArray0.getClass();
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray7);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray9);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray7);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.Class<?> wildcardClass10 = strArray9.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass8 = strArray4.getClass();
        java.lang.Class<?> wildcardClass9 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_UNESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass3 = strArray0.getClass();
        java.lang.Class<?> wildcardClass4 = strArray0.getClass();
        java.lang.Class<?> wildcardClass5 = strArray0.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.Class<?> wildcardClass11 = strArray10.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        java.lang.Class<?> wildcardClass7 = strArray5.getClass();
        java.lang.Class<?> wildcardClass8 = strArray5.getClass();
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray9);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray7);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.Class<?> wildcardClass10 = strArray9.getClass();
        java.lang.Class<?> wildcardClass11 = strArray9.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.ISO8859_1_ESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass3 = strArray0.getClass();
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.Class<?> wildcardClass3 = strArray0.getClass();
        java.lang.Class<?> wildcardClass4 = strArray0.getClass();
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.Class<?> wildcardClass8 = strArray6.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        java.lang.Class<?> wildcardClass7 = strArray5.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.Class<?> wildcardClass8 = strArray6.getClass();
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_UNESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.Class<?> wildcardClass6 = strArray4.getClass();
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray7);
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.Class<?> wildcardClass11 = strArray10.getClass();
        java.lang.String[][] strArray12 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray10);
        java.lang.Class<?> wildcardClass13 = strArray10.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.Class<?> wildcardClass3 = strArray0.getClass();
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        java.lang.Class<?> wildcardClass8 = strArray7.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.Class<?> wildcardClass7 = strArray5.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        java.lang.Class<?> wildcardClass9 = strArray5.getClass();
        java.lang.Class<?> wildcardClass10 = strArray5.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.Class<?> wildcardClass3 = strArray0.getClass();
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray7);
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        java.lang.Class<?> wildcardClass10 = strArray8.getClass();
        java.lang.String[][] strArray11 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.Class<?> wildcardClass9 = strArray6.getClass();
        java.lang.Class<?> wildcardClass10 = strArray6.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.Class<?> wildcardClass3 = strArray1.getClass();
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray9);
        java.lang.String[][] strArray11 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray9);
        java.lang.String[][] strArray12 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray9);
        java.lang.String[][] strArray13 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray9);
        java.lang.String[][] strArray14 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray13);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray14);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.Class<?> wildcardClass9 = strArray6.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass5 = strArray0.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.Class<?> wildcardClass3 = strArray0.getClass();
        java.lang.Class<?> wildcardClass4 = strArray0.getClass();
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass7 = strArray0.getClass();
        java.lang.Class<?> wildcardClass8 = strArray0.getClass();
        java.lang.Class<?> wildcardClass9 = strArray0.getClass();
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.Class<?> wildcardClass8 = strArray6.getClass();
        java.lang.Class<?> wildcardClass9 = strArray6.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.Class<?> wildcardClass8 = strArray7.getClass();
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray7);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.Class<?> wildcardClass3 = strArray1.getClass();
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_UNESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.BASIC_UNESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass3 = strArray0.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.String[][] strArray11 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.Class<?> wildcardClass12 = strArray11.getClass();
        java.lang.Class<?> wildcardClass13 = strArray11.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.Class<?> wildcardClass3 = strArray1.getClass();
        java.lang.Class<?> wildcardClass4 = strArray1.getClass();
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.ISO8859_1_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.Class<?> wildcardClass3 = strArray0.getClass();
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.Class<?> wildcardClass4 = strArray1.getClass();
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.Class<?> wildcardClass7 = strArray5.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.ISO8859_1_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass7 = strArray4.getClass();
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass10 = strArray9.getClass();
        java.lang.String[][] strArray11 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray9);
        java.lang.Class<?> wildcardClass12 = strArray9.getClass();
        java.lang.String[][] strArray13 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray9);
        java.lang.String[][] strArray14 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray9);
        java.lang.Class<?> wildcardClass15 = strArray9.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass6 = strArray4.getClass();
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.APOS_UNESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.Class<?> wildcardClass6 = strArray3.getClass();
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.Class<?> wildcardClass8 = strArray7.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_UNESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.Class<?> wildcardClass5 = strArray0.getClass();
        java.lang.Class<?> wildcardClass6 = strArray0.getClass();
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray3);
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray7);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray8);
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray9);
        java.lang.String[][] strArray11 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray10);
        java.lang.Class<?> wildcardClass12 = strArray10.getClass();
        java.lang.Class<?> wildcardClass13 = strArray10.getClass();
        java.lang.Class<?> wildcardClass14 = strArray10.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.JAVA_CTRL_CHARS_UNESCAPE();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray3 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray4 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray4);
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        java.lang.Class<?> wildcardClass8 = strArray5.getClass();
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        java.lang.String[][] strArray10 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray5);
        java.lang.Class<?> wildcardClass11 = strArray5.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        java.lang.String[][] strArray0 = org.apache.commons.lang3.text.translate.EntityArrays.HTML40_EXTENDED_ESCAPE();
        java.lang.String[][] strArray1 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray0);
        java.lang.String[][] strArray2 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray1);
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        java.lang.String[][] strArray5 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray6 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray2);
        java.lang.String[][] strArray7 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray6);
        java.lang.String[][] strArray8 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray7);
        java.lang.String[][] strArray9 = org.apache.commons.lang3.text.translate.EntityArrays.invert(strArray7);
        java.lang.Class<?> wildcardClass10 = strArray9.getClass();
        java.lang.Class<?> wildcardClass11 = strArray9.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }
}

