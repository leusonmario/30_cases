import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.Object obj0 = null;
        java.lang.String str2 = org.apache.commons.lang3.ArrayUtils.toString(obj0, "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double[] doubleArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.apache.commons.lang3.ArrayUtils.INDEX_NOT_FOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        byte[] byteArray0 = null;
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray0, (int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertNull(byteArray3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        float[] floatArray1 = new float[] { 'a' };
        try {
            float[] floatArray4 = org.apache.commons.lang3.ArrayUtils.add(floatArray1, 10, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.Object obj0 = null;
        int int1 = org.apache.commons.lang3.ArrayUtils.getLength(obj0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        boolean[] booleanArray5 = new boolean[] { false, true, false, false, true };
        try {
            boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (short) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long[] longArray4 = new long[] { 100L, 4, (-1), (short) 0 };
        try {
            long[] longArray6 = org.apache.commons.lang3.ArrayUtils.remove(longArray4, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.Object obj0 = null;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4, (short) (byte) -1);
        short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4);
        try {
            boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameType(obj0, (java.lang.Object) shortArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        char[][] charArray0 = new char[][] {};
        char[][] charArray3 = org.apache.commons.lang3.ArrayUtils.subarray(charArray0, (int) (short) 0, (int) '4');
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray0);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        char[][][] charArray0 = new char[][][] {};
        char[][] charArray2 = new char[][] {};
        char[][] charArray5 = org.apache.commons.lang3.ArrayUtils.subarray(charArray2, (int) (short) 0, (int) '4');
        try {
            char[][][] charArray6 = org.apache.commons.lang3.ArrayUtils.add(charArray0, 4, charArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        float[] floatArray4 = new float[] { (short) 10, 100.0f, (byte) 10, (-1) };
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray4, (float) 10L);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap7 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) strComparableArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, 'hi!', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        boolean[] booleanArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray0, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double[] doubleArray0 = new double[] {};
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (-1));
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double[] doubleArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (-1L), 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        boolean[] booleanArray0 = new boolean[] {};
        try {
            boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.add(booleanArray0, (int) '#', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        java.lang.String str14 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) boolean12, "");
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "false" + "'", str14.equals("false"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        int[] intArray6 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray10 = new int[] { '4', 1, ' ' };
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.addAll(intArray6, intArray10);
        int[] intArray16 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray20 = new int[] { '4', 1, ' ' };
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.addAll(intArray16, intArray20);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.addAll(intArray11, intArray21);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray11, 10, (int) (short) 1);
        try {
            java.lang.Object[] objArray26 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Object[]) shortArray0, 0, (java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: array element type mismatch");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray11, (double) (byte) 0, (int) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        try {
            int[] intArray14 = org.apache.commons.lang3.ArrayUtils.add(intArray11, 6, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.Boolean[] booleanArray0 = null;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray0);
        org.junit.Assert.assertNull(booleanArray1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Byte[] byteArray0 = new java.lang.Byte[] {};
        java.lang.Byte[] byteArray1 = new java.lang.Byte[] {};
        java.lang.Byte[] byteArray2 = new java.lang.Byte[] {};
        java.lang.Byte[][] byteArray3 = new java.lang.Byte[][] { byteArray0, byteArray1, byteArray2 };
        try {
            java.lang.Byte[][] byteArray5 = org.apache.commons.lang3.ArrayUtils.remove(byteArray3, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double[] doubleArray0 = null;
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray0, (double) 4);
        org.junit.Assert.assertNull(doubleArray2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        char[] charArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray0, '4', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray7, 1, (int) (byte) 10);
        try {
            float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.add(floatArray10, (int) ' ', (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int[] intArray0 = null;
        int[] intArray3 = org.apache.commons.lang3.ArrayUtils.subarray(intArray0, (int) (byte) 100, 100);
        org.junit.Assert.assertNull(intArray3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        try {
            long[] longArray9 = org.apache.commons.lang3.ArrayUtils.remove(longArray7, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 10, (byte) 10 };
        try {
            byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.add(byteArray5, (int) (byte) 10, (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        byte[] byteArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray0, (byte) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double[] doubleArray5 = new double[] { '4', 0.0f, 0.0f, 'a', (short) 100 };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray5, (double) 4, (double) (byte) 1);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray5);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray5, (double) (short) -1, (int) (byte) 10);
        try {
            double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.add(doubleArray5, 6, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        try {
            char[] charArray5 = org.apache.commons.lang3.ArrayUtils.remove(charArray2, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        try {
            char[] charArray6 = org.apache.commons.lang3.ArrayUtils.remove(charArray2, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray2 = new java.lang.Comparable[1][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray3 = (java.lang.Comparable<java.lang.String>[][]) comparableArray2;
        strComparableArray3[0] = strArray0;
        java.lang.String[] strArray6 = new java.lang.String[] {};
        java.lang.String[] strArray7 = new java.lang.String[] {};
        java.lang.String[] strArray8 = new java.lang.String[] {};
        java.lang.String[] strArray9 = new java.lang.String[] {};
        java.lang.String[] strArray10 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray12 = new java.lang.Comparable[5][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray13 = (java.lang.Comparable<java.lang.String>[][]) comparableArray12;
        strComparableArray13[0] = strArray6;
        strComparableArray13[1] = strArray7;
        strComparableArray13[2] = strArray8;
        strComparableArray13[3] = strArray9;
        strComparableArray13[4] = strArray10;
        java.lang.Comparable<java.lang.String>[][] strComparableArray24 = org.apache.commons.lang3.ArrayUtils.addAll(strComparableArray3, strComparableArray13);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap25 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) strComparableArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '[Ljava.lang.String;@766ab25b', has a length less than 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(strComparableArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(comparableArray12);
        org.junit.Assert.assertNotNull(strComparableArray13);
        org.junit.Assert.assertNotNull(strComparableArray24);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray4, (-1), (int) (short) 0);
        java.lang.String str18 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) (short) 0, "hi!");
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        char[] charArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(charArray0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, 0, (byte) 100);
        try {
            byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (int) (byte) 100, (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray4, (java.lang.Object) floatArray10);
        byte[] byteArray18 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains(byteArray18, (byte) 10);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.clone(byteArray18);
        try {
            java.io.Serializable[] serializableArray22 = org.apache.commons.lang3.ArrayUtils.add((java.io.Serializable[]) strArray4, (java.io.Serializable) byteArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayStoreException; message: [B");
        } catch (java.lang.ArrayStoreException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(byteArray21);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray2 = new java.lang.Comparable[1][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray3 = (java.lang.Comparable<java.lang.String>[][]) comparableArray2;
        strComparableArray3[0] = strArray0;
        java.lang.String[] strArray6 = new java.lang.String[] {};
        java.lang.String[] strArray7 = new java.lang.String[] {};
        java.lang.String[] strArray8 = new java.lang.String[] {};
        java.lang.String[] strArray9 = new java.lang.String[] {};
        java.lang.String[] strArray10 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray12 = new java.lang.Comparable[5][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray13 = (java.lang.Comparable<java.lang.String>[][]) comparableArray12;
        strComparableArray13[0] = strArray6;
        strComparableArray13[1] = strArray7;
        strComparableArray13[2] = strArray8;
        strComparableArray13[3] = strArray9;
        strComparableArray13[4] = strArray10;
        java.lang.Comparable<java.lang.String>[][] strComparableArray24 = org.apache.commons.lang3.ArrayUtils.addAll(strComparableArray3, strComparableArray13);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isEmpty(strComparableArray13);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(strComparableArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(comparableArray12);
        org.junit.Assert.assertNotNull(strComparableArray13);
        org.junit.Assert.assertNotNull(strComparableArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        try {
            byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray6, (int) (byte) -1, (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.add(floatArray7, (float) (-1L));
        int int10 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) floatArray9);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        float[] floatArray0 = null;
        float[] floatArray1 = org.apache.commons.lang3.ArrayUtils.clone(floatArray0);
        org.junit.Assert.assertNull(floatArray1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 1.0d, 10.0d, 0.0d, 0.0d, 0.0d, 1.0d };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray8, (double) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray6, (int) (byte) 1, ' ');
        try {
            char[] charArray12 = org.apache.commons.lang3.ArrayUtils.add(charArray6, 10, '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 0);
        try {
            byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.remove(byteArray9, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        int int46 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray36, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray48 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray36, (short) (byte) 1);
        java.lang.Short[] shortArray52 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray54 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray52, (short) (byte) -1);
        short[] shortArray57 = new short[] { (byte) 100, (byte) 100 };
        int int60 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray57, (short) (byte) 10, (int) (byte) 1);
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray54, shortArray57);
        short[] shortArray62 = org.apache.commons.lang3.ArrayUtils.clone(shortArray57);
        boolean boolean63 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray48, shortArray57);
        short[] shortArray64 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray23, shortArray57);
        short[] shortArray65 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray17, shortArray57);
        int int66 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) shortArray65);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(shortArray48);
        org.junit.Assert.assertNotNull(shortArray52);
        org.junit.Assert.assertNotNull(shortArray54);
        org.junit.Assert.assertNotNull(shortArray57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(shortArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(shortArray64);
        org.junit.Assert.assertNotNull(shortArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 5 + "'", int66 == 5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray4, 4);
        try {
            int[] intArray16 = org.apache.commons.lang3.ArrayUtils.add(intArray4, (-1), 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.add(charArray2, 'a');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        long[] longArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray0, (long) 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.Byte[] byteArray0 = null;
        byte[] byteArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0, (byte) 1);
        org.junit.Assert.assertNull(byteArray2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        boolean[] booleanArray0 = null;
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray0, (int) ' ', (int) '#');
        org.junit.Assert.assertNull(booleanArray3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        char[] charArray6 = new char[] { '4', '4', 'a', '4', '4', ' ' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray6, (int) (short) 0, '#');
        org.apache.commons.lang3.ArrayUtils.reverse(charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray4, (java.lang.Object) floatArray10);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean[] booleanArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray0, false, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int[] intArray0 = null;
        try {
            int[] intArray3 = org.apache.commons.lang3.ArrayUtils.add(intArray0, (int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (short) 1, (int) (short) 100);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray10, (float) 5, 1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.Float[] floatArray4 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        try {
            float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (-1), (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Long[] longArray6 = new java.lang.Long[] { (-1L), 0L, 100L, 100L, 1L, 100L };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        try {
            long[] longArray9 = org.apache.commons.lang3.ArrayUtils.remove(longArray7, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        char[] charArray6 = new char[] { '4', '4', 'a', '4', '4', ' ' };
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray6, (int) (short) 0, '#');
        try {
            char[] charArray11 = org.apache.commons.lang3.ArrayUtils.remove(charArray6, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray9);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int[] intArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(intArray0, 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.Boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY;
        org.junit.Assert.assertNotNull(booleanArray0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(floatArray0, (float) 4);
        try {
            float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.add(floatArray0, (int) (byte) 1, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 0);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray12, (byte) 10, (int) (byte) 10);
        try {
            byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.add(byteArray12, (int) (byte) 100, (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 7");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        int int46 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray36, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray48 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray36, (short) (byte) 1);
        java.lang.Short[] shortArray52 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray54 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray52, (short) (byte) -1);
        short[] shortArray57 = new short[] { (byte) 100, (byte) 100 };
        int int60 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray57, (short) (byte) 10, (int) (byte) 1);
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray54, shortArray57);
        short[] shortArray62 = org.apache.commons.lang3.ArrayUtils.clone(shortArray57);
        boolean boolean63 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray48, shortArray57);
        short[] shortArray64 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray23, shortArray57);
        short[] shortArray65 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray17, shortArray57);
        try {
            short[] shortArray68 = org.apache.commons.lang3.ArrayUtils.add(shortArray65, 100, (short) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(shortArray48);
        org.junit.Assert.assertNotNull(shortArray52);
        org.junit.Assert.assertNotNull(shortArray54);
        org.junit.Assert.assertNotNull(shortArray57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(shortArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(shortArray64);
        org.junit.Assert.assertNotNull(shortArray65);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.String str2 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) 1L, "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        char[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHAR_ARRAY;
        try {
            char[] charArray3 = org.apache.commons.lang3.ArrayUtils.add(charArray0, (int) (short) 100, '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        java.lang.Object obj1 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) charArray0, obj1, 5);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.add(floatArray7, (float) (-1L));
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(floatArray7, 1.0f);
        try {
            float[] floatArray14 = org.apache.commons.lang3.ArrayUtils.add(floatArray7, 10, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        long[] longArray1 = new long[] { (short) 1 };
        java.lang.Long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toObject(longArray1);
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        try {
            long[] longArray6 = org.apache.commons.lang3.ArrayUtils.add(longArray3, (int) (short) 100, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, 1);
        byte[] byteArray23 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains(byteArray23, (byte) 10);
        java.lang.Byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray23);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) intArray14, (java.lang.Object) byteArray26);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 1.0d, 10.0d, 0.0d, 0.0d, 0.0d, 1.0d };
        double[] doubleArray35 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray34);
        double[] doubleArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray34);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray36, (double) (byte) 10, 0.0d);
        int int40 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) intArray14, (java.lang.Object) int39);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        try {
            long[] longArray9 = org.apache.commons.lang3.ArrayUtils.remove(longArray7, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.subarray(charArray2, (int) (short) 100, (int) (short) 10);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.clone(charArray2);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(charArray7, '4');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) (byte) -1);
        short[] shortArray21 = new short[] { (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) (byte) 10, (int) (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray18, shortArray21);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray18, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray18, (short) (byte) 1);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        java.lang.Short[] shortArray47 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray49 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray47, (short) (byte) -1);
        short[] shortArray52 = new short[] { (byte) 100, (byte) 100 };
        int int55 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray52, (short) (byte) 10, (int) (byte) 1);
        boolean boolean56 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray49, shortArray52);
        int int59 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray49, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray61 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray49, (short) (byte) 1);
        java.lang.Short[] shortArray65 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray67 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray65, (short) (byte) -1);
        short[] shortArray70 = new short[] { (byte) 100, (byte) 100 };
        int int73 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray70, (short) (byte) 10, (int) (byte) 1);
        boolean boolean74 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray67, shortArray70);
        short[] shortArray75 = org.apache.commons.lang3.ArrayUtils.clone(shortArray70);
        boolean boolean76 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray61, shortArray70);
        short[] shortArray77 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray36, shortArray70);
        short[] shortArray78 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray30, shortArray70);
        short[] shortArray79 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray78);
        short[] shortArray80 = org.apache.commons.lang3.ArrayUtils.clone(shortArray79);
        int int82 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray79, (short) 0);
        try {
            short[] shortArray85 = org.apache.commons.lang3.ArrayUtils.add(shortArray79, (int) (short) -1, (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 8");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shortArray47);
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(shortArray52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(shortArray61);
        org.junit.Assert.assertNotNull(shortArray65);
        org.junit.Assert.assertNotNull(shortArray67);
        org.junit.Assert.assertNotNull(shortArray70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(shortArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(shortArray77);
        org.junit.Assert.assertNotNull(shortArray78);
        org.junit.Assert.assertNotNull(shortArray79);
        org.junit.Assert.assertNotNull(shortArray80);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 5 + "'", int82 == 5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) 1, (-1));
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray4, 1, (int) (short) 10);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        try {
            boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.add(booleanArray8, (int) '4', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        short[] shortArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, 'a');
        char[] charArray5 = new char[] { 'a', '4' };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray5);
        java.lang.Character[] charArray7 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray2, charArray9);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray10);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        short[] shortArray0 = null;
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray0, (int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertNull(shortArray3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        short[] shortArray31 = org.apache.commons.lang3.ArrayUtils.clone(shortArray26);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray26);
        try {
            short[] shortArray35 = org.apache.commons.lang3.ArrayUtils.add(shortArray26, (int) ' ', (short) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray0, (int) (byte) 1, (int) (short) 100);
        float[] floatArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 1, (int) (short) 100);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray0, floatArray4);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray4, (float) (short) -1, 3);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.Boolean[] booleanArray2 = new java.lang.Boolean[] { false, false };
        boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray2, true);
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 3, 5 };
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray7);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) booleanArray2, (java.lang.Object) intArray7);
        java.lang.String[] strArray10 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray12 = new java.lang.Comparable[1][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray13 = (java.lang.Comparable<java.lang.String>[][]) comparableArray12;
        strComparableArray13[0] = strArray10;
        java.lang.String[] strArray16 = new java.lang.String[] {};
        java.lang.String[] strArray17 = new java.lang.String[] {};
        java.lang.String[] strArray18 = new java.lang.String[] {};
        java.lang.String[] strArray19 = new java.lang.String[] {};
        java.lang.String[] strArray20 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray22 = new java.lang.Comparable[5][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray23 = (java.lang.Comparable<java.lang.String>[][]) comparableArray22;
        strComparableArray23[0] = strArray16;
        strComparableArray23[1] = strArray17;
        strComparableArray23[2] = strArray18;
        strComparableArray23[3] = strArray19;
        strComparableArray23[4] = strArray20;
        java.lang.Comparable<java.lang.String>[][] strComparableArray34 = org.apache.commons.lang3.ArrayUtils.addAll(strComparableArray13, strComparableArray23);
        int int35 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) booleanArray2, (java.lang.Object) strComparableArray23);
        java.lang.Long[] longArray42 = new java.lang.Long[] { (-1L), 0L, 100L, 100L, 1L, 100L };
        long[] longArray43 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray42);
        long[] longArray45 = org.apache.commons.lang3.ArrayUtils.add(longArray43, (long) (byte) 100);
        java.lang.Object[][] objArray46 = org.apache.commons.lang3.ArrayUtils.removeElement((java.lang.Object[][]) strComparableArray23, (java.lang.Object) longArray43);
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(comparableArray12);
        org.junit.Assert.assertNotNull(strComparableArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(comparableArray22);
        org.junit.Assert.assertNotNull(strComparableArray23);
        org.junit.Assert.assertNotNull(strComparableArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(longArray42);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertNotNull(objArray46);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray4, (java.lang.Object) floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray10, (float) 10);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray10, (float) (short) 0, 2);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(floatArray10, (float) (short) 10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        char[] charArray0 = null;
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.clone(charArray0);
        org.junit.Assert.assertNull(charArray1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        boolean[] booleanArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        char[] charArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray0, '#', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (short) 1, (int) (short) 100);
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.remove(floatArray10, (int) (byte) 1);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray10, (float) '#');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        try {
            int[] intArray16 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.lang.Short[] shortArray0 = new java.lang.Short[] {};
        java.lang.Short[] shortArray1 = new java.lang.Short[] {};
        java.lang.Short[] shortArray2 = new java.lang.Short[] {};
        java.lang.Short[] shortArray3 = new java.lang.Short[] {};
        java.lang.Short[][] shortArray4 = new java.lang.Short[][] { shortArray0, shortArray1, shortArray2, shortArray3 };
        java.lang.Short[][] shortArray5 = org.apache.commons.lang3.ArrayUtils.clone(shortArray4);
        java.lang.Short[] shortArray10 = new java.lang.Short[] { (short) 100, (short) 10, (short) 0 };
        short[] shortArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray10, (short) (byte) 100);
        try {
            java.lang.Short[][] shortArray13 = org.apache.commons.lang3.ArrayUtils.add(shortArray4, (int) (byte) 100, shortArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray10);
        org.junit.Assert.assertNotNull(shortArray12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray19);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.remove(intArray20, (int) (short) 1);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray22, 0);
        try {
            int[] intArray26 = org.apache.commons.lang3.ArrayUtils.remove(intArray24, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 13");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        char[] charArray2 = new char[] { '#', '4' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.subarray(charArray2, 100, 5);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray5);
        try {
            char[] charArray8 = org.apache.commons.lang3.ArrayUtils.remove(charArray5, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.add(intArray9, 1, (int) (byte) 1);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray12, (int) '#', (int) '#');
        try {
            int int16 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.Integer[] intArray0 = null;
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0, 5);
        org.junit.Assert.assertNull(intArray2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        long[] longArray0 = null;
        try {
            long[] longArray2 = org.apache.commons.lang3.ArrayUtils.remove(longArray0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        char[] charArray0 = new char[] {};
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.add(charArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#');
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#', 4);
        try {
            char[] charArray10 = org.apache.commons.lang3.ArrayUtils.add(charArray0, (int) (short) 100, '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double[] doubleArray0 = null;
        int int4 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 3, 0, 1.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        byte[] byteArray0 = null;
        byte[] byteArray3 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray0, (int) (byte) 100, 10);
        org.junit.Assert.assertNull(byteArray3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        byte[] byteArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray0, (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (-1L));
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 3, (double) (short) 10);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) '4');
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, (double) ' ', 100);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) 7);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 10);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray3, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, 10, (int) (short) 100);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray7);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) charArray2, (java.lang.Object) byteArray11);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.subarray(charArray2, (int) (short) 1, 0);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray2, '4');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Class<?>[] wildcardClassArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CLASS_ARRAY;
        try {
            java.lang.reflect.Type[] typeArray2 = org.apache.commons.lang3.ArrayUtils.remove((java.lang.reflect.Type[]) wildcardClassArray0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClassArray0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        boolean[] booleanArray17 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.add(booleanArray17, (int) (byte) 0, false);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray17, true, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray17);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray11, booleanArray17);
        try {
            boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray11, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray6);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 0);
        byte[] byteArray15 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray15, 10, (int) (short) 100);
        java.lang.Byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray15);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray19, (byte) 0);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.clone(byteArray21);
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.add(byteArray21, (byte) 1);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray24);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray25, byteArray26);
        try {
            byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.remove(byteArray25, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 9");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 0);
        byte[] byteArray15 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray15, 10, (int) (short) 100);
        java.lang.Byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray15);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray19, (byte) 0);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.clone(byteArray21);
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.add(byteArray21, (byte) 1);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray24);
        byte[] byteArray26 = null;
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray24, byteArray26);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 10.0d, 100.0d };
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 10.0d, 100.0d };
        java.lang.Double[] doubleArray8 = new java.lang.Double[] { 10.0d, 100.0d };
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 10.0d, 100.0d };
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 10.0d, 100.0d };
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 10.0d, 100.0d };
        java.lang.Double[][] doubleArray18 = new java.lang.Double[][] { doubleArray2, doubleArray5, doubleArray8, doubleArray11, doubleArray14, doubleArray17 };
        try {
            java.lang.Double[][] doubleArray20 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray18, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(floatArray0, (float) 4);
        try {
            float[] floatArray4 = org.apache.commons.lang3.ArrayUtils.remove(floatArray0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        boolean[] booleanArray1 = new boolean[] { false };
        boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.add(booleanArray1, (int) (short) 1, true);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        boolean[] booleanArray10 = null;
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray9, booleanArray10);
        try {
            boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.add(booleanArray9, (-1), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 0);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray16 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(byteArray16, (byte) 10);
        byte[] byteArray19 = null;
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray16, byteArray19);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray20);
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray21, (byte) -1, (int) (short) -1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        char[] charArray0 = new char[] {};
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.add(charArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#');
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.clone(charArray0);
        try {
            char[] charArray7 = org.apache.commons.lang3.ArrayUtils.remove(charArray5, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double[] doubleArray5 = new double[] { '4', 0.0f, 0.0f, 'a', (short) 100 };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray5, (double) 4, (double) (byte) 1);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray5);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray5, (double) (short) -1, (int) (byte) 10);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray5);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray5, (double) (byte) 10, (int) (short) 100, (double) (short) 100);
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray5, (double) 100, (int) (short) 10, (double) 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double[] doubleArray6 = new double[] { '#', 1, (byte) 0, 100, 1.0f, 100.0f };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (byte) -1);
        try {
            double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray6, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (-1L));
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 3, (double) (short) 10);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) 100);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        short[] shortArray6 = new short[] { (short) 1, (byte) 0, (short) 100, (byte) -1, (short) 10, (byte) 100 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(shortArray6, (short) (byte) 10);
        java.lang.Short[] shortArray12 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray12, (short) (byte) -1);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray14);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray6, (short) (byte) 0);
        try {
            short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.add(shortArray6, (-1), (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shortArray17);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.lang.CharSequence[] charSequenceArray5 = new java.lang.CharSequence[] { "false", "false", "", "{1.0,1.0,0.0,10.0}", "{1.0,1.0,0.0,10.0}" };
        try {
            java.lang.CharSequence[] charSequenceArray7 = org.apache.commons.lang3.ArrayUtils.remove(charSequenceArray5, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charSequenceArray5);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) byteArray6);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.Short[][][] shortArray0 = new java.lang.Short[][][] {};
        try {
            java.lang.Short[][][] shortArray2 = org.apache.commons.lang3.ArrayUtils.remove(shortArray0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, 10, (int) (short) 100);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray7);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) charArray2, (java.lang.Object) byteArray11);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray2);
        java.lang.Character[] charArray14 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        java.lang.Character[] charArray15 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray15);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray6, (int) (byte) 1, ' ');
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.clone(charArray9);
        java.lang.Character[] charArray11 = org.apache.commons.lang3.ArrayUtils.toObject(charArray10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray10, '4');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray2 = new java.lang.Comparable[1][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray3 = (java.lang.Comparable<java.lang.String>[][]) comparableArray2;
        strComparableArray3[0] = strArray0;
        java.lang.String[] strArray6 = new java.lang.String[] {};
        java.lang.String[] strArray7 = new java.lang.String[] {};
        java.lang.String[] strArray8 = new java.lang.String[] {};
        java.lang.String[] strArray9 = new java.lang.String[] {};
        java.lang.String[] strArray10 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray12 = new java.lang.Comparable[5][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray13 = (java.lang.Comparable<java.lang.String>[][]) comparableArray12;
        strComparableArray13[0] = strArray6;
        strComparableArray13[1] = strArray7;
        strComparableArray13[2] = strArray8;
        strComparableArray13[3] = strArray9;
        strComparableArray13[4] = strArray10;
        java.lang.Comparable<java.lang.String>[][] strComparableArray24 = org.apache.commons.lang3.ArrayUtils.addAll(strComparableArray3, strComparableArray13);
        boolean[] booleanArray30 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray33 = org.apache.commons.lang3.ArrayUtils.add(booleanArray30, (int) (byte) 0, false);
        boolean[] booleanArray34 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray33);
        java.lang.Boolean[] booleanArray35 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray33);
        boolean[] booleanArray37 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray35, true);
        boolean[] booleanArray39 = org.apache.commons.lang3.ArrayUtils.add(booleanArray37, true);
        int int40 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) strComparableArray13, (java.lang.Object) true);
        double[] doubleArray46 = new double[] { '4', 0.0f, 0.0f, 'a', (short) 100 };
        int int49 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray46, (double) 4, (double) (byte) 1);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray46);
        int int53 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray46, (double) (short) -1, (int) (byte) 10);
        int int55 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strComparableArray13, (java.lang.Object) doubleArray46, 6);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(strComparableArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(comparableArray12);
        org.junit.Assert.assertNotNull(strComparableArray13);
        org.junit.Assert.assertNotNull(strComparableArray24);
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertNotNull(booleanArray35);
        org.junit.Assert.assertNotNull(booleanArray37);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.lang3.ArrayUtils arrayUtils0 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils1 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils2 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils3 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray4 = new org.apache.commons.lang3.ArrayUtils[] { arrayUtils0, arrayUtils1, arrayUtils2, arrayUtils3 };
        org.apache.commons.lang3.ArrayUtils arrayUtils5 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils6 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils7 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils8 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils9 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray10 = new org.apache.commons.lang3.ArrayUtils[] { arrayUtils5, arrayUtils6, arrayUtils7, arrayUtils8, arrayUtils9 };
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray11 = org.apache.commons.lang3.ArrayUtils.addAll(arrayUtilsArray4, arrayUtilsArray10);
        try {
            org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray13 = org.apache.commons.lang3.ArrayUtils.remove(arrayUtilsArray10, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(arrayUtilsArray4);
        org.junit.Assert.assertNotNull(arrayUtilsArray10);
        org.junit.Assert.assertNotNull(arrayUtilsArray11);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 100, (byte) -1, (byte) -1, (byte) -1 };
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        try {
            byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray8, (int) (short) -1, (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray0, (int) (byte) 1, (int) (short) 100);
        float[] floatArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 1, (int) (short) 100);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray0, floatArray4);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray4, (float) 4);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        long[] longArray6 = new long[] { 100L, 0, (short) 0, ' ', (short) 1, 10 };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) (short) 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 1, (-1));
        try {
            long[] longArray15 = org.apache.commons.lang3.ArrayUtils.remove(longArray6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        short[] shortArray0 = null;
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray0, 0, 100);
        org.junit.Assert.assertNull(shortArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) (byte) -1);
        short[] shortArray21 = new short[] { (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) (byte) 10, (int) (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray18, shortArray21);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray18, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray18, (short) (byte) 1);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        short[] shortArray44 = org.apache.commons.lang3.ArrayUtils.clone(shortArray39);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray30, shortArray39);
        short[] shortArray46 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray39);
        java.lang.Short[] shortArray47 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(shortArray46);
        org.junit.Assert.assertNotNull(shortArray47);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        java.lang.Boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray9, false);
        boolean[] booleanArray12 = null;
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray11, booleanArray12);
        try {
            boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray12, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.Long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_OBJECT_ARRAY;
        long[] longArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0);
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.subarray(longArray1, 2, 0);
        try {
            long[] longArray6 = org.apache.commons.lang3.ArrayUtils.remove(longArray1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray5, true, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray5);
        try {
            boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray9, (double) ' ', (double) 0.0f);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray9, (double) (byte) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray9, (double) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 100, (byte) -1, (byte) -1, (byte) -1 };
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        boolean[] booleanArray14 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray17 = org.apache.commons.lang3.ArrayUtils.add(booleanArray14, (int) (byte) 0, false);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray17);
        boolean[] booleanArray19 = null;
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray18, booleanArray19);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray6, (java.lang.Object) booleanArray19, (int) (short) 0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, 'a');
        char[] charArray5 = new char[] { 'a', '4' };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray5);
        java.lang.Character[] charArray7 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray2, charArray9);
        char[] charArray13 = new char[] { 'a', '4' };
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray13);
        java.lang.Character[] charArray15 = org.apache.commons.lang3.ArrayUtils.toObject(charArray13);
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray15);
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray15);
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.add(charArray17, (int) (byte) 1, ' ');
        char[] charArray21 = org.apache.commons.lang3.ArrayUtils.clone(charArray20);
        java.lang.Character[] charArray22 = org.apache.commons.lang3.ArrayUtils.toObject(charArray21);
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.add(charArray21, (int) (short) 1, ' ');
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(charArray2, charArray21);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, 0.0d, (int) (byte) 0, (double) (short) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray3, (double) 1.0f);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray3, (double) 1L);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray0);
        try {
            boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, 1);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.clone(intArray16);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.clone(intArray17);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, 0.0d, (int) (byte) 0, (double) (short) 10);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray3, (double) 1.0f);
        try {
            double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray3, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, 1);
        byte[] byteArray23 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.contains(byteArray23, (byte) 10);
        java.lang.Byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray23);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) intArray14, (java.lang.Object) byteArray26);
        java.lang.Short[] shortArray31 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray31, (short) (byte) -1);
        short[] shortArray36 = new short[] { (byte) 100, (byte) 100 };
        int int39 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray36, (short) (byte) 10, (int) (byte) 1);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray33, shortArray36);
        int int43 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray36, (short) 0, (int) (short) -1);
        boolean boolean44 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) byteArray26, (java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertNotNull(shortArray33);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.remove(longArray9, 0);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray9, (long) 100);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray13);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        char[] charArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 0);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray8, (byte) 1);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray8, (int) (short) 1, (int) (byte) 0);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 1, 0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.Object obj0 = null;
        double[] doubleArray4 = new double[] { (byte) 100, 10, (byte) -1 };
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray4, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray4, (double) (short) 0);
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray4, (double) 7);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray12);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEquals(obj0, (java.lang.Object) doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 0);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        try {
            byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.remove(byteArray8, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        char[] charArray0 = new char[] {};
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.add(charArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#');
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#', 4);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray0);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[] byteArray17 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[] byteArray23 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[][] byteArray24 = new byte[][] { byteArray5, byteArray11, byteArray17, byteArray23 };
        byte[] byteArray28 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray28, 10, (int) (short) 100);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.contains(byteArray28, (byte) 0);
        byte[][] byteArray34 = org.apache.commons.lang3.ArrayUtils.add(byteArray24, (int) (short) 1, byteArray28);
        java.lang.Byte[] byteArray39 = new java.lang.Byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray39);
        byte[][] byteArray41 = org.apache.commons.lang3.ArrayUtils.add(byteArray24, byteArray40);
        try {
            byte[] byteArray43 = org.apache.commons.lang3.ArrayUtils.remove(byteArray40, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertNotNull(byteArray41);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 0);
        byte[] byteArray15 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray15, 10, (int) (short) 100);
        java.lang.Byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray15);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray19, (byte) 0);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.clone(byteArray21);
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.add(byteArray21, (byte) 1);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray24);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray25, byteArray26);
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray26, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        boolean[] booleanArray1 = new boolean[] { true };
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray1);
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray1);
        try {
            boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        float[] floatArray6 = new float[] { (short) -1, 6, (byte) 1, 1, 2, 0L };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray6, (float) (byte) 0, (int) (byte) 0);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double[] doubleArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 100.0f, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        java.lang.Boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.add(intArray14, 4);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains(intArray14, (int) (short) 0);
        java.lang.Integer[] intArray24 = org.apache.commons.lang3.ArrayUtils.toObject(intArray14);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray24, 1);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) booleanArray9, (java.lang.Object) intArray24, (int) (short) 100);
        boolean[] booleanArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray9);
        java.lang.Boolean[] booleanArray32 = new java.lang.Boolean[] { false, false };
        boolean[] booleanArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray32, true);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray29, booleanArray34);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray34, true, (int) (short) 1);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(booleanArray29);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 10);
        java.lang.Class<?> wildcardClass14 = intArray4.getClass();
        int[] intArray19 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray23 = new int[] { '4', 1, ' ' };
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.addAll(intArray19, intArray23);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.add(intArray19, 4);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.contains(intArray19, (int) (byte) 10);
        java.lang.Class<?> wildcardClass29 = intArray19.getClass();
        int[] intArray34 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray38 = new int[] { '4', 1, ' ' };
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.addAll(intArray34, intArray38);
        int[] intArray41 = org.apache.commons.lang3.ArrayUtils.add(intArray34, 4);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.contains(intArray34, (int) (byte) 10);
        java.lang.Class<?> wildcardClass44 = intArray34.getClass();
        int[] intArray49 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray53 = new int[] { '4', 1, ' ' };
        int[] intArray54 = org.apache.commons.lang3.ArrayUtils.addAll(intArray49, intArray53);
        int[] intArray56 = org.apache.commons.lang3.ArrayUtils.add(intArray49, 4);
        boolean boolean58 = org.apache.commons.lang3.ArrayUtils.contains(intArray49, (int) (byte) 10);
        java.lang.Class<?> wildcardClass59 = intArray49.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray60 = new java.lang.reflect.AnnotatedElement[] { wildcardClass14, wildcardClass29, wildcardClass44, wildcardClass59 };
        java.lang.reflect.AnnotatedElement[] annotatedElementArray63 = org.apache.commons.lang3.ArrayUtils.subarray(annotatedElementArray60, 7, (int) ' ');
        java.lang.Double[] doubleArray70 = new java.lang.Double[] { 1.0d, 10.0d, 0.0d, 0.0d, 0.0d, 1.0d };
        double[] doubleArray71 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray70);
        int int72 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) annotatedElementArray60, (java.lang.Object) doubleArray70);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(annotatedElementArray60);
        org.junit.Assert.assertNotNull(annotatedElementArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray8, false);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        float[] floatArray6 = new float[] { (short) -1, 6, (byte) 1, 1, 2, 0L };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        try {
            float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.add(floatArray6, (-1), (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.lang.Long[] longArray6 = new java.lang.Long[] { (-1L), 0L, 100L, 100L, 1L, 100L };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        java.lang.Integer[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        java.lang.Short[] shortArray12 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray12, (short) (byte) -1);
        short[] shortArray17 = new short[] { (byte) 100, (byte) 100 };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) (byte) 10, (int) (byte) 1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray14, shortArray17);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray14, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray14, (short) (byte) 1);
        java.lang.Short[] shortArray30 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray30, (short) (byte) -1);
        short[] shortArray35 = new short[] { (byte) 100, (byte) 100 };
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray35, (short) (byte) 10, (int) (byte) 1);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray32, shortArray35);
        java.lang.Short[] shortArray43 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray45 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray43, (short) (byte) -1);
        short[] shortArray48 = new short[] { (byte) 100, (byte) 100 };
        int int51 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray48, (short) (byte) 10, (int) (byte) 1);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray45, shortArray48);
        int int55 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray45, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray57 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray45, (short) (byte) 1);
        java.lang.Short[] shortArray61 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray63 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray61, (short) (byte) -1);
        short[] shortArray66 = new short[] { (byte) 100, (byte) 100 };
        int int69 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray66, (short) (byte) 10, (int) (byte) 1);
        boolean boolean70 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray63, shortArray66);
        short[] shortArray71 = org.apache.commons.lang3.ArrayUtils.clone(shortArray66);
        boolean boolean72 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray57, shortArray66);
        short[] shortArray73 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray32, shortArray66);
        short[] shortArray74 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray26, shortArray66);
        int int77 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) 100, (int) (short) 100);
        boolean boolean78 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) intArray8, (java.lang.Object) (short) 100);
        int int80 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray6, (java.lang.Object) (short) 100, (int) (short) 0);
        long[] longArray81 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        long[] longArray82 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shortArray43);
        org.junit.Assert.assertNotNull(shortArray45);
        org.junit.Assert.assertNotNull(shortArray48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(shortArray57);
        org.junit.Assert.assertNotNull(shortArray61);
        org.junit.Assert.assertNotNull(shortArray63);
        org.junit.Assert.assertNotNull(shortArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(shortArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(shortArray73);
        org.junit.Assert.assertNotNull(shortArray74);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertNotNull(longArray81);
        org.junit.Assert.assertNotNull(longArray82);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        long[][] longArray0 = new long[][] {};
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4, (short) (byte) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray6);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(shortArray6, (short) (byte) 10);
        long[][] longArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray0, (java.lang.Object) shortArray6);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray6, (short) (byte) 100, 7);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(shortArray17, (short) (byte) 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 100);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(shortArray15, (short) 100);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray15, (short) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray9, (long) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.clone(longArray9);
        long[] longArray15 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) 'a', 4);
        java.lang.Long[] longArray16 = org.apache.commons.lang3.ArrayUtils.toObject(longArray15);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.Float[] floatArray4 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4, (float) 0);
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        int int33 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray23, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray35 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray23, (short) (byte) 1);
        java.lang.Short[] shortArray39 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray39, (short) (byte) -1);
        short[] shortArray44 = new short[] { (byte) 100, (byte) 100 };
        int int47 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray44, (short) (byte) 10, (int) (byte) 1);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray41, shortArray44);
        java.lang.Short[] shortArray52 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray54 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray52, (short) (byte) -1);
        short[] shortArray57 = new short[] { (byte) 100, (byte) 100 };
        int int60 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray57, (short) (byte) 10, (int) (byte) 1);
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray54, shortArray57);
        int int64 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray54, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray66 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray54, (short) (byte) 1);
        java.lang.Short[] shortArray70 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray72 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray70, (short) (byte) -1);
        short[] shortArray75 = new short[] { (byte) 100, (byte) 100 };
        int int78 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray75, (short) (byte) 10, (int) (byte) 1);
        boolean boolean79 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray72, shortArray75);
        short[] shortArray80 = org.apache.commons.lang3.ArrayUtils.clone(shortArray75);
        boolean boolean81 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray66, shortArray75);
        short[] shortArray82 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray41, shortArray75);
        short[] shortArray83 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray35, shortArray75);
        boolean boolean84 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray75);
        short[] shortArray85 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(shortArray52);
        org.junit.Assert.assertNotNull(shortArray54);
        org.junit.Assert.assertNotNull(shortArray57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(shortArray66);
        org.junit.Assert.assertNotNull(shortArray70);
        org.junit.Assert.assertNotNull(shortArray72);
        org.junit.Assert.assertNotNull(shortArray75);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(shortArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(shortArray82);
        org.junit.Assert.assertNotNull(shortArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(shortArray85);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 0);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray16 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(byteArray16, (byte) 10);
        byte[] byteArray19 = null;
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray16, byteArray19);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray20);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains(byteArray9, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double[] doubleArray6 = new double[] { '#', 1, (byte) 0, 100, 1.0f, 100.0f };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (byte) -1);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray8, (double) (short) 1);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray8, (double) 7, (int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.Long[] longArray6 = new java.lang.Long[] { (-1L), 0L, 100L, 100L, 1L, 100L };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        java.lang.Integer[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        java.lang.Short[] shortArray12 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray12, (short) (byte) -1);
        short[] shortArray17 = new short[] { (byte) 100, (byte) 100 };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) (byte) 10, (int) (byte) 1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray14, shortArray17);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray14, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray14, (short) (byte) 1);
        java.lang.Short[] shortArray30 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray30, (short) (byte) -1);
        short[] shortArray35 = new short[] { (byte) 100, (byte) 100 };
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray35, (short) (byte) 10, (int) (byte) 1);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray32, shortArray35);
        java.lang.Short[] shortArray43 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray45 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray43, (short) (byte) -1);
        short[] shortArray48 = new short[] { (byte) 100, (byte) 100 };
        int int51 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray48, (short) (byte) 10, (int) (byte) 1);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray45, shortArray48);
        int int55 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray45, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray57 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray45, (short) (byte) 1);
        java.lang.Short[] shortArray61 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray63 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray61, (short) (byte) -1);
        short[] shortArray66 = new short[] { (byte) 100, (byte) 100 };
        int int69 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray66, (short) (byte) 10, (int) (byte) 1);
        boolean boolean70 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray63, shortArray66);
        short[] shortArray71 = org.apache.commons.lang3.ArrayUtils.clone(shortArray66);
        boolean boolean72 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray57, shortArray66);
        short[] shortArray73 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray32, shortArray66);
        short[] shortArray74 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray26, shortArray66);
        int int77 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) 100, (int) (short) 100);
        boolean boolean78 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) intArray8, (java.lang.Object) (short) 100);
        int int80 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray6, (java.lang.Object) (short) 100, (int) (short) 0);
        double[] doubleArray84 = new double[] { (byte) 100, 10, (byte) -1 };
        int int88 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray84, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray90 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray84, (double) (short) 0);
        int int93 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray90, (double) ' ', (double) 0.0f);
        double[] doubleArray95 = org.apache.commons.lang3.ArrayUtils.add(doubleArray90, (double) (byte) 100);
        int int97 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) longArray6, (java.lang.Object) doubleArray95, (int) (short) 100);
        long[] longArray99 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6, (long) (short) 10);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shortArray43);
        org.junit.Assert.assertNotNull(shortArray45);
        org.junit.Assert.assertNotNull(shortArray48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(shortArray57);
        org.junit.Assert.assertNotNull(shortArray61);
        org.junit.Assert.assertNotNull(shortArray63);
        org.junit.Assert.assertNotNull(shortArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(shortArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(shortArray73);
        org.junit.Assert.assertNotNull(shortArray74);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + (-1) + "'", int97 == (-1));
        org.junit.Assert.assertNotNull(longArray99);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 10, (byte) 0, (byte) 1, (byte) 1 };
        try {
            byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.remove(byteArray5, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.Object[] objArray0 = null;
        boolean[] booleanArray6 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, (int) (byte) 0, false);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray6);
        int[] intArray15 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray19 = new int[] { '4', 1, ' ' };
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray15, intArray19);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray15, 4);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (short) 0);
        java.lang.Integer[] intArray25 = org.apache.commons.lang3.ArrayUtils.toObject(intArray15);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray25, 1);
        int int29 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) booleanArray10, (java.lang.Object) intArray25, (int) (short) 100);
        boolean[] booleanArray30 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(objArray0, (java.lang.Object) booleanArray10, (int) (short) 10);
        boolean[] booleanArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray33, true);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray2 = new java.lang.Comparable[1][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray3 = (java.lang.Comparable<java.lang.String>[][]) comparableArray2;
        strComparableArray3[0] = strArray0;
        java.lang.String[] strArray6 = new java.lang.String[] {};
        java.lang.String[] strArray7 = new java.lang.String[] {};
        java.lang.String[] strArray8 = new java.lang.String[] {};
        java.lang.String[] strArray9 = new java.lang.String[] {};
        java.lang.String[] strArray10 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray12 = new java.lang.Comparable[5][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray13 = (java.lang.Comparable<java.lang.String>[][]) comparableArray12;
        strComparableArray13[0] = strArray6;
        strComparableArray13[1] = strArray7;
        strComparableArray13[2] = strArray8;
        strComparableArray13[3] = strArray9;
        strComparableArray13[4] = strArray10;
        java.lang.Comparable<java.lang.String>[][] strComparableArray24 = org.apache.commons.lang3.ArrayUtils.addAll(strComparableArray3, strComparableArray13);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap25 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) strComparableArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '[Ljava.lang.String;@2d67f851', has a length less than 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(strComparableArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(comparableArray12);
        org.junit.Assert.assertNotNull(strComparableArray13);
        org.junit.Assert.assertNotNull(strComparableArray24);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.Long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_OBJECT_ARRAY;
        long[] longArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0);
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.subarray(longArray1, 2, 0);
        try {
            long[] longArray6 = org.apache.commons.lang3.ArrayUtils.remove(longArray4, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray13, (short) (byte) -1);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.add(shortArray13, (short) (byte) 100);
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray13, (short) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) 0, (int) (short) -1);
        try {
            short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.remove(shortArray8, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 1, 1, 10, 1, 0, (-1) };
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray6);
        int[] intArray8 = null;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray7, intArray8);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray8);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray19);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray9, 10, (int) (short) 1);
        int[] intArray24 = null;
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray9, intArray24);
        int[] intArray30 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray34 = new int[] { '4', 1, ' ' };
        int[] intArray35 = org.apache.commons.lang3.ArrayUtils.addAll(intArray30, intArray34);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray35);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray35, (int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        long[] longArray6 = new long[] { 100L, 0, (short) 0, ' ', (short) 1, 10 };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) (short) 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 1, (-1));
        org.apache.commons.lang3.ArrayUtils.reverse(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray0, (int) (byte) 1, (int) (short) 100);
        float[] floatArray4 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray4, (int) (byte) 1, (int) (short) 100);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray0, floatArray4);
        java.lang.Float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray4);
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray4, 10.0f);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 1, 1, 10, 1, 0, (-1) };
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray6);
        int[] intArray8 = null;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray7, intArray8);
        try {
            int[] intArray12 = org.apache.commons.lang3.ArrayUtils.add(intArray7, (int) (short) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        long[] longArray1 = new long[] { (short) 1 };
        java.lang.Long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toObject(longArray1);
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, 0L);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray3, (long) (short) 100);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(longArray7);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        byte[] byteArray12 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 10);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray15);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.add(byteArray15, (byte) 0);
        byte[] byteArray21 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray21, 10, (int) (short) 100);
        java.lang.Byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray21);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray25, (byte) 0);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.clone(byteArray27);
        byte[] byteArray30 = org.apache.commons.lang3.ArrayUtils.add(byteArray27, (byte) 1);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray15, byteArray30);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray5, byteArray15);
        java.lang.Byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        int int34 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) byteArray33);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        long[] longArray1 = new long[] { (short) 1 };
        java.lang.Long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toObject(longArray1);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.contains(longArray1, (-1L));
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray1, (long) (short) 0);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        try {
            int[] intArray14 = org.apache.commons.lang3.ArrayUtils.add(intArray4, (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10, true);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.add(booleanArray12, true);
        boolean[] booleanArray20 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray23 = org.apache.commons.lang3.ArrayUtils.add(booleanArray20, (int) (byte) 0, false);
        boolean[] booleanArray24 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray23);
        java.lang.Boolean[] booleanArray25 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray23);
        boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray12, booleanArray23);
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray26, false);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray24);
        org.junit.Assert.assertNotNull(booleanArray25);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0);
        try {
            double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.add(doubleArray1, 100, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray5);
        boolean[] booleanArray15 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.add(booleanArray15, (int) (byte) 0, false);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray5, booleanArray15);
        boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, (int) 'a', (int) (byte) 100);
        try {
            boolean[] booleanArray25 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) '#', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(booleanArray22);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(intArray8, (int) '4');
        java.lang.Integer[] intArray12 = org.apache.commons.lang3.ArrayUtils.toObject(intArray8);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 1.0d, 10.0d, 0.0d, 0.0d, 0.0d, 1.0d };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.add(doubleArray8, (double) 'a');
        java.lang.Long[] longArray11 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_OBJECT_ARRAY;
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray11);
        long[] longArray15 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) ' ', (int) ' ');
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.subarray(longArray15, (int) '4', (int) (byte) 0);
        long[] longArray25 = new long[] { 100L, 0, (short) 0, ' ', (short) 1, 10 };
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray25, (long) (short) 1);
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray25);
        long[] longArray29 = org.apache.commons.lang3.ArrayUtils.addAll(longArray15, longArray25);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) 'a', (java.lang.Object) longArray25);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        short[] shortArray0 = null;
        short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.add(shortArray0, (short) 0);
        org.junit.Assert.assertNotNull(shortArray2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 100, (byte) -1, (byte) -1, (byte) -1 };
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        try {
            byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.remove(byteArray8, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        boolean[] booleanArray1 = new boolean[] { true };
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray1);
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray1);
        try {
            boolean[] booleanArray6 = org.apache.commons.lang3.ArrayUtils.add(booleanArray3, (int) ' ', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(booleanArray3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray7, (-1.0f));
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray7, 100.0f);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.remove(longArray9, 0);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray9, (long) 100);
        java.lang.String str15 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) longArray9, "0");
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0,4,4,10,52,0}" + "'", str15.equals("{0,4,4,10,52,0}"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, 'a');
        char[] charArray5 = new char[] { 'a', '4' };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray5);
        java.lang.Character[] charArray7 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray2, charArray9);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray2, ' ', 100);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        char[] charArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(charArray0, '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 0.0f, 0.0f, 'a', (short) 100 };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray17, (double) 4, (double) (byte) 1);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray17);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray3, doubleArray17);
        double[] doubleArray26 = new double[] { (byte) 100, 10, (byte) -1 };
        int int30 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray26, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray26, (double) (short) 0);
        double[] doubleArray34 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray26, (double) 7);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray17, doubleArray34);
        double[] doubleArray38 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray17, (int) ' ', 7);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        short[] shortArray2 = new short[] { (byte) 100, (byte) 100 };
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray2, (short) (byte) 10, (int) (byte) 1);
        short[] shortArray8 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray2, (int) (byte) 1, 10);
        try {
            short[] shortArray10 = org.apache.commons.lang3.ArrayUtils.remove(shortArray8, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(shortArray8);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        boolean[] booleanArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray0, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        long[] longArray1 = new long[] { (short) 1 };
        java.lang.Long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toObject(longArray1);
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.clone(longArray4);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray5, (long) (short) -1, (int) (short) 1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        java.lang.Double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray3);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray12, (double) 5);
        try {
            double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, 7, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        java.lang.Boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray5);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.add(intArray14, 4);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.contains(intArray14, (int) (short) 0);
        java.lang.Integer[] intArray24 = org.apache.commons.lang3.ArrayUtils.toObject(intArray14);
        int[] intArray26 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray24, 1);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) booleanArray9, (java.lang.Object) intArray24, (int) (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) intArray24);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) intArray24);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray4, (java.lang.Object) floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray10, (float) 10);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray10, (float) (short) 0, 2);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray10, (float) 10);
        float[] floatArray22 = new float[] { '#', (short) -1, 10L };
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray18, floatArray22);
        try {
            float[] floatArray25 = org.apache.commons.lang3.ArrayUtils.remove(floatArray22, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 0);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray8, (byte) 1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        byte[] byteArray15 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray15, 10, (int) (short) 100);
        byte[] byteArray25 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains(byteArray25, (byte) 10);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.clone(byteArray25);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray28);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.add(byteArray28, (byte) 0);
        byte[] byteArray34 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray37 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray34, 10, (int) (short) 100);
        java.lang.Byte[] byteArray38 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray34);
        byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray38, (byte) 0);
        byte[] byteArray41 = org.apache.commons.lang3.ArrayUtils.clone(byteArray40);
        byte[] byteArray43 = org.apache.commons.lang3.ArrayUtils.add(byteArray40, (byte) 1);
        byte[] byteArray44 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray28, byteArray43);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray18, byteArray28);
        java.lang.Byte[] byteArray46 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray18);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray18, (byte) 10, 3);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray11, byteArray18);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray13, (short) (byte) -1);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.add(shortArray13, (short) (byte) 100);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray13, (short) 1, 3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Long[] longArray6 = new java.lang.Long[] { (-1L), 0L, 100L, 100L, 1L, 100L };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (-1L));
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray9);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        boolean[] booleanArray1 = new boolean[] { true };
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray1);
        try {
            boolean[] booleanArray5 = org.apache.commons.lang3.ArrayUtils.add(booleanArray1, (int) '#', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        short[] shortArray5 = new short[] { (byte) 1, (byte) 100, (short) -1, (short) 0, (byte) 1 };
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) 0, 3);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 1);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray9, (byte) 100, (int) 'a');
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray9, (byte) 1);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        long[] longArray6 = new long[] { 100L, 0, (short) 0, ' ', (short) 1, 10 };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) (short) 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 1, (-1));
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray6, (long) '4', (int) (short) 10);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, 1L, (int) (short) 10);
        java.lang.Long[] longArray20 = org.apache.commons.lang3.ArrayUtils.toObject(longArray6);
        try {
            long[] longArray23 = org.apache.commons.lang3.ArrayUtils.add(longArray6, 11, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(longArray20);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray9, (long) '4');
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.clone(longArray9);
        long[] longArray15 = org.apache.commons.lang3.ArrayUtils.subarray(longArray12, (int) 'a', 4);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray12);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertNotNull(longArray15);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        long[] longArray0 = new long[] {};
        long[] longArray2 = org.apache.commons.lang3.ArrayUtils.add(longArray0, (long) 7);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray2, (long) 11, (int) (short) 10);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 100);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(shortArray15, (short) 100);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray15, (short) -1);
        try {
            short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.add(shortArray15, (int) ' ', (short) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray13, (short) (byte) -1);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.add(shortArray13, (short) (byte) 100);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(shortArray13, (short) (byte) 10);
        try {
            short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.remove(shortArray13, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        boolean[] booleanArray10 = null;
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray9, booleanArray10);
        boolean[] booleanArray17 = new boolean[] { false, false, true, false, true };
        boolean[] booleanArray23 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.add(booleanArray23, (int) (byte) 0, false);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray17, booleanArray23);
        boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray10, booleanArray17);
        boolean[] booleanArray29 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertNull(booleanArray29);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        byte[] byteArray12 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 10);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray15);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.add(byteArray15, (byte) 0);
        byte[] byteArray21 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray21, 10, (int) (short) 100);
        java.lang.Byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray21);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray25, (byte) 0);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.clone(byteArray27);
        byte[] byteArray30 = org.apache.commons.lang3.ArrayUtils.add(byteArray27, (byte) 1);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray15, byteArray30);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray5, byteArray15);
        java.lang.Byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        byte[] byteArray36 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray5, (int) (byte) -1, (int) (byte) 1);
        byte[] byteArray38 = org.apache.commons.lang3.ArrayUtils.add(byteArray5, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray38);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 1L);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, (double) 10);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray13, (double) 2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (-1L));
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 3, (double) (short) 10);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray16, (double) (byte) 100, (double) 4);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, (double) (-1L), (int) (byte) 100);
        try {
            double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (int) (short) 100, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray19);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.remove(intArray20, (int) (short) 1);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray22, (int) (short) -1, (int) (short) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(intArray22);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.subarray(intArray22, (int) (byte) 0, (int) (byte) -1);
        try {
            int[] intArray31 = org.apache.commons.lang3.ArrayUtils.remove(intArray22, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 13");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        char[][] charArray0 = new char[][] {};
        char[][] charArray1 = new char[][] {};
        char[][][] charArray2 = new char[][][] { charArray0, charArray1 };
        char[] charArray4 = new char[] {};
        char[] charArray5 = new char[] {};
        char[] charArray6 = new char[] {};
        char[] charArray7 = new char[] {};
        char[][] charArray8 = new char[][] { charArray4, charArray5, charArray6, charArray7 };
        try {
            char[][][] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray2, (int) '#', charArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_OBJECT_ARRAY;
        long[] longArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0);
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.subarray(longArray1, (int) ' ', (int) ' ');
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.subarray(longArray4, (int) '4', (int) (byte) 0);
        long[] longArray14 = new long[] { 100L, 0, (short) 0, ' ', (short) 1, 10 };
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray14, (long) (short) 1);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray14);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.addAll(longArray4, longArray14);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray18);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        byte[] byteArray12 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 10);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray15);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.add(byteArray15, (byte) 0);
        byte[] byteArray21 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray21, 10, (int) (short) 100);
        java.lang.Byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray21);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray25, (byte) 0);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.clone(byteArray27);
        byte[] byteArray30 = org.apache.commons.lang3.ArrayUtils.add(byteArray27, (byte) 1);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray15, byteArray30);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray5, byteArray15);
        byte[] byteArray34 = org.apache.commons.lang3.ArrayUtils.remove(byteArray15, 0);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray34, (byte) -1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 0);
        try {
            byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray8, (int) (short) 10, (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 1, 1, 10, 1, 0, (-1) };
        int[] intArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray6);
        int[] intArray8 = null;
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray7, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray9, (-1));
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) (byte) -1);
        short[] shortArray21 = new short[] { (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) (byte) 10, (int) (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray18, shortArray21);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray18, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray18, (short) (byte) 1);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        java.lang.Short[] shortArray47 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray49 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray47, (short) (byte) -1);
        short[] shortArray52 = new short[] { (byte) 100, (byte) 100 };
        int int55 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray52, (short) (byte) 10, (int) (byte) 1);
        boolean boolean56 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray49, shortArray52);
        int int59 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray49, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray61 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray49, (short) (byte) 1);
        java.lang.Short[] shortArray65 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray67 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray65, (short) (byte) -1);
        short[] shortArray70 = new short[] { (byte) 100, (byte) 100 };
        int int73 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray70, (short) (byte) 10, (int) (byte) 1);
        boolean boolean74 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray67, shortArray70);
        short[] shortArray75 = org.apache.commons.lang3.ArrayUtils.clone(shortArray70);
        boolean boolean76 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray61, shortArray70);
        short[] shortArray77 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray36, shortArray70);
        short[] shortArray78 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray30, shortArray70);
        short[] shortArray79 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray78);
        int int82 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray79, (short) -1, (int) ' ');
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray79);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shortArray47);
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(shortArray52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(shortArray61);
        org.junit.Assert.assertNotNull(shortArray65);
        org.junit.Assert.assertNotNull(shortArray67);
        org.junit.Assert.assertNotNull(shortArray70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(shortArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(shortArray77);
        org.junit.Assert.assertNotNull(shortArray78);
        org.junit.Assert.assertNotNull(shortArray79);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 0.0f, 0.0f, 'a', (short) 100 };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray17, (double) 4, (double) (byte) 1);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray17);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray3, doubleArray17);
        double[] doubleArray26 = new double[] { (byte) 100, 10, (byte) -1 };
        int int30 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray26, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray32 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray26, (double) (short) 0);
        double[] doubleArray34 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray26, (double) 7);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray17, doubleArray34);
        double[] doubleArray37 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray17, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, 1);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, 7, 2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.Object[] objArray0 = null;
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray3, 10, (int) (short) 100);
        java.lang.Byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray3);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray3, (byte) 10);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(byteArray9, (byte) 10);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, (int) (byte) -1, (int) '4');
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(objArray0, (java.lang.Object) byteArray9);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        byte[] byteArray12 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 10);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray15);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.add(byteArray15, (byte) 0);
        byte[] byteArray21 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray21, 10, (int) (short) 100);
        java.lang.Byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray21);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray25, (byte) 0);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.clone(byteArray27);
        byte[] byteArray30 = org.apache.commons.lang3.ArrayUtils.add(byteArray27, (byte) 1);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray15, byteArray30);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray5, byteArray15);
        java.lang.Byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        byte[] byteArray36 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray5, (int) (byte) -1, (int) (byte) 1);
        byte[] byteArray37 = org.apache.commons.lang3.ArrayUtils.clone(byteArray36);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray37);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, 1);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.clone(intArray16);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.subarray(intArray16, (int) (short) 100, (-1));
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray16);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        boolean[] booleanArray1 = new boolean[] { true };
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray1);
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray1);
        java.lang.Boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray1);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(booleanArray4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { 0.0d, (-1.0d) };
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray2, (double) 10L);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray8, false);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(booleanArray14);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray6, (int) (byte) 1, ' ');
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.subarray(charArray9, 6, (int) 'a');
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray9, 'a');
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.add(charArray9, 'a');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(charArray16);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        short[] shortArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray0, (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.subarray(charArray2, (int) (short) 100, (int) (short) 10);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray6, '#');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double[] doubleArray6 = new double[] { '#', 1, (byte) 0, 100, 1.0f, 100.0f };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (byte) -1);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray8, (double) (short) 1);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray8, (double) 100);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray8);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray13, (double) 1.0f, 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        float[] floatArray6 = new float[] { (short) -1, 6, (byte) 1, 1, 2, 0L };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray7, (float) 'a', (int) (byte) 0);
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.remove(floatArray7, 4);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(floatArray7, (float) 10L);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        java.lang.Short[] shortArray18 = new java.lang.Short[] { (short) 10, (short) -1 };
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray18);
        java.lang.Short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray19);
        short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray19);
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray21, 7, (-1));
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray24);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray24);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 0);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray16 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(byteArray16, (byte) 10);
        byte[] byteArray19 = null;
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray16, byteArray19);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray20);
        java.lang.Byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray9);
        byte[] byteArray23 = null;
        java.lang.Byte[] byteArray28 = new java.lang.Byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray28);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray23, byteArray29);
        byte[] byteArray31 = null;
        java.lang.Byte[] byteArray36 = new java.lang.Byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte[] byteArray37 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray36);
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray31, byteArray37);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray23, byteArray37);
        byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray23);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(byteArray40);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.Float[] floatArray4 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        java.lang.Float[] floatArray10 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray4, (java.lang.Object[]) floatArray10);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.contains(floatArray15, (float) 100);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (short) 1, (int) (short) 100);
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.remove(floatArray10, (int) (byte) 1);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray12, 0.0f);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (-1L));
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray3, 1, (int) (short) 0);
        try {
            double[] doubleArray19 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (int) '4', (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray10, (long) 1);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray8, true);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray10);
        try {
            boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.add(booleanArray11, (int) '#', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray11);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(shortArray5, (short) (byte) 10);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray5);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray19);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.remove(intArray20, (int) (short) 1);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.add(intArray20, (int) (short) 0, 0);
        int[] intArray28 = org.apache.commons.lang3.ArrayUtils.add(intArray20, 2, 1);
        try {
            int[] intArray30 = org.apache.commons.lang3.ArrayUtils.remove(intArray28, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 15");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 100, (byte) -1, (byte) -1, (byte) -1 };
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray8);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray7);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.Float[] floatArray4 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        java.lang.Float[] floatArray10 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray4, (java.lang.Object[]) floatArray10);
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4, (float) 10);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4, (float) (byte) 0);
        char[] charArray21 = new char[] { 'a', '4' };
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray21);
        java.lang.Character[] charArray23 = org.apache.commons.lang3.ArrayUtils.toObject(charArray21);
        char[] charArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray23);
        char[] charArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray23);
        char[] charArray28 = org.apache.commons.lang3.ArrayUtils.add(charArray25, (int) (byte) 1, ' ');
        char[] charArray29 = org.apache.commons.lang3.ArrayUtils.clone(charArray28);
        java.lang.Character[] charArray30 = org.apache.commons.lang3.ArrayUtils.toObject(charArray29);
        char[] charArray33 = org.apache.commons.lang3.ArrayUtils.add(charArray29, (int) (short) 1, ' ');
        char[] charArray35 = org.apache.commons.lang3.ArrayUtils.remove(charArray33, (int) (byte) 1);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) floatArray18, (java.lang.Object) (byte) 1);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        boolean[] booleanArray1 = new boolean[] { true };
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray1);
        boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray1);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray3, true, (int) (byte) 1);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(booleanArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        int int46 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray36, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray48 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray36, (short) (byte) 1);
        java.lang.Short[] shortArray52 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray54 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray52, (short) (byte) -1);
        short[] shortArray57 = new short[] { (byte) 100, (byte) 100 };
        int int60 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray57, (short) (byte) 10, (int) (byte) 1);
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray54, shortArray57);
        short[] shortArray62 = org.apache.commons.lang3.ArrayUtils.clone(shortArray57);
        boolean boolean63 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray48, shortArray57);
        short[] shortArray64 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray23, shortArray57);
        short[] shortArray65 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray17, shortArray57);
        int int68 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) 100, (int) (short) 100);
        int int71 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) 0, (int) (short) 1);
        int int74 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) (byte) 1, 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(shortArray48);
        org.junit.Assert.assertNotNull(shortArray52);
        org.junit.Assert.assertNotNull(shortArray54);
        org.junit.Assert.assertNotNull(shortArray57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(shortArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(shortArray64);
        org.junit.Assert.assertNotNull(shortArray65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray9, (double) 4);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray11, (double) (short) -1, (double) 0.0f);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray11, (double) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.lang3.ArrayUtils arrayUtils0 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils1 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils2 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils3 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray4 = new org.apache.commons.lang3.ArrayUtils[] { arrayUtils0, arrayUtils1, arrayUtils2, arrayUtils3 };
        org.apache.commons.lang3.ArrayUtils arrayUtils5 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils6 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils7 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils8 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils arrayUtils9 = new org.apache.commons.lang3.ArrayUtils();
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray10 = new org.apache.commons.lang3.ArrayUtils[] { arrayUtils5, arrayUtils6, arrayUtils7, arrayUtils8, arrayUtils9 };
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray11 = org.apache.commons.lang3.ArrayUtils.addAll(arrayUtilsArray4, arrayUtilsArray10);
        org.apache.commons.lang3.ArrayUtils[] arrayUtilsArray14 = org.apache.commons.lang3.ArrayUtils.subarray(arrayUtilsArray10, (int) (short) 100, (int) 'a');
        org.junit.Assert.assertNotNull(arrayUtilsArray4);
        org.junit.Assert.assertNotNull(arrayUtilsArray10);
        org.junit.Assert.assertNotNull(arrayUtilsArray11);
        org.junit.Assert.assertNotNull(arrayUtilsArray14);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double[] doubleArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) '4', (double) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        long[] longArray1 = new long[] { (short) 1 };
        java.lang.Long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toObject(longArray1);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.add(longArray1, (int) (byte) 1, (long) 100);
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray5, 0L);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray5, (long) (byte) 100);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        short[] shortArray31 = org.apache.commons.lang3.ArrayUtils.clone(shortArray26);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray26);
        short[] shortArray34 = org.apache.commons.lang3.ArrayUtils.add(shortArray17, (short) -1);
        int int36 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray34, (short) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        boolean[] booleanArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray0, false, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        short[] shortArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(shortArray0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 0.0d };
        double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray1, (double) 100);
        int int5 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray3, (double) '#');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray9, (double) ' ', (double) 0.0f);
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.add(doubleArray9, (double) (byte) 100);
        try {
            double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.add(doubleArray14, (int) '#', (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        float[] floatArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        float[] floatArray3 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray0, (int) (byte) 1, (int) (short) 100);
        java.lang.Class<?> wildcardClass4 = floatArray0.getClass();
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray19);
        java.lang.Integer[] intArray21 = org.apache.commons.lang3.ArrayUtils.toObject(intArray20);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.add(intArray20, 5, (int) ' ');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Integer[] intArray0 = null;
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray0, (int) (short) 100);
        org.junit.Assert.assertNull(intArray2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray3, 10, (int) (short) 100);
        byte[] byteArray13 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(byteArray13, (byte) 10);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.add(byteArray16, (byte) 0);
        byte[] byteArray22 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray22, 10, (int) (short) 100);
        java.lang.Byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray22);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray26, (byte) 0);
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.clone(byteArray28);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.add(byteArray28, (byte) 1);
        byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray16, byteArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray16);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray0, byteArray6);
        byte[] byteArray37 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray0, (int) (short) 100, 2);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(byteArray37);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 11, (int) (byte) 10, (double) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 1.0d, 10.0d, 0.0d, 0.0d, 0.0d, 1.0d };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray6);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray6, (double) (-1.0f));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        float[] floatArray0 = null;
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray5, '#', (int) ' ');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.Object[] objArray0 = null;
        boolean[] booleanArray6 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.add(booleanArray6, (int) (byte) 0, false);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray6);
        int[] intArray15 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray19 = new int[] { '4', 1, ' ' };
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray15, intArray19);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.add(intArray15, 4);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.contains(intArray15, (int) (short) 0);
        java.lang.Integer[] intArray25 = org.apache.commons.lang3.ArrayUtils.toObject(intArray15);
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray25, 1);
        int int29 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) booleanArray10, (java.lang.Object) intArray25, (int) (short) 100);
        boolean[] booleanArray30 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10);
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(objArray0, (java.lang.Object) booleanArray10, (int) (short) 10);
        boolean[] booleanArray33 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10);
        boolean[] booleanArray35 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10, false);
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(booleanArray33);
        org.junit.Assert.assertNotNull(booleanArray35);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) 7);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray11, (double) 10, (int) (short) 1);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray11, 0.0d, 3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int[] intArray0 = null;
        boolean boolean1 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray4, (java.lang.Object) floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray10, (float) 10);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray10, (float) (short) 0, 2);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray10, (float) 10);
        try {
            float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, 5, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.Float[] floatArray5 = new java.lang.Float[] { 1.0f, 100.0f, 0.0f, (-1.0f), 10.0f };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5, (float) 10L);
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray5);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.remove(floatArray8, 4);
        try {
            float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.remove(floatArray10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 10, (int) (short) 100);
        byte[] byteArray19 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(byteArray19, (byte) 10);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.clone(byteArray19);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray22);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.add(byteArray22, (byte) 0);
        byte[] byteArray28 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray28, 10, (int) (short) 100);
        java.lang.Byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray28);
        byte[] byteArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray32, (byte) 0);
        byte[] byteArray35 = org.apache.commons.lang3.ArrayUtils.clone(byteArray34);
        byte[] byteArray37 = org.apache.commons.lang3.ArrayUtils.add(byteArray34, (byte) 1);
        byte[] byteArray38 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray22, byteArray37);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray12, byteArray22);
        java.lang.Byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray12);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strComparableArray6, (java.lang.Object[]) byteArray40);
        byte[] byteArray42 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray40);
        byte[] byteArray44 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray40, (byte) 1);
        byte[] byteArray47 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray44, (int) (short) 100, (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertNotNull(byteArray47);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray9, (long) '4');
        java.lang.Class<?> wildcardClass12 = longArray9.getClass();
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray9, (long) 0, (int) 'a');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, (int) (short) 0);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray16);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.add(shortArray5, (short) (byte) -1);
        short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.add(shortArray19, (short) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray21);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray6, (int) (byte) 1, ' ');
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.clone(charArray9);
        java.lang.Character[] charArray11 = org.apache.commons.lang3.ArrayUtils.toObject(charArray10);
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.add(charArray10, (int) (short) 1, ' ');
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.remove(charArray14, (int) (byte) 1);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray14, 'a', (-1));
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, 'a', (int) (short) 1);
        try {
            char[] charArray24 = org.apache.commons.lang3.ArrayUtils.remove(charArray14, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.Class[][] classArray1 = new java.lang.Class[0][];
        @SuppressWarnings("unchecked") java.lang.Class<?>[][] wildcardClassArray2 = (java.lang.Class<?>[][]) classArray1;
        long[] longArray8 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.add(longArray8, 0L);
        long[] longArray12 = org.apache.commons.lang3.ArrayUtils.add(longArray8, (long) (short) 0);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray12, (long) '4');
        java.lang.Class<?> wildcardClass15 = longArray12.getClass();
        long[] longArray21 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray23 = org.apache.commons.lang3.ArrayUtils.add(longArray21, 0L);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.add(longArray21, (long) (short) 0);
        int int27 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray25, (long) '4');
        java.lang.Class<?> wildcardClass28 = longArray25.getClass();
        int[] intArray33 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray37 = new int[] { '4', 1, ' ' };
        int[] intArray38 = org.apache.commons.lang3.ArrayUtils.addAll(intArray33, intArray37);
        int[] intArray40 = org.apache.commons.lang3.ArrayUtils.add(intArray33, 4);
        boolean boolean42 = org.apache.commons.lang3.ArrayUtils.contains(intArray33, (int) (byte) 10);
        java.lang.Class<?> wildcardClass43 = intArray33.getClass();
        java.lang.Class[] classArray45 = new java.lang.Class[3];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray46 = (java.lang.Class<?>[]) classArray45;
        wildcardClassArray46[0] = wildcardClass15;
        wildcardClassArray46[1] = wildcardClass28;
        wildcardClassArray46[2] = wildcardClass43;
        java.lang.Class<?>[][] wildcardClassArray53 = org.apache.commons.lang3.ArrayUtils.add(wildcardClassArray2, wildcardClassArray46);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap54 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) wildcardClassArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, 'class [J', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(classArray1);
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(classArray45);
        org.junit.Assert.assertNotNull(wildcardClassArray46);
        org.junit.Assert.assertNotNull(wildcardClassArray53);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        java.lang.Float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray5);
        java.lang.String[] strArray9 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray11 = new java.lang.Comparable[1][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray12 = (java.lang.Comparable<java.lang.String>[][]) comparableArray11;
        strComparableArray12[0] = strArray9;
        java.lang.String[] strArray15 = new java.lang.String[] {};
        java.lang.String[] strArray16 = new java.lang.String[] {};
        java.lang.String[] strArray17 = new java.lang.String[] {};
        java.lang.String[] strArray18 = new java.lang.String[] {};
        java.lang.String[] strArray19 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray21 = new java.lang.Comparable[5][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray22 = (java.lang.Comparable<java.lang.String>[][]) comparableArray21;
        strComparableArray22[0] = strArray15;
        strComparableArray22[1] = strArray16;
        strComparableArray22[2] = strArray17;
        strComparableArray22[3] = strArray18;
        strComparableArray22[4] = strArray19;
        java.lang.Comparable<java.lang.String>[][] strComparableArray33 = org.apache.commons.lang3.ArrayUtils.addAll(strComparableArray12, strComparableArray22);
        boolean[] booleanArray39 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.add(booleanArray39, (int) (byte) 0, false);
        boolean[] booleanArray43 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray42);
        java.lang.Boolean[] booleanArray44 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray42);
        boolean[] booleanArray46 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray44, true);
        boolean[] booleanArray48 = org.apache.commons.lang3.ArrayUtils.add(booleanArray46, true);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) strComparableArray22, (java.lang.Object) true);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray8, (java.lang.Object[]) strComparableArray22);
        java.lang.Comparable<java.lang.String>[][] strComparableArray53 = org.apache.commons.lang3.ArrayUtils.subarray(strComparableArray22, (int) (byte) 100, 0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(strComparableArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(comparableArray21);
        org.junit.Assert.assertNotNull(strComparableArray22);
        org.junit.Assert.assertNotNull(strComparableArray33);
        org.junit.Assert.assertNotNull(booleanArray39);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray44);
        org.junit.Assert.assertNotNull(booleanArray46);
        org.junit.Assert.assertNotNull(booleanArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(strComparableArray53);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, 1);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.clone(intArray16);
        java.lang.String str19 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) intArray16, "0");
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{-1,1,97,52}" + "'", str19.equals("{-1,1,97,52}"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, 1);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.clone(intArray16);
        int[] intArray22 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray26 = new int[] { '4', 1, ' ' };
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.addAll(intArray22, intArray26);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.add(intArray22, 4);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.contains(intArray22, (int) (short) 0);
        java.lang.Integer[] intArray32 = org.apache.commons.lang3.ArrayUtils.toObject(intArray22);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray32, 1);
        int[] intArray35 = org.apache.commons.lang3.ArrayUtils.clone(intArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray16, intArray34);
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray16, (int) 'a');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) 7);
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray3);
        double[] doubleArray16 = new double[] { (byte) 100, 10, (byte) -1 };
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray16, (double) (short) 0);
        int int25 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray22, (double) ' ', (double) 0.0f);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray3, doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double[] doubleArray6 = new double[] { '#', 1, (byte) 0, 100, 1.0f, 100.0f };
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray6, (double) (byte) -1);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray8, (int) 'a', (int) ' ');
        double[] doubleArray14 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray11, (int) '4', (int) (byte) 100);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray19);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.remove(intArray20, (int) (short) 1);
        int[] intArray25 = org.apache.commons.lang3.ArrayUtils.add(intArray20, (int) (short) 0, 0);
        try {
            int[] intArray28 = org.apache.commons.lang3.ArrayUtils.add(intArray20, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 14");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, 1);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray16);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        short[] shortArray6 = new short[] { (short) 1, (byte) 0, (short) 100, (byte) -1, (short) 10, (byte) 100 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(shortArray6, (short) (byte) 10);
        java.lang.Short[] shortArray12 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray12, (short) (byte) -1);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray14);
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.clone(shortArray14);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shortArray16);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray4, (java.lang.Object) floatArray10);
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.clone(floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray13, (int) (byte) 1, (int) (short) 100);
        float[] floatArray17 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray17, (int) (byte) 1, (int) (short) 100);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray13, floatArray17);
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.add(floatArray13, (float) (byte) 10);
        float[] floatArray29 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.add(floatArray29, (float) (short) 100);
        float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray29, (int) (short) 1, (int) (short) 100);
        int int37 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray29, (float) (byte) 10, 2);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray23, floatArray29);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray12, floatArray29);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.contains(floatArray39, (float) 10);
        try {
            float[] floatArray44 = org.apache.commons.lang3.ArrayUtils.add(floatArray39, (int) (short) 100, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        byte[] byteArray0 = null;
        java.lang.Byte[] byteArray5 = new java.lang.Byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray5);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray0, byteArray6);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.add(byteArray0, (byte) 100);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray9, 0, 3);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray9, 5, (int) (short) 100);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        short[] shortArray31 = org.apache.commons.lang3.ArrayUtils.clone(shortArray26);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray26);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray17);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) shortArray15);
        try {
            short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.add(shortArray15, 7, (short) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        short[] shortArray0 = null;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4, (short) (byte) -1);
        short[] shortArray9 = new short[] { (byte) 100, (byte) 100 };
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) (byte) 10, (int) (byte) 1);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray9);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray6, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray6, (short) (byte) 1);
        java.lang.Short[] shortArray22 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray22, (short) (byte) -1);
        short[] shortArray27 = new short[] { (byte) 100, (byte) 100 };
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray27, (short) (byte) 10, (int) (byte) 1);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray24, shortArray27);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray24, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray24, (short) (byte) 1);
        java.lang.Short[] shortArray40 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray42 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray40, (short) (byte) -1);
        short[] shortArray45 = new short[] { (byte) 100, (byte) 100 };
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray45, (short) (byte) 10, (int) (byte) 1);
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray42, shortArray45);
        java.lang.Short[] shortArray53 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray55 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray53, (short) (byte) -1);
        short[] shortArray58 = new short[] { (byte) 100, (byte) 100 };
        int int61 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray58, (short) (byte) 10, (int) (byte) 1);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray55, shortArray58);
        int int65 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray55, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray67 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray55, (short) (byte) 1);
        java.lang.Short[] shortArray71 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray73 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray71, (short) (byte) -1);
        short[] shortArray76 = new short[] { (byte) 100, (byte) 100 };
        int int79 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray76, (short) (byte) 10, (int) (byte) 1);
        boolean boolean80 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray73, shortArray76);
        short[] shortArray81 = org.apache.commons.lang3.ArrayUtils.clone(shortArray76);
        boolean boolean82 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray67, shortArray76);
        short[] shortArray83 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray42, shortArray76);
        short[] shortArray84 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray36, shortArray76);
        boolean boolean85 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray76);
        short[] shortArray86 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray6);
        int int88 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray0, (short) 1);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray40);
        org.junit.Assert.assertNotNull(shortArray42);
        org.junit.Assert.assertNotNull(shortArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(shortArray53);
        org.junit.Assert.assertNotNull(shortArray55);
        org.junit.Assert.assertNotNull(shortArray58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(shortArray67);
        org.junit.Assert.assertNotNull(shortArray71);
        org.junit.Assert.assertNotNull(shortArray73);
        org.junit.Assert.assertNotNull(shortArray76);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(shortArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(shortArray83);
        org.junit.Assert.assertNotNull(shortArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(shortArray86);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) (byte) -1);
        short[] shortArray21 = new short[] { (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) (byte) 10, (int) (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray18, shortArray21);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray18, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray18, (short) (byte) 1);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        java.lang.Short[] shortArray47 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray49 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray47, (short) (byte) -1);
        short[] shortArray52 = new short[] { (byte) 100, (byte) 100 };
        int int55 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray52, (short) (byte) 10, (int) (byte) 1);
        boolean boolean56 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray49, shortArray52);
        int int59 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray49, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray61 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray49, (short) (byte) 1);
        java.lang.Short[] shortArray65 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray67 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray65, (short) (byte) -1);
        short[] shortArray70 = new short[] { (byte) 100, (byte) 100 };
        int int73 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray70, (short) (byte) 10, (int) (byte) 1);
        boolean boolean74 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray67, shortArray70);
        short[] shortArray75 = org.apache.commons.lang3.ArrayUtils.clone(shortArray70);
        boolean boolean76 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray61, shortArray70);
        short[] shortArray77 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray36, shortArray70);
        short[] shortArray78 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray30, shortArray70);
        short[] shortArray79 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray78);
        short[] shortArray80 = org.apache.commons.lang3.ArrayUtils.clone(shortArray79);
        int int82 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray79, (short) 0);
        boolean boolean84 = org.apache.commons.lang3.ArrayUtils.contains(shortArray79, (short) (byte) -1);
        short[] shortArray87 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray79, (int) (short) -1, (int) (short) 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shortArray47);
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(shortArray52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(shortArray61);
        org.junit.Assert.assertNotNull(shortArray65);
        org.junit.Assert.assertNotNull(shortArray67);
        org.junit.Assert.assertNotNull(shortArray70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(shortArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(shortArray77);
        org.junit.Assert.assertNotNull(shortArray78);
        org.junit.Assert.assertNotNull(shortArray79);
        org.junit.Assert.assertNotNull(shortArray80);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 5 + "'", int82 == 5);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(shortArray87);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Float[] floatArray4 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        java.lang.Float[] floatArray10 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray4, (java.lang.Object[]) floatArray10);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray16, (float) (short) -1);
        float[] floatArray19 = null;
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray16, floatArray19);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray0);
        try {
            boolean[] booleanArray3 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (-1L));
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 3, (double) (short) 10);
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.add(doubleArray16, (double) '4');
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, (double) 'a', (double) 1);
        java.lang.Short[] shortArray25 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray25, (short) (byte) -1);
        short[] shortArray30 = new short[] { (byte) 100, (byte) 100 };
        int int33 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray30, (short) (byte) 10, (int) (byte) 1);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray27, shortArray30);
        short[] shortArray35 = org.apache.commons.lang3.ArrayUtils.clone(shortArray30);
        short[] shortArray37 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray30, (short) 100);
        int int38 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) shortArray37);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) 1, (java.lang.Object) int38);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(shortArray25);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertNotNull(shortArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        java.lang.Short[] shortArray18 = new java.lang.Short[] { (short) 10, (short) -1 };
        short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray18);
        java.lang.Short[] shortArray20 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray19);
        short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray19);
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray21, 7, (-1));
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray24, (short) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray26);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 0);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        try {
            byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray8, (int) (short) -1, (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.subarray(charArray2, (int) (short) 100, (int) (short) 10);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.clone(charArray2);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(charArray2, ' ');
        org.apache.commons.lang3.ArrayUtils.reverse(charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.clone(shortArray5);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray18);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        char[] charArray0 = new char[] {};
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.add(charArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#');
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray0, '#');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double[][] doubleArray0 = new double[][] {};
        try {
            double[][] doubleArray2 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        byte[] byteArray1 = new byte[] { (byte) 1 };
        try {
            byte[] byteArray4 = org.apache.commons.lang3.ArrayUtils.add(byteArray1, (int) (byte) 100, (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 0.0d };
        double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray1, (double) 100);
        double[] doubleArray7 = new double[] { (byte) 100, 10, (byte) -1 };
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray7, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray7, 0.0d);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray7, 0, (double) (short) 1);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray3, doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        long[] longArray6 = new long[] { 100L, 0, (short) 0, ' ', (short) 1, 10 };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) (short) 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 1, (-1));
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray6, (long) '4', (int) (short) 10);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray6, (long) 2);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray8);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray8);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10, true);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray12, true);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray14);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) (byte) -1);
        short[] shortArray21 = new short[] { (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) (byte) 10, (int) (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray18, shortArray21);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray18, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray18, (short) (byte) 1);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        short[] shortArray44 = org.apache.commons.lang3.ArrayUtils.clone(shortArray39);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray30, shortArray39);
        short[] shortArray46 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray39);
        short[] shortArray47 = org.apache.commons.lang3.ArrayUtils.clone(shortArray39);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray47);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(shortArray46);
        org.junit.Assert.assertNotNull(shortArray47);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.lang.Float[] floatArray4 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        java.lang.Float[] floatArray10 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray4, (java.lang.Object[]) floatArray10);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray16, (float) (short) -1);
        float[] floatArray24 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.add(floatArray24, (float) (short) 100);
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray26, 0.0f);
        float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray16, floatArray26);
        java.lang.Float[] floatArray30 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray16);
        try {
            float[] floatArray33 = org.apache.commons.lang3.ArrayUtils.add(floatArray16, (int) 'a', 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        boolean[] booleanArray17 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.add(booleanArray17, (int) (byte) 0, false);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray17, true, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray17);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray11, booleanArray17);
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray17, true, (int) (short) -1);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.clone(intArray4);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray15, (int) (short) 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double[] doubleArray0 = new double[] {};
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray0, 1.0d);
        int int4 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (byte) 10);
        int[] intArray14 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.add(intArray14, 0);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray16);
        try {
            int[] intArray19 = org.apache.commons.lang3.ArrayUtils.remove(intArray17, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray5);
        boolean[] booleanArray15 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.add(booleanArray15, (int) (byte) 0, false);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray5, booleanArray15);
        boolean[] booleanArray21 = org.apache.commons.lang3.ArrayUtils.add(booleanArray15, false);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(booleanArray21);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) ' ');
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, 10, (int) (short) 100);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray7);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) charArray2, (java.lang.Object) byteArray11);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        char[] charArray15 = org.apache.commons.lang3.ArrayUtils.add(charArray2, '#');
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.clone(charArray15);
        try {
            char[] charArray18 = org.apache.commons.lang3.ArrayUtils.remove(charArray15, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray16);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        long[] longArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray0, 0L, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 1.0d };
        double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray1, (double) (byte) 0);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray13, (short) (byte) -1);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.add(shortArray15, (short) (byte) 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertNotNull(shortArray17);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray4, (-1), (int) (short) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray4, 7, (int) (byte) 10);
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray4, (int) (byte) -1, (int) (short) 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, true };
        boolean[] booleanArray11 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.add(booleanArray11, (int) (byte) 0, false);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray5, booleanArray11);
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, 4, (int) (byte) -1);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(booleanArray18);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, 'a');
        char[] charArray5 = new char[] { 'a', '4' };
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray5);
        java.lang.Character[] charArray7 = org.apache.commons.lang3.ArrayUtils.toObject(charArray5);
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray7);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.addAll(charArray2, charArray9);
        java.lang.Character[] charArray11 = org.apache.commons.lang3.ArrayUtils.toObject(charArray9);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Byte[] byteArray4 = new java.lang.Byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray4);
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 100, (byte) -1, (byte) -1, (byte) -1 };
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray9, (byte) -1, (int) (byte) 10);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        short[] shortArray0 = null;
        try {
            short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.add(shortArray0, (int) (byte) 100, (short) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0);
        java.util.Map<java.lang.Object, java.lang.Object> objMap2 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(objMap2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10, true);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.add(booleanArray12, true);
        boolean[] booleanArray16 = org.apache.commons.lang3.ArrayUtils.add(booleanArray12, false);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray16);
        boolean[] booleanArray23 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.add(booleanArray23, (int) (byte) 0, false);
        boolean[] booleanArray27 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray26);
        java.lang.Boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray26);
        boolean[] booleanArray30 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray28, true);
        boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.add(booleanArray30, true);
        boolean[] booleanArray38 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray41 = org.apache.commons.lang3.ArrayUtils.add(booleanArray38, (int) (byte) 0, false);
        boolean[] booleanArray42 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray41);
        java.lang.Boolean[] booleanArray43 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray41);
        boolean[] booleanArray44 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray30, booleanArray41);
        boolean[] booleanArray46 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray44, false);
        boolean[] booleanArray47 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray16, booleanArray44);
        int int50 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray47, true, (int) (short) 10);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertNotNull(booleanArray30);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertNotNull(booleanArray38);
        org.junit.Assert.assertNotNull(booleanArray41);
        org.junit.Assert.assertNotNull(booleanArray42);
        org.junit.Assert.assertNotNull(booleanArray43);
        org.junit.Assert.assertNotNull(booleanArray44);
        org.junit.Assert.assertNotNull(booleanArray46);
        org.junit.Assert.assertNotNull(booleanArray47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        short[] shortArray15 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray8, (short) 100);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray15, (short) (byte) 0);
        try {
            short[] shortArray19 = org.apache.commons.lang3.ArrayUtils.remove(shortArray15, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.lang.Short[] shortArray2 = new java.lang.Short[] { (short) 10, (short) -1 };
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray2);
        java.lang.Short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray3);
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray3);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray9 = new int[] { '4', 1, ' ' };
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.addAll(intArray5, intArray9);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.add(intArray5, 4);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(intArray5, (int) (short) 0);
        java.lang.Integer[] intArray15 = org.apache.commons.lang3.ArrayUtils.toObject(intArray5);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray15, (int) (short) 0);
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.add(intArray17, (int) ' ');
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray19, 6, 5);
        java.lang.Integer[] intArray23 = org.apache.commons.lang3.ArrayUtils.toObject(intArray19);
        boolean boolean24 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray0, intArray19);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        byte[] byteArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray0, (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (-1L));
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray3, 1, (int) (short) 0);
        double[] doubleArray17 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray6, (int) (byte) 1, ' ');
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.clone(charArray9);
        java.lang.Character[] charArray11 = org.apache.commons.lang3.ArrayUtils.toObject(charArray10);
        char[] charArray14 = org.apache.commons.lang3.ArrayUtils.add(charArray10, (int) (short) 1, ' ');
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.remove(charArray14, (int) (byte) 1);
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray14, '4', (-1));
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        short[] shortArray0 = null;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4, (short) (byte) -1);
        short[] shortArray9 = new short[] { (byte) 100, (byte) 100 };
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) (byte) 10, (int) (byte) 1);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray9);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.clone(shortArray9);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray9);
        short[] shortArray16 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray9);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shortArray16);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        char[] charArray2 = new char[] { '#', '4' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.subarray(charArray2, 100, 5);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray5);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray5, ' ', (int) 'a');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 0);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray16 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(byteArray16, (byte) 10);
        byte[] byteArray19 = null;
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray16, byteArray19);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray20);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray9);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray21);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        byte[] byteArray12 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 10);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray15);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.add(byteArray15, (byte) 0);
        byte[] byteArray21 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray21, 10, (int) (short) 100);
        java.lang.Byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray21);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray25, (byte) 0);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.clone(byteArray27);
        byte[] byteArray30 = org.apache.commons.lang3.ArrayUtils.add(byteArray27, (byte) 1);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray15, byteArray30);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray5, byteArray15);
        java.lang.Byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        byte[] byteArray36 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray5, (int) (byte) -1, (int) (byte) 1);
        try {
            byte[] byteArray39 = org.apache.commons.lang3.ArrayUtils.add(byteArray5, 3, (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray36);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray4, (java.lang.Object) floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray10, (float) 10);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray10, (float) (short) 0, 2);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray10, (float) 10);
        int int21 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray10, (float) (short) 0, (int) (byte) 0);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.Float[] floatArray4 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        java.lang.Float[] floatArray10 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray4, (java.lang.Object[]) floatArray10);
        double[] doubleArray18 = new double[] { (byte) 100, 10, (byte) -1 };
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray18, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray18, (double) (short) 0);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, 100.0d);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) floatArray4, (java.lang.Object) doubleArray18);
        float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4, (-1.0f));
        int int32 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray29, (float) (short) 100, 3);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray29, (float) 1, (int) (short) 1);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        char[] charArray0 = new char[] {};
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.add(charArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#');
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.clone(charArray0);
        java.lang.Character[] charArray6 = org.apache.commons.lang3.ArrayUtils.toObject(charArray0);
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray6, ' ');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int[] intArray0 = null;
        int[] intArray1 = org.apache.commons.lang3.ArrayUtils.clone(intArray0);
        org.junit.Assert.assertNull(intArray1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int[] intArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray0, 11, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        float[] floatArray0 = null;
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.contains(floatArray0, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        long[] longArray1 = new long[] { (short) 1 };
        java.lang.Long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toObject(longArray1);
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray9 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray7, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray12 = org.apache.commons.lang3.ArrayUtils.subarray(strArray7, (-1), (int) (short) 10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray7, (java.lang.Object) floatArray13);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray2, (java.lang.Object) strArray14);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, 0L);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strComparableArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(longArray17);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray2, ' ');
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.clone(charArray2);
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.clone(charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) (byte) -1);
        short[] shortArray21 = new short[] { (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) (byte) 10, (int) (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray18, shortArray21);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray18, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray18, (short) (byte) 1);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        short[] shortArray44 = org.apache.commons.lang3.ArrayUtils.clone(shortArray39);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray30, shortArray39);
        short[] shortArray46 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray39);
        short[] shortArray47 = org.apache.commons.lang3.ArrayUtils.clone(shortArray46);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray46, (short) 0);
        short[] shortArray50 = org.apache.commons.lang3.ArrayUtils.clone(shortArray46);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(shortArray46);
        org.junit.Assert.assertNotNull(shortArray47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
        org.junit.Assert.assertNotNull(shortArray50);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_ARRAY;
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray3, 10, (int) (short) 100);
        byte[] byteArray13 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(byteArray13, (byte) 10);
        byte[] byteArray16 = org.apache.commons.lang3.ArrayUtils.clone(byteArray13);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray16);
        byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.add(byteArray16, (byte) 0);
        byte[] byteArray22 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray22, 10, (int) (short) 100);
        java.lang.Byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray22);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray26, (byte) 0);
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.clone(byteArray28);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.add(byteArray28, (byte) 1);
        byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray16, byteArray31);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray6, byteArray16);
        boolean boolean34 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray0, byteArray6);
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray6);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        long[][] longArray0 = new long[][] {};
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4, (short) (byte) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray6);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains(shortArray6, (short) (byte) 10);
        long[][] longArray10 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray0, (java.lang.Object) shortArray6);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray13 = org.apache.commons.lang3.ArrayUtils.add(intArray11, 0);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(intArray11, (int) (byte) 10);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) longArray10, (java.lang.Object) (byte) 10);
        boolean boolean17 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray10);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, (int) (short) 0);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14);
        java.lang.Object obj18 = null;
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) intArray14, obj18);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.add(intArray9, 1, (int) (byte) 1);
        int int13 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) intArray9);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 0.0d };
        double[] doubleArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray1, (double) 100);
        double[] doubleArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        byte[] byteArray12 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.contains(byteArray12, (byte) 10);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.clone(byteArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray15);
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.add(byteArray15, (byte) 0);
        byte[] byteArray21 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray21, 10, (int) (short) 100);
        java.lang.Byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray21);
        byte[] byteArray27 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray25, (byte) 0);
        byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.clone(byteArray27);
        byte[] byteArray30 = org.apache.commons.lang3.ArrayUtils.add(byteArray27, (byte) 1);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray15, byteArray30);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray5, byteArray15);
        java.lang.Byte[] byteArray33 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        byte[] byteArray35 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray33, (byte) 1);
        int int37 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray35, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 10, (int) (short) 100);
        byte[] byteArray19 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(byteArray19, (byte) 10);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.clone(byteArray19);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray22);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.add(byteArray22, (byte) 0);
        byte[] byteArray28 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray28, 10, (int) (short) 100);
        java.lang.Byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray28);
        byte[] byteArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray32, (byte) 0);
        byte[] byteArray35 = org.apache.commons.lang3.ArrayUtils.clone(byteArray34);
        byte[] byteArray37 = org.apache.commons.lang3.ArrayUtils.add(byteArray34, (byte) 1);
        byte[] byteArray38 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray22, byteArray37);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray12, byteArray22);
        java.lang.Byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray12);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strComparableArray6, (java.lang.Object[]) byteArray40);
        java.lang.Double[] doubleArray43 = new java.lang.Double[] { 1.0d };
        double[] doubleArray45 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray43, (double) (byte) 0);
        boolean boolean46 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strComparableArray6, (java.lang.Object[]) doubleArray43);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) doubleArray43);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        float[] floatArray9 = org.apache.commons.lang3.ArrayUtils.add(floatArray7, (float) (-1L));
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(floatArray7, 1.0f);
        java.lang.Float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray7);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 0);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray12, (byte) 10, (int) (byte) 10);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray12, (byte) 1);
        try {
            byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.remove(byteArray17, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Length: 7");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertNotNull(byteArray17);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        int int7 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) charArray4, (java.lang.Object) 1.0f);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4, 'a');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(charArray9);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        char[] charArray0 = new char[] {};
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.add(charArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#');
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#', 4);
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.subarray(charArray0, (int) (short) 1, 3);
        byte[] byteArray17 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.contains(byteArray17, (byte) 10);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.clone(byteArray17);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) charArray0, (java.lang.Object) byteArray20);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { '4', 0.0f, 0.0f, 'a', (short) 100 };
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray6, (double) 4, (double) (byte) 1);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray6);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_ARRAY;
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray6, doubleArray11);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray0, doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        boolean[] booleanArray17 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.add(booleanArray17, (int) (byte) 0, false);
        int int23 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray17, true, (int) (byte) 0);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray17);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray11, booleanArray17);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.lang.Short[] shortArray0 = null;
        short[] shortArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        org.junit.Assert.assertNull(shortArray1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        int int46 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray36, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray48 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray36, (short) (byte) 1);
        java.lang.Short[] shortArray52 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray54 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray52, (short) (byte) -1);
        short[] shortArray57 = new short[] { (byte) 100, (byte) 100 };
        int int60 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray57, (short) (byte) 10, (int) (byte) 1);
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray54, shortArray57);
        short[] shortArray62 = org.apache.commons.lang3.ArrayUtils.clone(shortArray57);
        boolean boolean63 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray48, shortArray57);
        short[] shortArray64 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray23, shortArray57);
        short[] shortArray65 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray17, shortArray57);
        int int68 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) 100, (int) (short) 100);
        java.lang.Short[] shortArray72 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray74 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray72, (short) (byte) -1);
        short[] shortArray77 = new short[] { (byte) 100, (byte) 100 };
        int int80 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray77, (short) (byte) 10, (int) (byte) 1);
        boolean boolean81 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray74, shortArray77);
        int int84 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray74, (short) (byte) -1, (int) (byte) 100);
        java.lang.Short[] shortArray87 = new java.lang.Short[] { (short) 10, (short) -1 };
        short[] shortArray88 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray87);
        java.lang.Short[] shortArray89 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray88);
        short[] shortArray90 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray74, shortArray88);
        short[] shortArray92 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray90, (short) 100);
        short[] shortArray93 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray17, shortArray92);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(shortArray48);
        org.junit.Assert.assertNotNull(shortArray52);
        org.junit.Assert.assertNotNull(shortArray54);
        org.junit.Assert.assertNotNull(shortArray57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(shortArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(shortArray64);
        org.junit.Assert.assertNotNull(shortArray65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(shortArray72);
        org.junit.Assert.assertNotNull(shortArray74);
        org.junit.Assert.assertNotNull(shortArray77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertNotNull(shortArray87);
        org.junit.Assert.assertNotNull(shortArray88);
        org.junit.Assert.assertNotNull(shortArray89);
        org.junit.Assert.assertNotNull(shortArray90);
        org.junit.Assert.assertNotNull(shortArray92);
        org.junit.Assert.assertNotNull(shortArray93);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.Long[] longArray6 = new java.lang.Long[] { (-1L), 0L, 100L, 100L, 1L, 100L };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        java.lang.Integer[] intArray8 = org.apache.commons.lang3.ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY;
        java.lang.Short[] shortArray12 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray12, (short) (byte) -1);
        short[] shortArray17 = new short[] { (byte) 100, (byte) 100 };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) (byte) 10, (int) (byte) 1);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray14, shortArray17);
        int int24 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray14, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray14, (short) (byte) 1);
        java.lang.Short[] shortArray30 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray32 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray30, (short) (byte) -1);
        short[] shortArray35 = new short[] { (byte) 100, (byte) 100 };
        int int38 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray35, (short) (byte) 10, (int) (byte) 1);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray32, shortArray35);
        java.lang.Short[] shortArray43 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray45 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray43, (short) (byte) -1);
        short[] shortArray48 = new short[] { (byte) 100, (byte) 100 };
        int int51 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray48, (short) (byte) 10, (int) (byte) 1);
        boolean boolean52 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray45, shortArray48);
        int int55 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray45, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray57 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray45, (short) (byte) 1);
        java.lang.Short[] shortArray61 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray63 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray61, (short) (byte) -1);
        short[] shortArray66 = new short[] { (byte) 100, (byte) 100 };
        int int69 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray66, (short) (byte) 10, (int) (byte) 1);
        boolean boolean70 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray63, shortArray66);
        short[] shortArray71 = org.apache.commons.lang3.ArrayUtils.clone(shortArray66);
        boolean boolean72 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray57, shortArray66);
        short[] shortArray73 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray32, shortArray66);
        short[] shortArray74 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray26, shortArray66);
        int int77 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) 100, (int) (short) 100);
        boolean boolean78 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) intArray8, (java.lang.Object) (short) 100);
        int int80 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray6, (java.lang.Object) (short) 100, (int) (short) 0);
        long[] longArray81 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        long[] longArray87 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray89 = org.apache.commons.lang3.ArrayUtils.add(longArray87, 0L);
        boolean boolean90 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray81, longArray89);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(shortArray12);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray32);
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shortArray43);
        org.junit.Assert.assertNotNull(shortArray45);
        org.junit.Assert.assertNotNull(shortArray48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(shortArray57);
        org.junit.Assert.assertNotNull(shortArray61);
        org.junit.Assert.assertNotNull(shortArray63);
        org.junit.Assert.assertNotNull(shortArray66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(shortArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(shortArray73);
        org.junit.Assert.assertNotNull(shortArray74);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
        org.junit.Assert.assertNotNull(longArray81);
        org.junit.Assert.assertNotNull(longArray87);
        org.junit.Assert.assertNotNull(longArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 0);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray8, (byte) 1);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.clone(byteArray11);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray11, (byte) 0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.Long[] longArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_LONG_OBJECT_ARRAY;
        long[] longArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray0);
        long[] longArray4 = org.apache.commons.lang3.ArrayUtils.subarray(longArray1, (int) ' ', (int) ' ');
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.subarray(longArray4, (int) '4', (int) (byte) 0);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray7, 0L, 11);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray5);
        try {
            short[] shortArray9 = org.apache.commons.lang3.ArrayUtils.add(shortArray5, 7, (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray9, (double) 4);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray9);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray9, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, 1);
        int[] intArray17 = org.apache.commons.lang3.ArrayUtils.clone(intArray16);
        int[] intArray22 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray26 = new int[] { '4', 1, ' ' };
        int[] intArray27 = org.apache.commons.lang3.ArrayUtils.addAll(intArray22, intArray26);
        int[] intArray29 = org.apache.commons.lang3.ArrayUtils.add(intArray22, 4);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.contains(intArray22, (int) (short) 0);
        java.lang.Integer[] intArray32 = org.apache.commons.lang3.ArrayUtils.toObject(intArray22);
        int[] intArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray32, 1);
        int[] intArray35 = org.apache.commons.lang3.ArrayUtils.clone(intArray34);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray16, intArray34);
        int[] intArray37 = org.apache.commons.lang3.ArrayUtils.clone(intArray34);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray9, (byte) 0);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray12, (byte) 0);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray12);
        boolean boolean16 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray12);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray17 = new double[] { '4', 0.0f, 0.0f, 'a', (short) 100 };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray17, (double) 4, (double) (byte) 1);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray17);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray3, doubleArray17);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray17, (double) (byte) 1, (double) (short) 10);
        double[] doubleArray27 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray17, 1.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray4, (-1), (int) (short) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(intArray4, 4, 0);
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.removeElement(intArray4, (int) (short) 1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray15 = new double[] { (byte) 100, 10, (byte) -1 };
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray15, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray11, doubleArray15);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray20, (double) 10.0f, (double) 4);
        int int27 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray20, (double) (short) 10, (int) ' ', 100.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 1L);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, (double) 10);
        java.lang.String str14 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{100.0,10.0,-1.0}" + "'", str14.equals("{100.0,10.0,-1.0}"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 0);
        byte[] byteArray15 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray18 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray15, 10, (int) (short) 100);
        java.lang.Byte[] byteArray19 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray15);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray19, (byte) 0);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.clone(byteArray21);
        byte[] byteArray24 = org.apache.commons.lang3.ArrayUtils.add(byteArray21, (byte) 1);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray9, byteArray24);
        byte[] byteArray26 = org.apache.commons.lang3.ArrayUtils.clone(byteArray24);
        try {
            byte[] byteArray28 = org.apache.commons.lang3.ArrayUtils.remove(byteArray24, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray26);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) 7);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 10);
        double[] doubleArray17 = new double[] { (byte) 100, 10, (byte) -1 };
        int int21 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray17, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray23 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray17, (double) (short) 0);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray23, (double) ' ', (double) 0.0f);
        double[] doubleArray28 = org.apache.commons.lang3.ArrayUtils.add(doubleArray23, (double) (byte) 100);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray23);
        double[] doubleArray30 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray3, doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray2, (byte) 10);
        try {
            byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray2, (-1), (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        long[] longArray1 = new long[] { (short) 1 };
        java.lang.Long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toObject(longArray1);
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, 10L);
        boolean boolean6 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray5);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray19);
        int[] intArray22 = org.apache.commons.lang3.ArrayUtils.remove(intArray20, (int) (short) 1);
        int[] intArray24 = org.apache.commons.lang3.ArrayUtils.remove(intArray22, 0);
        try {
            int[] intArray27 = org.apache.commons.lang3.ArrayUtils.add(intArray22, (int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 13");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double[] doubleArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray0, (double) (-1.0f), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray15 = org.apache.commons.lang3.ArrayUtils.clone(intArray4);
        java.lang.String str17 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) intArray4, "{100.0,10.0,-1.0}");
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{-1,1,97,52}" + "'", str17.equals("{-1,1,97,52}"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray9, (byte) 0);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray12, (byte) 0);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray14, (byte) 0, 0);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0, (short) 1);
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.clone(shortArray2);
        try {
            short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.add(shortArray3, (int) (byte) 100, (short) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.Character[] charArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY;
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, '#');
        char[] charArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0, ' ');
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (-1L));
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 3, (double) (short) 10);
        boolean boolean18 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray3, (double) 100);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray3, (double) (-1.0f));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        char[] charArray0 = new char[] {};
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.add(charArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#');
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.clone(charArray0);
        char[] charArray7 = org.apache.commons.lang3.ArrayUtils.add(charArray0, '#');
        try {
            char[] charArray10 = org.apache.commons.lang3.ArrayUtils.add(charArray7, (int) 'a', 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray6, (int) (byte) 1, ' ');
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.clone(charArray9);
        java.lang.Character[] charArray11 = org.apache.commons.lang3.ArrayUtils.toObject(charArray10);
        double[] doubleArray15 = new double[] { (byte) 100, 10, (byte) -1 };
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray15, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray21 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray15, (double) (short) 0);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray15, (double) 1L);
        double[] doubleArray25 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray15, (int) (byte) 1);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) charArray11, (java.lang.Object) doubleArray15);
        double[] doubleArray30 = new double[] { (byte) 100, 10, (byte) -1 };
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray30, (double) 100, (int) 'a', (double) 0.0f);
        int int38 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray30, 0.0d, (int) (byte) 0, (double) (short) 10);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray15, doubleArray30);
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray30, (double) (short) -1, (double) '4');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.Long[] longArray6 = new java.lang.Long[] { (-1L), 0L, 100L, 100L, 1L, 100L };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray6);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray7, (-1L));
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray9, (long) ' ');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.Float[] floatArray4 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        java.lang.Float[] floatArray10 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray4, (java.lang.Object[]) floatArray10);
        double[] doubleArray18 = new double[] { (byte) 100, 10, (byte) -1 };
        int int22 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray18, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray24 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray18, (double) (short) 0);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray18, 100.0d);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) floatArray4, (java.lang.Object) doubleArray18);
        int[] intArray32 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray36 = new int[] { '4', 1, ' ' };
        int[] intArray37 = org.apache.commons.lang3.ArrayUtils.addAll(intArray32, intArray36);
        int[] intArray39 = org.apache.commons.lang3.ArrayUtils.add(intArray32, 4);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.contains(intArray32, (int) (short) 0);
        java.lang.Integer[] intArray42 = org.apache.commons.lang3.ArrayUtils.toObject(intArray32);
        int[] intArray44 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray42, (int) (short) 0);
        int[] intArray46 = org.apache.commons.lang3.ArrayUtils.add(intArray44, (int) ' ');
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray46, 6, 5);
        int[] intArray54 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray58 = new int[] { '4', 1, ' ' };
        int[] intArray59 = org.apache.commons.lang3.ArrayUtils.addAll(intArray54, intArray58);
        int[] intArray61 = org.apache.commons.lang3.ArrayUtils.add(intArray54, 4);
        boolean boolean63 = org.apache.commons.lang3.ArrayUtils.contains(intArray54, (int) (byte) 10);
        int[] intArray64 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray66 = org.apache.commons.lang3.ArrayUtils.add(intArray64, 0);
        int[] intArray67 = org.apache.commons.lang3.ArrayUtils.addAll(intArray54, intArray66);
        boolean boolean68 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray46, intArray66);
        int[] intArray69 = org.apache.commons.lang3.ArrayUtils.clone(intArray66);
        boolean boolean70 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) floatArray4, (java.lang.Object) intArray66);
        java.lang.String[] strArray75 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray77 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray75, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray80 = org.apache.commons.lang3.ArrayUtils.subarray(strArray75, (-1), (int) (short) 10);
        float[] floatArray81 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray82 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray75, (java.lang.Object) floatArray81);
        float[] floatArray84 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray81, (float) 10);
        int int85 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) floatArray4, (java.lang.Object) floatArray81);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(strArray75);
        org.junit.Assert.assertNotNull(strComparableArray77);
        org.junit.Assert.assertNotNull(strArray80);
        org.junit.Assert.assertNotNull(floatArray81);
        org.junit.Assert.assertNotNull(strArray82);
        org.junit.Assert.assertNotNull(floatArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        long[] longArray0 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.add(longArray0, 0, 0L);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) 5);
        int int8 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) 7, (int) '#');
        try {
            long[] longArray11 = org.apache.commons.lang3.ArrayUtils.add(longArray3, (int) (short) 10, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        try {
            int int1 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) "1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0, (short) -1);
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        int int6 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray3, (short) (byte) 10, 7);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray9, 10, (int) (short) 100);
        byte[] byteArray19 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.contains(byteArray19, (byte) 10);
        byte[] byteArray22 = org.apache.commons.lang3.ArrayUtils.clone(byteArray19);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray22);
        byte[] byteArray25 = org.apache.commons.lang3.ArrayUtils.add(byteArray22, (byte) 0);
        byte[] byteArray28 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray28, 10, (int) (short) 100);
        java.lang.Byte[] byteArray32 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray28);
        byte[] byteArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray32, (byte) 0);
        byte[] byteArray35 = org.apache.commons.lang3.ArrayUtils.clone(byteArray34);
        byte[] byteArray37 = org.apache.commons.lang3.ArrayUtils.add(byteArray34, (byte) 1);
        byte[] byteArray38 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray22, byteArray37);
        boolean boolean39 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray12, byteArray22);
        java.lang.Byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray12);
        boolean boolean41 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) strComparableArray6, (java.lang.Object[]) byteArray40);
        byte[] byteArray42 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray40);
        java.lang.String[] strArray47 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray49 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray47, (java.lang.Comparable<java.lang.String>) "hi!");
        int int51 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) strComparableArray49, (java.lang.Object) 10.0d);
        char[] charArray54 = new char[] { 'a', '4' };
        boolean boolean55 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray54);
        java.lang.Character[] charArray56 = org.apache.commons.lang3.ArrayUtils.toObject(charArray54);
        char[] charArray57 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray56);
        char[] charArray58 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray56);
        char[] charArray59 = org.apache.commons.lang3.ArrayUtils.clone(charArray58);
        int int60 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) strComparableArray49, (java.lang.Object) charArray58);
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) byteArray40, (java.lang.Object) int60);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertNotNull(strComparableArray49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(charArray56);
        org.junit.Assert.assertNotNull(charArray57);
        org.junit.Assert.assertNotNull(charArray58);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.clone(longArray5);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray11, (long) (short) -1, 100);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (short) 1, (int) (short) 100);
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.remove(floatArray10, (int) (byte) 1);
        float[] floatArray18 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) (short) 100);
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray20, (-1.0f));
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray10, floatArray22);
        try {
            float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.add(floatArray10, (int) (byte) 100, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        java.lang.CharSequence[] charSequenceArray11 = org.apache.commons.lang3.ArrayUtils.add((java.lang.CharSequence[]) strArray4, (java.lang.CharSequence) "{1.0,1.0,0.0,10.0}");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(charSequenceArray11);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray6, (int) (byte) 1, ' ');
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.clone(charArray9);
        java.lang.Character[] charArray11 = org.apache.commons.lang3.ArrayUtils.toObject(charArray9);
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray11, '#');
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap14 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) charArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, 'a', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray13);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Boolean[] booleanArray6 = new java.lang.Boolean[] { false, false, true, false, true, false };
        java.lang.Boolean[] booleanArray13 = new java.lang.Boolean[] { false, false, true, false, true, false };
        java.lang.Boolean[] booleanArray20 = new java.lang.Boolean[] { false, false, true, false, true, false };
        java.lang.Boolean[] booleanArray27 = new java.lang.Boolean[] { false, false, true, false, true, false };
        java.lang.Boolean[][] booleanArray28 = new java.lang.Boolean[][] { booleanArray6, booleanArray13, booleanArray20, booleanArray27 };
        try {
            java.lang.Boolean[][] booleanArray30 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray28, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray6);
        org.junit.Assert.assertNotNull(booleanArray13);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertNotNull(booleanArray27);
        org.junit.Assert.assertNotNull(booleanArray28);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray9, (double) ' ', (double) 0.0f);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray9, (double) 1.0f, (double) (-1));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.subarray(charArray2, (int) (short) 100, (int) (short) 10);
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.add(charArray6, '4');
        char[] charArray9 = new char[] {};
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.add(charArray9, '4');
        int int13 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray9, '#');
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray9, '#', 4);
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.subarray(charArray9, (int) (short) 1, 3);
        char[] charArray20 = org.apache.commons.lang3.ArrayUtils.addAll(charArray8, charArray19);
        boolean boolean21 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray19);
        java.lang.Character[] charArray22 = org.apache.commons.lang3.ArrayUtils.toObject(charArray19);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(charArray22);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = null;
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray6, byteArray9);
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray6, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        short[] shortArray31 = org.apache.commons.lang3.ArrayUtils.clone(shortArray26);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray26);
        short[] shortArray35 = org.apache.commons.lang3.ArrayUtils.add(shortArray26, (int) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shortArray35);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        long[] longArray4 = new long[] { (-1), 3, (byte) 10, (byte) 0 };
        long[] longArray11 = new long[] { 100L, 0, (short) 0, ' ', (short) 1, 10 };
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray11, (long) (short) 1);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray11);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray11, (long) (short) 0, (int) '#');
        long[] longArray19 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray11, 1L);
        byte[] byteArray26 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean28 = org.apache.commons.lang3.ArrayUtils.contains(byteArray26, (byte) 10);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray26, (byte) -1);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) longArray19, (java.lang.Object) byteArray26);
        long[] longArray32 = org.apache.commons.lang3.ArrayUtils.addAll(longArray4, longArray19);
        long[] longArray35 = org.apache.commons.lang3.ArrayUtils.subarray(longArray32, 4, (int) 'a');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray35);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[] byteArray17 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[] byteArray23 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[][] byteArray24 = new byte[][] { byteArray5, byteArray11, byteArray17, byteArray23 };
        byte[] byteArray28 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray28, 10, (int) (short) 100);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.contains(byteArray28, (byte) 0);
        byte[][] byteArray34 = org.apache.commons.lang3.ArrayUtils.add(byteArray24, (int) (short) 1, byteArray28);
        java.lang.Byte[] byteArray39 = new java.lang.Byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray39);
        byte[][] byteArray41 = org.apache.commons.lang3.ArrayUtils.add(byteArray24, byteArray40);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) byteArray41);
        long[] longArray44 = new long[] { (short) 1 };
        java.lang.Long[] longArray45 = org.apache.commons.lang3.ArrayUtils.toObject(longArray44);
        boolean boolean47 = org.apache.commons.lang3.ArrayUtils.contains(longArray44, (-1L));
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray41, (java.lang.Object) longArray44, (int) (byte) 0);
        byte[][] byteArray50 = org.apache.commons.lang3.ArrayUtils.clone(byteArray41);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(longArray44);
        org.junit.Assert.assertNotNull(longArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(byteArray50);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        long[] longArray1 = new long[] { (short) 1 };
        java.lang.Long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toObject(longArray1);
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, 10L);
        try {
            long[] longArray7 = org.apache.commons.lang3.ArrayUtils.remove(longArray5, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        boolean boolean7 = org.apache.commons.lang3.ArrayUtils.contains(shortArray5, (short) 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 100, (byte) -1, (byte) -1, (byte) -1 };
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray5);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray5, (byte) -1);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray4, (java.lang.Object) floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray10, (float) 10);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray10, (float) (-1L), (int) (byte) 0);
        try {
            float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.remove(floatArray10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray2, (byte) 10);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray8, (byte) 0);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray8);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray8);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(byteArray11);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, 10, (int) (short) 100);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray7);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) charArray2, (java.lang.Object) byteArray11);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray2, 'a', (int) (byte) 1);
        int int17 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray2, 'a');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        short[] shortArray0 = null;
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray0, 6, (-1));
        org.junit.Assert.assertNull(shortArray3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[] byteArray17 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[] byteArray23 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 100, (byte) 10 };
        byte[][] byteArray24 = new byte[][] { byteArray5, byteArray11, byteArray17, byteArray23 };
        byte[] byteArray28 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray28, 10, (int) (short) 100);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.contains(byteArray28, (byte) 0);
        byte[][] byteArray34 = org.apache.commons.lang3.ArrayUtils.add(byteArray24, (int) (short) 1, byteArray28);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap35 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) byteArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '[B@3ee1df83', is neither of type Map.Entry nor an Array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(byteArray34);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray5);
        java.lang.Short[] shortArray7 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray5);
        java.lang.Short[] shortArray11 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray11, (short) (byte) -1);
        short[] shortArray16 = new short[] { (byte) 100, (byte) 100 };
        int int19 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray16, (short) (byte) 10, (int) (byte) 1);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray13, shortArray16);
        short[] shortArray21 = org.apache.commons.lang3.ArrayUtils.clone(shortArray16);
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray16);
        org.apache.commons.lang3.ArrayUtils.reverse(shortArray5);
        short[] shortArray25 = org.apache.commons.lang3.ArrayUtils.add(shortArray5, (short) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray7);
        org.junit.Assert.assertNotNull(shortArray11);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(shortArray25);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        java.lang.Double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray3);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray12);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray13, 100.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.subarray(charArray2, (int) (short) 100, (int) (short) 10);
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(charArray2, 'a');
        java.lang.Character[] charArray9 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(charArray9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        char[] charArray0 = new char[] {};
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.add(charArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#');
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.clone(charArray0);
        org.apache.commons.lang3.ArrayUtils.reverse(charArray0);
        int int9 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#', (-1));
        java.lang.Character[] charArray10 = org.apache.commons.lang3.ArrayUtils.toObject(charArray0);
        char[] charArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray10);
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray10);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        long[] longArray1 = new long[] { (short) 1 };
        java.lang.Long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toObject(longArray1);
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, 10L);
        long[] longArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        char[] charArray9 = new char[] { 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray9);
        java.lang.Character[] charArray11 = org.apache.commons.lang3.ArrayUtils.toObject(charArray9);
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray11);
        char[] charArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray11);
        char[] charArray16 = org.apache.commons.lang3.ArrayUtils.add(charArray13, (int) (byte) 1, ' ');
        char[] charArray17 = org.apache.commons.lang3.ArrayUtils.clone(charArray16);
        char[] charArray18 = null;
        char[] charArray19 = org.apache.commons.lang3.ArrayUtils.addAll(charArray16, charArray18);
        int int20 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray2, (java.lang.Object) charArray18);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        float[] floatArray6 = new float[] { (short) -1, 6, (byte) 1, 1, 2, 0L };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        float[] floatArray8 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(floatArray8);
        try {
            float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.add(floatArray8, (-1), (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: -1, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) (byte) -1);
        short[] shortArray21 = new short[] { (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) (byte) 10, (int) (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray18, shortArray21);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray18, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray18, (short) (byte) 1);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        short[] shortArray44 = org.apache.commons.lang3.ArrayUtils.clone(shortArray39);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray30, shortArray39);
        short[] shortArray46 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray39);
        short[] shortArray47 = org.apache.commons.lang3.ArrayUtils.clone(shortArray39);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray39);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(shortArray46);
        org.junit.Assert.assertNotNull(shortArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray4, (java.lang.Object) floatArray10);
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.clone(floatArray10);
        float[] floatArray18 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) (short) 100);
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray20, 0.0f);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray12, floatArray22);
        float[] floatArray29 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.add(floatArray29, (float) (short) 100);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray31);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray31, (float) '#', (int) 'a');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.lang.Character[] charArray0 = null;
        char[] charArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray0);
        org.junit.Assert.assertNull(charArray1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (short) 1, (int) (short) 100);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray5, (int) (byte) 10, 3);
        try {
            float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, 100, (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray7, (byte) -1, 4);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0, (short) 1);
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 100, (byte) -1, (byte) -1, (byte) -1 };
        java.lang.Byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray8);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray9, (byte) 10);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray9);
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) shortArray0, (java.lang.Object) byteArray9, 5);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray4, (java.lang.Object) floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray10, (float) 10);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray10, (float) (short) 0, 2);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.add(floatArray10, (float) 10);
        float[] floatArray22 = new float[] { '#', (short) -1, 10L };
        float[] floatArray23 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray18, floatArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray29 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray26, 10, (int) (short) 100);
        byte[] byteArray36 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean38 = org.apache.commons.lang3.ArrayUtils.contains(byteArray36, (byte) 10);
        byte[] byteArray39 = org.apache.commons.lang3.ArrayUtils.clone(byteArray36);
        boolean boolean40 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray39);
        byte[] byteArray42 = org.apache.commons.lang3.ArrayUtils.add(byteArray39, (byte) 0);
        byte[] byteArray45 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray48 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray45, 10, (int) (short) 100);
        java.lang.Byte[] byteArray49 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray45);
        byte[] byteArray51 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray49, (byte) 0);
        byte[] byteArray52 = org.apache.commons.lang3.ArrayUtils.clone(byteArray51);
        byte[] byteArray54 = org.apache.commons.lang3.ArrayUtils.add(byteArray51, (byte) 1);
        byte[] byteArray55 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray39, byteArray54);
        boolean boolean56 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray29, byteArray39);
        boolean boolean57 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) floatArray23, (java.lang.Object) boolean56);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertNotNull(byteArray51);
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        char[] charArray2 = new char[] { '#', '4' };
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.subarray(charArray2, 100, 5);
        java.lang.String str6 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) 5);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "5" + "'", str6.equals("5"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray4, 4);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray4, (int) (short) 0);
        java.lang.Integer[] intArray14 = org.apache.commons.lang3.ArrayUtils.toObject(intArray4);
        int[] intArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray14, (int) (short) 0);
        int[] intArray18 = org.apache.commons.lang3.ArrayUtils.add(intArray16, (int) ' ');
        int[] intArray21 = org.apache.commons.lang3.ArrayUtils.add(intArray16, (int) (byte) 1, (int) '4');
        java.lang.Integer[] intArray22 = org.apache.commons.lang3.ArrayUtils.toObject(intArray16);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) (byte) -1);
        short[] shortArray21 = new short[] { (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) (byte) 10, (int) (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray18, shortArray21);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray18, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray18, (short) (byte) 1);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        java.lang.Short[] shortArray47 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray49 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray47, (short) (byte) -1);
        short[] shortArray52 = new short[] { (byte) 100, (byte) 100 };
        int int55 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray52, (short) (byte) 10, (int) (byte) 1);
        boolean boolean56 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray49, shortArray52);
        int int59 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray49, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray61 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray49, (short) (byte) 1);
        java.lang.Short[] shortArray65 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray67 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray65, (short) (byte) -1);
        short[] shortArray70 = new short[] { (byte) 100, (byte) 100 };
        int int73 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray70, (short) (byte) 10, (int) (byte) 1);
        boolean boolean74 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray67, shortArray70);
        short[] shortArray75 = org.apache.commons.lang3.ArrayUtils.clone(shortArray70);
        boolean boolean76 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray61, shortArray70);
        short[] shortArray77 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray36, shortArray70);
        short[] shortArray78 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray30, shortArray70);
        short[] shortArray79 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray78);
        short[] shortArray80 = org.apache.commons.lang3.ArrayUtils.clone(shortArray79);
        short[] shortArray82 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray80, (short) (byte) -1);
        boolean boolean84 = org.apache.commons.lang3.ArrayUtils.contains(shortArray82, (short) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shortArray47);
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertNotNull(shortArray52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(shortArray61);
        org.junit.Assert.assertNotNull(shortArray65);
        org.junit.Assert.assertNotNull(shortArray67);
        org.junit.Assert.assertNotNull(shortArray70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(shortArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(shortArray77);
        org.junit.Assert.assertNotNull(shortArray78);
        org.junit.Assert.assertNotNull(shortArray79);
        org.junit.Assert.assertNotNull(shortArray80);
        org.junit.Assert.assertNotNull(shortArray82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 1L);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, (double) 10);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isEmpty(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 1.0d, 10.0d, 0.0d, 0.0d, 0.0d, 1.0d };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray6);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) doubleArray6);
        java.lang.Object obj10 = null;
        int int12 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) doubleArray6, obj10, (int) '#');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) (byte) -1);
        short[] shortArray21 = new short[] { (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) (byte) 10, (int) (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray18, shortArray21);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray18, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray18, (short) (byte) 1);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        short[] shortArray44 = org.apache.commons.lang3.ArrayUtils.clone(shortArray39);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray30, shortArray39);
        short[] shortArray46 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray39);
        short[] shortArray47 = org.apache.commons.lang3.ArrayUtils.clone(shortArray46);
        int int49 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray46, (short) 0);
        short[] shortArray51 = org.apache.commons.lang3.ArrayUtils.add(shortArray46, (short) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(shortArray46);
        org.junit.Assert.assertNotNull(shortArray47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
        org.junit.Assert.assertNotNull(shortArray51);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean[] booleanArray1 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray0);
        int int3 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray1, false);
        int int6 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray1, true, 5);
        int int9 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray1, false, 6);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10, true);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.add(booleanArray12, true);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray14, false);
        java.lang.Short[] shortArray20 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray20, (short) (byte) -1);
        short[] shortArray25 = new short[] { (byte) 100, (byte) 100 };
        int int28 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray25, (short) (byte) 10, (int) (byte) 1);
        boolean boolean29 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray22, shortArray25);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isEquals((java.lang.Object) int16, (java.lang.Object) shortArray22);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(shortArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        short[] shortArray0 = null;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4, (short) (byte) -1);
        short[] shortArray9 = new short[] { (byte) 100, (byte) 100 };
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) (byte) 10, (int) (byte) 1);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray9);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray6, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray6, (short) (byte) 1);
        java.lang.Short[] shortArray22 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray22, (short) (byte) -1);
        short[] shortArray27 = new short[] { (byte) 100, (byte) 100 };
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray27, (short) (byte) 10, (int) (byte) 1);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray24, shortArray27);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray24, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray24, (short) (byte) 1);
        java.lang.Short[] shortArray40 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray42 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray40, (short) (byte) -1);
        short[] shortArray45 = new short[] { (byte) 100, (byte) 100 };
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray45, (short) (byte) 10, (int) (byte) 1);
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray42, shortArray45);
        java.lang.Short[] shortArray53 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray55 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray53, (short) (byte) -1);
        short[] shortArray58 = new short[] { (byte) 100, (byte) 100 };
        int int61 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray58, (short) (byte) 10, (int) (byte) 1);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray55, shortArray58);
        int int65 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray55, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray67 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray55, (short) (byte) 1);
        java.lang.Short[] shortArray71 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray73 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray71, (short) (byte) -1);
        short[] shortArray76 = new short[] { (byte) 100, (byte) 100 };
        int int79 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray76, (short) (byte) 10, (int) (byte) 1);
        boolean boolean80 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray73, shortArray76);
        short[] shortArray81 = org.apache.commons.lang3.ArrayUtils.clone(shortArray76);
        boolean boolean82 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray67, shortArray76);
        short[] shortArray83 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray42, shortArray76);
        short[] shortArray84 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray36, shortArray76);
        boolean boolean85 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray76);
        short[] shortArray86 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray6);
        short[] shortArray87 = org.apache.commons.lang3.ArrayUtils.clone(shortArray86);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray40);
        org.junit.Assert.assertNotNull(shortArray42);
        org.junit.Assert.assertNotNull(shortArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(shortArray53);
        org.junit.Assert.assertNotNull(shortArray55);
        org.junit.Assert.assertNotNull(shortArray58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(shortArray67);
        org.junit.Assert.assertNotNull(shortArray71);
        org.junit.Assert.assertNotNull(shortArray73);
        org.junit.Assert.assertNotNull(shortArray76);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(shortArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(shortArray83);
        org.junit.Assert.assertNotNull(shortArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(shortArray86);
        org.junit.Assert.assertNotNull(shortArray87);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray15 = new double[] { (byte) 100, 10, (byte) -1 };
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray15, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray20 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray11, doubleArray15);
        boolean boolean22 = org.apache.commons.lang3.ArrayUtils.contains(doubleArray15, (double) (-1));
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray15);
        int int26 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray15, (double) (-1), 6);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.Byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_OBJECT_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4, (short) (byte) -1);
        short[] shortArray9 = new short[] { (byte) 100, (byte) 100 };
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) (byte) 10, (int) (byte) 1);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray9);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.clone(shortArray9);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray9);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray9, (short) (byte) 10);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray0, (java.lang.Object) int17);
        byte[] byteArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0, (byte) 10);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(byteArray20);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0, (short) -1);
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0);
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0, (short) 100);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        boolean[] booleanArray10 = null;
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray9, booleanArray10);
        boolean[] booleanArray17 = new boolean[] { false, false, true, false, true };
        boolean[] booleanArray23 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.add(booleanArray23, (int) (byte) 0, false);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray17, booleanArray23);
        boolean[] booleanArray28 = org.apache.commons.lang3.ArrayUtils.addAll(booleanArray10, booleanArray17);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray28, false);
        boolean[] booleanArray32 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray28, 0);
        boolean[] booleanArray34 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray32, (int) (byte) 0);
        boolean boolean36 = org.apache.commons.lang3.ArrayUtils.contains(booleanArray32, false);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(booleanArray17);
        org.junit.Assert.assertNotNull(booleanArray23);
        org.junit.Assert.assertNotNull(booleanArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(booleanArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(booleanArray32);
        org.junit.Assert.assertNotNull(booleanArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 1L);
        java.lang.String str13 = org.apache.commons.lang3.ArrayUtils.toString((java.lang.Object) int11, "{0,10,-1,100,0,10}");
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray5 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray2, 10, (int) (short) 100);
        java.lang.Byte[] byteArray6 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray2);
        byte[] byteArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray6, (byte) 0);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray8);
        byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.add(byteArray8, (byte) 1);
        byte[] byteArray14 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray8, (int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray14);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.Double[] doubleArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY;
        double[] doubleArray1 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0);
        double[] doubleArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray19);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray9, 10, (int) (short) 1);
        int[] intArray24 = null;
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(intArray9, intArray24);
        int[] intArray30 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray34 = new int[] { '4', 1, ' ' };
        int[] intArray35 = org.apache.commons.lang3.ArrayUtils.addAll(intArray30, intArray34);
        int[] intArray36 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray35);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray9);
        int int39 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray9, 0);
        java.lang.Class<?> wildcardClass40 = intArray9.getClass();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        short[] shortArray13 = org.apache.commons.lang3.ArrayUtils.clone(shortArray8);
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) 0, 0);
        try {
            short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.remove(shortArray8, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        char[] charArray0 = new char[] {};
        char[] charArray2 = org.apache.commons.lang3.ArrayUtils.add(charArray0, '4');
        int int4 = org.apache.commons.lang3.ArrayUtils.indexOf(charArray0, '#');
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.clone(charArray0);
        java.lang.Character[] charArray6 = org.apache.commons.lang3.ArrayUtils.toObject(charArray0);
        char[] charArray8 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray0, ' ');
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(charArray8, '#');
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.removeElement(charArray8, '#');
        try {
            char[] charArray14 = org.apache.commons.lang3.ArrayUtils.remove(charArray12, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(charArray12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Boolean[] booleanArray2 = new java.lang.Boolean[] { false, false };
        boolean[] booleanArray4 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray2, true);
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { 3, 5 };
        int[] intArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray7);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.contains((java.lang.Object[]) booleanArray2, (java.lang.Object) intArray7);
        java.lang.String[] strArray10 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray12 = new java.lang.Comparable[1][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray13 = (java.lang.Comparable<java.lang.String>[][]) comparableArray12;
        strComparableArray13[0] = strArray10;
        java.lang.String[] strArray16 = new java.lang.String[] {};
        java.lang.String[] strArray17 = new java.lang.String[] {};
        java.lang.String[] strArray18 = new java.lang.String[] {};
        java.lang.String[] strArray19 = new java.lang.String[] {};
        java.lang.String[] strArray20 = new java.lang.String[] {};
        java.lang.Comparable[][] comparableArray22 = new java.lang.Comparable[5][];
        @SuppressWarnings("unchecked") java.lang.Comparable<java.lang.String>[][] strComparableArray23 = (java.lang.Comparable<java.lang.String>[][]) comparableArray22;
        strComparableArray23[0] = strArray16;
        strComparableArray23[1] = strArray17;
        strComparableArray23[2] = strArray18;
        strComparableArray23[3] = strArray19;
        strComparableArray23[4] = strArray20;
        java.lang.Comparable<java.lang.String>[][] strComparableArray34 = org.apache.commons.lang3.ArrayUtils.addAll(strComparableArray13, strComparableArray23);
        int int35 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) booleanArray2, (java.lang.Object) strComparableArray23);
        try {
            java.util.Map<java.lang.Object, java.lang.Object> objMap36 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) strComparableArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array element 0, '[Ljava.lang.String;@3192a16', has a length less than 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray2);
        org.junit.Assert.assertNotNull(booleanArray4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(comparableArray12);
        org.junit.Assert.assertNotNull(strComparableArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(comparableArray22);
        org.junit.Assert.assertNotNull(strComparableArray23);
        org.junit.Assert.assertNotNull(strComparableArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray10 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray7, 10, (int) (short) 100);
        java.lang.Byte[] byteArray11 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray7);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameType((java.lang.Object) charArray2, (java.lang.Object) byteArray11);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) (byte) -1);
        short[] shortArray21 = new short[] { (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) (byte) 10, (int) (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray18, shortArray21);
        short[] shortArray26 = org.apache.commons.lang3.ArrayUtils.clone(shortArray21);
        boolean boolean27 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray21);
        int int29 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray21, (short) (byte) 10);
        java.lang.Short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray21);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray21);
        boolean boolean33 = org.apache.commons.lang3.ArrayUtils.contains(shortArray21, (short) -1);
        int int35 = org.apache.commons.lang3.ArrayUtils.lastIndexOf((java.lang.Object[]) byteArray11, (java.lang.Object) boolean33, (int) (short) 1);
        int[] intArray40 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray44 = new int[] { '4', 1, ' ' };
        int[] intArray45 = org.apache.commons.lang3.ArrayUtils.addAll(intArray40, intArray44);
        int[] intArray50 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray54 = new int[] { '4', 1, ' ' };
        int[] intArray55 = org.apache.commons.lang3.ArrayUtils.addAll(intArray50, intArray54);
        int[] intArray56 = org.apache.commons.lang3.ArrayUtils.addAll(intArray45, intArray55);
        int int59 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray45, (int) ' ', (int) (byte) -1);
        java.lang.Integer[] intArray60 = org.apache.commons.lang3.ArrayUtils.toObject(intArray45);
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) byteArray11, (java.lang.Object[]) intArray60);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 6 + "'", int59 == 6);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int[][] intArray5 = new int[][] { intArray1, intArray2, intArray3, intArray4 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { 3, 5 };
        int[] intArray10 = org.apache.commons.lang3.ArrayUtils.toPrimitive(intArray9);
        int[][] intArray11 = org.apache.commons.lang3.ArrayUtils.add(intArray5, (int) (short) 0, intArray10);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.addAll(intArray0, intArray10);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray5);
        boolean[] booleanArray15 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray18 = org.apache.commons.lang3.ArrayUtils.add(booleanArray15, (int) (byte) 0, false);
        boolean boolean19 = org.apache.commons.lang3.ArrayUtils.isSameLength(booleanArray5, booleanArray15);
        boolean[] booleanArray22 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray5, (int) 'a', (int) (byte) 100);
        boolean[] booleanArray23 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray22);
        try {
            boolean[] booleanArray26 = org.apache.commons.lang3.ArrayUtils.add(booleanArray22, (int) (byte) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray15);
        org.junit.Assert.assertNotNull(booleanArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(booleanArray22);
        org.junit.Assert.assertNotNull(booleanArray23);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray9, (double) 4);
        double[] doubleArray17 = new double[] { '4', 0.0f, 0.0f, 'a', (short) 100 };
        int int20 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray17, (double) 4, (double) (byte) 1);
        org.apache.commons.lang3.ArrayUtils.reverse(doubleArray17);
        int int25 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray17, (double) 1, (int) 'a', (double) (-1.0f));
        double[] doubleArray26 = org.apache.commons.lang3.ArrayUtils.addAll(doubleArray9, doubleArray17);
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray26, (double) 0, 2, (double) 0L);
        try {
            double[] doubleArray33 = org.apache.commons.lang3.ArrayUtils.add(doubleArray26, 100, (double) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 8");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int[] intArray0 = null;
        int[] intArray3 = org.apache.commons.lang3.ArrayUtils.subarray(intArray0, 100, 7);
        org.junit.Assert.assertNull(intArray3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.lang.Float[] floatArray4 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        java.lang.Float[] floatArray10 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray4, (java.lang.Object[]) floatArray10);
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4, (float) 10);
        float[] floatArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4, (float) (byte) 0);
        float[] floatArray19 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        float[] floatArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4, (float) 1);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double[][] doubleArray0 = null;
        double[] doubleArray1 = null;
        double[][] doubleArray2 = org.apache.commons.lang3.ArrayUtils.add(doubleArray0, doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        long[] longArray6 = new long[] { 100L, 0, (short) 0, ' ', (short) 1, 10 };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) (short) 1);
        boolean boolean9 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray6);
        org.apache.commons.lang3.ArrayUtils.reverse(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10, true);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty((java.lang.Object[]) booleanArray10);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10);
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10);
        try {
            boolean[] booleanArray17 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray15, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) -1);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (-1L));
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.subarray(doubleArray3, 1, (int) (short) 0);
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray16, (double) (byte) -1, 3);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray16, (double) (byte) -1, (int) '4');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 1L);
        double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.remove(doubleArray3, (int) (byte) 1);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (double) (byte) 100);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        int int11 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray9, (long) 5);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.add(longArray9, (long) (byte) 100);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(longArray13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double[] doubleArray0 = null;
        int int3 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) 11, (double) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.lang.Short[] shortArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY;
        short[] shortArray2 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray0, (short) -1);
        try {
            short[] shortArray4 = org.apache.commons.lang3.ArrayUtils.remove(shortArray2, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Length: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertNotNull(shortArray2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        short[] shortArray0 = null;
        short[] shortArray3 = org.apache.commons.lang3.ArrayUtils.subarray(shortArray0, (int) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertNull(shortArray3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray19);
        java.lang.Integer[] intArray21 = org.apache.commons.lang3.ArrayUtils.toObject(intArray20);
        try {
            int[] intArray23 = org.apache.commons.lang3.ArrayUtils.remove(intArray20, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 14");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 0);
        int int15 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(byteArray12, (byte) 10, (int) (byte) 10);
        byte[] byteArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(byteArray12, (byte) 1);
        int int19 = org.apache.commons.lang3.ArrayUtils.indexOf(byteArray17, (byte) -1);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray17);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        short[] shortArray0 = null;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4, (short) (byte) -1);
        short[] shortArray9 = new short[] { (byte) 100, (byte) 100 };
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) (byte) 10, (int) (byte) 1);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray9);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray6, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray6, (short) (byte) 1);
        java.lang.Short[] shortArray22 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray22, (short) (byte) -1);
        short[] shortArray27 = new short[] { (byte) 100, (byte) 100 };
        int int30 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray27, (short) (byte) 10, (int) (byte) 1);
        boolean boolean31 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray24, shortArray27);
        int int34 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray24, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray24, (short) (byte) 1);
        java.lang.Short[] shortArray40 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray42 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray40, (short) (byte) -1);
        short[] shortArray45 = new short[] { (byte) 100, (byte) 100 };
        int int48 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray45, (short) (byte) 10, (int) (byte) 1);
        boolean boolean49 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray42, shortArray45);
        java.lang.Short[] shortArray53 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray55 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray53, (short) (byte) -1);
        short[] shortArray58 = new short[] { (byte) 100, (byte) 100 };
        int int61 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray58, (short) (byte) 10, (int) (byte) 1);
        boolean boolean62 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray55, shortArray58);
        int int65 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray55, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray67 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray55, (short) (byte) 1);
        java.lang.Short[] shortArray71 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray73 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray71, (short) (byte) -1);
        short[] shortArray76 = new short[] { (byte) 100, (byte) 100 };
        int int79 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray76, (short) (byte) 10, (int) (byte) 1);
        boolean boolean80 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray73, shortArray76);
        short[] shortArray81 = org.apache.commons.lang3.ArrayUtils.clone(shortArray76);
        boolean boolean82 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray67, shortArray76);
        short[] shortArray83 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray42, shortArray76);
        short[] shortArray84 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray36, shortArray76);
        boolean boolean85 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray76);
        short[] shortArray86 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray0, shortArray6);
        int int88 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray0, (short) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray22);
        org.junit.Assert.assertNotNull(shortArray24);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray40);
        org.junit.Assert.assertNotNull(shortArray42);
        org.junit.Assert.assertNotNull(shortArray45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(shortArray53);
        org.junit.Assert.assertNotNull(shortArray55);
        org.junit.Assert.assertNotNull(shortArray58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(shortArray67);
        org.junit.Assert.assertNotNull(shortArray71);
        org.junit.Assert.assertNotNull(shortArray73);
        org.junit.Assert.assertNotNull(shortArray76);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(shortArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(shortArray83);
        org.junit.Assert.assertNotNull(shortArray84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(shortArray86);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        boolean[] booleanArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        boolean[] booleanArray2 = org.apache.commons.lang3.ArrayUtils.add(booleanArray0, false);
        org.junit.Assert.assertNotNull(booleanArray0);
        org.junit.Assert.assertNotNull(booleanArray2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10, true);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty((java.lang.Object[]) booleanArray10);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10);
        boolean[] booleanArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10);
        try {
            boolean[] booleanArray17 = org.apache.commons.lang3.ArrayUtils.remove(booleanArray15, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray15);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        char[] charArray2 = new char[] { 'a', '4' };
        boolean boolean3 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray2);
        java.lang.Character[] charArray4 = org.apache.commons.lang3.ArrayUtils.toObject(charArray2);
        char[] charArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(charArray4);
        char[] charArray9 = org.apache.commons.lang3.ArrayUtils.add(charArray6, (int) (byte) 1, ' ');
        char[] charArray10 = org.apache.commons.lang3.ArrayUtils.clone(charArray9);
        char[] charArray11 = null;
        char[] charArray12 = org.apache.commons.lang3.ArrayUtils.addAll(charArray9, charArray11);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isEmpty(charArray12);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.contains(charArray12, 'a');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Long[] longArray4 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[] longArray9 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[][] longArray10 = new java.lang.Long[][] { longArray4, longArray9 };
        java.lang.Long[] longArray15 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[] longArray20 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[][] longArray21 = new java.lang.Long[][] { longArray15, longArray20 };
        java.lang.Long[] longArray26 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[] longArray31 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[][] longArray32 = new java.lang.Long[][] { longArray26, longArray31 };
        java.lang.Long[] longArray37 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[] longArray42 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[][] longArray43 = new java.lang.Long[][] { longArray37, longArray42 };
        java.lang.Long[] longArray48 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[] longArray53 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[][] longArray54 = new java.lang.Long[][] { longArray48, longArray53 };
        java.lang.Long[] longArray59 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[] longArray64 = new java.lang.Long[] { 0L, 100L, 10L, 1L };
        java.lang.Long[][] longArray65 = new java.lang.Long[][] { longArray59, longArray64 };
        java.lang.Long[][][] longArray66 = new java.lang.Long[][][] { longArray10, longArray21, longArray32, longArray43, longArray54, longArray65 };
        java.lang.Long[] longArray72 = new java.lang.Long[] { (-1L), 10L, 0L, 0L, (-1L) };
        java.lang.Long[][] longArray73 = new java.lang.Long[][] { longArray72 };
        java.lang.Long[][][] longArray74 = new java.lang.Long[][][] { longArray73 };
        java.lang.Long[][][] longArray77 = org.apache.commons.lang3.ArrayUtils.subarray(longArray74, 0, (int) '#');
        java.lang.Long[][][] longArray78 = org.apache.commons.lang3.ArrayUtils.addAll(longArray66, longArray74);
        try {
            java.lang.Long[][][] longArray80 = org.apache.commons.lang3.ArrayUtils.remove(longArray78, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Length: 7");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray15);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray21);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray31);
        org.junit.Assert.assertNotNull(longArray32);
        org.junit.Assert.assertNotNull(longArray37);
        org.junit.Assert.assertNotNull(longArray42);
        org.junit.Assert.assertNotNull(longArray43);
        org.junit.Assert.assertNotNull(longArray48);
        org.junit.Assert.assertNotNull(longArray53);
        org.junit.Assert.assertNotNull(longArray54);
        org.junit.Assert.assertNotNull(longArray59);
        org.junit.Assert.assertNotNull(longArray64);
        org.junit.Assert.assertNotNull(longArray65);
        org.junit.Assert.assertNotNull(longArray66);
        org.junit.Assert.assertNotNull(longArray72);
        org.junit.Assert.assertNotNull(longArray73);
        org.junit.Assert.assertNotNull(longArray74);
        org.junit.Assert.assertNotNull(longArray77);
        org.junit.Assert.assertNotNull(longArray78);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        long[] longArray0 = null;
        java.lang.Long[] longArray7 = new java.lang.Long[] { (-1L), 0L, 100L, 100L, 1L, 100L };
        long[] longArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray7);
        long[] longArray10 = org.apache.commons.lang3.ArrayUtils.add(longArray8, (long) (byte) 100);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray8, 100L, 0);
        long[] longArray14 = org.apache.commons.lang3.ArrayUtils.addAll(longArray0, longArray8);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(longArray8);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray12 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, (byte) 0);
        byte[] byteArray15 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, 5, (byte) 100);
        byte[] byteArray18 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray18, 10, (int) (short) 100);
        byte[] byteArray28 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.contains(byteArray28, (byte) 10);
        byte[] byteArray31 = org.apache.commons.lang3.ArrayUtils.clone(byteArray28);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray31);
        byte[] byteArray34 = org.apache.commons.lang3.ArrayUtils.add(byteArray31, (byte) 0);
        byte[] byteArray37 = new byte[] { (byte) -1, (byte) -1 };
        byte[] byteArray40 = org.apache.commons.lang3.ArrayUtils.subarray(byteArray37, 10, (int) (short) 100);
        java.lang.Byte[] byteArray41 = org.apache.commons.lang3.ArrayUtils.toObject(byteArray37);
        byte[] byteArray43 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray41, (byte) 0);
        byte[] byteArray44 = org.apache.commons.lang3.ArrayUtils.clone(byteArray43);
        byte[] byteArray46 = org.apache.commons.lang3.ArrayUtils.add(byteArray43, (byte) 1);
        byte[] byteArray47 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray31, byteArray46);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(byteArray21, byteArray31);
        byte[] byteArray49 = org.apache.commons.lang3.ArrayUtils.addAll(byteArray15, byteArray21);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(byteArray49);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.Float[] floatArray4 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray4);
        java.lang.Float[] floatArray10 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10, (float) 0);
        boolean boolean14 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray4, (java.lang.Object[]) floatArray10);
        float[] floatArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        float[] floatArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray10);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray16, (float) (short) -1);
        float[] floatArray24 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray26 = org.apache.commons.lang3.ArrayUtils.add(floatArray24, (float) (short) 100);
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray26, 0.0f);
        float[] floatArray29 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray16, floatArray26);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray16, (int) (short) 1, (int) (short) 10);
        java.lang.Class<?> wildcardClass33 = floatArray32.getClass();
        boolean boolean35 = org.apache.commons.lang3.ArrayUtils.contains(floatArray32, (float) 100L);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0.0d);
        double[] doubleArray12 = org.apache.commons.lang3.ArrayUtils.add(doubleArray3, 0, (double) (short) 1);
        java.lang.Double[] doubleArray13 = org.apache.commons.lang3.ArrayUtils.toObject(doubleArray12);
        double[] doubleArray15 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray13, (double) 1L);
        double[] doubleArray16 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        long[] longArray0 = new long[] {};
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.add(longArray0, 0, 0L);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) 5);
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray3, (long) 4, (int) (short) 100);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray3, (long) (short) -1);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        long[] longArray1 = new long[] { (short) 1 };
        java.lang.Long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toObject(longArray1);
        long[] longArray3 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2);
        long[] longArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray2, 10L);
        java.lang.Long[] longArray6 = org.apache.commons.lang3.ArrayUtils.toObject(longArray5);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray6);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray12 = org.apache.commons.lang3.ArrayUtils.subarray(intArray9, (int) '4', 4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        boolean[] booleanArray1 = new boolean[] { true };
        boolean boolean2 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray1);
        int int5 = org.apache.commons.lang3.ArrayUtils.indexOf(booleanArray1, false, 11);
        org.junit.Assert.assertNotNull(booleanArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.lang.Byte[] byteArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_BYTE_OBJECT_ARRAY;
        java.lang.Short[] shortArray4 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray6 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray4, (short) (byte) -1);
        short[] shortArray9 = new short[] { (byte) 100, (byte) 100 };
        int int12 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray9, (short) (byte) 10, (int) (byte) 1);
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray6, shortArray9);
        short[] shortArray14 = org.apache.commons.lang3.ArrayUtils.clone(shortArray9);
        boolean boolean15 = org.apache.commons.lang3.ArrayUtils.isEmpty(shortArray9);
        int int17 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray9, (short) (byte) 10);
        int int18 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray0, (java.lang.Object) int17);
        java.util.Map<java.lang.Object, java.lang.Object> objMap19 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) byteArray0);
        byte[] byteArray21 = org.apache.commons.lang3.ArrayUtils.toPrimitive(byteArray0, (byte) -1);
        java.util.Map<java.lang.Object, java.lang.Object> objMap22 = org.apache.commons.lang3.ArrayUtils.toMap((java.lang.Object[]) byteArray0);
        java.lang.Float[] floatArray27 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray28 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray27);
        java.lang.Float[] floatArray33 = new java.lang.Float[] { 1.0f, 1.0f, 0.0f, 10.0f };
        float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray33);
        float[] floatArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray33, (float) 0);
        boolean boolean37 = org.apache.commons.lang3.ArrayUtils.isSameLength((java.lang.Object[]) floatArray27, (java.lang.Object[]) floatArray33);
        float[] floatArray38 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray33);
        float[] floatArray39 = org.apache.commons.lang3.ArrayUtils.toPrimitive(floatArray33);
        int int41 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray39, (float) (short) -1);
        float[] floatArray47 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray49 = org.apache.commons.lang3.ArrayUtils.add(floatArray47, (float) (short) 100);
        float[] floatArray51 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray49, 0.0f);
        float[] floatArray52 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray39, floatArray49);
        float[] floatArray53 = org.apache.commons.lang3.ArrayUtils.clone(floatArray39);
        boolean boolean54 = org.apache.commons.lang3.ArrayUtils.isEmpty(floatArray39);
        int int55 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) byteArray0, (java.lang.Object) boolean54);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(objMap19);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertNotNull(objMap22);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray5);
        boolean[] booleanArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(booleanArray5, false);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isEmpty(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int[] intArray0 = org.apache.commons.lang3.ArrayUtils.EMPTY_INT_ARRAY;
        int[] intArray2 = org.apache.commons.lang3.ArrayUtils.add(intArray0, 0);
        boolean boolean4 = org.apache.commons.lang3.ArrayUtils.contains(intArray2, (int) '#');
        boolean boolean5 = org.apache.commons.lang3.ArrayUtils.isEmpty(intArray2);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        char[] charArray0 = null;
        char[] charArray3 = org.apache.commons.lang3.ArrayUtils.subarray(charArray0, 6, 4);
        org.junit.Assert.assertNull(charArray3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        int int33 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray23, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray35 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray23, (short) (byte) 1);
        java.lang.Short[] shortArray39 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray41 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray39, (short) (byte) -1);
        short[] shortArray44 = new short[] { (byte) 100, (byte) 100 };
        int int47 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray44, (short) (byte) 10, (int) (byte) 1);
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray41, shortArray44);
        java.lang.Short[] shortArray52 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray54 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray52, (short) (byte) -1);
        short[] shortArray57 = new short[] { (byte) 100, (byte) 100 };
        int int60 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray57, (short) (byte) 10, (int) (byte) 1);
        boolean boolean61 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray54, shortArray57);
        int int64 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray54, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray66 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray54, (short) (byte) 1);
        java.lang.Short[] shortArray70 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray72 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray70, (short) (byte) -1);
        short[] shortArray75 = new short[] { (byte) 100, (byte) 100 };
        int int78 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray75, (short) (byte) 10, (int) (byte) 1);
        boolean boolean79 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray72, shortArray75);
        short[] shortArray80 = org.apache.commons.lang3.ArrayUtils.clone(shortArray75);
        boolean boolean81 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray66, shortArray75);
        short[] shortArray82 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray41, shortArray75);
        short[] shortArray83 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray35, shortArray75);
        boolean boolean84 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray75);
        java.lang.Short[] shortArray85 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray75);
        java.lang.Short[] shortArray86 = org.apache.commons.lang3.ArrayUtils.toObject(shortArray75);
        short[] shortArray88 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray86, (short) (byte) 100);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(shortArray35);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertNotNull(shortArray41);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(shortArray52);
        org.junit.Assert.assertNotNull(shortArray54);
        org.junit.Assert.assertNotNull(shortArray57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(shortArray66);
        org.junit.Assert.assertNotNull(shortArray70);
        org.junit.Assert.assertNotNull(shortArray72);
        org.junit.Assert.assertNotNull(shortArray75);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(shortArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(shortArray82);
        org.junit.Assert.assertNotNull(shortArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(shortArray85);
        org.junit.Assert.assertNotNull(shortArray86);
        org.junit.Assert.assertNotNull(shortArray88);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        float[] floatArray6 = new float[] { (short) -1, 6, (byte) 1, 1, 2, 0L };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.clone(floatArray6);
        int int10 = org.apache.commons.lang3.ArrayUtils.indexOf(floatArray7, (float) 'a', (int) (byte) 0);
        java.lang.Float[] floatArray11 = org.apache.commons.lang3.ArrayUtils.toObject(floatArray7);
        org.apache.commons.lang3.ArrayUtils.reverse((java.lang.Object[]) floatArray11);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double[] doubleArray0 = null;
        double[] doubleArray1 = org.apache.commons.lang3.ArrayUtils.clone(doubleArray0);
        org.junit.Assert.assertNull(doubleArray1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double[] doubleArray3 = new double[] { (byte) 100, 10, (byte) -1 };
        int int7 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray3, (double) 100, (int) 'a', (double) 0.0f);
        double[] doubleArray9 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) (short) 0);
        double[] doubleArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(doubleArray3, (double) 7);
        int int14 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray3, (double) (short) 100, 0.0d);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 0.0d };
        double[] doubleArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray16, (double) 100);
        int int19 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) doubleArray18);
        boolean boolean20 = org.apache.commons.lang3.ArrayUtils.isSameLength(doubleArray3, doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        long[] longArray6 = new long[] { 100L, 0, (short) 0, ' ', (short) 1, 10 };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) (short) 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) (short) -1, (int) (byte) 1);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        short[] shortArray31 = org.apache.commons.lang3.ArrayUtils.clone(shortArray26);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray26);
        short[] shortArray34 = org.apache.commons.lang3.ArrayUtils.add(shortArray17, (short) -1);
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray17, (short) 0);
        short[] shortArray38 = org.apache.commons.lang3.ArrayUtils.add(shortArray36, (short) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray38);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        java.lang.Short[] shortArray16 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray18 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray16, (short) (byte) -1);
        short[] shortArray21 = new short[] { (byte) 100, (byte) 100 };
        int int24 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray21, (short) (byte) 10, (int) (byte) 1);
        boolean boolean25 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray18, shortArray21);
        int int28 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray18, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray30 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray18, (short) (byte) 1);
        java.lang.Short[] shortArray34 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray36 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray34, (short) (byte) -1);
        short[] shortArray39 = new short[] { (byte) 100, (byte) 100 };
        int int42 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray39, (short) (byte) 10, (int) (byte) 1);
        boolean boolean43 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray36, shortArray39);
        short[] shortArray44 = org.apache.commons.lang3.ArrayUtils.clone(shortArray39);
        boolean boolean45 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray30, shortArray39);
        short[] shortArray46 = org.apache.commons.lang3.ArrayUtils.addAll(shortArray5, shortArray39);
        short[] shortArray47 = null;
        boolean boolean48 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray39, shortArray47);
        boolean boolean50 = org.apache.commons.lang3.ArrayUtils.contains(shortArray47, (short) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertNotNull(shortArray18);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shortArray30);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertNotNull(shortArray36);
        org.junit.Assert.assertNotNull(shortArray39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shortArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(shortArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        boolean[] booleanArray5 = new boolean[] { false, false, true, false, false };
        boolean[] booleanArray8 = org.apache.commons.lang3.ArrayUtils.add(booleanArray5, (int) (byte) 0, false);
        boolean[] booleanArray9 = org.apache.commons.lang3.ArrayUtils.clone(booleanArray8);
        java.lang.Boolean[] booleanArray10 = org.apache.commons.lang3.ArrayUtils.toObject(booleanArray8);
        boolean[] booleanArray12 = org.apache.commons.lang3.ArrayUtils.toPrimitive(booleanArray10, true);
        boolean[] booleanArray14 = org.apache.commons.lang3.ArrayUtils.add(booleanArray12, true);
        boolean[] booleanArray16 = org.apache.commons.lang3.ArrayUtils.add(booleanArray12, false);
        org.apache.commons.lang3.ArrayUtils.reverse(booleanArray16);
        boolean[] booleanArray20 = org.apache.commons.lang3.ArrayUtils.subarray(booleanArray16, 7, 6);
        int int22 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(booleanArray16, false);
        org.junit.Assert.assertNotNull(booleanArray5);
        org.junit.Assert.assertNotNull(booleanArray8);
        org.junit.Assert.assertNotNull(booleanArray9);
        org.junit.Assert.assertNotNull(booleanArray10);
        org.junit.Assert.assertNotNull(booleanArray12);
        org.junit.Assert.assertNotNull(booleanArray14);
        org.junit.Assert.assertNotNull(booleanArray16);
        org.junit.Assert.assertNotNull(booleanArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray6 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray4, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.ArrayUtils.subarray(strArray4, (-1), (int) (short) 10);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray11 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray4, (java.lang.Object) floatArray10);
        float[] floatArray12 = org.apache.commons.lang3.ArrayUtils.clone(floatArray10);
        float[] floatArray18 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray20 = org.apache.commons.lang3.ArrayUtils.add(floatArray18, (float) (short) 100);
        float[] floatArray22 = org.apache.commons.lang3.ArrayUtils.removeElement(floatArray20, 0.0f);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(floatArray12, floatArray22);
        float[] floatArray29 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray31 = org.apache.commons.lang3.ArrayUtils.add(floatArray29, (float) (short) 100);
        float[] floatArray32 = org.apache.commons.lang3.ArrayUtils.addAll(floatArray22, floatArray31);
        try {
            float[] floatArray34 = org.apache.commons.lang3.ArrayUtils.remove(floatArray22, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Length: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strComparableArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.remove(longArray9, 0);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray9, (long) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray13, (long) 4, (int) (short) 10);
        int int18 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray13, (long) 5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        int[] intArray14 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray18 = new int[] { '4', 1, ' ' };
        int[] intArray19 = org.apache.commons.lang3.ArrayUtils.addAll(intArray14, intArray18);
        int[] intArray20 = org.apache.commons.lang3.ArrayUtils.addAll(intArray9, intArray19);
        int int23 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray9, (int) ' ', (int) (byte) -1);
        int int26 = org.apache.commons.lang3.ArrayUtils.indexOf(intArray9, 3, (int) (byte) 10);
        try {
            int[] intArray28 = org.apache.commons.lang3.ArrayUtils.remove(intArray9, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Length: 7");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 0, (byte) 10 };
        boolean boolean8 = org.apache.commons.lang3.ArrayUtils.contains(byteArray6, (byte) 10);
        byte[] byteArray9 = org.apache.commons.lang3.ArrayUtils.clone(byteArray6);
        boolean boolean10 = org.apache.commons.lang3.ArrayUtils.isEmpty(byteArray9);
        byte[] byteArray13 = org.apache.commons.lang3.ArrayUtils.add(byteArray9, 0, (byte) 100);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray13);
        org.apache.commons.lang3.ArrayUtils.reverse(byteArray13);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.remove(longArray9, 0);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray9, (long) 100);
        long[] longArray16 = org.apache.commons.lang3.ArrayUtils.add(longArray9, 5, (long) '4');
        long[] longArray18 = new long[] { (short) 1 };
        java.lang.Long[] longArray19 = org.apache.commons.lang3.ArrayUtils.toObject(longArray18);
        long[] longArray20 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray19);
        long[] longArray22 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray19, 10L);
        boolean boolean23 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray16, longArray22);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        long[] longArray5 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray7 = org.apache.commons.lang3.ArrayUtils.add(longArray5, 0L);
        long[] longArray9 = org.apache.commons.lang3.ArrayUtils.add(longArray5, (long) (short) 0);
        long[] longArray11 = org.apache.commons.lang3.ArrayUtils.remove(longArray9, 0);
        long[] longArray13 = org.apache.commons.lang3.ArrayUtils.removeElement(longArray9, (long) 100);
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray13, (long) 4, (int) (short) 10);
        long[] longArray17 = org.apache.commons.lang3.ArrayUtils.clone(longArray13);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(longArray17);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        int[] intArray4 = new int[] { (-1), 1, 'a', '4' };
        int[] intArray8 = new int[] { '4', 1, ' ' };
        int[] intArray9 = org.apache.commons.lang3.ArrayUtils.addAll(intArray4, intArray8);
        boolean boolean11 = org.apache.commons.lang3.ArrayUtils.contains(intArray8, (int) '4');
        boolean boolean13 = org.apache.commons.lang3.ArrayUtils.contains(intArray8, 7);
        int int14 = org.apache.commons.lang3.ArrayUtils.getLength((java.lang.Object) intArray8);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        float[] floatArray5 = new float[] { '4', '4', 4, (byte) 100, (short) 1 };
        float[] floatArray7 = org.apache.commons.lang3.ArrayUtils.add(floatArray5, (float) (short) 100);
        float[] floatArray10 = org.apache.commons.lang3.ArrayUtils.subarray(floatArray7, 1, (int) (byte) 10);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(floatArray7, (float) 4, 0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        long[] longArray1 = new long[] { (short) 1 };
        java.lang.Long[] longArray2 = org.apache.commons.lang3.ArrayUtils.toObject(longArray1);
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "hi!", "hi!", "hi!" };
        java.lang.Comparable<java.lang.String>[] strComparableArray9 = org.apache.commons.lang3.ArrayUtils.add((java.lang.Comparable<java.lang.String>[]) strArray7, (java.lang.Comparable<java.lang.String>) "hi!");
        java.lang.String[] strArray12 = org.apache.commons.lang3.ArrayUtils.subarray(strArray7, (-1), (int) (short) 10);
        float[] floatArray13 = org.apache.commons.lang3.ArrayUtils.EMPTY_FLOAT_ARRAY;
        java.lang.String[] strArray14 = org.apache.commons.lang3.ArrayUtils.removeElement(strArray7, (java.lang.Object) floatArray13);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf((java.lang.Object[]) longArray2, (java.lang.Object) strArray14);
        try {
            java.lang.Comparable<java.lang.String>[] strComparableArray17 = org.apache.commons.lang3.ArrayUtils.remove((java.lang.Comparable<java.lang.String>[]) strArray14, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Length: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strComparableArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double[] doubleArray0 = null;
        int int2 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(doubleArray0, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        long[] longArray6 = new long[] { 100L, 0, (short) 0, ' ', (short) 1, 10 };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) (short) 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 1, (-1));
        int int16 = org.apache.commons.lang3.ArrayUtils.indexOf(longArray6, (long) '4', (int) (short) 10);
        java.lang.Long[] longArray23 = new java.lang.Long[] { (-1L), 0L, 100L, 100L, 1L, 100L };
        long[] longArray24 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray23);
        long[] longArray25 = org.apache.commons.lang3.ArrayUtils.toPrimitive(longArray23);
        boolean boolean26 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray6, longArray25);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(longArray23);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        long[] longArray6 = new long[] { 100L, 0, (short) 0, ' ', (short) 1, 10 };
        int int8 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) (short) 1);
        int int10 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 0);
        int int13 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) 1, (-1));
        int int16 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(longArray6, (long) ' ', (int) (byte) 10);
        long[] longArray18 = org.apache.commons.lang3.ArrayUtils.remove(longArray6, (int) (byte) 1);
        long[] longArray24 = new long[] { (short) 0, 4, 4, 10L, '4' };
        long[] longArray26 = org.apache.commons.lang3.ArrayUtils.add(longArray24, 0L);
        long[] longArray28 = org.apache.commons.lang3.ArrayUtils.add(longArray24, (long) (short) 0);
        long[] longArray29 = org.apache.commons.lang3.ArrayUtils.clone(longArray24);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(longArray6, longArray24);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertNotNull(longArray18);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray26);
        org.junit.Assert.assertNotNull(longArray28);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 1.0d, 10.0d, 0.0d, 0.0d, 0.0d, 1.0d };
        double[] doubleArray7 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray6);
        double[] doubleArray8 = org.apache.commons.lang3.ArrayUtils.toPrimitive(doubleArray6);
        double[] doubleArray10 = org.apache.commons.lang3.ArrayUtils.add(doubleArray8, (double) 'a');
        int int14 = org.apache.commons.lang3.ArrayUtils.indexOf(doubleArray8, (double) 1.0f, 100, (double) 1.0f);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Short[] shortArray3 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray5 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray3, (short) (byte) -1);
        short[] shortArray8 = new short[] { (byte) 100, (byte) 100 };
        int int11 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray8, (short) (byte) 10, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray5, shortArray8);
        int int15 = org.apache.commons.lang3.ArrayUtils.indexOf(shortArray5, (short) (byte) -1, (int) (byte) 100);
        short[] shortArray17 = org.apache.commons.lang3.ArrayUtils.removeElement(shortArray5, (short) (byte) 1);
        java.lang.Short[] shortArray21 = new java.lang.Short[] { (short) -1, (short) -1, (short) 0 };
        short[] shortArray23 = org.apache.commons.lang3.ArrayUtils.toPrimitive(shortArray21, (short) (byte) -1);
        short[] shortArray26 = new short[] { (byte) 100, (byte) 100 };
        int int29 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray26, (short) (byte) 10, (int) (byte) 1);
        boolean boolean30 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray23, shortArray26);
        short[] shortArray31 = org.apache.commons.lang3.ArrayUtils.clone(shortArray26);
        boolean boolean32 = org.apache.commons.lang3.ArrayUtils.isSameLength(shortArray17, shortArray26);
        short[] shortArray34 = org.apache.commons.lang3.ArrayUtils.add(shortArray17, (short) -1);
        int int37 = org.apache.commons.lang3.ArrayUtils.lastIndexOf(shortArray17, (short) -1, 4);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertNotNull(shortArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(shortArray17);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray23);
        org.junit.Assert.assertNotNull(shortArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shortArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shortArray34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }
}

