import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test01");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.negate();
        byte byte8 = fraction7.byteValue();
        byte byte9 = fraction7.byteValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.add(fraction7);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction5 and fraction10", (fraction5.compareTo(fraction10) == 0) == fraction5.equals(fraction10));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test02");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        byte byte5 = fraction4.byteValue();
        byte byte6 = fraction4.byteValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction4.reduce();
        int int8 = fraction4.getProperWhole();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction2 and fraction7", (fraction2.compareTo(fraction7) == 0) == fraction2.equals(fraction7));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test03");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int14 = fraction13.getNumerator();
        float float15 = fraction13.floatValue();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction13.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction3.add(fraction20);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -2, (int) (short) 0, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction20.subtract(fraction25);
        int int27 = fraction26.intValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction19 and fraction25", (fraction19.compareTo(fraction25) == 0) == fraction19.equals(fraction25));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test04");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int14 = fraction13.getNumerator();
        float float15 = fraction13.floatValue();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction13.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction3.add(fraction20);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -2, (int) (short) 0, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction20.subtract(fraction25);
        long long27 = fraction26.longValue();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction19 and fraction25", (fraction19.compareTo(fraction25) == 0) == fraction19.equals(fraction25));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test05");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        java.lang.Object obj7 = null;
        boolean boolean8 = fraction3.equals(obj7);
        java.lang.String str9 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.add(fraction3);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str15 = fraction14.toProperString();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int18 = fraction17.getNumerator();
        int int19 = fraction17.getDenominator();
        byte byte20 = fraction17.byteValue();
        int int21 = fraction17.getProperWhole();
        int int22 = fraction14.compareTo(fraction17);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction14.negate();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int25 = fraction24.getNumerator();
        float float26 = fraction24.floatValue();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction24.subtract(fraction30);
        int int32 = fraction24.getNumerator();
        int int33 = fraction14.compareTo(fraction24);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction11.multiplyBy(fraction24);
        org.apache.commons.lang3.math.Fraction fraction35 = fraction3.multiplyBy(fraction24);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction0 and fraction24", (fraction0.compareTo(fraction24) == 0) == fraction0.equals(fraction24));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test06");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        short short4 = fraction1.shortValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.negate();
        long long6 = fraction1.longValue();
        int int7 = fraction1.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((-2), (int) (byte) 100);
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str16 = fraction15.toProperString();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int19 = fraction18.getNumerator();
        int int20 = fraction18.getDenominator();
        byte byte21 = fraction18.byteValue();
        int int22 = fraction18.getProperWhole();
        int int23 = fraction15.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction15.negate();
        long long25 = fraction24.longValue();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction24.negate();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction10.add(fraction26);
        boolean boolean28 = fraction1.equals((java.lang.Object) fraction26);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction10 and fraction12", (fraction10.compareTo(fraction12) == 0) == fraction10.equals(fraction12));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test07");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        byte byte5 = fraction4.byteValue();
        byte byte6 = fraction4.byteValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.invert();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction2 and fraction7", (fraction2.compareTo(fraction7) == 0) == fraction2.equals(fraction7));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test08");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 4);
        int int3 = fraction2.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.abs();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction2.add(fraction5);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction5 and fraction6", (fraction5.compareTo(fraction6) == 0) == fraction5.equals(fraction6));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test09");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        byte byte5 = fraction4.byteValue();
        byte byte6 = fraction4.byteValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.invert();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int10 = fraction9.getNumerator();
        float float11 = fraction9.floatValue();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction9.subtract(fraction15);
        byte byte17 = fraction15.byteValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        int int19 = fraction15.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction8.subtract(fraction18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction2 and fraction7", (fraction2.compareTo(fraction7) == 0) == fraction2.equals(fraction7));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test10");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((-2), (int) (byte) 100);
        int int3 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str8 = fraction7.toProperString();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int11 = fraction10.getNumerator();
        int int12 = fraction10.getDenominator();
        byte byte13 = fraction10.byteValue();
        int int14 = fraction10.getProperWhole();
        int int15 = fraction7.compareTo(fraction10);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction7.negate();
        long long17 = fraction16.longValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction16.negate();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.add(fraction18);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getFraction(10, (int) (byte) 1);
        int int23 = fraction22.intValue();
        java.lang.Class<?> wildcardClass24 = fraction22.getClass();
        int int25 = fraction22.intValue();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int28 = fraction27.getNumerator();
        int int29 = fraction27.getDenominator();
        short short30 = fraction27.shortValue();
        boolean boolean32 = fraction27.equals((java.lang.Object) 10);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction22.multiplyBy(fraction27);
        int int34 = fraction22.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction22.pow((int) (short) 0);
        org.apache.commons.lang3.math.Fraction fraction37 = fraction2.multiplyBy(fraction36);
        int int38 = fraction37.getDenominator();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction2 and fraction4", (fraction2.compareTo(fraction4) == 0) == fraction2.equals(fraction4));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test11");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        java.lang.Object obj7 = null;
        boolean boolean8 = fraction3.equals(obj7);
        java.lang.String str9 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.add(fraction3);
        java.lang.String str11 = fraction10.toString();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.reduce();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        double double14 = fraction13.doubleValue();
        int int15 = fraction10.compareTo(fraction13);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on fraction10 and fraction12", (fraction10.compareTo(fraction12) == 0) == fraction10.equals(fraction12));
    }
}

