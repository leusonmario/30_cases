import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = fraction1.pow((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_THIRDS;
        int int1 = fraction0.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        try {
            org.apache.commons.lang3.math.Fraction fraction8 = fraction0.divideBy(fraction7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The fraction to divide by must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int1 = fraction0.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction2 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = fraction0.add(fraction2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        float float5 = fraction1.floatValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.pow((int) (byte) 0);
        try {
            org.apache.commons.lang3.math.Fraction fraction8 = fraction1.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(fraction7);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(3, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction(3, (int) ' ');
        boolean boolean6 = fraction2.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        try {
            org.apache.commons.lang3.math.Fraction fraction4 = fraction2.pow((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("0/1");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = fraction1.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str1 = fraction0.toString();
        double double2 = fraction0.doubleValue();
        java.lang.String str3 = fraction0.toProperString();
        float float4 = fraction0.floatValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1/2" + "'", str1.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1/2" + "'", str3.equals("1/2"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.5f + "'", float4 == 0.5f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("0");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) ' ', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, 2);
        java.lang.String str3 = fraction2.toProperString();
        try {
            org.apache.commons.lang3.math.Fraction fraction5 = fraction2.pow((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mulPos");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1/2" + "'", str3.equals("1/2"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, (int) (byte) 100);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        short short4 = fraction1.shortValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.negate();
        int int6 = fraction1.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, 100);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        java.lang.Class<?> wildcardClass1 = fraction0.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        int int5 = fraction3.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        long long5 = fraction3.longValue();
        try {
            org.apache.commons.lang3.math.Fraction fraction7 = fraction3.pow((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mulPos");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(2, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100L);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction15 = fraction2.multiplyBy(fraction14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) -2, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.reduce();
        boolean boolean13 = fraction8.equals((java.lang.Object) fraction11);
        java.lang.String str14 = fraction11.toString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "4/5" + "'", str14.equals("4/5"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction3 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction4 = fraction2.add(fraction3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.6f);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        byte byte5 = fraction4.byteValue();
        java.lang.String str6 = fraction4.toString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10/100" + "'", str6.equals("10/100"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_THIRDS;
        int int1 = fraction0.getDenominator();
        byte byte2 = fraction0.byteValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.reduce();
        try {
            org.apache.commons.lang3.math.Fraction fraction7 = fraction1.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -2, (-1), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The numerator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        long long5 = fraction1.longValue();
        boolean boolean7 = fraction1.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(2, 2, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction1.abs();
        int int12 = fraction11.getProperWhole();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str7 = fraction6.toString();
        double double8 = fraction6.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction3.add(fraction6);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction10.reduce();
        java.lang.String str12 = fraction11.toProperString();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.abs();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction9.divideBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction0.divideBy(fraction9);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1/2" + "'", str7.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4/5" + "'", str12.equals("4/5"));
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        float float1 = fraction0.floatValue();
        java.lang.Class<?> wildcardClass2 = fraction0.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.6f + "'", float1 == 0.6f);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (-2L));
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) (byte) 10, (int) (short) 10);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        int int8 = fraction7.getDenominator();
        boolean boolean9 = fraction1.equals((java.lang.Object) int8);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction10.abs();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str13 = fraction12.toString();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean18 = fraction16.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int21 = fraction20.getNumerator();
        int int22 = fraction20.getDenominator();
        short short23 = fraction20.shortValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction20.negate();
        int int25 = fraction24.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction16.add(fraction24);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction12.divideBy(fraction16);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction10.multiplyBy(fraction12);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction1.multiplyBy(fraction10);
        org.apache.commons.lang3.math.Fraction fraction30 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction31 = fraction1.multiplyBy(fraction30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1/2" + "'", str13.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 2);
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean4 = fraction2.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        int int6 = fraction1.compareTo(fraction5);
        double double7 = fraction1.doubleValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.add(fraction14);
        int int16 = fraction14.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction14.abs();
        float float18 = fraction17.floatValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction("0/1");
        boolean boolean4 = fraction0.equals((java.lang.Object) "0/1");
        org.apache.commons.lang3.math.Fraction fraction5 = fraction0.invert();
        int int6 = fraction0.intValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction10.subtract(fraction11);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) ' ', 0, (int) (byte) 100);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        short short11 = fraction5.shortValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction10.multiplyBy(fraction15);
        short short21 = fraction10.shortValue();
        int int22 = fraction10.getProperWhole();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 0 + "'", short21 == (short) 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction0.multiplyBy(fraction3);
        float float9 = fraction3.floatValue();
        java.lang.String str10 = fraction3.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0/1" + "'", str10.equals("0/1"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str1 = fraction0.toString();
        double double2 = fraction0.doubleValue();
        byte byte3 = fraction0.byteValue();
        long long4 = fraction0.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1/2" + "'", str1.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        short short4 = fraction1.shortValue();
        java.lang.Class<?> wildcardClass5 = fraction1.getClass();
        short short6 = fraction1.shortValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean5 = fraction3.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int8 = fraction7.getNumerator();
        int int9 = fraction7.getDenominator();
        short short10 = fraction7.shortValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.negate();
        int int12 = fraction3.compareTo(fraction7);
        int int13 = fraction3.getProperWhole();
        float float14 = fraction3.floatValue();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction3.add(fraction15);
        int int17 = fraction15.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction0.divideBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction20 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction21 = fraction0.add(fraction20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.625f + "'", float14 == 1.625f);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction11 = fraction9.divideBy(fraction10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_THIRDS;
        short short1 = fraction0.shortValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) '4');
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        short short1 = fraction0.shortValue();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        byte byte6 = fraction3.byteValue();
        int int7 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.abs();
        int int9 = fraction0.compareTo(fraction3);
        int int10 = fraction3.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        java.lang.String str2 = fraction1.toString();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.abs();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0/1" + "'", str2.equals("0/1"));
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int8 = fraction7.getNumerator();
        int int9 = fraction7.getDenominator();
        byte byte10 = fraction7.byteValue();
        int int11 = fraction7.getProperWhole();
        float float12 = fraction7.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction5.subtract(fraction7);
        int int14 = fraction7.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100.0f);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.pow(3);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction("1 5/8");
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.subtract(fraction6);
        int int8 = fraction7.getNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-13) + "'", int8 == (-13));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        int int8 = fraction7.getDenominator();
        boolean boolean9 = fraction1.equals((java.lang.Object) int8);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction11 = fraction10.abs();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str13 = fraction12.toString();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean18 = fraction16.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int21 = fraction20.getNumerator();
        int int22 = fraction20.getDenominator();
        short short23 = fraction20.shortValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction20.negate();
        int int25 = fraction24.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction16.add(fraction24);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction12.divideBy(fraction16);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction10.multiplyBy(fraction12);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction1.multiplyBy(fraction10);
        int int30 = fraction10.intValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1/2" + "'", str13.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long4 = fraction3.longValue();
        int int5 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean10 = fraction8.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int13 = fraction12.getNumerator();
        int int14 = fraction12.getDenominator();
        short short15 = fraction12.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.negate();
        int int17 = fraction8.compareTo(fraction12);
        int int18 = fraction8.getProperWhole();
        float float19 = fraction8.floatValue();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction8.add(fraction20);
        int int22 = fraction20.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction20.abs();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction3.subtract(fraction25);
        short short27 = fraction3.shortValue();
        int int28 = fraction3.getDenominator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2L) + "'", long4 == (-2L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2) + "'", int5 == (-2));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.625f + "'", float19 == 1.625f);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + short27 + "' != '" + (short) -2 + "'", short27 == (short) -2);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.reduce();
        java.lang.String str7 = fraction6.toProperString();
        double double8 = fraction6.doubleValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str4 = fraction3.toProperString();
        int int5 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        int int8 = fraction7.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.abs();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.add(fraction7);
        try {
            org.apache.commons.lang3.math.Fraction fraction12 = fraction7.pow((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 45/52" + "'", str4.equals("1 45/52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        java.lang.String str10 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.multiplyBy(fraction4);
        java.lang.String str12 = fraction4.toProperString();
        java.lang.String str13 = fraction4.toProperString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(2, (int) (byte) 10);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.reduce();
        java.lang.String str7 = fraction6.toString();
        try {
            org.apache.commons.lang3.math.Fraction fraction9 = fraction6.pow((int) (short) -2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0/1" + "'", str7.equals("0/1"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction10.multiplyBy(fraction15);
        int int21 = fraction10.intValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100);
        int int2 = fraction1.intValue();
        short short3 = fraction1.shortValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        float float8 = fraction7.floatValue();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int10 = fraction9.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int13 = fraction12.getNumerator();
        int int14 = fraction12.getDenominator();
        short short15 = fraction12.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.negate();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction9.multiplyBy(fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction7.multiplyBy(fraction12);
        byte byte19 = fraction18.byteValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 0 + "'", byte19 == (byte) 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.add(fraction14);
        int int16 = fraction14.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.pow((int) (byte) -1);
        int int20 = fraction17.getProperWhole();
        int int21 = fraction17.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, (int) '4');
        int int3 = fraction2.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        int int4 = fraction3.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction3.pow((int) (byte) -2);
        double double7 = fraction3.doubleValue();
        short short8 = fraction3.shortValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 97 + "'", short8 == (short) 97);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100);
        int int2 = fraction1.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.multiplyBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) ' ', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction13);
        java.lang.Class<?> wildcardClass15 = fraction14.getClass();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("2/1");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        short short4 = fraction1.shortValue();
        boolean boolean6 = fraction1.equals((java.lang.Object) 10);
        int int7 = fraction1.getProperNumerator();
        int int8 = fraction1.intValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        java.lang.Class<?> wildcardClass5 = fraction4.getClass();
        try {
            org.apache.commons.lang3.math.Fraction fraction7 = fraction4.pow((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, (-1));
        int int3 = fraction2.getDenominator();
        java.lang.String str4 = fraction2.toProperString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.pow(10);
        byte byte4 = fraction1.byteValue();
        byte byte5 = fraction1.byteValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (-1));
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        int int6 = fraction1.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        java.lang.String str10 = fraction9.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.abs();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction7.divideBy(fraction9);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.abs();
        java.lang.Object obj14 = null;
        boolean boolean15 = fraction13.equals(obj14);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4/5" + "'", str10.equals("4/5"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (byte) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) (byte) -35);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, (-1));
        int int3 = fraction2.getDenominator();
        java.lang.String str4 = fraction2.toString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1/1" + "'", str4.equals("-1/1"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int1 = fraction0.getProperWhole();
        double double2 = fraction0.doubleValue();
        double double3 = fraction0.doubleValue();
        int int4 = fraction0.getNumerator();
        int int5 = fraction0.getNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.75d + "'", double2 == 0.75d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.75d + "'", double3 == 0.75d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (byte) -1);
        java.lang.Class<?> wildcardClass3 = fraction2.getClass();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        float float2 = fraction0.floatValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction0.subtract(fraction6);
        java.lang.String str8 = fraction6.toProperString();
        int int9 = fraction6.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-2" + "'", str8.equals("-2"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = fraction0.pow((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mulPos");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        float float1 = fraction0.floatValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.abs();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.6f + "'", float1 == 0.6f);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int8 = fraction7.getNumerator();
        int int9 = fraction7.getDenominator();
        byte byte10 = fraction7.byteValue();
        int int11 = fraction7.getProperWhole();
        float float12 = fraction7.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction5.subtract(fraction7);
        long long14 = fraction7.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("80/1");
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction1.abs();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.pow(0);
        java.lang.String str14 = fraction11.toProperString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(2, 52);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int9 = fraction8.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int12 = fraction11.getNumerator();
        int int13 = fraction11.getDenominator();
        short short14 = fraction11.shortValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.negate();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction8.multiplyBy(fraction11);
        java.lang.Class<?> wildcardClass17 = fraction11.getClass();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction6.subtract(fraction11);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction2.divideBy(fraction6);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2L) + "'", long7 == (-2L));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        float float8 = fraction7.floatValue();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int10 = fraction9.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int13 = fraction12.getNumerator();
        int int14 = fraction12.getDenominator();
        short short15 = fraction12.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.negate();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction9.multiplyBy(fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction7.multiplyBy(fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int20 = fraction19.getNumerator();
        float float21 = fraction19.floatValue();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction19.subtract(fraction25);
        int int27 = fraction19.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction18.multiplyBy(fraction19);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(fraction28);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', (int) (short) 97);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("-1");
        byte byte2 = fraction1.byteValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(1, (-3), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The numerator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(10, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.abs();
        float float5 = fraction4.floatValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.3125f + "'", float5 == 0.3125f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction1.negate();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 2);
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean4 = fraction2.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        int int6 = fraction1.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str10 = fraction9.toProperString();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, 2);
        java.lang.String str14 = fraction13.toProperString();
        double double15 = fraction13.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction9.add(fraction13);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction1.add(fraction9);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.invert();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 0);
        try {
            org.apache.commons.lang3.math.Fraction fraction21 = fraction18.divideBy(fraction20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The fraction to divide by must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 5/8" + "'", str10.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1/2" + "'", str14.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction20);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ZERO;
        try {
            org.apache.commons.lang3.math.Fraction fraction1 = fraction0.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction("1 5/8");
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.invert();
        java.lang.Class<?> wildcardClass9 = fraction6.getClass();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        java.lang.Class<?> wildcardClass2 = fraction1.getClass();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int4 = fraction3.getNumerator();
        float float5 = fraction3.floatValue();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.subtract(fraction9);
        java.lang.String str11 = fraction9.toProperString();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction1.add(fraction9);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-2" + "'", str11.equals("-2"));
        org.junit.Assert.assertNotNull(fraction12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.add(fraction14);
        int int16 = fraction14.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.pow((int) (byte) -1);
        java.lang.String str20 = fraction19.toProperString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(4, (int) '#', (int) (short) 100);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean12 = fraction10.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.divideBy(fraction10);
        java.lang.String str14 = fraction13.toProperString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        double double7 = fraction4.doubleValue();
        float float8 = fraction4.floatValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.4d + "'", double7 == 0.4d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.4f + "'", float8 == 0.4f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int8 = fraction7.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int11 = fraction10.getNumerator();
        int int12 = fraction10.getDenominator();
        short short13 = fraction10.shortValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction10.negate();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction7.multiplyBy(fraction10);
        java.lang.String str16 = fraction10.toString();
        long long17 = fraction10.longValue();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean25 = fraction23.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int28 = fraction27.getNumerator();
        int int29 = fraction27.getDenominator();
        short short30 = fraction27.shortValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction27.negate();
        int int32 = fraction23.compareTo(fraction27);
        int int33 = fraction23.getProperWhole();
        float float34 = fraction23.floatValue();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction36 = fraction23.add(fraction35);
        int int37 = fraction35.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction38 = fraction35.abs();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction38.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction43.negate();
        org.apache.commons.lang3.math.Fraction fraction45 = fraction44.negate();
        boolean boolean46 = fraction38.equals((java.lang.Object) fraction45);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction20.divideBy(fraction38);
        int int48 = fraction38.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction49 = fraction10.add(fraction38);
        int int50 = fraction4.compareTo(fraction10);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0/1" + "'", str16.equals("0/1"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 0 + "'", short30 == (short) 0);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.625f + "'", float34 == 1.625f);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, (int) (byte) 6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction1.abs();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.pow(0);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.abs();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        byte byte5 = fraction4.byteValue();
        byte byte6 = fraction4.byteValue();
        long long7 = fraction4.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        java.lang.String str10 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.multiplyBy(fraction4);
        try {
            org.apache.commons.lang3.math.Fraction fraction12 = fraction4.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertNotNull(fraction11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.5f);
        int int2 = fraction1.getProperWhole();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        byte byte6 = fraction3.byteValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int8 = fraction7.getNumerator();
        float float9 = fraction7.floatValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.divideBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction1.multiplyBy(fraction3);
        java.lang.Class<?> wildcardClass13 = fraction3.getClass();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction10.multiplyBy(fraction15);
        int int21 = fraction20.getProperWhole();
        long long22 = fraction20.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        java.lang.String str10 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.multiplyBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int14 = fraction13.getNumerator();
        int int15 = fraction13.getDenominator();
        byte byte16 = fraction13.byteValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int18 = fraction17.getNumerator();
        float float19 = fraction17.floatValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction13.divideBy(fraction17);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction13.negate();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction13.negate();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        short short24 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction22.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) -1, (int) '4', (int) (byte) 100);
        int int30 = fraction22.compareTo(fraction29);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction4.multiplyBy(fraction29);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 0 + "'", byte16 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + short24 + "' != '" + (short) 0 + "'", short24 == (short) 0);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(fraction31);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        long long3 = fraction2.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int14 = fraction13.getNumerator();
        float float15 = fraction13.floatValue();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction13.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction3.add(fraction20);
        long long22 = fraction3.longValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(10, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.abs();
        int int5 = fraction2.intValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        double double14 = fraction10.doubleValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 2, (int) (short) 2);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', 5);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str6 = fraction5.toProperString();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        byte byte11 = fraction8.byteValue();
        int int12 = fraction8.getProperWhole();
        int int13 = fraction5.compareTo(fraction8);
        int int14 = fraction8.intValue();
        try {
            org.apache.commons.lang3.math.Fraction fraction15 = fraction2.divideBy(fraction8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The fraction to divide by must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1 5/8" + "'", str6.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) 'a', (int) (byte) 2);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(10, (-5), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.abs();
        byte byte4 = fraction0.byteValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 0, (int) (byte) -2, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The numerator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -2, (int) (short) 2);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        float float8 = fraction7.floatValue();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int10 = fraction9.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int13 = fraction12.getNumerator();
        int int14 = fraction12.getDenominator();
        short short15 = fraction12.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.negate();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction9.multiplyBy(fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction7.multiplyBy(fraction12);
        long long19 = fraction12.longValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction("0/1");
        boolean boolean4 = fraction0.equals((java.lang.Object) "0/1");
        java.lang.Class<?> wildcardClass5 = fraction0.getClass();
        int int6 = fraction0.intValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int9 = fraction8.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str11 = fraction10.toString();
        double double12 = fraction10.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction8.add(fraction10);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction5.add(fraction13);
        int int15 = fraction5.getNumerator();
        java.lang.String str16 = fraction5.toString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1/2" + "'", str11.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5d + "'", double12 == 0.5d);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-97) + "'", int15 == (-97));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-97/1" + "'", str16.equals("-97/1"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (-2));
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int11 = fraction10.getNumerator();
        float float12 = fraction10.floatValue();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction10.subtract(fraction16);
        boolean boolean18 = fraction1.equals((java.lang.Object) fraction16);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean23 = fraction21.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int26 = fraction25.getNumerator();
        int int27 = fraction25.getDenominator();
        short short28 = fraction25.shortValue();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction25.negate();
        int int30 = fraction21.compareTo(fraction25);
        long long31 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction21.reduce();
        int int33 = fraction16.compareTo(fraction21);
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int36 = fraction35.getNumerator();
        int int37 = fraction35.getDenominator();
        byte byte38 = fraction35.byteValue();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int40 = fraction39.getNumerator();
        float float41 = fraction39.floatValue();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction35.divideBy(fraction39);
        org.apache.commons.lang3.math.Fraction fraction43 = fraction35.negate();
        org.apache.commons.lang3.math.Fraction fraction44 = fraction35.negate();
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction46 = fraction45.reduce();
        int int47 = fraction44.compareTo(fraction46);
        org.apache.commons.lang3.math.Fraction fraction48 = fraction44.negate();
        try {
            org.apache.commons.lang3.math.Fraction fraction49 = fraction21.divideBy(fraction48);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The fraction to divide by must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + short28 + "' != '" + (short) 0 + "'", short28 == (short) 0);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + byte38 + "' != '" + (byte) 0 + "'", byte38 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.5f + "'", float41 == 0.5f);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(fraction48);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(0, 4);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int1 = fraction0.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean6 = fraction4.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        int int13 = fraction12.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction12);
        java.lang.String str15 = fraction12.toProperString();
        boolean boolean16 = fraction0.equals((java.lang.Object) fraction12);
        java.lang.String str17 = fraction0.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2/5" + "'", str17.equals("2/5"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 97, 4);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.reduce();
        int int13 = fraction10.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction10.negate();
        byte byte15 = fraction14.byteValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 0 + "'", byte15 == (byte) 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        java.lang.Class<?> wildcardClass13 = fraction2.getClass();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.abs();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.reduce();
        float float10 = fraction6.floatValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.4f + "'", float10 == 0.4f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int14 = fraction13.getNumerator();
        float float15 = fraction13.floatValue();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction13.subtract(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction3.add(fraction20);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -2, (int) (short) 0, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction20.subtract(fraction25);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.reduce();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        int int2 = fraction1.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.abs();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str7 = fraction6.toProperString();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.multiplyBy(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.negate();
        int int10 = fraction9.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1 5/8" + "'", str7.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 0, (int) (byte) -1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The numerator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((-3), (int) (byte) 103);
        int int3 = fraction2.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-3) + "'", int3 == (-3));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.pow((int) (short) -2);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean10 = fraction8.equals((java.lang.Object) fraction9);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.multiplyBy(fraction9);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.invert();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.negate();
        java.lang.Class<?> wildcardClass12 = fraction2.getClass();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 10, 2);
        byte byte4 = fraction3.byteValue();
        int int5 = fraction3.getNumerator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 6 + "'", byte4 == (byte) 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(52, 97);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0);
        int int2 = fraction1.getProperWhole();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (-35.0f));
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int13 = fraction12.getNumerator();
        float float14 = fraction12.floatValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction12.subtract(fraction18);
        int int20 = fraction12.getNumerator();
        int int21 = fraction2.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction12.reduce();
        int int23 = fraction12.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        int int3 = fraction2.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean10 = fraction8.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int13 = fraction12.getNumerator();
        int int14 = fraction12.getDenominator();
        short short15 = fraction12.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.negate();
        int int17 = fraction16.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction8.add(fraction16);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction4.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction2.subtract(fraction8);
        try {
            org.apache.commons.lang3.math.Fraction fraction21 = fraction20.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100);
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.reduce();
        int int4 = fraction3.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.multiplyBy(fraction5);
        java.lang.String str7 = fraction6.toString();
        double double8 = fraction6.doubleValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "80/1" + "'", str7.equals("80/1"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 80.0d + "'", double8 == 80.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        float float2 = fraction0.floatValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction0.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.negate();
        java.lang.String str9 = fraction6.toProperString();
        java.lang.String str10 = fraction6.toProperString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-2" + "'", str9.equals("-2"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-2" + "'", str10.equals("-2"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, 2);
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction4 = null;
        try {
            int int5 = fraction2.compareTo(fraction4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1/2" + "'", str3.equals("1/2"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.abs();
        int int6 = fraction4.getNumerator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-97) + "'", int6 == (-97));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int11 = fraction10.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str13 = fraction12.toString();
        double double14 = fraction12.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.add(fraction12);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction1.divideBy(fraction10);
        java.lang.Class<?> wildcardClass17 = fraction10.getClass();
        int int18 = fraction10.getProperWhole();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1/2" + "'", str13.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5d + "'", double14 == 0.5d);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction(0.0d);
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        byte byte6 = fraction3.byteValue();
        int int7 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.negate();
        double double9 = fraction8.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction8.pow(4);
        try {
            org.apache.commons.lang3.math.Fraction fraction12 = fraction1.divideBy(fraction11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The fraction to divide by must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(fraction11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        java.lang.String str10 = fraction9.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.abs();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction7.divideBy(fraction9);
        byte byte13 = fraction12.byteValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4/5" + "'", str10.equals("4/5"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction10.multiplyBy(fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int22 = fraction21.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.invert();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction15.multiplyBy(fraction23);
        try {
            org.apache.commons.lang3.math.Fraction fraction25 = fraction15.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.negate();
        java.lang.Class<?> wildcardClass7 = fraction1.getClass();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean7 = fraction5.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int10 = fraction9.getNumerator();
        int int11 = fraction9.getDenominator();
        short short12 = fraction9.shortValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.negate();
        int int14 = fraction5.compareTo(fraction9);
        int int15 = fraction5.getProperWhole();
        float float16 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction5.add(fraction17);
        int int19 = fraction17.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction17.abs();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction25.negate();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction26.negate();
        boolean boolean28 = fraction20.equals((java.lang.Object) fraction27);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction2.divideBy(fraction20);
        int int30 = fraction20.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction20.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.625f + "'", float16 == 1.625f);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(fraction31);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int7 = fraction6.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int10 = fraction9.getNumerator();
        int int11 = fraction9.getDenominator();
        short short12 = fraction9.shortValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.negate();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction6.multiplyBy(fraction9);
        short short15 = fraction14.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.abs();
        int int17 = fraction3.compareTo(fraction14);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.invert();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long11 = fraction10.longValue();
        int int12 = fraction10.intValue();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean17 = fraction15.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int20 = fraction19.getNumerator();
        int int21 = fraction19.getDenominator();
        short short22 = fraction19.shortValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction19.negate();
        int int24 = fraction15.compareTo(fraction19);
        int int25 = fraction15.getProperWhole();
        float float26 = fraction15.floatValue();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction28 = fraction15.add(fraction27);
        int int29 = fraction27.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction27.abs();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction30.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction10.subtract(fraction32);
        short short34 = fraction10.shortValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction6.subtract(fraction10);
        short short36 = fraction10.shortValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2L) + "'", long11 == (-2L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-2) + "'", int12 == (-2));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + short22 + "' != '" + (short) 0 + "'", short22 == (short) 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.625f + "'", float26 == 1.625f);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + short34 + "' != '" + (short) -2 + "'", short34 == (short) -2);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + short36 + "' != '" + (short) -2 + "'", short36 == (short) -2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 4);
        int int3 = fraction2.getDenominator();
        long long4 = fraction2.longValue();
        int int5 = fraction2.intValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("-1/10");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int13 = fraction12.getNumerator();
        float float14 = fraction12.floatValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction12.subtract(fraction18);
        int int20 = fraction12.getNumerator();
        int int21 = fraction2.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction12.invert();
        int int23 = fraction12.getNumerator();
        long long24 = fraction12.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(10, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        byte byte4 = fraction2.byteValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.pow((-5));
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((-1), 8);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        java.lang.Class<?> wildcardClass11 = fraction5.getClass();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean16 = fraction14.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int19 = fraction18.getNumerator();
        int int20 = fraction18.getDenominator();
        short short21 = fraction18.shortValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.negate();
        int int23 = fraction14.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean29 = fraction27.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int32 = fraction31.getNumerator();
        int int33 = fraction31.getDenominator();
        short short34 = fraction31.shortValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction31.negate();
        int int36 = fraction27.compareTo(fraction31);
        int int37 = fraction27.getProperWhole();
        float float38 = fraction27.floatValue();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction40 = fraction27.add(fraction39);
        int int41 = fraction39.getDenominator();
        short short42 = fraction39.shortValue();
        long long43 = fraction39.longValue();
        org.apache.commons.lang3.math.Fraction fraction44 = fraction14.divideBy(fraction39);
        org.apache.commons.lang3.math.Fraction fraction46 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int47 = fraction46.getNumerator();
        int int48 = fraction46.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction52 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction53 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction54 = fraction52.divideBy(fraction53);
        org.apache.commons.lang3.math.Fraction fraction55 = fraction46.divideBy(fraction53);
        org.apache.commons.lang3.math.Fraction fraction56 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction57 = fraction56.reduce();
        boolean boolean58 = fraction53.equals((java.lang.Object) fraction56);
        org.apache.commons.lang3.math.Fraction fraction59 = fraction39.add(fraction53);
        org.apache.commons.lang3.math.Fraction fraction60 = fraction5.subtract(fraction53);
        double double61 = fraction5.doubleValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 0 + "'", short21 == (short) 0);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + short34 + "' != '" + (short) 0 + "'", short34 == (short) 0);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.625f + "'", float38 == 1.625f);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + short42 + "' != '" + (short) 1 + "'", short42 == (short) 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertNotNull(fraction56);
        org.junit.Assert.assertNotNull(fraction57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertNotNull(fraction60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.negate();
        int int2 = fraction1.intValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str6 = fraction5.toProperString();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        byte byte11 = fraction8.byteValue();
        int int12 = fraction8.getProperWhole();
        int int13 = fraction5.compareTo(fraction8);
        java.lang.Class<?> wildcardClass14 = fraction8.getClass();
        int int15 = fraction1.compareTo(fraction8);
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int17 = fraction16.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int20 = fraction19.getNumerator();
        int int21 = fraction19.getDenominator();
        short short22 = fraction19.shortValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction19.negate();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction16.multiplyBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str28 = fraction27.toProperString();
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, 2);
        java.lang.String str32 = fraction31.toProperString();
        double double33 = fraction31.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction27.add(fraction31);
        org.apache.commons.lang3.math.Fraction fraction35 = fraction16.multiplyBy(fraction27);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction1.subtract(fraction16);
        org.apache.commons.lang3.math.Fraction fraction37 = fraction16.abs();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1 5/8" + "'", str6.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + short22 + "' != '" + (short) 0 + "'", short22 == (short) 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1 5/8" + "'", str28.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1/2" + "'", str32.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.5d + "'", double33 == 0.5d);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -2, (int) (byte) 2);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        int int11 = fraction5.getProperWhole();
        int int12 = fraction5.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction5.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(fraction13);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.reduce();
        short short7 = fraction1.shortValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        int int2 = fraction1.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.abs();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str7 = fraction6.toProperString();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.multiplyBy(fraction6);
        int int9 = fraction6.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction10 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction11 = fraction6.divideBy(fraction10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1 5/8" + "'", str7.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) '4', (int) (short) 97);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) -2, 8);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.add(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int8 = fraction7.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean13 = fraction11.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        int int20 = fraction19.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction11.add(fraction19);
        java.lang.String str22 = fraction19.toProperString();
        boolean boolean23 = fraction7.equals((java.lang.Object) fraction19);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction5.multiplyBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction25 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction26 = fraction5.add(fraction25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(fraction24);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        int int4 = fraction3.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction3.pow((int) (byte) -2);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        double double1 = fraction0.doubleValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (-5), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The numerator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.add(fraction14);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(0, 12);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        double double4 = fraction1.doubleValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int11 = fraction10.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str13 = fraction12.toString();
        double double14 = fraction12.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.add(fraction12);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction1.divideBy(fraction10);
        org.apache.commons.lang3.math.Fraction fraction17 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction18 = fraction1.add(fraction17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1/2" + "'", str13.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5d + "'", double14 == 0.5d);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long4 = fraction3.longValue();
        int int5 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean10 = fraction8.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int13 = fraction12.getNumerator();
        int int14 = fraction12.getDenominator();
        short short15 = fraction12.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.negate();
        int int17 = fraction8.compareTo(fraction12);
        int int18 = fraction8.getProperWhole();
        float float19 = fraction8.floatValue();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction8.add(fraction20);
        int int22 = fraction20.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction20.abs();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction3.subtract(fraction25);
        org.apache.commons.lang3.math.Fraction fraction27 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction28 = fraction3.divideBy(fraction27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2L) + "'", long4 == (-2L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2) + "'", int5 == (-2));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.625f + "'", float19 == 1.625f);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        java.lang.String str10 = fraction9.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.abs();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction7.divideBy(fraction9);
        double double13 = fraction12.doubleValue();
        float float14 = fraction12.floatValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4/5" + "'", str10.equals("4/5"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.625d + "'", double13 == 0.625d);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.625f + "'", float14 == 0.625f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str4 = fraction3.toProperString();
        int int5 = fraction3.intValue();
        try {
            org.apache.commons.lang3.math.Fraction fraction7 = fraction3.pow(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 45/52" + "'", str4.equals("1 45/52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int1 = fraction0.getProperWhole();
        int int2 = fraction0.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        java.lang.Object obj7 = null;
        boolean boolean8 = fraction3.equals(obj7);
        java.lang.String str9 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.add(fraction3);
        int int11 = fraction10.intValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0/1" + "'", str9.equals("0/1"));
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        short short4 = fraction1.shortValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.negate();
        int int6 = fraction5.getNumerator();
        java.lang.String str7 = fraction5.toProperString();
        org.apache.commons.lang3.math.Fraction fraction8 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction9 = fraction5.divideBy(fraction8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 103, (int) (byte) -2);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1 45/52");
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.negate();
        int int6 = fraction1.compareTo(fraction5);
        short short7 = fraction1.shortValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        java.lang.String str3 = fraction1.toProperString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.invert();
        long long3 = fraction2.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        short short12 = fraction11.shortValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction10.divideBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str17 = fraction16.toProperString();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int20 = fraction19.getNumerator();
        int int21 = fraction19.getDenominator();
        byte byte22 = fraction19.byteValue();
        int int23 = fraction19.getProperWhole();
        int int24 = fraction16.compareTo(fraction19);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction16.negate();
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int27 = fraction26.getNumerator();
        float float28 = fraction26.floatValue();
        org.apache.commons.lang3.math.Fraction fraction32 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction26.subtract(fraction32);
        int int34 = fraction26.getNumerator();
        int int35 = fraction16.compareTo(fraction26);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction26.invert();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction10.multiplyBy(fraction36);
        org.apache.commons.lang3.math.Fraction fraction38 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction39 = fraction10.multiplyBy(fraction38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1 5/8" + "'", str17.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + byte22 + "' != '" + (byte) 0 + "'", byte22 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.5f + "'", float28 == 0.5f);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        long long5 = fraction4.longValue();
        short short6 = fraction4.shortValue();
        java.lang.String str7 = fraction4.toString();
        long long8 = fraction4.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2L + "'", long5 == 2L);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 2 + "'", short6 == (short) 2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2/1" + "'", str7.equals("2/1"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.pow(10);
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.negate();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.negate();
        try {
            org.apache.commons.lang3.math.Fraction fraction11 = fraction1.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        byte byte5 = fraction4.byteValue();
        byte byte6 = fraction4.byteValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.invert();
        java.lang.String str9 = fraction7.toString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1/10" + "'", str9.equals("1/10"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("10/100");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) '4', (int) (byte) 100, (int) 'a');
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.invert();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction(2.0d);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction1.abs();
        int int12 = fraction11.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        java.lang.Class<?> wildcardClass2 = fraction1.getClass();
        long long3 = fraction1.longValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.subtract(fraction10);
        java.lang.String str13 = fraction12.toString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "97/1" + "'", str13.equals("97/1"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str1 = fraction0.toString();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean6 = fraction4.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        int int13 = fraction12.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction12);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction0.divideBy(fraction4);
        java.lang.String str16 = fraction4.toProperString();
        java.lang.String str17 = fraction4.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1/2" + "'", str1.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1 5/8" + "'", str16.equals("1 5/8"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13/8" + "'", str17.equals("13/8"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction0.multiplyBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int11 = fraction10.getNumerator();
        int int12 = fraction10.getDenominator();
        byte byte13 = fraction10.byteValue();
        int int14 = fraction10.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.negate();
        double double16 = fraction15.doubleValue();
        java.lang.Class<?> wildcardClass17 = fraction15.getClass();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction0.multiplyBy(fraction15);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int13 = fraction12.getNumerator();
        float float14 = fraction12.floatValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction12.subtract(fraction18);
        int int20 = fraction12.getNumerator();
        int int21 = fraction2.compareTo(fraction12);
        float float22 = fraction2.floatValue();
        int int23 = fraction2.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.625f + "'", float22 == 1.625f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, (-2));
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long4 = fraction3.longValue();
        double double5 = fraction3.doubleValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2L) + "'", long4 == (-2L));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.0d) + "'", double5 == (-2.0d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        java.lang.String str10 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.multiplyBy(fraction4);
        double double12 = fraction4.doubleValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(173, (int) '4', 3);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (-1.0f));
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.negate();
        int int11 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str15 = fraction14.toProperString();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int18 = fraction17.getNumerator();
        int int19 = fraction17.getDenominator();
        short short20 = fraction17.shortValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.negate();
        int int22 = fraction21.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction14.add(fraction21);
        int int24 = fraction1.compareTo(fraction14);
        java.lang.String str25 = fraction1.toProperString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1 5/8" + "'", str15.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + short20 + "' != '" + (short) 0 + "'", short20 == (short) 0);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 103, (-200), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The numerator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 1);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("97/1");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 2, 1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction1.abs();
        java.lang.Class<?> wildcardClass12 = fraction1.getClass();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        java.lang.Class<?> wildcardClass14 = fraction2.getClass();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(fraction15);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        long long6 = fraction4.longValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long4 = fraction3.longValue();
        int int5 = fraction3.intValue();
        java.lang.Class<?> wildcardClass6 = fraction3.getClass();
        double double7 = fraction3.doubleValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2L) + "'", long4 == (-2L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2) + "'", int5 == (-2));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-2.0d) + "'", double7 == (-2.0d));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int15 = fraction14.getProperWhole();
        double double16 = fraction14.doubleValue();
        double double17 = fraction14.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction2.subtract(fraction14);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean21 = fraction19.equals((java.lang.Object) fraction20);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.negate();
        long long23 = fraction22.longValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction18.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str28 = fraction27.toProperString();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int31 = fraction30.getNumerator();
        int int32 = fraction30.getDenominator();
        byte byte33 = fraction30.byteValue();
        int int34 = fraction30.getProperWhole();
        int int35 = fraction27.compareTo(fraction30);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction27.negate();
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int38 = fraction37.getNumerator();
        float float39 = fraction37.floatValue();
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction37.subtract(fraction43);
        int int45 = fraction37.getNumerator();
        int int46 = fraction27.compareTo(fraction37);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction37.reduce();
        int int48 = fraction22.compareTo(fraction47);
        org.apache.commons.lang3.math.Fraction fraction50 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction52 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int53 = fraction52.getNumerator();
        int int54 = fraction52.getDenominator();
        byte byte55 = fraction52.byteValue();
        org.apache.commons.lang3.math.Fraction fraction56 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int57 = fraction56.getNumerator();
        float float58 = fraction56.floatValue();
        org.apache.commons.lang3.math.Fraction fraction59 = fraction52.divideBy(fraction56);
        org.apache.commons.lang3.math.Fraction fraction60 = fraction52.negate();
        org.apache.commons.lang3.math.Fraction fraction61 = fraction50.multiplyBy(fraction52);
        org.apache.commons.lang3.math.Fraction fraction63 = fraction50.pow((int) (short) 97);
        float float64 = fraction50.floatValue();
        org.apache.commons.lang3.math.Fraction fraction65 = fraction22.add(fraction50);
        org.apache.commons.lang3.math.Fraction fraction69 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long70 = fraction69.longValue();
        org.apache.commons.lang3.math.Fraction fraction71 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int72 = fraction71.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction74 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int75 = fraction74.getNumerator();
        int int76 = fraction74.getDenominator();
        short short77 = fraction74.shortValue();
        org.apache.commons.lang3.math.Fraction fraction78 = fraction74.negate();
        org.apache.commons.lang3.math.Fraction fraction79 = fraction71.multiplyBy(fraction74);
        java.lang.Class<?> wildcardClass80 = fraction74.getClass();
        org.apache.commons.lang3.math.Fraction fraction81 = fraction69.subtract(fraction74);
        java.lang.String str82 = fraction81.toString();
        org.apache.commons.lang3.math.Fraction fraction83 = fraction22.subtract(fraction81);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.75d + "'", double16 == 0.75d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.75d + "'", double17 == 0.75d);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1 5/8" + "'", str28.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + byte33 + "' != '" + (byte) 0 + "'", byte33 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.5f + "'", float39 == 0.5f);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + byte55 + "' != '" + (byte) 0 + "'", byte55 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.5f + "'", float58 == 0.5f);
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertNotNull(fraction60);
        org.junit.Assert.assertNotNull(fraction61);
        org.junit.Assert.assertNotNull(fraction63);
        org.junit.Assert.assertTrue("'" + float64 + "' != '" + (-1.0f) + "'", float64 == (-1.0f));
        org.junit.Assert.assertNotNull(fraction65);
        org.junit.Assert.assertNotNull(fraction69);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-2L) + "'", long70 == (-2L));
        org.junit.Assert.assertNotNull(fraction71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(fraction74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + short77 + "' != '" + (short) 0 + "'", short77 == (short) 0);
        org.junit.Assert.assertNotNull(fraction78);
        org.junit.Assert.assertNotNull(fraction79);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(fraction81);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "-2/1" + "'", str82.equals("-2/1"));
        org.junit.Assert.assertNotNull(fraction83);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 4);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.negate();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int10 = fraction9.getNumerator();
        int int11 = fraction9.getDenominator();
        short short12 = fraction9.shortValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.negate();
        int int14 = fraction13.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction6.subtract(fraction13);
        boolean boolean16 = fraction2.equals((java.lang.Object) fraction13);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean5 = fraction3.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int8 = fraction7.getNumerator();
        int int9 = fraction7.getDenominator();
        short short10 = fraction7.shortValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.negate();
        int int12 = fraction3.compareTo(fraction7);
        int int13 = fraction3.getProperWhole();
        float float14 = fraction3.floatValue();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction3.add(fraction15);
        int int17 = fraction15.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction0.divideBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction0.reduce();
        float float21 = fraction0.floatValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.625f + "'", float14 == 1.625f);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        java.lang.String str11 = fraction8.toProperString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2/5" + "'", str11.equals("2/5"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.abs();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str16 = fraction15.toProperString();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int19 = fraction18.getNumerator();
        int int20 = fraction18.getDenominator();
        byte byte21 = fraction18.byteValue();
        int int22 = fraction18.getProperWhole();
        int int23 = fraction15.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean29 = fraction27.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int32 = fraction31.getNumerator();
        int int33 = fraction31.getDenominator();
        short short34 = fraction31.shortValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction31.negate();
        int int36 = fraction35.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction27.add(fraction35);
        java.lang.String str38 = fraction35.toProperString();
        org.apache.commons.lang3.math.Fraction fraction40 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int41 = fraction40.getNumerator();
        int int42 = fraction40.getDenominator();
        short short43 = fraction40.shortValue();
        org.apache.commons.lang3.math.Fraction fraction44 = fraction40.negate();
        org.apache.commons.lang3.math.Fraction fraction45 = fraction35.multiplyBy(fraction40);
        org.apache.commons.lang3.math.Fraction fraction46 = fraction24.add(fraction40);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction2.multiplyBy(fraction40);
        short short48 = fraction2.shortValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1 5/8" + "'", str16.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + byte21 + "' != '" + (byte) 0 + "'", byte21 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + short34 + "' != '" + (short) 0 + "'", short34 == (short) 0);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + short43 + "' != '" + (short) 0 + "'", short43 == (short) 0);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertTrue("'" + short48 + "' != '" + (short) 1 + "'", short48 == (short) 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction("1 5/8");
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.subtract(fraction6);
        int int8 = fraction1.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int13 = fraction12.getNumerator();
        float float14 = fraction12.floatValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction12.subtract(fraction18);
        int int20 = fraction12.getNumerator();
        int int21 = fraction2.compareTo(fraction12);
        int int22 = fraction12.getProperNumerator();
        float float23 = fraction12.floatValue();
        int int24 = fraction12.intValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(3, 0, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.pow((-1));
        float float6 = fraction3.floatValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 3.0f + "'", float6 == 3.0f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((-2), (int) (byte) 100);
        short short7 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.abs();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean13 = fraction11.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        int int20 = fraction11.compareTo(fraction15);
        int int21 = fraction11.getProperWhole();
        float float22 = fraction11.floatValue();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction24 = fraction11.add(fraction23);
        float float25 = fraction11.floatValue();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction11.abs();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        boolean boolean28 = fraction26.equals((java.lang.Object) fraction27);
        boolean boolean29 = fraction8.equals((java.lang.Object) fraction26);
        int int30 = fraction1.compareTo(fraction26);
        try {
            org.apache.commons.lang3.math.Fraction fraction31 = fraction1.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.625f + "'", float22 == 1.625f);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.625f + "'", float25 == 1.625f);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.negate();
        int int8 = fraction7.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(10, (int) (byte) 1);
        int int3 = fraction2.intValue();
        java.lang.Class<?> wildcardClass4 = fraction2.getClass();
        long long5 = fraction2.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str4 = fraction3.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.invert();
        double double6 = fraction3.doubleValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 45/52" + "'", str4.equals("1 45/52"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.8653846153846154d + "'", double6 == 1.8653846153846154d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1 5/8");
        int int2 = fraction1.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.5f);
        byte byte2 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        java.lang.Class<?> wildcardClass11 = fraction5.getClass();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean16 = fraction14.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int19 = fraction18.getNumerator();
        int int20 = fraction18.getDenominator();
        short short21 = fraction18.shortValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.negate();
        int int23 = fraction14.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean29 = fraction27.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int32 = fraction31.getNumerator();
        int int33 = fraction31.getDenominator();
        short short34 = fraction31.shortValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction31.negate();
        int int36 = fraction27.compareTo(fraction31);
        int int37 = fraction27.getProperWhole();
        float float38 = fraction27.floatValue();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction40 = fraction27.add(fraction39);
        int int41 = fraction39.getDenominator();
        short short42 = fraction39.shortValue();
        long long43 = fraction39.longValue();
        org.apache.commons.lang3.math.Fraction fraction44 = fraction14.divideBy(fraction39);
        org.apache.commons.lang3.math.Fraction fraction46 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int47 = fraction46.getNumerator();
        int int48 = fraction46.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction52 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction53 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction54 = fraction52.divideBy(fraction53);
        org.apache.commons.lang3.math.Fraction fraction55 = fraction46.divideBy(fraction53);
        org.apache.commons.lang3.math.Fraction fraction56 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction57 = fraction56.reduce();
        boolean boolean58 = fraction53.equals((java.lang.Object) fraction56);
        org.apache.commons.lang3.math.Fraction fraction59 = fraction39.add(fraction53);
        org.apache.commons.lang3.math.Fraction fraction60 = fraction5.subtract(fraction53);
        byte byte61 = fraction53.byteValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 0 + "'", short21 == (short) 0);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + short34 + "' != '" + (short) 0 + "'", short34 == (short) 0);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.625f + "'", float38 == 1.625f);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + short42 + "' != '" + (short) 1 + "'", short42 == (short) 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertNotNull(fraction56);
        org.junit.Assert.assertNotNull(fraction57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertNotNull(fraction60);
        org.junit.Assert.assertTrue("'" + byte61 + "' != '" + (byte) 0 + "'", byte61 == (byte) 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str4 = fraction3.toProperString();
        int int5 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction3.abs();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 45/52" + "'", str4.equals("1 45/52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(fraction6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.negate();
        java.lang.String str2 = fraction0.toString();
        short short3 = fraction0.shortValue();
        int int4 = fraction0.intValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3/5" + "'", str2.equals("3/5"));
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction0.multiplyBy(fraction3);
        short short9 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        long long11 = fraction10.longValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.abs();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction8.subtract(fraction10);
        int int14 = fraction8.getProperWhole();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        java.lang.String str2 = fraction0.toProperString();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction0.reduce();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1/2" + "'", str2.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(2, (-97));
        long long3 = fraction2.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str1 = fraction0.toString();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean6 = fraction4.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        int int13 = fraction12.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction12);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction0.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int17 = fraction16.getProperWhole();
        double double18 = fraction16.doubleValue();
        double double19 = fraction16.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction4.multiplyBy(fraction16);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1/2" + "'", str1.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.75d + "'", double18 == 0.75d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.75d + "'", double19 == 0.75d);
        org.junit.Assert.assertNotNull(fraction20);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(3, 100);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(10, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        int int4 = fraction3.getProperWhole();
        int int5 = fraction3.getNumerator();
        byte byte6 = fraction3.byteValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-5) + "'", int5 == (-5));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str4 = fraction3.toProperString();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        byte byte9 = fraction6.byteValue();
        int int10 = fraction6.getProperWhole();
        int int11 = fraction3.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int14 = fraction13.getNumerator();
        float float15 = fraction13.floatValue();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction13.subtract(fraction19);
        int int21 = fraction13.getNumerator();
        int int22 = fraction3.compareTo(fraction13);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction0.multiplyBy(fraction13);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean28 = fraction26.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int31 = fraction30.getNumerator();
        int int32 = fraction30.getDenominator();
        short short33 = fraction30.shortValue();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.negate();
        int int35 = fraction26.compareTo(fraction30);
        int int36 = fraction26.getProperWhole();
        float float37 = fraction26.floatValue();
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction39 = fraction26.add(fraction38);
        int int40 = fraction38.getDenominator();
        short short41 = fraction38.shortValue();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction38.reduce();
        org.apache.commons.lang3.math.Fraction fraction43 = fraction13.subtract(fraction42);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 5/8" + "'", str4.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + short33 + "' != '" + (short) 0 + "'", short33 == (short) 0);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.625f + "'", float37 == 1.625f);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + short41 + "' != '" + (short) 1 + "'", short41 == (short) 1);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction1.abs();
        byte byte12 = fraction11.byteValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction10.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction10.abs();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction17.abs();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction23 = fraction22.negate();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction23.abs();
        int int25 = fraction23.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction26.reduce();
        boolean boolean28 = fraction18.equals((java.lang.Object) fraction26);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        java.lang.String str3 = fraction1.toProperString();
        float float4 = fraction1.floatValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int3 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction2.add(fraction4);
        int int8 = fraction7.getProperWhole();
        long long9 = fraction7.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 173, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1/5");
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.negate();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((-13), (int) '#');
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 10, (int) (short) -2);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 10, (int) (short) 100);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -2, (int) (short) 0, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction(0.75d);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction3.add(fraction5);
        int int7 = fraction3.getNumerator();
        java.lang.Class<?> wildcardClass8 = fraction3.getClass();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-200) + "'", int7 == (-200));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        long long5 = fraction3.longValue();
        java.lang.Class<?> wildcardClass6 = fraction3.getClass();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("-2");
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.Class<?> wildcardClass13 = fraction12.getClass();
        byte byte14 = fraction12.byteValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.abs();
        byte byte17 = fraction12.byteValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 1 + "'", byte14 == (byte) 1);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 1 + "'", byte17 == (byte) 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction10.multiplyBy(fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int22 = fraction21.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction21.invert();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction15.multiplyBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction15.abs();
        byte byte26 = fraction15.byteValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + byte26 + "' != '" + (byte) 0 + "'", byte26 == (byte) 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("-1/1");
        int int2 = fraction1.getProperWhole();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-2), 4, (int) (short) 10);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(1, (int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        double double1 = fraction0.doubleValue();
        int int2 = fraction0.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8d + "'", double1 == 0.8d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str14 = fraction13.toProperString();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int17 = fraction16.getNumerator();
        int int18 = fraction16.getDenominator();
        byte byte19 = fraction16.byteValue();
        int int20 = fraction16.getProperWhole();
        int int21 = fraction13.compareTo(fraction16);
        float float22 = fraction13.floatValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction5.divideBy(fraction13);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int26 = fraction25.getNumerator();
        int int27 = fraction25.getDenominator();
        byte byte28 = fraction25.byteValue();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int30 = fraction29.getNumerator();
        float float31 = fraction29.floatValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction25.divideBy(fraction29);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction25.negate();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction25.negate();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        short short36 = fraction35.shortValue();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction34.divideBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction38 = fraction13.divideBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction41 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, 2);
        java.lang.String str42 = fraction41.toProperString();
        int int43 = fraction41.getProperNumerator();
        boolean boolean44 = fraction13.equals((java.lang.Object) int43);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1 5/8" + "'", str14.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 0 + "'", byte19 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.625f + "'", float22 == 1.625f);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + byte28 + "' != '" + (byte) 0 + "'", byte28 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + short36 + "' != '" + (short) 0 + "'", short36 == (short) 0);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1/2" + "'", str42.equals("1/2"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 52);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.pow((-2));
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        int int2 = fraction1.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.abs();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str7 = fraction6.toProperString();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.multiplyBy(fraction6);
        int int9 = fraction6.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.abs();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1 5/8" + "'", str7.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertNotNull(fraction10);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(8, (-1));
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        byte byte7 = fraction4.byteValue();
        int int8 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction4.reduce();
        java.lang.String str10 = fraction9.toProperString();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction9.pow((int) (byte) 100);
        int int13 = fraction2.compareTo(fraction12);
        short short14 = fraction12.shortValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-97), 2, (int) (short) 1);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(2, 52);
        int int3 = fraction2.getProperWhole();
        int int4 = fraction2.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 0, 0, 13);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(173, (-200));
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 103, 8);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.negate();
        int int11 = fraction1.getProperWhole();
        int int12 = fraction1.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction10.negate();
        java.lang.String str12 = fraction11.toProperString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (short) 10);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1 45/52");
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.negate();
        int int6 = fraction1.compareTo(fraction5);
        int int7 = fraction1.getNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        int int3 = fraction2.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean10 = fraction8.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int13 = fraction12.getNumerator();
        int int14 = fraction12.getDenominator();
        short short15 = fraction12.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.negate();
        int int17 = fraction16.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction8.add(fraction16);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction4.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction2.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int22 = fraction21.getNumerator();
        float float23 = fraction21.floatValue();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction21.subtract(fraction27);
        byte byte29 = fraction27.byteValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction8.multiplyBy(fraction27);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction30.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + byte29 + "' != '" + (byte) -2 + "'", byte29 == (byte) -2);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) '4', (int) (short) 97);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) -2, 8);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.add(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int8 = fraction7.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean13 = fraction11.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        int int20 = fraction19.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction11.add(fraction19);
        java.lang.String str22 = fraction19.toProperString();
        boolean boolean23 = fraction7.equals((java.lang.Object) fraction19);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction5.multiplyBy(fraction19);
        long long25 = fraction19.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.negate();
        long long12 = fraction11.longValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.negate();
        int int14 = fraction13.getProperWhole();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(0, (int) (short) 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getDenominator();
        boolean boolean12 = fraction4.equals((java.lang.Object) int11);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.abs();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str16 = fraction15.toString();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean21 = fraction19.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int24 = fraction23.getNumerator();
        int int25 = fraction23.getDenominator();
        short short26 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction23.negate();
        int int28 = fraction27.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction19.add(fraction27);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction15.divideBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction13.multiplyBy(fraction15);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction4.multiplyBy(fraction13);
        boolean boolean33 = fraction2.equals((java.lang.Object) fraction4);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction2.reduce();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1/2" + "'", str16.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + short26 + "' != '" + (short) 0 + "'", short26 == (short) 0);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(fraction34);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (byte) -1);
        java.lang.String str3 = fraction2.toProperString();
        int int4 = fraction2.getProperNumerator();
        int int5 = fraction2.getProperWhole();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-35" + "'", str3.equals("-35"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-35) + "'", int5 == (-35));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((-2), (int) (byte) 100);
        short short3 = fraction2.shortValue();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.abs();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction5.invert();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.reduce();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction2.multiplyBy(fraction7);
        byte byte10 = fraction7.byteValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 1 + "'", byte10 == (byte) 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (short) 97);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean9 = fraction7.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int12 = fraction11.getNumerator();
        int int13 = fraction11.getDenominator();
        short short14 = fraction11.shortValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.negate();
        int int16 = fraction7.compareTo(fraction11);
        int int17 = fraction7.getProperWhole();
        float float18 = fraction7.floatValue();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction20 = fraction7.add(fraction19);
        int int21 = fraction19.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction19.abs();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction22.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction27.negate();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction28.negate();
        boolean boolean30 = fraction22.equals((java.lang.Object) fraction29);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction4.divideBy(fraction22);
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getFraction(100, (int) ' ', (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction36 = fraction4.add(fraction35);
        org.apache.commons.lang3.math.Fraction fraction37 = fraction0.add(fraction4);
        org.apache.commons.lang3.math.Fraction fraction40 = org.apache.commons.lang3.math.Fraction.getFraction(97, 10);
        org.apache.commons.lang3.math.Fraction fraction44 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction45 = fraction44.negate();
        org.apache.commons.lang3.math.Fraction fraction46 = fraction44.negate();
        org.apache.commons.lang3.math.Fraction fraction49 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int50 = fraction49.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction51 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str52 = fraction51.toString();
        double double53 = fraction51.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction54 = fraction49.add(fraction51);
        org.apache.commons.lang3.math.Fraction fraction55 = fraction46.add(fraction54);
        int int56 = fraction46.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction59 = org.apache.commons.lang3.math.Fraction.getFraction((int) '4', (int) (short) 97);
        org.apache.commons.lang3.math.Fraction fraction62 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) -2, 8);
        org.apache.commons.lang3.math.Fraction fraction63 = fraction59.add(fraction62);
        org.apache.commons.lang3.math.Fraction fraction64 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int65 = fraction64.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction68 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean70 = fraction68.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction72 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int73 = fraction72.getNumerator();
        int int74 = fraction72.getDenominator();
        short short75 = fraction72.shortValue();
        org.apache.commons.lang3.math.Fraction fraction76 = fraction72.negate();
        int int77 = fraction76.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction78 = fraction68.add(fraction76);
        java.lang.String str79 = fraction76.toProperString();
        boolean boolean80 = fraction64.equals((java.lang.Object) fraction76);
        org.apache.commons.lang3.math.Fraction fraction81 = fraction62.multiplyBy(fraction76);
        org.apache.commons.lang3.math.Fraction fraction82 = fraction46.multiplyBy(fraction62);
        org.apache.commons.lang3.math.Fraction fraction83 = fraction62.abs();
        org.apache.commons.lang3.math.Fraction fraction84 = fraction40.subtract(fraction83);
        org.apache.commons.lang3.math.Fraction fraction85 = fraction0.subtract(fraction40);
        int int86 = fraction40.getNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.625f + "'", float18 == 1.625f);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1/2" + "'", str52.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.5d + "'", double53 == 0.5d);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-97) + "'", int56 == (-97));
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertNotNull(fraction62);
        org.junit.Assert.assertNotNull(fraction63);
        org.junit.Assert.assertNotNull(fraction64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(fraction68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(fraction72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + short75 + "' != '" + (short) 0 + "'", short75 == (short) 0);
        org.junit.Assert.assertNotNull(fraction76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(fraction78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "0" + "'", str79.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(fraction81);
        org.junit.Assert.assertNotNull(fraction82);
        org.junit.Assert.assertNotNull(fraction83);
        org.junit.Assert.assertNotNull(fraction84);
        org.junit.Assert.assertNotNull(fraction85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 97 + "'", int86 == 97);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        int int2 = fraction0.getProperWhole();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.add(fraction14);
        int int16 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction2.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertNotNull(fraction17);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.abs();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.reduce();
        short short10 = fraction6.shortValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int3 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction2.add(fraction4);
        long long8 = fraction7.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int3 = fraction2.getProperNumerator();
        try {
            org.apache.commons.lang3.math.Fraction fraction5 = fraction2.pow((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mulPos");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (byte) -1);
        java.lang.String str3 = fraction2.toProperString();
        float float4 = fraction2.floatValue();
        java.lang.Class<?> wildcardClass5 = fraction2.getClass();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-35" + "'", str3.equals("-35"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-35.0f) + "'", float4 == (-35.0f));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction10.multiplyBy(fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction26 = fraction25.negate();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int28 = fraction27.getProperWhole();
        double double29 = fraction27.doubleValue();
        double double30 = fraction27.doubleValue();
        int int31 = fraction27.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction26.multiplyBy(fraction27);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction21.multiplyBy(fraction32);
        org.apache.commons.lang3.math.Fraction fraction34 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction35 = fraction33.divideBy(fraction34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.75d + "'", double29 == 0.75d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.75d + "'", double30 == 0.75d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean16 = fraction14.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int19 = fraction18.getNumerator();
        int int20 = fraction18.getDenominator();
        short short21 = fraction18.shortValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.negate();
        int int23 = fraction22.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction14.add(fraction22);
        java.lang.String str25 = fraction22.toProperString();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int28 = fraction27.getNumerator();
        int int29 = fraction27.getDenominator();
        short short30 = fraction27.shortValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction27.negate();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction22.multiplyBy(fraction27);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction11.add(fraction27);
        try {
            org.apache.commons.lang3.math.Fraction fraction35 = fraction27.pow((int) (short) -2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 0 + "'", short21 == (short) 0);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 0 + "'", short30 == (short) 0);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction10.multiplyBy(fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction21.abs();
        float float23 = fraction21.floatValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction0.multiplyBy(fraction3);
        java.lang.String str9 = fraction3.toString();
        long long10 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean18 = fraction16.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int21 = fraction20.getNumerator();
        int int22 = fraction20.getDenominator();
        short short23 = fraction20.shortValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction20.negate();
        int int25 = fraction16.compareTo(fraction20);
        int int26 = fraction16.getProperWhole();
        float float27 = fraction16.floatValue();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction29 = fraction16.add(fraction28);
        int int30 = fraction28.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction28.abs();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction31.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction37 = fraction36.negate();
        org.apache.commons.lang3.math.Fraction fraction38 = fraction37.negate();
        boolean boolean39 = fraction31.equals((java.lang.Object) fraction38);
        org.apache.commons.lang3.math.Fraction fraction40 = fraction13.divideBy(fraction31);
        int int41 = fraction31.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction3.add(fraction31);
        byte byte43 = fraction42.byteValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0/1" + "'", str9.equals("0/1"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.625f + "'", float27 == 1.625f);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertTrue("'" + byte43 + "' != '" + (byte) 1 + "'", byte43 == (byte) 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        float float5 = fraction1.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, (int) (byte) -2);
        int int9 = fraction1.compareTo(fraction8);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        java.lang.String str6 = fraction3.toProperString();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.reduce();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1/2" + "'", str6.equals("-1/2"));
        org.junit.Assert.assertNotNull(fraction7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction5.multiplyBy(fraction8);
        java.lang.Class<?> wildcardClass14 = fraction8.getClass();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction3.subtract(fraction8);
        int int16 = fraction15.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2L) + "'", long4 == (-2L));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        int int14 = fraction10.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction("1 5/8");
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.invert();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str12 = fraction11.toProperString();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int15 = fraction14.getNumerator();
        int int16 = fraction14.getDenominator();
        byte byte17 = fraction14.byteValue();
        int int18 = fraction14.getProperWhole();
        int int19 = fraction11.compareTo(fraction14);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction11.negate();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int22 = fraction21.getNumerator();
        float float23 = fraction21.floatValue();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction21.subtract(fraction27);
        int int29 = fraction21.getNumerator();
        int int30 = fraction11.compareTo(fraction21);
        float float31 = fraction11.floatValue();
        int int32 = fraction8.compareTo(fraction11);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1 5/8" + "'", str12.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 0 + "'", byte17 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.625f + "'", float31 == 1.625f);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-97), (int) (short) -2, (int) (short) -2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.negate();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int10 = fraction9.getNumerator();
        int int11 = fraction9.getDenominator();
        byte byte12 = fraction9.byteValue();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int14 = fraction13.getNumerator();
        float float15 = fraction13.floatValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction9.divideBy(fraction13);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction9.negate();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.abs();
        java.lang.String str19 = fraction9.toString();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction7.multiplyBy(fraction9);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction2.add(fraction7);
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean26 = fraction24.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int29 = fraction28.getNumerator();
        int int30 = fraction28.getDenominator();
        short short31 = fraction28.shortValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction28.negate();
        int int33 = fraction24.compareTo(fraction28);
        int int34 = fraction24.getProperWhole();
        float float35 = fraction24.floatValue();
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int37 = fraction36.getProperWhole();
        double double38 = fraction36.doubleValue();
        double double39 = fraction36.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction24.subtract(fraction36);
        org.apache.commons.lang3.math.Fraction fraction41 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction42 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean43 = fraction41.equals((java.lang.Object) fraction42);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction42.negate();
        long long45 = fraction44.longValue();
        org.apache.commons.lang3.math.Fraction fraction46 = fraction40.subtract(fraction44);
        org.apache.commons.lang3.math.Fraction fraction49 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str50 = fraction49.toProperString();
        org.apache.commons.lang3.math.Fraction fraction52 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int53 = fraction52.getNumerator();
        int int54 = fraction52.getDenominator();
        byte byte55 = fraction52.byteValue();
        int int56 = fraction52.getProperWhole();
        int int57 = fraction49.compareTo(fraction52);
        org.apache.commons.lang3.math.Fraction fraction58 = fraction49.negate();
        org.apache.commons.lang3.math.Fraction fraction59 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int60 = fraction59.getNumerator();
        float float61 = fraction59.floatValue();
        org.apache.commons.lang3.math.Fraction fraction65 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction66 = fraction59.subtract(fraction65);
        int int67 = fraction59.getNumerator();
        int int68 = fraction49.compareTo(fraction59);
        org.apache.commons.lang3.math.Fraction fraction69 = fraction59.reduce();
        int int70 = fraction44.compareTo(fraction69);
        org.apache.commons.lang3.math.Fraction fraction72 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction74 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int75 = fraction74.getNumerator();
        int int76 = fraction74.getDenominator();
        byte byte77 = fraction74.byteValue();
        org.apache.commons.lang3.math.Fraction fraction78 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int79 = fraction78.getNumerator();
        float float80 = fraction78.floatValue();
        org.apache.commons.lang3.math.Fraction fraction81 = fraction74.divideBy(fraction78);
        org.apache.commons.lang3.math.Fraction fraction82 = fraction74.negate();
        org.apache.commons.lang3.math.Fraction fraction83 = fraction72.multiplyBy(fraction74);
        org.apache.commons.lang3.math.Fraction fraction85 = fraction72.pow((int) (short) 97);
        float float86 = fraction72.floatValue();
        org.apache.commons.lang3.math.Fraction fraction87 = fraction44.add(fraction72);
        int int88 = fraction2.compareTo(fraction87);
        int int89 = fraction2.getDenominator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0/1" + "'", str19.equals("0/1"));
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + short31 + "' != '" + (short) 0 + "'", short31 == (short) 0);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 1.625f + "'", float35 == 1.625f);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.75d + "'", double38 == 0.75d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.75d + "'", double39 == 0.75d);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1 5/8" + "'", str50.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + byte55 + "' != '" + (byte) 0 + "'", byte55 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(fraction58);
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + float61 + "' != '" + 0.5f + "'", float61 == 0.5f);
        org.junit.Assert.assertNotNull(fraction65);
        org.junit.Assert.assertNotNull(fraction66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(fraction69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNotNull(fraction72);
        org.junit.Assert.assertNotNull(fraction74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + byte77 + "' != '" + (byte) 0 + "'", byte77 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertTrue("'" + float80 + "' != '" + 0.5f + "'", float80 == 0.5f);
        org.junit.Assert.assertNotNull(fraction81);
        org.junit.Assert.assertNotNull(fraction82);
        org.junit.Assert.assertNotNull(fraction83);
        org.junit.Assert.assertNotNull(fraction85);
        org.junit.Assert.assertTrue("'" + float86 + "' != '" + (-1.0f) + "'", float86 == (-1.0f));
        org.junit.Assert.assertNotNull(fraction87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.abs();
        int int13 = fraction12.getProperWhole();
        float float14 = fraction12.floatValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.625f + "'", float14 == 1.625f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(3, 0, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction4 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -2, 0, (int) (byte) -2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((-13), (-2));
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.invert();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        java.lang.String str6 = fraction3.toProperString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-2" + "'", str6.equals("-2"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("-35");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, 2);
        java.lang.String str7 = fraction6.toProperString();
        double double8 = fraction6.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction2.add(fraction6);
        double double10 = fraction2.doubleValue();
        int int11 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((-2), (int) (byte) 100);
        short short15 = fraction14.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean21 = fraction19.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int24 = fraction23.getNumerator();
        int int25 = fraction23.getDenominator();
        short short26 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction23.negate();
        int int28 = fraction27.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction19.add(fraction27);
        java.lang.String str30 = fraction27.toProperString();
        org.apache.commons.lang3.math.Fraction fraction32 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int33 = fraction32.getNumerator();
        int int34 = fraction32.getDenominator();
        short short35 = fraction32.shortValue();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction32.negate();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction27.multiplyBy(fraction32);
        org.apache.commons.lang3.math.Fraction fraction38 = fraction37.negate();
        org.apache.commons.lang3.math.Fraction fraction39 = fraction14.add(fraction37);
        org.apache.commons.lang3.math.Fraction fraction40 = fraction37.abs();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction37.pow((int) 'a');
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean47 = fraction45.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction49 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int50 = fraction49.getNumerator();
        int int51 = fraction49.getDenominator();
        short short52 = fraction49.shortValue();
        org.apache.commons.lang3.math.Fraction fraction53 = fraction49.negate();
        int int54 = fraction45.compareTo(fraction49);
        int int55 = fraction45.getProperWhole();
        float float56 = fraction45.floatValue();
        java.lang.Class<?> wildcardClass57 = fraction45.getClass();
        java.lang.String str58 = fraction45.toString();
        org.apache.commons.lang3.math.Fraction fraction59 = fraction37.multiplyBy(fraction45);
        org.apache.commons.lang3.math.Fraction fraction60 = fraction2.multiplyBy(fraction45);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1/2" + "'", str7.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.625d + "'", double10 == 1.625d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + short26 + "' != '" + (short) 0 + "'", short26 == (short) 0);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + short35 + "' != '" + (short) 0 + "'", short35 == (short) 0);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + short52 + "' != '" + (short) 0 + "'", short52 == (short) 0);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 1.625f + "'", float56 == 1.625f);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "13/8" + "'", str58.equals("13/8"));
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertNotNull(fraction60);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.reduce();
        java.lang.String str7 = fraction6.toString();
        float float8 = fraction6.floatValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0/1" + "'", str7.equals("0/1"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int15 = fraction14.getProperWhole();
        double double16 = fraction14.doubleValue();
        double double17 = fraction14.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction2.subtract(fraction14);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean21 = fraction19.equals((java.lang.Object) fraction20);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.negate();
        long long23 = fraction22.longValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction18.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str28 = fraction27.toProperString();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int31 = fraction30.getNumerator();
        int int32 = fraction30.getDenominator();
        byte byte33 = fraction30.byteValue();
        int int34 = fraction30.getProperWhole();
        int int35 = fraction27.compareTo(fraction30);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction27.negate();
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int38 = fraction37.getNumerator();
        float float39 = fraction37.floatValue();
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction37.subtract(fraction43);
        int int45 = fraction37.getNumerator();
        int int46 = fraction27.compareTo(fraction37);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction37.reduce();
        int int48 = fraction22.compareTo(fraction47);
        org.apache.commons.lang3.math.Fraction fraction49 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int50 = fraction49.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction51 = fraction22.multiplyBy(fraction49);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.75d + "'", double16 == 0.75d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.75d + "'", double17 == 0.75d);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1 5/8" + "'", str28.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + byte33 + "' != '" + (byte) 0 + "'", byte33 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.5f + "'", float39 == 0.5f);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(fraction51);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 1);
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.invert();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((-3), (int) (byte) 2);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction0.multiplyBy(fraction3);
        float float9 = fraction3.floatValue();
        byte byte10 = fraction3.byteValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        byte byte5 = fraction4.byteValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.invert();
        java.lang.String str7 = fraction4.toProperString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10/100" + "'", str7.equals("10/100"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.Class<?> wildcardClass13 = fraction12.getClass();
        byte byte14 = fraction12.byteValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction12.reduce();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction16.divideBy(fraction19);
        java.lang.String str21 = fraction16.toProperString();
        int int22 = fraction16.getProperNumerator();
        boolean boolean23 = fraction15.equals((java.lang.Object) fraction16);
        short short24 = fraction16.shortValue();
        float float25 = fraction16.floatValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 1 + "'", byte14 == (byte) 1);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1/5" + "'", str21.equals("1/5"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + short24 + "' != '" + (short) 0 + "'", short24 == (short) 0);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.2f + "'", float25 == 0.2f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str4 = fraction3.toProperString();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        byte byte9 = fraction6.byteValue();
        int int10 = fraction6.getProperWhole();
        int int11 = fraction3.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int14 = fraction13.getNumerator();
        float float15 = fraction13.floatValue();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction13.subtract(fraction19);
        int int21 = fraction13.getNumerator();
        int int22 = fraction3.compareTo(fraction13);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction0.multiplyBy(fraction13);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction29 = fraction27.divideBy(fraction28);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction28.abs();
        double double31 = fraction28.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction0.subtract(fraction28);
        int int33 = fraction28.getProperNumerator();
        int int34 = fraction28.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 5/8" + "'", str4.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.4d + "'", double31 == 0.4d);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5 + "'", int34 == 5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(100, (int) (short) 0, (int) '#');
        java.lang.Class<?> wildcardClass4 = fraction3.getClass();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1 5/8");
        long long2 = fraction1.longValue();
        int int3 = fraction1.getProperWhole();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str4 = fraction3.toProperString();
        int int5 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction6.reduce();
        int int8 = fraction7.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.abs();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.add(fraction7);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str14 = fraction13.toProperString();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int17 = fraction16.getNumerator();
        int int18 = fraction16.getDenominator();
        byte byte19 = fraction16.byteValue();
        int int20 = fraction16.getProperWhole();
        int int21 = fraction13.compareTo(fraction16);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction13.negate();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int24 = fraction23.getNumerator();
        float float25 = fraction23.floatValue();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction30 = fraction23.subtract(fraction29);
        int int31 = fraction23.getNumerator();
        int int32 = fraction13.compareTo(fraction23);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction10.subtract(fraction33);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 45/52" + "'", str4.equals("1 45/52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1 5/8" + "'", str14.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 0 + "'", byte19 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100);
        int int2 = fraction1.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.multiplyBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) ' ', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction13);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.abs();
        int int17 = fraction16.getProperWhole();
        boolean boolean18 = fraction4.equals((java.lang.Object) int17);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.invert();
        long long3 = fraction0.longValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        int int3 = fraction2.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        try {
            org.apache.commons.lang3.math.Fraction fraction9 = fraction1.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int11 = fraction10.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str13 = fraction12.toString();
        double double14 = fraction12.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.add(fraction12);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction1.divideBy(fraction10);
        int int17 = fraction16.getProperWhole();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1/2" + "'", str13.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5d + "'", double14 == 0.5d);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.add(fraction14);
        int int16 = fraction14.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction17.abs();
        int int21 = fraction20.intValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int1 = fraction0.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean6 = fraction4.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        int int13 = fraction12.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction12);
        java.lang.String str15 = fraction12.toProperString();
        boolean boolean16 = fraction0.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, (int) '4');
        int int20 = fraction0.compareTo(fraction19);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean25 = fraction23.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int28 = fraction27.getNumerator();
        int int29 = fraction27.getDenominator();
        short short30 = fraction27.shortValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction27.negate();
        int int32 = fraction23.compareTo(fraction27);
        long long33 = fraction23.longValue();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction0.subtract(fraction34);
        java.lang.String str36 = fraction35.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 0 + "'", short30 == (short) 0);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-49/40" + "'", str36.equals("-49/40"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((-200), (-97));
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        java.lang.String str5 = fraction0.toProperString();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction("3/5");
        org.apache.commons.lang3.math.Fraction fraction8 = fraction0.add(fraction7);
        int int9 = fraction0.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/5" + "'", str5.equals("1/5"));
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(10, (int) (byte) 1);
        int int3 = fraction2.intValue();
        java.lang.Class<?> wildcardClass4 = fraction2.getClass();
        int int5 = fraction2.intValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int8 = fraction7.getNumerator();
        int int9 = fraction7.getDenominator();
        short short10 = fraction7.shortValue();
        boolean boolean12 = fraction7.equals((java.lang.Object) 10);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction2.multiplyBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int15 = fraction14.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction14.negate();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.subtract(fraction16);
        int int18 = fraction16.getDenominator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(2, 52);
        int int3 = fraction2.getProperWhole();
        java.lang.Class<?> wildcardClass4 = fraction2.getClass();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 2);
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean4 = fraction2.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        int int6 = fraction1.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str10 = fraction9.toProperString();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, 2);
        java.lang.String str14 = fraction13.toProperString();
        double double15 = fraction13.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction9.add(fraction13);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction1.add(fraction9);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction9.invert();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean23 = fraction21.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int26 = fraction25.getNumerator();
        int int27 = fraction25.getDenominator();
        short short28 = fraction25.shortValue();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction25.negate();
        int int30 = fraction21.compareTo(fraction25);
        int int31 = fraction21.getProperWhole();
        float float32 = fraction21.floatValue();
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int34 = fraction33.getProperWhole();
        double double35 = fraction33.doubleValue();
        double double36 = fraction33.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction21.subtract(fraction33);
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean40 = fraction38.equals((java.lang.Object) fraction39);
        org.apache.commons.lang3.math.Fraction fraction41 = fraction39.negate();
        long long42 = fraction41.longValue();
        org.apache.commons.lang3.math.Fraction fraction43 = fraction37.subtract(fraction41);
        org.apache.commons.lang3.math.Fraction fraction46 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str47 = fraction46.toProperString();
        org.apache.commons.lang3.math.Fraction fraction49 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int50 = fraction49.getNumerator();
        int int51 = fraction49.getDenominator();
        byte byte52 = fraction49.byteValue();
        int int53 = fraction49.getProperWhole();
        int int54 = fraction46.compareTo(fraction49);
        org.apache.commons.lang3.math.Fraction fraction55 = fraction46.negate();
        org.apache.commons.lang3.math.Fraction fraction56 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int57 = fraction56.getNumerator();
        float float58 = fraction56.floatValue();
        org.apache.commons.lang3.math.Fraction fraction62 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction63 = fraction56.subtract(fraction62);
        int int64 = fraction56.getNumerator();
        int int65 = fraction46.compareTo(fraction56);
        org.apache.commons.lang3.math.Fraction fraction66 = fraction56.reduce();
        int int67 = fraction41.compareTo(fraction66);
        int int68 = fraction18.compareTo(fraction41);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 5/8" + "'", str10.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1/2" + "'", str14.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + short28 + "' != '" + (short) 0 + "'", short28 == (short) 0);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.625f + "'", float32 == 1.625f);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.75d + "'", double35 == 0.75d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.75d + "'", double36 == 0.75d);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1 5/8" + "'", str47.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + byte52 + "' != '" + (byte) 0 + "'", byte52 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertNotNull(fraction56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.5f + "'", float58 == 0.5f);
        org.junit.Assert.assertNotNull(fraction62);
        org.junit.Assert.assertNotNull(fraction63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(fraction66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        int int2 = fraction1.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.abs();
        int int4 = fraction3.getNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        float float11 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str15 = fraction14.toProperString();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int18 = fraction17.getNumerator();
        int int19 = fraction17.getDenominator();
        short short20 = fraction17.shortValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.negate();
        int int22 = fraction21.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction14.add(fraction21);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction2.multiplyBy(fraction21);
        long long25 = fraction24.longValue();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction24.reduce();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.625f + "'", float11 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1 5/8" + "'", str15.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + short20 + "' != '" + (short) 0 + "'", short20 == (short) 0);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(fraction26);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean7 = fraction5.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int10 = fraction9.getNumerator();
        int int11 = fraction9.getDenominator();
        short short12 = fraction9.shortValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.negate();
        int int14 = fraction5.compareTo(fraction9);
        int int15 = fraction5.getProperWhole();
        float float16 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction5.add(fraction17);
        int int19 = fraction17.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction17.abs();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction25.negate();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction26.negate();
        boolean boolean28 = fraction20.equals((java.lang.Object) fraction27);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction2.divideBy(fraction20);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.getFraction(100, (int) ' ', (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction34 = fraction2.add(fraction33);
        float float35 = fraction34.floatValue();
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int38 = fraction37.getNumerator();
        int int39 = fraction37.getDenominator();
        short short40 = fraction37.shortValue();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction37.negate();
        int int42 = fraction41.getNumerator();
        float float43 = fraction41.floatValue();
        org.apache.commons.lang3.math.Fraction fraction45 = fraction41.pow((int) 'a');
        org.apache.commons.lang3.math.Fraction fraction46 = fraction34.multiplyBy(fraction45);
        int int47 = fraction45.getDenominator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.625f + "'", float16 == 1.625f);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 101.02857f + "'", float35 == 101.02857f);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + short40 + "' != '" + (short) 0 + "'", short40 == (short) 0);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) '4', (int) (byte) 100, (int) 'a');
        java.lang.String str4 = fraction3.toProperString();
        java.lang.String str5 = fraction3.toString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "53 3/97" + "'", str4.equals("53 3/97"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "5144/97" + "'", str5.equals("5144/97"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str14 = fraction13.toProperString();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int17 = fraction16.getNumerator();
        int int18 = fraction16.getDenominator();
        byte byte19 = fraction16.byteValue();
        int int20 = fraction16.getProperWhole();
        int int21 = fraction13.compareTo(fraction16);
        float float22 = fraction13.floatValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction5.divideBy(fraction13);
        long long24 = fraction5.longValue();
        java.lang.Class<?> wildcardClass25 = fraction5.getClass();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1 5/8" + "'", str14.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 0 + "'", byte19 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.625f + "'", float22 == 1.625f);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 1.625f);
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.invert();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ZERO;
        int int1 = fraction0.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100);
        int int2 = fraction1.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.multiplyBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) ' ', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction13);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction4.pow((int) (short) 100);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction16);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        long long1 = fraction0.longValue();
        int int2 = fraction0.intValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction5.multiplyBy(fraction8);
        java.lang.Class<?> wildcardClass14 = fraction8.getClass();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction3.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean20 = fraction18.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int23 = fraction22.getNumerator();
        int int24 = fraction22.getDenominator();
        short short25 = fraction22.shortValue();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction22.negate();
        int int27 = fraction18.compareTo(fraction22);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction8.divideBy(fraction18);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2L) + "'", long4 == (-2L));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(fraction28);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int13 = fraction12.getNumerator();
        float float14 = fraction12.floatValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction12.subtract(fraction18);
        int int20 = fraction12.getNumerator();
        int int21 = fraction2.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction12.invert();
        int int23 = fraction12.getDenominator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(8, (-1));
        int int3 = fraction2.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        float float5 = fraction1.floatValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.pow((int) (byte) 0);
        java.lang.String str8 = fraction1.toProperString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("3/4");
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction7 = fraction5.divideBy(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.abs();
        int int9 = fraction1.compareTo(fraction6);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str4 = fraction3.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.invert();
        float float6 = fraction3.floatValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 45/52" + "'", str4.equals("1 45/52"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.8653846f + "'", float6 == 1.8653846f);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction2.negate();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        short short8 = fraction5.shortValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.negate();
        int int10 = fraction9.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.add(fraction9);
        int int12 = fraction11.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int15 = fraction14.getNumerator();
        int int16 = fraction14.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.divideBy(fraction21);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction14.divideBy(fraction21);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction24.pow(0);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction24.reduce();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction11.multiplyBy(fraction24);
        int int29 = fraction28.getProperWhole();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("12/2");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1 45/52");
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.negate();
        int int6 = fraction1.compareTo(fraction5);
        try {
            org.apache.commons.lang3.math.Fraction fraction8 = fraction1.pow(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction(97.0d);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-10), (int) (byte) 100, (int) (short) 2);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction1.abs();
        java.lang.String str12 = fraction1.toProperString();
        org.apache.commons.lang3.math.Fraction fraction13 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction14 = fraction1.subtract(fraction13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        float float2 = fraction0.floatValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction0.subtract(fraction6);
        short short8 = fraction6.shortValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -2 + "'", short8 == (short) -2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int13 = fraction12.getNumerator();
        float float14 = fraction12.floatValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction12.subtract(fraction18);
        int int20 = fraction12.getNumerator();
        int int21 = fraction2.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction12.invert();
        int int23 = fraction22.getNumerator();
        int int24 = fraction22.getProperWhole();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 1, (int) 'a', 2);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.invert();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str14 = fraction13.toProperString();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int17 = fraction16.getNumerator();
        int int18 = fraction16.getDenominator();
        byte byte19 = fraction16.byteValue();
        int int20 = fraction16.getProperWhole();
        int int21 = fraction13.compareTo(fraction16);
        float float22 = fraction13.floatValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction5.divideBy(fraction13);
        byte byte24 = fraction13.byteValue();
        int int25 = fraction13.intValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1 5/8" + "'", str14.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 0 + "'", byte19 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.625f + "'", float22 == 1.625f);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + byte24 + "' != '" + (byte) 1 + "'", byte24 == (byte) 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.divideBy(fraction3);
        java.lang.String str5 = fraction0.toProperString();
        int int6 = fraction0.getNumerator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/5" + "'", str5.equals("1/5"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        byte byte9 = fraction6.byteValue();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int11 = fraction10.getNumerator();
        float float12 = fraction10.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction6.divideBy(fraction10);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction6.negate();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction6.abs();
        java.lang.String str16 = fraction6.toString();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction4.multiplyBy(fraction6);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 10, 2);
        boolean boolean22 = fraction6.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0/1" + "'", str16.equals("0/1"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-35), 4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-5), (-5), (int) (byte) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The numerator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int11 = fraction10.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str13 = fraction12.toString();
        double double14 = fraction12.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction10.add(fraction12);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction1.divideBy(fraction10);
        java.lang.Class<?> wildcardClass17 = fraction10.getClass();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction10.abs();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1/2" + "'", str13.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5d + "'", double14 == 0.5d);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(fraction18);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 4);
        int int3 = fraction2.getDenominator();
        int int4 = fraction2.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) -2, 5);
        java.lang.String str3 = fraction2.toProperString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-2/5" + "'", str3.equals("-2/5"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '#', 5);
        java.lang.Class<?> wildcardClass3 = fraction2.getClass();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.abs();
        float float11 = fraction8.floatValue();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str16 = fraction15.toProperString();
        int int17 = fraction8.compareTo(fraction15);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction2.add(fraction8);
        java.lang.String str19 = fraction8.toString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.4f + "'", float11 == 0.4f);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1 45/52" + "'", str16.equals("1 45/52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2/5" + "'", str19.equals("2/5"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction5.multiplyBy(fraction8);
        java.lang.Class<?> wildcardClass14 = fraction8.getClass();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction3.subtract(fraction8);
        java.lang.String str16 = fraction15.toString();
        int int17 = fraction15.getDenominator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2L) + "'", long4 == (-2L));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-2/1" + "'", str16.equals("-2/1"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        int int2 = fraction0.getProperWhole();
        java.lang.Class<?> wildcardClass3 = fraction0.getClass();
        java.lang.String str4 = fraction0.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction0.negate();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4/5" + "'", str4.equals("4/5"));
        org.junit.Assert.assertNotNull(fraction5);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.pow((int) (short) -2);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int9 = fraction8.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int12 = fraction11.getNumerator();
        int int13 = fraction11.getDenominator();
        short short14 = fraction11.shortValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.negate();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction8.multiplyBy(fraction11);
        java.lang.String str17 = fraction11.toString();
        long long18 = fraction11.longValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction7.subtract(fraction11);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean24 = fraction22.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int27 = fraction26.getNumerator();
        int int28 = fraction26.getDenominator();
        short short29 = fraction26.shortValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction26.negate();
        int int31 = fraction30.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction22.add(fraction30);
        java.lang.String str33 = fraction30.toProperString();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int36 = fraction35.getNumerator();
        int int37 = fraction35.getDenominator();
        short short38 = fraction35.shortValue();
        org.apache.commons.lang3.math.Fraction fraction39 = fraction35.negate();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction30.multiplyBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction41 = fraction35.reduce();
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction46 = fraction45.negate();
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int48 = fraction47.getProperWhole();
        double double49 = fraction47.doubleValue();
        double double50 = fraction47.doubleValue();
        int int51 = fraction47.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction52 = fraction46.multiplyBy(fraction47);
        org.apache.commons.lang3.math.Fraction fraction53 = fraction41.multiplyBy(fraction52);
        org.apache.commons.lang3.math.Fraction fraction54 = fraction11.subtract(fraction41);
        int int55 = fraction11.getProperWhole();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0/1" + "'", str17.equals("0/1"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + short29 + "' != '" + (short) 0 + "'", short29 == (short) 0);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "0" + "'", str33.equals("0"));
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + short38 + "' != '" + (short) 0 + "'", short38 == (short) 0);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.75d + "'", double49 == 0.75d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.75d + "'", double50 == 0.75d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 3 + "'", int51 == 3);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction1.abs();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction11.pow(0);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction11.reduce();
        int int15 = fraction11.getDenominator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int3 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction2.add(fraction4);
        int int8 = fraction7.getProperWhole();
        int int9 = fraction7.intValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        float float13 = fraction10.floatValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str3 = fraction2.toString();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean8 = fraction6.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int11 = fraction10.getNumerator();
        int int12 = fraction10.getDenominator();
        short short13 = fraction10.shortValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction10.negate();
        int int15 = fraction14.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction6.add(fraction14);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction2.divideBy(fraction6);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction0.multiplyBy(fraction2);
        int int19 = fraction2.getProperWhole();
        java.lang.String str20 = fraction2.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1/2" + "'", str3.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1/2" + "'", str20.equals("1/2"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) -1, (int) (short) 10);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.invert();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long11 = fraction10.longValue();
        int int12 = fraction10.intValue();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean17 = fraction15.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int20 = fraction19.getNumerator();
        int int21 = fraction19.getDenominator();
        short short22 = fraction19.shortValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction19.negate();
        int int24 = fraction15.compareTo(fraction19);
        int int25 = fraction15.getProperWhole();
        float float26 = fraction15.floatValue();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction28 = fraction15.add(fraction27);
        int int29 = fraction27.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction27.abs();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction30.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction10.subtract(fraction32);
        short short34 = fraction10.shortValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction6.subtract(fraction10);
        int int36 = fraction6.getProperNumerator();
        double double37 = fraction6.doubleValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2L) + "'", long11 == (-2L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-2) + "'", int12 == (-2));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + short22 + "' != '" + (short) 0 + "'", short22 == (short) 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.625f + "'", float26 == 1.625f);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + short34 + "' != '" + (short) -2 + "'", short34 == (short) -2);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-0.2d) + "'", double37 == (-0.2d));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str4 = fraction3.toProperString();
        int int5 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction3.invert();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 45/52" + "'", str4.equals("1 45/52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(fraction6);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        int int14 = fraction10.intValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int1 = fraction0.getProperWhole();
        int int2 = fraction0.intValue();
        java.lang.String str3 = fraction0.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2/5" + "'", str3.equals("2/5"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100);
        int int2 = fraction1.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        byte byte7 = fraction4.byteValue();
        int int8 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction4.negate();
        float float10 = fraction4.floatValue();
        boolean boolean11 = fraction1.equals((java.lang.Object) fraction4);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        byte byte5 = fraction4.byteValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str9 = fraction8.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int12 = fraction11.getNumerator();
        int int13 = fraction11.getDenominator();
        byte byte14 = fraction11.byteValue();
        int int15 = fraction11.getProperWhole();
        int int16 = fraction8.compareTo(fraction11);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int19 = fraction18.getNumerator();
        float float20 = fraction18.floatValue();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction18.subtract(fraction24);
        int int26 = fraction18.getNumerator();
        int int27 = fraction8.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction4.multiplyBy(fraction8);
        float float29 = fraction8.floatValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1 5/8" + "'", str9.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.625f + "'", float29 == 1.625f);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        short short4 = fraction1.shortValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.negate();
        long long6 = fraction1.longValue();
        try {
            org.apache.commons.lang3.math.Fraction fraction8 = fraction1.pow((-200));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(100, (int) (short) 0, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (byte) -1);
        byte byte7 = fraction6.byteValue();
        int int8 = fraction3.compareTo(fraction6);
        java.lang.String str9 = fraction6.toString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -35 + "'", byte7 == (byte) -35);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-35/1" + "'", str9.equals("-35/1"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.negate();
        double double7 = fraction6.doubleValue();
        java.lang.Class<?> wildcardClass8 = fraction6.getClass();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.negate();
        int int10 = fraction9.intValue();
        int int11 = fraction9.getProperWhole();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        float float2 = fraction0.floatValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction0.subtract(fraction6);
        int int8 = fraction6.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.negate();
        int int12 = fraction2.getDenominator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 6, (int) (byte) 10);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        int int3 = fraction2.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        byte byte9 = fraction6.byteValue();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int11 = fraction10.getNumerator();
        float float12 = fraction10.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction6.divideBy(fraction10);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction6.negate();
        try {
            org.apache.commons.lang3.math.Fraction fraction15 = fraction4.divideBy(fraction6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The fraction to divide by must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        double double1 = fraction0.doubleValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6d + "'", double1 == 0.6d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (short) -10);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        byte byte7 = fraction4.byteValue();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean12 = fraction10.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int15 = fraction14.getNumerator();
        int int16 = fraction14.getDenominator();
        short short17 = fraction14.shortValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction14.negate();
        int int19 = fraction10.compareTo(fraction14);
        int int20 = fraction10.getProperWhole();
        float float21 = fraction10.floatValue();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction23 = fraction10.add(fraction22);
        int int24 = fraction22.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction22.abs();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.pow((int) (byte) -1);
        int int28 = fraction25.getProperWhole();
        double double29 = fraction25.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction4.divideBy(fraction25);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction25.pow((int) (short) 97);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 0 + "'", short17 == (short) 0);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.625f + "'", float21 == 1.625f);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction32);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 10, 2);
        int int4 = fraction3.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction("1 45/52");
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction12.negate();
        int int14 = fraction9.compareTo(fraction13);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction7.divideBy(fraction13);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction3.subtract(fraction15);
        java.lang.Class<?> wildcardClass17 = fraction16.getClass();
        int int18 = fraction16.getNumerator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 14 + "'", int18 == 14);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean7 = fraction5.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int10 = fraction9.getNumerator();
        int int11 = fraction9.getDenominator();
        short short12 = fraction9.shortValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.negate();
        int int14 = fraction5.compareTo(fraction9);
        int int15 = fraction5.getProperWhole();
        float float16 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction5.add(fraction17);
        int int19 = fraction17.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction17.abs();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction25.negate();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction26.negate();
        boolean boolean28 = fraction20.equals((java.lang.Object) fraction27);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction2.divideBy(fraction20);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.getFraction(100, (int) ' ', (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction34 = fraction2.add(fraction33);
        java.lang.String str35 = fraction34.toString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.625f + "'", float16 == 1.625f);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "113152/1120" + "'", str35.equals("113152/1120"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100);
        int int2 = fraction1.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.multiplyBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction4.abs();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction4.reduce();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction10.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction10.abs();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction17.abs();
        short short19 = fraction18.shortValue();
        int int20 = fraction18.getDenominator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1/2");
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.negate();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        long long14 = fraction2.longValue();
        java.lang.String str15 = fraction2.toProperString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1 5/8" + "'", str15.equals("1 5/8"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str1 = fraction0.toString();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.reduce();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.invert();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1/2" + "'", str1.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 6, (-3));
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(2, 12, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction10.multiplyBy(fraction15);
        short short21 = fraction10.shortValue();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str26 = fraction25.toProperString();
        int int27 = fraction25.intValue();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction29 = fraction28.reduce();
        int int30 = fraction29.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.abs();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction25.add(fraction29);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction10.subtract(fraction29);
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        long long35 = fraction34.longValue();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction34.abs();
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction38 = fraction37.negate();
        int int39 = fraction38.intValue();
        org.apache.commons.lang3.math.Fraction fraction42 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str43 = fraction42.toProperString();
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int46 = fraction45.getNumerator();
        int int47 = fraction45.getDenominator();
        byte byte48 = fraction45.byteValue();
        int int49 = fraction45.getProperWhole();
        int int50 = fraction42.compareTo(fraction45);
        java.lang.Class<?> wildcardClass51 = fraction45.getClass();
        int int52 = fraction38.compareTo(fraction45);
        boolean boolean53 = fraction34.equals((java.lang.Object) fraction45);
        int int54 = fraction10.compareTo(fraction34);
        org.apache.commons.lang3.math.Fraction fraction55 = fraction10.reduce();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 0 + "'", short21 == (short) 0);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1 45/52" + "'", str26.equals("1 45/52"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1 5/8" + "'", str43.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + byte48 + "' != '" + (byte) 0 + "'", byte48 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(fraction55);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) -35, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) (-3));
        org.apache.commons.lang3.math.Fraction fraction5 = fraction2.multiplyBy(fraction4);
        java.lang.String str6 = fraction2.toProperString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-3 5/10" + "'", str6.equals("-3 5/10"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        int int2 = fraction0.getProperWhole();
        java.lang.Class<?> wildcardClass3 = fraction0.getClass();
        java.lang.String str4 = fraction0.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction0.reduce();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4/5" + "'", str4.equals("4/5"));
        org.junit.Assert.assertNotNull(fraction5);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.invert();
        int int7 = fraction5.getProperWhole();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-5) + "'", int7 == (-5));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((-97), (int) (byte) 6);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        int int4 = fraction3.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction(3, (int) ' ');
        int int8 = fraction7.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction3.divideBy(fraction7);
        long long10 = fraction7.longValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.negate();
        int int2 = fraction1.getProperWhole();
        float float3 = fraction1.floatValue();
        java.lang.Class<?> wildcardClass4 = fraction1.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-0.6f) + "'", float3 == (-0.6f));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_QUARTER;
        int int1 = fraction0.getProperWhole();
        int int2 = fraction0.intValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction0.multiplyBy(fraction3);
        java.lang.String str9 = fraction3.toString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.abs();
        long long11 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long16 = fraction15.longValue();
        int int17 = fraction15.intValue();
        java.lang.Class<?> wildcardClass18 = fraction15.getClass();
        byte byte19 = fraction15.byteValue();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction3.add(fraction15);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0/1" + "'", str9.equals("0/1"));
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2L) + "'", long16 == (-2L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2) + "'", int17 == (-2));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) -2 + "'", byte19 == (byte) -2);
        org.junit.Assert.assertNotNull(fraction20);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.negate();
        double double7 = fraction6.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.pow(4);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int11 = fraction10.getProperWhole();
        int int12 = fraction10.intValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction6.multiplyBy(fraction10);
        double double14 = fraction6.doubleValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean7 = fraction5.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int10 = fraction9.getNumerator();
        int int11 = fraction9.getDenominator();
        short short12 = fraction9.shortValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.negate();
        int int14 = fraction5.compareTo(fraction9);
        int int15 = fraction5.getProperWhole();
        float float16 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction5.add(fraction17);
        int int19 = fraction17.getDenominator();
        int int20 = fraction2.compareTo(fraction17);
        java.lang.Class<?> wildcardClass21 = fraction2.getClass();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.625f + "'", float16 == 1.625f);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("-49/40");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(1, 13);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((-3), (int) (byte) 103);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 10, 2);
        double double4 = fraction3.doubleValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.0d + "'", double4 == 6.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(10, (int) (byte) 1);
        int int3 = fraction2.intValue();
        java.lang.Class<?> wildcardClass4 = fraction2.getClass();
        int int5 = fraction2.intValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int8 = fraction7.getNumerator();
        int int9 = fraction7.getDenominator();
        short short10 = fraction7.shortValue();
        boolean boolean12 = fraction7.equals((java.lang.Object) 10);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction2.multiplyBy(fraction7);
        int int14 = fraction2.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction2.pow((int) (short) 0);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean21 = fraction19.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int24 = fraction23.getNumerator();
        int int25 = fraction23.getDenominator();
        short short26 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction23.negate();
        int int28 = fraction19.compareTo(fraction23);
        int int29 = fraction19.getProperWhole();
        float float30 = fraction19.floatValue();
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int32 = fraction31.getProperWhole();
        double double33 = fraction31.doubleValue();
        double double34 = fraction31.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction19.subtract(fraction31);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction2.multiplyBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction37 = fraction19.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + short26 + "' != '" + (short) 0 + "'", short26 == (short) 0);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.625f + "'", float30 == 1.625f);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.75d + "'", double33 == 0.75d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.75d + "'", double34 == 0.75d);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        long long6 = fraction3.longValue();
        int int7 = fraction3.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2L) + "'", long6 == (-2L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction0.multiplyBy(fraction3);
        java.lang.String str9 = fraction3.toString();
        long long10 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean18 = fraction16.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int21 = fraction20.getNumerator();
        int int22 = fraction20.getDenominator();
        short short23 = fraction20.shortValue();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction20.negate();
        int int25 = fraction16.compareTo(fraction20);
        int int26 = fraction16.getProperWhole();
        float float27 = fraction16.floatValue();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction29 = fraction16.add(fraction28);
        int int30 = fraction28.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction28.abs();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction31.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction37 = fraction36.negate();
        org.apache.commons.lang3.math.Fraction fraction38 = fraction37.negate();
        boolean boolean39 = fraction31.equals((java.lang.Object) fraction38);
        org.apache.commons.lang3.math.Fraction fraction40 = fraction13.divideBy(fraction31);
        int int41 = fraction31.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction3.add(fraction31);
        org.apache.commons.lang3.math.Fraction fraction44 = org.apache.commons.lang3.math.Fraction.getFraction("13/8");
        java.lang.String str45 = fraction44.toString();
        org.apache.commons.lang3.math.Fraction fraction46 = fraction3.add(fraction44);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction3.abs();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0/1" + "'", str9.equals("0/1"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.625f + "'", float27 == 1.625f);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "13/8" + "'", str45.equals("13/8"));
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction47);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 10, 2);
        int int4 = fraction3.getDenominator();
        java.lang.String str5 = fraction3.toString();
        float float6 = fraction3.floatValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12/2" + "'", str5.equals("12/2"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 6.0f + "'", float6 == 6.0f);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("96/32");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        long long8 = fraction3.longValue();
        int int9 = fraction3.getProperNumerator();
        try {
            org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The fraction to divide by must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1 45/52");
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.negate();
        int int6 = fraction1.compareTo(fraction5);
        java.lang.String str7 = fraction5.toString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-10/1" + "'", str7.equals("-10/1"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        java.lang.Class<?> wildcardClass11 = fraction2.getClass();
        int int12 = fraction2.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((-97), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 6, 173, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        java.lang.String str10 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.multiplyBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction4.add(fraction14);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', 12);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        short short8 = fraction5.shortValue();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.negate();
        int int10 = fraction9.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.add(fraction9);
        short short12 = fraction2.shortValue();
        java.lang.String str13 = fraction2.toProperString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1 5/8" + "'", str13.equals("1 5/8"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.abs();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str16 = fraction15.toProperString();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int19 = fraction18.getNumerator();
        int int20 = fraction18.getDenominator();
        byte byte21 = fraction18.byteValue();
        int int22 = fraction18.getProperWhole();
        int int23 = fraction15.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean29 = fraction27.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int32 = fraction31.getNumerator();
        int int33 = fraction31.getDenominator();
        short short34 = fraction31.shortValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction31.negate();
        int int36 = fraction35.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction27.add(fraction35);
        java.lang.String str38 = fraction35.toProperString();
        org.apache.commons.lang3.math.Fraction fraction40 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int41 = fraction40.getNumerator();
        int int42 = fraction40.getDenominator();
        short short43 = fraction40.shortValue();
        org.apache.commons.lang3.math.Fraction fraction44 = fraction40.negate();
        org.apache.commons.lang3.math.Fraction fraction45 = fraction35.multiplyBy(fraction40);
        org.apache.commons.lang3.math.Fraction fraction46 = fraction24.add(fraction40);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction2.multiplyBy(fraction40);
        try {
            org.apache.commons.lang3.math.Fraction fraction48 = fraction47.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1 5/8" + "'", str16.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + byte21 + "' != '" + (byte) 0 + "'", byte21 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + short34 + "' != '" + (short) 0 + "'", short34 == (short) 0);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + short43 + "' != '" + (short) 0 + "'", short43 == (short) 0);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction47);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) -2, (int) (short) 0, (int) (byte) 10);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction(3, (int) ' ');
        int int7 = fraction6.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.subtract(fraction6);
        long long9 = fraction6.longValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.add(fraction14);
        int int16 = fraction14.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.pow((int) (byte) -1);
        int int20 = fraction17.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str25 = fraction24.toProperString();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int28 = fraction27.getNumerator();
        int int29 = fraction27.getDenominator();
        byte byte30 = fraction27.byteValue();
        int int31 = fraction27.getProperWhole();
        int int32 = fraction24.compareTo(fraction27);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction24.negate();
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int35 = fraction34.getNumerator();
        float float36 = fraction34.floatValue();
        org.apache.commons.lang3.math.Fraction fraction40 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction41 = fraction34.subtract(fraction40);
        int int42 = fraction34.getNumerator();
        int int43 = fraction24.compareTo(fraction34);
        org.apache.commons.lang3.math.Fraction fraction44 = fraction21.multiplyBy(fraction34);
        org.apache.commons.lang3.math.Fraction fraction48 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction49 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction50 = fraction48.divideBy(fraction49);
        org.apache.commons.lang3.math.Fraction fraction51 = fraction49.abs();
        double double52 = fraction49.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction53 = fraction21.subtract(fraction49);
        org.apache.commons.lang3.math.Fraction fraction54 = fraction17.subtract(fraction21);
        java.lang.String str55 = fraction21.toProperString();
        org.apache.commons.lang3.math.Fraction fraction56 = fraction21.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1 5/8" + "'", str25.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + byte30 + "' != '" + (byte) 0 + "'", byte30 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.5f + "'", float36 == 0.5f);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction48);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.4d + "'", double52 == 0.4d);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "1/2" + "'", str55.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction56);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -2, (int) (short) 0, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction(0.75d);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction3.add(fraction5);
        int int7 = fraction5.getNumerator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (-10.0f));
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.reduce();
        int int13 = fraction10.compareTo(fraction12);
        long long14 = fraction10.longValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.invert();
        float float3 = fraction2.floatValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.25f + "'", float3 == 1.25f);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 100, (-3));
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(3, (int) (short) 10);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int1 = fraction0.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean6 = fraction4.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        int int13 = fraction12.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction12);
        java.lang.String str15 = fraction12.toProperString();
        boolean boolean16 = fraction0.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, (int) '4');
        int int20 = fraction0.compareTo(fraction19);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean25 = fraction23.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int28 = fraction27.getNumerator();
        int int29 = fraction27.getDenominator();
        short short30 = fraction27.shortValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction27.negate();
        int int32 = fraction23.compareTo(fraction27);
        long long33 = fraction23.longValue();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction0.subtract(fraction34);
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.getFraction(10, (int) (byte) 1);
        int int39 = fraction38.intValue();
        java.lang.Class<?> wildcardClass40 = fraction38.getClass();
        int int41 = fraction38.intValue();
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int44 = fraction43.getNumerator();
        int int45 = fraction43.getDenominator();
        short short46 = fraction43.shortValue();
        boolean boolean48 = fraction43.equals((java.lang.Object) 10);
        org.apache.commons.lang3.math.Fraction fraction49 = fraction38.multiplyBy(fraction43);
        org.apache.commons.lang3.math.Fraction fraction50 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int51 = fraction50.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction52 = fraction50.negate();
        org.apache.commons.lang3.math.Fraction fraction53 = fraction49.subtract(fraction52);
        try {
            org.apache.commons.lang3.math.Fraction fraction54 = fraction34.divideBy(fraction49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The fraction to divide by must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 0 + "'", short30 == (short) 0);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + short46 + "' != '" + (short) 0 + "'", short46 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertNotNull(fraction53);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.subtract(fraction1);
        java.lang.String str3 = fraction0.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3/5" + "'", str3.equals("3/5"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str14 = fraction13.toProperString();
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int17 = fraction16.getNumerator();
        int int18 = fraction16.getDenominator();
        byte byte19 = fraction16.byteValue();
        int int20 = fraction16.getProperWhole();
        int int21 = fraction13.compareTo(fraction16);
        float float22 = fraction13.floatValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction5.divideBy(fraction13);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction23.reduce();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1 5/8" + "'", str14.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 0 + "'", byte19 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.625f + "'", float22 == 1.625f);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) ' ', (-3));
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        java.lang.Class<?> wildcardClass5 = fraction4.getClass();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.negate();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction2.subtract(fraction8);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.pow((-1));
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.reduce();
        java.lang.String str6 = fraction4.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "5/3" + "'", str6.equals("5/3"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction10.multiplyBy(fraction15);
        int int21 = fraction20.getProperWhole();
        byte byte22 = fraction20.byteValue();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str26 = fraction25.toProperString();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int29 = fraction28.getNumerator();
        int int30 = fraction28.getDenominator();
        byte byte31 = fraction28.byteValue();
        int int32 = fraction28.getProperWhole();
        int int33 = fraction25.compareTo(fraction28);
        org.apache.commons.lang3.math.Fraction fraction36 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str37 = fraction36.toProperString();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int40 = fraction39.getNumerator();
        int int41 = fraction39.getDenominator();
        byte byte42 = fraction39.byteValue();
        int int43 = fraction39.getProperWhole();
        int int44 = fraction36.compareTo(fraction39);
        float float45 = fraction36.floatValue();
        org.apache.commons.lang3.math.Fraction fraction46 = fraction28.divideBy(fraction36);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction20.subtract(fraction36);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + byte22 + "' != '" + (byte) 0 + "'", byte22 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1 5/8" + "'", str26.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + byte31 + "' != '" + (byte) 0 + "'", byte31 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1 5/8" + "'", str37.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + byte42 + "' != '" + (byte) 0 + "'", byte42 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 1.625f + "'", float45 == 1.625f);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction47);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("-3 5/10");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 2);
        int int2 = fraction1.getDenominator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_THIRDS;
        int int1 = fraction0.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-2.0d));
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.multiplyBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean9 = fraction7.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.pow((-2));
        int int12 = fraction7.intValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction7.negate();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.divideBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        short short16 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int19 = fraction18.getNumerator();
        int int20 = fraction18.getDenominator();
        byte byte21 = fraction18.byteValue();
        int int22 = fraction18.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction18.abs();
        int int24 = fraction15.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction7.add(fraction18);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + byte21 + "' != '" + (byte) 0 + "'", byte21 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(fraction25);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', (int) (short) -1, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The numerator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(12, 14);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str1 = fraction0.toString();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction(10, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.negate();
        int int6 = fraction5.getProperWhole();
        int int7 = fraction5.getNumerator();
        int int8 = fraction0.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = null;
        try {
            org.apache.commons.lang3.math.Fraction fraction10 = fraction0.subtract(fraction9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fraction must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1/2" + "'", str1.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-5) + "'", int7 == (-5));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.abs();
        java.lang.Class<?> wildcardClass9 = fraction8.getClass();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) 10);
        int int2 = fraction1.getDenominator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str9 = fraction8.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int12 = fraction11.getNumerator();
        int int13 = fraction11.getDenominator();
        byte byte14 = fraction11.byteValue();
        int int15 = fraction11.getProperWhole();
        int int16 = fraction8.compareTo(fraction11);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int19 = fraction18.getNumerator();
        float float20 = fraction18.floatValue();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction18.subtract(fraction24);
        int int26 = fraction18.getNumerator();
        int int27 = fraction8.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction5.multiplyBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction32 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction34 = fraction32.divideBy(fraction33);
        org.apache.commons.lang3.math.Fraction fraction35 = fraction33.abs();
        double double36 = fraction33.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction5.subtract(fraction33);
        int int38 = fraction33.getProperNumerator();
        boolean boolean39 = fraction4.equals((java.lang.Object) int38);
        java.lang.String str40 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction4.invert();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1 5/8" + "'", str9.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.4d + "'", double36 == 0.4d);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "-1 45/52" + "'", str40.equals("-1 45/52"));
        org.junit.Assert.assertNotNull(fraction41);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        byte byte9 = fraction6.byteValue();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int11 = fraction10.getNumerator();
        float float12 = fraction10.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction6.divideBy(fraction10);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction6.negate();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction6.abs();
        java.lang.String str16 = fraction6.toString();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction4.multiplyBy(fraction6);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction19 = fraction18.reduce();
        int int20 = fraction19.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.abs();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str25 = fraction24.toProperString();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction21.multiplyBy(fraction24);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction26.abs();
        int int28 = fraction4.compareTo(fraction27);
        double double29 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction("1/2");
        int int32 = fraction31.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getFraction((int) '4', (int) (short) 97);
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) -2, 8);
        org.apache.commons.lang3.math.Fraction fraction39 = fraction35.add(fraction38);
        org.apache.commons.lang3.math.Fraction fraction40 = fraction31.subtract(fraction39);
        boolean boolean41 = fraction4.equals((java.lang.Object) fraction39);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0/1" + "'", str16.equals("0/1"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1 5/8" + "'", str25.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.1d + "'", double29 == 0.1d);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction10.subtract(fraction15);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction10.abs();
        java.lang.Class<?> wildcardClass18 = fraction10.getClass();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction10.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(fraction19);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -2, (int) (short) 0, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction(0.75d);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction3.add(fraction5);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int11 = fraction10.getNumerator();
        int int12 = fraction10.getDenominator();
        short short13 = fraction10.shortValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction10.negate();
        int int15 = fraction14.getDenominator();
        boolean boolean16 = fraction8.equals((java.lang.Object) int15);
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction17.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str20 = fraction19.toString();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean25 = fraction23.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int28 = fraction27.getNumerator();
        int int29 = fraction27.getDenominator();
        short short30 = fraction27.shortValue();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction27.negate();
        int int32 = fraction31.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction23.add(fraction31);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction19.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction35 = fraction17.multiplyBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction8.multiplyBy(fraction17);
        double double37 = fraction8.doubleValue();
        int int38 = fraction8.intValue();
        int int39 = fraction6.compareTo(fraction8);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1/2" + "'", str20.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 0 + "'", short30 == (short) 0);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.pow((-2));
        int int7 = fraction2.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.negate();
        float float9 = fraction2.floatValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.625f + "'", float9 == 1.625f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        long long1 = fraction0.longValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.pow((-1));
        int int5 = fraction4.getProperWhole();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_THIRDS;
        byte byte1 = fraction0.byteValue();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        int int7 = fraction6.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.pow((int) (byte) -2);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction0.multiplyBy(fraction9);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((-3), (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getFraction(3, 0, (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction18 = fraction13.multiplyBy(fraction17);
        java.lang.Class<?> wildcardClass19 = fraction18.getClass();
        boolean boolean20 = fraction9.equals((java.lang.Object) wildcardClass19);
        int int21 = fraction9.getProperWhole();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 97L);
        java.lang.Class<?> wildcardClass2 = fraction1.getClass();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int6 = fraction5.intValue();
        boolean boolean7 = fraction1.equals((java.lang.Object) int6);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction10.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.negate();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int15 = fraction14.getNumerator();
        int int16 = fraction14.getDenominator();
        byte byte17 = fraction14.byteValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int19 = fraction18.getNumerator();
        float float20 = fraction18.floatValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction14.divideBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction14.negate();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction14.abs();
        java.lang.String str24 = fraction14.toString();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction12.multiplyBy(fraction14);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction1.subtract(fraction12);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 0 + "'", byte17 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0/1" + "'", str24.equals("0/1"));
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(0, (-97));
        java.lang.String str3 = fraction2.toString();
        byte byte4 = fraction2.byteValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0/97" + "'", str3.equals("0/97"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        long long5 = fraction3.longValue();
        double double6 = fraction3.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.reduce();
        int int8 = fraction7.getProperWhole();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.1d) + "'", double6 == (-0.1d));
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.abs();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean17 = fraction15.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int20 = fraction19.getNumerator();
        int int21 = fraction19.getDenominator();
        short short22 = fraction19.shortValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction19.negate();
        int int24 = fraction15.compareTo(fraction19);
        int int25 = fraction15.getProperWhole();
        float float26 = fraction15.floatValue();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction28 = fraction15.add(fraction27);
        int int29 = fraction27.getDenominator();
        short short30 = fraction27.shortValue();
        long long31 = fraction27.longValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction2.divideBy(fraction27);
        int int33 = fraction32.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction32.reduce();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + short22 + "' != '" + (short) 0 + "'", short22 == (short) 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.625f + "'", float26 == 1.625f);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 1 + "'", short30 == (short) 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(fraction34);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.add(fraction14);
        int int16 = fraction14.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction22.negate();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction23.negate();
        boolean boolean25 = fraction17.equals((java.lang.Object) fraction24);
        int int26 = fraction24.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long4 = fraction3.longValue();
        int int5 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean10 = fraction8.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int13 = fraction12.getNumerator();
        int int14 = fraction12.getDenominator();
        short short15 = fraction12.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.negate();
        int int17 = fraction8.compareTo(fraction12);
        int int18 = fraction8.getProperWhole();
        float float19 = fraction8.floatValue();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction8.add(fraction20);
        int int22 = fraction20.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction20.abs();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction3.subtract(fraction25);
        float float27 = fraction3.floatValue();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.getFraction((int) ' ', (-3));
        org.apache.commons.lang3.math.Fraction fraction31 = fraction3.add(fraction30);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2L) + "'", long4 == (-2L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2) + "'", int5 == (-2));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.625f + "'", float19 == 1.625f);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + (-2.0f) + "'", float27 == (-2.0f));
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.abs();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean6 = fraction4.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction4.pow((-2));
        int int9 = fraction4.intValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction4.negate();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction15 = fraction14.negate();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.abs();
        int int17 = fraction15.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction15.reduce();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction4.multiplyBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int22 = fraction21.getNumerator();
        int int23 = fraction21.getDenominator();
        byte byte24 = fraction21.byteValue();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int26 = fraction25.getNumerator();
        float float27 = fraction25.floatValue();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction21.divideBy(fraction25);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction21.negate();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction21.negate();
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction32 = fraction31.reduce();
        int int33 = fraction30.compareTo(fraction32);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.negate();
        int int35 = fraction34.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction4.subtract(fraction34);
        org.apache.commons.lang3.math.Fraction fraction37 = fraction0.divideBy(fraction36);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + byte24 + "' != '" + (byte) 0 + "'", byte24 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        int int3 = fraction2.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.invert();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100);
        int int2 = fraction1.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.multiplyBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) ' ', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction13);
        int int15 = fraction4.getProperWhole();
        java.lang.String str16 = fraction4.toProperString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 0, 13);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean7 = fraction5.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.pow((-2));
        int int10 = fraction5.intValue();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction5.negate();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction16 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction16.abs();
        int int18 = fraction16.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction16.reduce();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction5.multiplyBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction2.multiplyBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction26 = fraction25.negate();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction26.abs();
        int int28 = fraction26.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction26.reduce();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction21.divideBy(fraction26);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        long long14 = fraction2.longValue();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int16 = fraction15.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int19 = fraction18.getNumerator();
        int int20 = fraction18.getDenominator();
        short short21 = fraction18.shortValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.negate();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction15.multiplyBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction2.add(fraction18);
        int int25 = fraction2.intValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 0 + "'", short21 == (short) 0);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, (int) '#', 10);
        byte byte4 = fraction3.byteValue();
        java.lang.String str5 = fraction3.toString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 103 + "'", byte4 == (byte) 103);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1035/10" + "'", str5.equals("1035/10"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.add(fraction14);
        int int16 = fraction14.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction22.negate();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction23.negate();
        boolean boolean25 = fraction17.equals((java.lang.Object) fraction24);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.ZERO;
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        boolean boolean30 = fraction26.equals((java.lang.Object) (byte) 10);
        int int31 = fraction24.compareTo(fraction26);
        java.lang.String str32 = fraction24.toString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10/100" + "'", str32.equals("10/100"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(10, (int) (byte) 1);
        int int3 = fraction2.intValue();
        long long4 = fraction2.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction5.multiplyBy(fraction8);
        java.lang.Class<?> wildcardClass14 = fraction8.getClass();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction3.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((int) '4', (int) (short) 97);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) -2, 8);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.add(fraction21);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int24 = fraction23.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean29 = fraction27.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int32 = fraction31.getNumerator();
        int int33 = fraction31.getDenominator();
        short short34 = fraction31.shortValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction31.negate();
        int int36 = fraction35.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction27.add(fraction35);
        java.lang.String str38 = fraction35.toProperString();
        boolean boolean39 = fraction23.equals((java.lang.Object) fraction35);
        org.apache.commons.lang3.math.Fraction fraction40 = fraction21.multiplyBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction41 = fraction15.subtract(fraction40);
        org.apache.commons.lang3.math.Fraction fraction42 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction43 = fraction42.negate();
        int int44 = fraction43.getProperWhole();
        float float45 = fraction43.floatValue();
        org.apache.commons.lang3.math.Fraction fraction46 = fraction15.subtract(fraction43);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2L) + "'", long4 == (-2L));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + short34 + "' != '" + (short) 0 + "'", short34 == (short) 0);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + (-0.6f) + "'", float45 == (-0.6f));
        org.junit.Assert.assertNotNull(fraction46);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 3);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_THIRDS;
        int int1 = fraction0.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-2.0d));
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.multiplyBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction((-3), (int) (byte) 103);
        boolean boolean8 = fraction0.equals((java.lang.Object) (byte) 103);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.negate();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.abs();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 173);
        double double2 = fraction1.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.reduce();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 173.0d + "'", double2 == 173.0d);
        org.junit.Assert.assertNotNull(fraction3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1 45/52");
        byte byte2 = fraction1.byteValue();
        int int3 = fraction1.getDenominator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) (byte) 10);
        int int3 = fraction2.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction("1 45/52");
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.negate();
        int int9 = fraction4.compareTo(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction2.divideBy(fraction8);
        java.lang.String str11 = fraction8.toProperString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-10" + "'", str11.equals("-10"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 4);
        int int3 = fraction2.getDenominator();
        long long4 = fraction2.longValue();
        byte byte5 = fraction2.byteValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("4/5");
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str5 = fraction4.toProperString();
        byte byte6 = fraction4.byteValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction4.negate();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.subtract(fraction4);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1 5/8" + "'", str5.equals("1 5/8"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        byte byte11 = fraction8.byteValue();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int13 = fraction12.getProperWhole();
        float float14 = fraction12.floatValue();
        int int15 = fraction8.compareTo(fraction12);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.4f + "'", float14 == 0.4f);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("-10");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str9 = fraction8.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int12 = fraction11.getNumerator();
        int int13 = fraction11.getDenominator();
        byte byte14 = fraction11.byteValue();
        int int15 = fraction11.getProperWhole();
        int int16 = fraction8.compareTo(fraction11);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int19 = fraction18.getNumerator();
        float float20 = fraction18.floatValue();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction18.subtract(fraction24);
        int int26 = fraction18.getNumerator();
        int int27 = fraction8.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction5.multiplyBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction32 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction34 = fraction32.divideBy(fraction33);
        org.apache.commons.lang3.math.Fraction fraction35 = fraction33.abs();
        double double36 = fraction33.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction5.subtract(fraction33);
        int int38 = fraction33.getProperNumerator();
        boolean boolean39 = fraction4.equals((java.lang.Object) int38);
        org.apache.commons.lang3.math.Fraction fraction41 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int42 = fraction41.getNumerator();
        int int43 = fraction41.getDenominator();
        short short44 = fraction41.shortValue();
        org.apache.commons.lang3.math.Fraction fraction45 = fraction41.negate();
        int int46 = fraction45.getNumerator();
        float float47 = fraction45.floatValue();
        try {
            org.apache.commons.lang3.math.Fraction fraction48 = fraction4.divideBy(fraction45);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The fraction to divide by must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1 5/8" + "'", str9.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.4d + "'", double36 == 0.4d);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + short44 + "' != '" + (short) 0 + "'", short44 == (short) 0);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.negate();
        double double7 = fraction6.doubleValue();
        java.lang.Class<?> wildcardClass8 = fraction6.getClass();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean13 = fraction11.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        int int20 = fraction11.compareTo(fraction15);
        int int21 = fraction11.getProperWhole();
        float float22 = fraction11.floatValue();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction24 = fraction11.add(fraction23);
        int int25 = fraction23.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction6.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction23.abs();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction27.negate();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.625f + "'", float22 == 1.625f);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1 5/8");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int3 = fraction2.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean8 = fraction6.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int11 = fraction10.getNumerator();
        int int12 = fraction10.getDenominator();
        short short13 = fraction10.shortValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction10.negate();
        int int15 = fraction6.compareTo(fraction10);
        int int16 = fraction6.getProperWhole();
        float float17 = fraction6.floatValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int19 = fraction18.getProperWhole();
        double double20 = fraction18.doubleValue();
        double double21 = fraction18.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction6.subtract(fraction18);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction2.add(fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction1.multiplyBy(fraction2);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int27 = fraction26.getNumerator();
        int int28 = fraction26.getDenominator();
        short short29 = fraction26.shortValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction26.negate();
        int int31 = fraction30.getNumerator();
        float float32 = fraction30.floatValue();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.pow((int) 'a');
        boolean boolean35 = fraction24.equals((java.lang.Object) fraction30);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.625f + "'", float17 == 1.625f);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.75d + "'", double20 == 0.75d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.75d + "'", double21 == 0.75d);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + short29 + "' != '" + (short) 0 + "'", short29 == (short) 0);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean12 = fraction10.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.divideBy(fraction10);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean16 = fraction14.equals((java.lang.Object) fraction15);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction15.negate();
        long long18 = fraction17.longValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction9.divideBy(fraction19);
        float float21 = fraction20.floatValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 8);
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str1 = fraction0.toString();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean6 = fraction4.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        int int13 = fraction12.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction12);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction0.divideBy(fraction4);
        long long16 = fraction15.longValue();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction15.reduce();
        short short18 = fraction17.shortValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1/2" + "'", str1.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.pow((-2));
        int int7 = fraction2.getDenominator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction7.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.divideBy(fraction8);
        int int11 = fraction10.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction2.pow((-2));
        int int7 = fraction2.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction13 = fraction12.negate();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.abs();
        int int15 = fraction13.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction13.reduce();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction2.multiplyBy(fraction16);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int20 = fraction19.getNumerator();
        int int21 = fraction19.getDenominator();
        byte byte22 = fraction19.byteValue();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int24 = fraction23.getNumerator();
        float float25 = fraction23.floatValue();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction19.divideBy(fraction23);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction19.negate();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction19.negate();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction30 = fraction29.reduce();
        int int31 = fraction28.compareTo(fraction30);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction28.negate();
        int int33 = fraction32.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction2.subtract(fraction32);
        double double35 = fraction2.doubleValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + byte22 + "' != '" + (byte) 0 + "'", byte22 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.625d + "'", double35 == 1.625d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.5f);
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        int int3 = fraction1.getProperWhole();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) '4', (int) (byte) 100, (int) 'a');
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction("0/1");
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.abs();
        int int7 = fraction6.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction12.abs();
        int int14 = fraction12.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction6.multiplyBy(fraction12);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction3.divideBy(fraction12);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int19 = fraction18.getNumerator();
        int int20 = fraction18.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction26 = fraction24.divideBy(fraction25);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction18.divideBy(fraction25);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction18.abs();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction28.pow(0);
        org.apache.commons.lang3.math.Fraction fraction31 = fraction28.reduce();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction12.add(fraction31);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(2, 52);
        java.lang.Class<?> wildcardClass3 = fraction2.getClass();
        int int4 = fraction2.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }
}

