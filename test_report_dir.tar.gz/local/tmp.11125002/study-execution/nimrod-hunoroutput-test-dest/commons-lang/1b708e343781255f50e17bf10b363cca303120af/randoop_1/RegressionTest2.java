import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int1 = fraction0.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean6 = fraction4.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        int int13 = fraction12.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction12);
        java.lang.String str15 = fraction12.toProperString();
        boolean boolean16 = fraction0.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, (int) '4');
        int int20 = fraction0.compareTo(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.negate();
        int int22 = fraction19.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean28 = fraction26.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int31 = fraction30.getNumerator();
        int int32 = fraction30.getDenominator();
        short short33 = fraction30.shortValue();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction30.negate();
        int int35 = fraction26.compareTo(fraction30);
        int int36 = fraction26.getProperWhole();
        float float37 = fraction26.floatValue();
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction39 = fraction26.add(fraction38);
        int int40 = fraction38.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction38.abs();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction23.divideBy(fraction41);
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str44 = fraction43.toString();
        org.apache.commons.lang3.math.Fraction fraction45 = fraction43.reduce();
        org.apache.commons.lang3.math.Fraction fraction48 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str49 = fraction48.toProperString();
        byte byte50 = fraction48.byteValue();
        org.apache.commons.lang3.math.Fraction fraction51 = fraction48.negate();
        java.lang.Class<?> wildcardClass52 = fraction51.getClass();
        boolean boolean53 = fraction45.equals((java.lang.Object) wildcardClass52);
        org.apache.commons.lang3.math.Fraction fraction54 = fraction23.divideBy(fraction45);
        boolean boolean55 = fraction19.equals((java.lang.Object) fraction45);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + short33 + "' != '" + (short) 0 + "'", short33 == (short) 0);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.625f + "'", float37 == 1.625f);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1/2" + "'", str44.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1 5/8" + "'", str49.equals("1 5/8"));
        org.junit.Assert.assertTrue("'" + byte50 + "' != '" + (byte) 1 + "'", byte50 == (byte) 1);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) '#', (int) (byte) -2);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_THIRDS;
        int int1 = fraction0.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-2.0d));
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.multiplyBy(fraction3);
        int int5 = fraction3.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction5.multiplyBy(fraction8);
        java.lang.Class<?> wildcardClass14 = fraction8.getClass();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction3.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((int) '4', (int) (short) 97);
        org.apache.commons.lang3.math.Fraction fraction21 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) -2, 8);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.add(fraction21);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int24 = fraction23.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean29 = fraction27.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int32 = fraction31.getNumerator();
        int int33 = fraction31.getDenominator();
        short short34 = fraction31.shortValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction31.negate();
        int int36 = fraction35.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction27.add(fraction35);
        java.lang.String str38 = fraction35.toProperString();
        boolean boolean39 = fraction23.equals((java.lang.Object) fraction35);
        org.apache.commons.lang3.math.Fraction fraction40 = fraction21.multiplyBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction41 = fraction15.subtract(fraction40);
        java.lang.Object obj42 = null;
        boolean boolean43 = fraction15.equals(obj42);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2L) + "'", long4 == (-2L));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + short34 + "' != '" + (short) 0 + "'", short34 == (short) 0);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        int int3 = fraction2.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean10 = fraction8.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int13 = fraction12.getNumerator();
        int int14 = fraction12.getDenominator();
        short short15 = fraction12.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.negate();
        int int17 = fraction16.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction8.add(fraction16);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction4.divideBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction2.subtract(fraction8);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction8.negate();
        int int22 = fraction8.getDenominator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        float float2 = fraction0.floatValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction7 = fraction0.subtract(fraction6);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.abs();
        java.lang.String str9 = fraction6.toProperString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-2" + "'", str9.equals("-2"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.pow((int) (short) -2);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int9 = fraction8.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int12 = fraction11.getNumerator();
        int int13 = fraction11.getDenominator();
        short short14 = fraction11.shortValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.negate();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction8.multiplyBy(fraction11);
        java.lang.String str17 = fraction11.toString();
        long long18 = fraction11.longValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction7.subtract(fraction11);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean24 = fraction22.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int27 = fraction26.getNumerator();
        int int28 = fraction26.getDenominator();
        short short29 = fraction26.shortValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction26.negate();
        int int31 = fraction30.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction22.add(fraction30);
        java.lang.String str33 = fraction30.toProperString();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int36 = fraction35.getNumerator();
        int int37 = fraction35.getDenominator();
        short short38 = fraction35.shortValue();
        org.apache.commons.lang3.math.Fraction fraction39 = fraction35.negate();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction30.multiplyBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction41 = fraction35.reduce();
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction46 = fraction45.negate();
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int48 = fraction47.getProperWhole();
        double double49 = fraction47.doubleValue();
        double double50 = fraction47.doubleValue();
        int int51 = fraction47.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction52 = fraction46.multiplyBy(fraction47);
        org.apache.commons.lang3.math.Fraction fraction53 = fraction41.multiplyBy(fraction52);
        org.apache.commons.lang3.math.Fraction fraction54 = fraction11.subtract(fraction41);
        org.apache.commons.lang3.math.Fraction fraction56 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int57 = fraction56.getNumerator();
        int int58 = fraction56.getDenominator();
        byte byte59 = fraction56.byteValue();
        org.apache.commons.lang3.math.Fraction fraction60 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int61 = fraction60.getNumerator();
        float float62 = fraction60.floatValue();
        org.apache.commons.lang3.math.Fraction fraction63 = fraction56.divideBy(fraction60);
        org.apache.commons.lang3.math.Fraction fraction64 = fraction56.negate();
        org.apache.commons.lang3.math.Fraction fraction65 = fraction56.negate();
        org.apache.commons.lang3.math.Fraction fraction66 = fraction56.reduce();
        int int67 = fraction54.compareTo(fraction56);
        org.apache.commons.lang3.math.Fraction fraction68 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction69 = fraction68.negate();
        int int70 = fraction69.getProperWhole();
        int int71 = fraction54.compareTo(fraction69);
        org.apache.commons.lang3.math.Fraction fraction72 = fraction54.negate();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0/1" + "'", str17.equals("0/1"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + short29 + "' != '" + (short) 0 + "'", short29 == (short) 0);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "0" + "'", str33.equals("0"));
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + short38 + "' != '" + (short) 0 + "'", short38 == (short) 0);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.75d + "'", double49 == 0.75d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.75d + "'", double50 == 0.75d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 3 + "'", int51 == 3);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertNotNull(fraction56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + byte59 + "' != '" + (byte) 0 + "'", byte59 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 0.5f + "'", float62 == 0.5f);
        org.junit.Assert.assertNotNull(fraction63);
        org.junit.Assert.assertNotNull(fraction64);
        org.junit.Assert.assertNotNull(fraction65);
        org.junit.Assert.assertNotNull(fraction66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(fraction68);
        org.junit.Assert.assertNotNull(fraction69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(fraction72);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        short short12 = fraction11.shortValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction10.divideBy(fraction11);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction11.invert();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int16 = fraction15.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int19 = fraction18.getNumerator();
        int int20 = fraction18.getDenominator();
        short short21 = fraction18.shortValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.negate();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction15.multiplyBy(fraction18);
        short short24 = fraction23.shortValue();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        long long26 = fraction25.longValue();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.abs();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction23.subtract(fraction25);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction11.add(fraction23);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 0 + "'", short21 == (short) 0);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + short24 + "' != '" + (short) 0 + "'", short24 == (short) 0);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 2, (int) (byte) 10);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        byte byte6 = fraction3.byteValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int8 = fraction7.getNumerator();
        float float9 = fraction7.floatValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.divideBy(fraction7);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction1.multiplyBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction1.pow((int) (short) 97);
        float float15 = fraction1.floatValue();
        int int16 = fraction1.intValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + (-1.0f) + "'", float15 == (-1.0f));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        java.lang.String str10 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.multiplyBy(fraction4);
        java.lang.String str12 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction4.reduce();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        byte byte18 = fraction15.byteValue();
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int20 = fraction19.getNumerator();
        float float21 = fraction19.floatValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction15.divideBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean26 = fraction24.equals((java.lang.Object) fraction25);
        org.apache.commons.lang3.math.Fraction fraction27 = fraction23.divideBy(fraction24);
        long long28 = fraction24.longValue();
        org.apache.commons.lang3.math.Fraction fraction29 = fraction4.divideBy(fraction24);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 0 + "'", byte18 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(fraction29);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.negate();
        int int11 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str15 = fraction14.toProperString();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int18 = fraction17.getNumerator();
        int int19 = fraction17.getDenominator();
        short short20 = fraction17.shortValue();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.negate();
        int int22 = fraction21.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction14.add(fraction21);
        int int24 = fraction1.compareTo(fraction14);
        java.lang.String str25 = fraction14.toProperString();
        int int26 = fraction14.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction14.invert();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1 5/8" + "'", str15.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + short20 + "' != '" + (short) 0 + "'", short20 == (short) 0);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1 5/8" + "'", str25.equals("1 5/8"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(fraction27);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((-200), 100);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 97, (int) (short) 2);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(5, 0, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(97, (-35));
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str8 = fraction7.toString();
        double double9 = fraction7.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction4.add(fraction7);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int14 = fraction13.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str16 = fraction15.toString();
        double double17 = fraction15.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction13.add(fraction15);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction4.divideBy(fraction13);
        int int20 = fraction2.compareTo(fraction13);
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getReducedFraction(8, (-1));
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int26 = fraction25.getNumerator();
        int int27 = fraction25.getDenominator();
        byte byte28 = fraction25.byteValue();
        int int29 = fraction25.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction25.reduce();
        java.lang.String str31 = fraction30.toProperString();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction30.pow((int) (byte) 100);
        int int34 = fraction23.compareTo(fraction33);
        int int35 = fraction23.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction2.divideBy(fraction23);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1/2" + "'", str8.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1/2" + "'", str16.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + byte28 + "' != '" + (byte) 0 + "'", byte28 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-8) + "'", int35 == (-8));
        org.junit.Assert.assertNotNull(fraction36);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.pow((int) (short) -2);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean10 = fraction8.equals((java.lang.Object) fraction9);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.multiplyBy(fraction9);
        java.lang.Class<?> wildcardClass12 = fraction11.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100);
        int int2 = fraction1.intValue();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        short short7 = fraction4.shortValue();
        java.lang.Class<?> wildcardClass8 = fraction4.getClass();
        java.lang.String str9 = fraction4.toProperString();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.multiplyBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) ' ', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction13);
        org.apache.commons.lang3.math.Fraction fraction16 = org.apache.commons.lang3.math.Fraction.getFraction("-2/1");
        org.apache.commons.lang3.math.Fraction fraction17 = fraction4.subtract(fraction16);
        org.apache.commons.lang3.math.Fraction fraction18 = fraction4.negate();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction4.abs();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean11 = fraction9.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int14 = fraction13.getNumerator();
        int int15 = fraction13.getDenominator();
        short short16 = fraction13.shortValue();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction13.negate();
        int int18 = fraction9.compareTo(fraction13);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction9.abs();
        int int20 = fraction19.getProperWhole();
        byte byte21 = fraction19.byteValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction4.add(fraction19);
        java.lang.String str23 = fraction22.toString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + byte21 + "' != '" + (byte) 1 + "'", byte21 == (byte) 1);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-25/104" + "'", str23.equals("-25/104"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        java.lang.String str10 = fraction9.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction9.abs();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction7.divideBy(fraction9);
        int int13 = fraction9.intValue();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction9.abs();
        short short15 = fraction14.shortValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4/5" + "'", str10.equals("4/5"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.add(fraction14);
        float float16 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction2.abs();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_QUARTERS;
        boolean boolean19 = fraction17.equals((java.lang.Object) fraction18);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction17.pow((int) (short) -1);
        int int22 = fraction21.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.625f + "'", float16 == 1.625f);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        byte byte7 = fraction4.byteValue();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean12 = fraction10.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int15 = fraction14.getNumerator();
        int int16 = fraction14.getDenominator();
        short short17 = fraction14.shortValue();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction14.negate();
        int int19 = fraction10.compareTo(fraction14);
        int int20 = fraction10.getProperWhole();
        float float21 = fraction10.floatValue();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction23 = fraction10.add(fraction22);
        int int24 = fraction22.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction22.abs();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.pow((int) (byte) -1);
        int int28 = fraction25.getProperWhole();
        double double29 = fraction25.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction4.divideBy(fraction25);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction32 = fraction31.abs();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean40 = fraction38.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction42 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int43 = fraction42.getNumerator();
        int int44 = fraction42.getDenominator();
        short short45 = fraction42.shortValue();
        org.apache.commons.lang3.math.Fraction fraction46 = fraction42.negate();
        int int47 = fraction38.compareTo(fraction42);
        int int48 = fraction38.getProperWhole();
        float float49 = fraction38.floatValue();
        org.apache.commons.lang3.math.Fraction fraction50 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction51 = fraction38.add(fraction50);
        int int52 = fraction50.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction53 = fraction50.abs();
        org.apache.commons.lang3.math.Fraction fraction55 = fraction53.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction58 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction59 = fraction58.negate();
        org.apache.commons.lang3.math.Fraction fraction60 = fraction59.negate();
        boolean boolean61 = fraction53.equals((java.lang.Object) fraction60);
        org.apache.commons.lang3.math.Fraction fraction62 = fraction35.divideBy(fraction53);
        org.apache.commons.lang3.math.Fraction fraction66 = org.apache.commons.lang3.math.Fraction.getFraction(100, (int) ' ', (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction67 = fraction35.add(fraction66);
        org.apache.commons.lang3.math.Fraction fraction68 = fraction31.add(fraction35);
        byte byte69 = fraction31.byteValue();
        float float70 = fraction31.floatValue();
        org.apache.commons.lang3.math.Fraction fraction71 = fraction25.add(fraction31);
        java.lang.String str72 = fraction31.toProperString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 0 + "'", short17 == (short) 0);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.625f + "'", float21 == 1.625f);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + short45 + "' != '" + (short) 0 + "'", short45 == (short) 0);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 1.625f + "'", float49 == 1.625f);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertNotNull(fraction58);
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertNotNull(fraction60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(fraction62);
        org.junit.Assert.assertNotNull(fraction66);
        org.junit.Assert.assertNotNull(fraction67);
        org.junit.Assert.assertNotNull(fraction68);
        org.junit.Assert.assertTrue("'" + byte69 + "' != '" + (byte) 1 + "'", byte69 == (byte) 1);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(fraction71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "1" + "'", str72.equals("1"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int13 = fraction12.getNumerator();
        float float14 = fraction12.floatValue();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction19 = fraction12.subtract(fraction18);
        int int20 = fraction12.getNumerator();
        int int21 = fraction2.compareTo(fraction12);
        org.apache.commons.lang3.math.Fraction fraction22 = fraction12.invert();
        java.lang.Class<?> wildcardClass23 = fraction22.getClass();
        java.lang.String str24 = fraction22.toString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2/1" + "'", str24.equals("2/1"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction(100.0d);
        int int2 = fraction1.intValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction10.multiplyBy(fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction20.negate();
        long long22 = fraction21.longValue();
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 6, (int) (short) 100, 13);
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean31 = fraction29.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int34 = fraction33.getNumerator();
        int int35 = fraction33.getDenominator();
        short short36 = fraction33.shortValue();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction33.negate();
        int int38 = fraction29.compareTo(fraction33);
        org.apache.commons.lang3.math.Fraction fraction39 = fraction29.abs();
        int int40 = fraction39.getProperWhole();
        byte byte41 = fraction39.byteValue();
        org.apache.commons.lang3.math.Fraction fraction42 = fraction26.subtract(fraction39);
        org.apache.commons.lang3.math.Fraction fraction43 = fraction21.multiplyBy(fraction39);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + short36 + "' != '" + (short) 0 + "'", short36 == (short) 0);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + byte41 + "' != '" + (byte) 1 + "'", byte41 == (byte) 1);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (short) 100);
        long long2 = fraction1.longValue();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE_FIFTH;
        float float4 = fraction3.floatValue();
        boolean boolean5 = fraction1.equals((java.lang.Object) float4);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.2f + "'", float4 == 0.2f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int3 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction2.add(fraction4);
        int int8 = fraction7.getProperWhole();
        int int9 = fraction7.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str13 = fraction12.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        byte byte18 = fraction15.byteValue();
        int int19 = fraction15.getProperWhole();
        int int20 = fraction12.compareTo(fraction15);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction12.negate();
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int23 = fraction22.getNumerator();
        float float24 = fraction22.floatValue();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction22.subtract(fraction28);
        int int30 = fraction22.getNumerator();
        int int31 = fraction12.compareTo(fraction22);
        org.apache.commons.lang3.math.Fraction fraction32 = fraction22.reduce();
        java.lang.Class<?> wildcardClass33 = fraction22.getClass();
        org.apache.commons.lang3.math.Fraction fraction34 = fraction7.divideBy(fraction22);
        org.apache.commons.lang3.math.Fraction fraction38 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) -1, 3, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction39 = fraction34.divideBy(fraction38);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1 5/8" + "'", str13.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 0 + "'", byte18 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.5f + "'", float24 == 0.5f);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.pow((int) (short) -2);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean10 = fraction8.equals((java.lang.Object) fraction9);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction7.multiplyBy(fraction9);
        byte byte12 = fraction9.byteValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.invert();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction13);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int6 = fraction5.getProperWhole();
        double double7 = fraction5.doubleValue();
        double double8 = fraction5.doubleValue();
        int int9 = fraction5.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction4.multiplyBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction5.abs();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.reduce();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction11.pow((-2));
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str18 = fraction17.toProperString();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int21 = fraction20.getNumerator();
        int int22 = fraction20.getDenominator();
        byte byte23 = fraction20.byteValue();
        int int24 = fraction20.getProperWhole();
        int int25 = fraction17.compareTo(fraction20);
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str29 = fraction28.toProperString();
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int32 = fraction31.getNumerator();
        int int33 = fraction31.getDenominator();
        byte byte34 = fraction31.byteValue();
        int int35 = fraction31.getProperWhole();
        int int36 = fraction28.compareTo(fraction31);
        float float37 = fraction28.floatValue();
        org.apache.commons.lang3.math.Fraction fraction38 = fraction20.divideBy(fraction28);
        org.apache.commons.lang3.math.Fraction fraction40 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int41 = fraction40.getNumerator();
        int int42 = fraction40.getDenominator();
        byte byte43 = fraction40.byteValue();
        org.apache.commons.lang3.math.Fraction fraction44 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int45 = fraction44.getNumerator();
        float float46 = fraction44.floatValue();
        org.apache.commons.lang3.math.Fraction fraction47 = fraction40.divideBy(fraction44);
        org.apache.commons.lang3.math.Fraction fraction48 = fraction40.negate();
        org.apache.commons.lang3.math.Fraction fraction49 = fraction40.negate();
        org.apache.commons.lang3.math.Fraction fraction50 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        short short51 = fraction50.shortValue();
        org.apache.commons.lang3.math.Fraction fraction52 = fraction49.divideBy(fraction50);
        org.apache.commons.lang3.math.Fraction fraction53 = fraction28.divideBy(fraction50);
        int int54 = fraction14.compareTo(fraction28);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.75d + "'", double7 == 0.75d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.75d + "'", double8 == 0.75d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1 5/8" + "'", str18.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + byte23 + "' != '" + (byte) 0 + "'", byte23 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1 5/8" + "'", str29.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + byte34 + "' != '" + (byte) 0 + "'", byte34 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.625f + "'", float37 == 1.625f);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + byte43 + "' != '" + (byte) 0 + "'", byte43 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.5f + "'", float46 == 0.5f);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertNotNull(fraction48);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertTrue("'" + short51 + "' != '" + (short) 0 + "'", short51 == (short) 0);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        byte byte7 = fraction4.byteValue();
        int int8 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction4.reduce();
        java.lang.String str10 = fraction9.toString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.multiplyBy(fraction9);
        long long12 = fraction11.longValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0/1" + "'", str10.equals("0/1"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.reduce();
        int int2 = fraction1.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.abs();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str7 = fraction6.toProperString();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction3.multiplyBy(fraction6);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction6.negate();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int12 = fraction11.getNumerator();
        int int13 = fraction11.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str15 = fraction14.toString();
        double double16 = fraction14.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction11.add(fraction14);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction19 = fraction18.reduce();
        java.lang.String str20 = fraction19.toProperString();
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.abs();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction17.divideBy(fraction19);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction9.subtract(fraction22);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        java.lang.Class<?> wildcardClass26 = fraction25.getClass();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction25.abs();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction22.subtract(fraction27);
        long long29 = fraction27.longValue();
        int int30 = fraction27.getProperNumerator();
        java.lang.Class<?> wildcardClass31 = fraction27.getClass();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1 5/8" + "'", str7.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1/2" + "'", str15.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5d + "'", double16 == 0.5d);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "4/5" + "'", str20.equals("4/5"));
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((-5), (-3));
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1/2");
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.pow((-10));
        long long4 = fraction1.longValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(10, (int) (byte) 1);
        int int3 = fraction2.intValue();
        java.lang.Class<?> wildcardClass4 = fraction2.getClass();
        int int5 = fraction2.intValue();
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int8 = fraction7.getNumerator();
        int int9 = fraction7.getDenominator();
        short short10 = fraction7.shortValue();
        boolean boolean12 = fraction7.equals((java.lang.Object) 10);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction2.multiplyBy(fraction7);
        java.lang.Class<?> wildcardClass14 = fraction13.getClass();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("0/1");
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.abs();
        long long3 = fraction1.longValue();
        try {
            org.apache.commons.lang3.math.Fraction fraction5 = fraction1.pow((int) (byte) -3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("-2/5");
        int int2 = fraction1.getProperNumerator();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("53 3/97");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        byte byte6 = fraction3.byteValue();
        int int7 = fraction3.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getReducedFraction(52, (int) 'a');
        org.apache.commons.lang3.math.Fraction fraction11 = fraction3.subtract(fraction10);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction1.multiplyBy(fraction3);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction3.abs();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        try {
            org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, (-4));
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        byte byte6 = fraction1.byteValue();
        short short7 = fraction1.shortValue();
        double double8 = fraction1.doubleValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        short short12 = fraction11.shortValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction10.divideBy(fraction11);
        int int14 = fraction10.intValue();
        byte byte15 = fraction10.byteValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction10.abs();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 0 + "'", byte15 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction16);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 100, (-2));
        int int3 = fraction2.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-50) + "'", int3 == (-50));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) 100, (-2));
        long long3 = fraction2.longValue();
        long long4 = fraction2.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-50L) + "'", long3 == (-50L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-50L) + "'", long4 == (-50L));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(8, (int) (short) 1);
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.negate();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8" + "'", str3.equals("8"));
        org.junit.Assert.assertNotNull(fraction4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(100, (int) (byte) 10, 8);
        java.lang.String str4 = fraction3.toProperString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "101 2/8" + "'", str4.equals("101 2/8"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction10.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.add(fraction10);
        java.lang.String str13 = fraction10.toProperString();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction10.multiplyBy(fraction15);
        short short21 = fraction10.shortValue();
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str26 = fraction25.toProperString();
        int int27 = fraction25.intValue();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction29 = fraction28.reduce();
        int int30 = fraction29.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction31 = fraction29.abs();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction25.add(fraction29);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction10.subtract(fraction29);
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.THREE_FIFTHS;
        long long35 = fraction34.longValue();
        org.apache.commons.lang3.math.Fraction fraction36 = fraction34.abs();
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction38 = fraction37.negate();
        int int39 = fraction38.intValue();
        org.apache.commons.lang3.math.Fraction fraction42 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str43 = fraction42.toProperString();
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int46 = fraction45.getNumerator();
        int int47 = fraction45.getDenominator();
        byte byte48 = fraction45.byteValue();
        int int49 = fraction45.getProperWhole();
        int int50 = fraction42.compareTo(fraction45);
        java.lang.Class<?> wildcardClass51 = fraction45.getClass();
        int int52 = fraction38.compareTo(fraction45);
        boolean boolean53 = fraction34.equals((java.lang.Object) fraction45);
        int int54 = fraction10.compareTo(fraction34);
        org.apache.commons.lang3.math.Fraction fraction55 = fraction34.invert();
        org.apache.commons.lang3.math.Fraction fraction56 = fraction34.reduce();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 0 + "'", short21 == (short) 0);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1 45/52" + "'", str26.equals("1 45/52"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(fraction36);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1 5/8" + "'", str43.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + byte48 + "' != '" + (byte) 0 + "'", byte48 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertNotNull(fraction56);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int3 = fraction2.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction2.add(fraction4);
        float float8 = fraction4.floatValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction4.pow((int) (short) -10);
        java.lang.String str11 = fraction4.toString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1/2" + "'", str11.equals("1/2"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction("1 5/8");
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.subtract(fraction6);
        java.lang.String str8 = fraction6.toString();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13/8" + "'", str8.equals("13/8"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int1 = fraction0.getProperWhole();
        int int2 = fraction0.intValue();
        int int3 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction0.abs();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(fraction4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) 'a', 173);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.abs();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction(100, 5);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction3.divideBy(fraction9);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("1/2");
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.pow((-10));
        java.lang.Class<?> wildcardClass4 = fraction1.getClass();
        long long5 = fraction1.longValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        byte byte7 = fraction4.byteValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction4.abs();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        int int11 = fraction9.getProperWhole();
        java.lang.Class<?> wildcardClass12 = fraction9.getClass();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction8.add(fraction9);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.reduce();
        long long15 = fraction13.longValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        float float8 = fraction4.floatValue();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        int int11 = fraction10.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.abs();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str16 = fraction15.toProperString();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction12.multiplyBy(fraction15);
        boolean boolean18 = fraction4.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction22.negate();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction22.negate();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int28 = fraction27.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str30 = fraction29.toString();
        double double31 = fraction29.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction27.add(fraction29);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction24.add(fraction32);
        int int34 = fraction12.compareTo(fraction32);
        try {
            org.apache.commons.lang3.math.Fraction fraction36 = fraction32.pow((-97));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1 5/8" + "'", str16.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1/2" + "'", str30.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.5d + "'", double31 == 0.5d);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int1 = fraction0.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean6 = fraction4.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        int int13 = fraction12.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction12);
        java.lang.String str15 = fraction12.toProperString();
        boolean boolean16 = fraction0.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, (int) '4');
        int int20 = fraction0.compareTo(fraction19);
        org.apache.commons.lang3.math.Fraction fraction21 = fraction19.negate();
        short short22 = fraction21.shortValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + short22 + "' != '" + (short) 0 + "'", short22 == (short) 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        float float8 = fraction4.floatValue();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        int int11 = fraction10.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.abs();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str16 = fraction15.toProperString();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction12.multiplyBy(fraction15);
        boolean boolean18 = fraction4.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction23 = fraction22.negate();
        org.apache.commons.lang3.math.Fraction fraction24 = fraction22.negate();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int28 = fraction27.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction29 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str30 = fraction29.toString();
        double double31 = fraction29.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction27.add(fraction29);
        org.apache.commons.lang3.math.Fraction fraction33 = fraction24.add(fraction32);
        int int34 = fraction12.compareTo(fraction32);
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.TWO_THIRDS;
        byte byte36 = fraction35.byteValue();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction35.abs();
        org.apache.commons.lang3.math.Fraction fraction41 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        int int42 = fraction41.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction44 = fraction41.pow((int) (byte) -2);
        org.apache.commons.lang3.math.Fraction fraction45 = fraction35.multiplyBy(fraction44);
        org.apache.commons.lang3.math.Fraction fraction46 = fraction12.multiplyBy(fraction45);
        float float47 = fraction12.floatValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1 5/8" + "'", str16.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1/2" + "'", str30.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.5d + "'", double31 == 0.5d);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + byte36 + "' != '" + (byte) 0 + "'", byte36 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 97 + "'", int42 == 97);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.8f + "'", float47 == 0.8f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        float float11 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = org.apache.commons.lang3.math.Fraction.getFraction("1/5");
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        byte byte18 = fraction15.byteValue();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getFraction("1 5/8");
        org.apache.commons.lang3.math.Fraction fraction21 = fraction15.subtract(fraction20);
        int int22 = fraction13.compareTo(fraction15);
        java.lang.String str23 = fraction15.toProperString();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        short short25 = fraction24.shortValue();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int28 = fraction27.getNumerator();
        int int29 = fraction27.getDenominator();
        byte byte30 = fraction27.byteValue();
        int int31 = fraction27.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction27.abs();
        int int33 = fraction24.compareTo(fraction27);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction27.reduce();
        boolean boolean35 = fraction15.equals((java.lang.Object) fraction34);
        org.apache.commons.lang3.math.Fraction fraction36 = fraction2.subtract(fraction15);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.625f + "'", float11 == 1.625f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 0 + "'", byte18 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + byte30 + "' != '" + (byte) 0 + "'", byte30 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(fraction36);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.negate();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        byte byte5 = fraction4.byteValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str9 = fraction8.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int12 = fraction11.getNumerator();
        int int13 = fraction11.getDenominator();
        byte byte14 = fraction11.byteValue();
        int int15 = fraction11.getProperWhole();
        int int16 = fraction8.compareTo(fraction11);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int19 = fraction18.getNumerator();
        float float20 = fraction18.floatValue();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction18.subtract(fraction24);
        int int26 = fraction18.getNumerator();
        int int27 = fraction8.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction4.multiplyBy(fraction8);
        java.lang.String str29 = fraction8.toString();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1 5/8" + "'", str9.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13/8" + "'", str29.equals("13/8"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        short short4 = fraction1.shortValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.negate();
        int int6 = fraction5.getNumerator();
        java.lang.Class<?> wildcardClass7 = fraction5.getClass();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction8.invert();
        boolean boolean11 = fraction5.equals((java.lang.Object) fraction8);
        double double12 = fraction8.doubleValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.8d + "'", double12 == 0.8d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str5 = fraction4.toString();
        double double6 = fraction4.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.add(fraction4);
        float float8 = fraction4.floatValue();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction10 = fraction9.reduce();
        int int11 = fraction10.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction10.abs();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str16 = fraction15.toProperString();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction12.multiplyBy(fraction15);
        boolean boolean18 = fraction4.equals((java.lang.Object) fraction12);
        int int19 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.getFraction((int) 'a', 0, (int) (short) 1);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction23.negate();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.negate();
        org.apache.commons.lang3.math.Fraction fraction28 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        int int29 = fraction28.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction30 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        java.lang.String str31 = fraction30.toString();
        double double32 = fraction30.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction33 = fraction28.add(fraction30);
        org.apache.commons.lang3.math.Fraction fraction34 = fraction25.add(fraction33);
        org.apache.commons.lang3.math.Fraction fraction35 = fraction4.multiplyBy(fraction34);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/2" + "'", str5.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1 5/8" + "'", str16.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1/2" + "'", str31.equals("1/2"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.5d + "'", double32 == 0.5d);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (byte) -2, (-97));
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 0, (int) '4');
        java.lang.Class<?> wildcardClass3 = fraction2.getClass();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        java.lang.Class<?> wildcardClass12 = fraction6.getClass();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction6.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(fraction13);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) -35, 10);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) (-3));
        org.apache.commons.lang3.math.Fraction fraction5 = fraction2.multiplyBy(fraction4);
        int int6 = fraction2.getDenominator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("13/16");
        org.junit.Assert.assertNotNull(fraction1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 2);
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean4 = fraction2.equals((java.lang.Object) fraction3);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        int int6 = fraction1.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.negate();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.subtract(fraction9);
        float float11 = fraction1.floatValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction1.pow(12);
        short short14 = fraction1.shortValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 2 + "'", short14 == (short) 2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        int int12 = fraction2.getProperWhole();
        float float13 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction15 = fraction2.add(fraction14);
        float float16 = fraction2.floatValue();
        org.apache.commons.lang3.math.Fraction fraction17 = fraction2.abs();
        byte byte18 = fraction17.byteValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.625f + "'", float13 == 1.625f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.625f + "'", float16 == 1.625f);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 1 + "'", byte18 == (byte) 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((-8), (-10));
        org.apache.commons.lang3.math.Fraction fraction3 = fraction2.abs();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.reduce();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean2 = fraction0.equals((java.lang.Object) fraction1);
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.negate();
        long long4 = fraction3.longValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.pow((int) (short) -2);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int9 = fraction8.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int12 = fraction11.getNumerator();
        int int13 = fraction11.getDenominator();
        short short14 = fraction11.shortValue();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction11.negate();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction8.multiplyBy(fraction11);
        java.lang.String str17 = fraction11.toString();
        long long18 = fraction11.longValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction7.subtract(fraction11);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean24 = fraction22.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int27 = fraction26.getNumerator();
        int int28 = fraction26.getDenominator();
        short short29 = fraction26.shortValue();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction26.negate();
        int int31 = fraction30.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction22.add(fraction30);
        java.lang.String str33 = fraction30.toProperString();
        org.apache.commons.lang3.math.Fraction fraction35 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int36 = fraction35.getNumerator();
        int int37 = fraction35.getDenominator();
        short short38 = fraction35.shortValue();
        org.apache.commons.lang3.math.Fraction fraction39 = fraction35.negate();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction30.multiplyBy(fraction35);
        org.apache.commons.lang3.math.Fraction fraction41 = fraction35.reduce();
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction46 = fraction45.negate();
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int48 = fraction47.getProperWhole();
        double double49 = fraction47.doubleValue();
        double double50 = fraction47.doubleValue();
        int int51 = fraction47.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction52 = fraction46.multiplyBy(fraction47);
        org.apache.commons.lang3.math.Fraction fraction53 = fraction41.multiplyBy(fraction52);
        org.apache.commons.lang3.math.Fraction fraction54 = fraction11.subtract(fraction41);
        byte byte55 = fraction41.byteValue();
        int int56 = fraction41.getDenominator();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0/1" + "'", str17.equals("0/1"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + short29 + "' != '" + (short) 0 + "'", short29 == (short) 0);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "0" + "'", str33.equals("0"));
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + short38 + "' != '" + (short) 0 + "'", short38 == (short) 0);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.75d + "'", double49 == 0.75d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.75d + "'", double50 == 0.75d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 3 + "'", int51 == 3);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertTrue("'" + byte55 + "' != '" + (byte) 0 + "'", byte55 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(0, (int) ' ', (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 100);
        int int6 = fraction5.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        java.lang.Class<?> wildcardClass12 = fraction8.getClass();
        java.lang.String str13 = fraction8.toProperString();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction5.multiplyBy(fraction8);
        org.apache.commons.lang3.math.Fraction fraction15 = fraction8.abs();
        double double16 = fraction15.doubleValue();
        boolean boolean17 = fraction3.equals((java.lang.Object) double16);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        java.lang.Class<?> wildcardClass2 = fraction1.getClass();
        org.apache.commons.lang3.math.Fraction fraction3 = fraction1.abs();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.abs();
        java.lang.Class<?> wildcardClass6 = fraction5.getClass();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) (short) 100);
        org.apache.commons.lang3.math.Fraction fraction2 = fraction1.reduce();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        byte byte7 = fraction4.byteValue();
        int int8 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction4.reduce();
        java.lang.String str10 = fraction9.toString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.multiplyBy(fraction9);
        java.lang.Class<?> wildcardClass12 = fraction11.getClass();
        int int13 = fraction11.intValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0/1" + "'", str10.equals("0/1"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        boolean boolean12 = fraction10.equals((java.lang.Object) fraction11);
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.divideBy(fraction10);
        org.apache.commons.lang3.math.Fraction fraction14 = fraction13.negate();
        try {
            org.apache.commons.lang3.math.Fraction fraction15 = fraction13.invert();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Unable to invert zero.");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertNotNull(fraction14);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction(100, (int) ' ', (int) ' ');
        java.lang.String str4 = fraction3.toProperString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "101" + "'", str4.equals("101"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction1 = fraction0.abs();
        int int2 = fraction1.getProperNumerator();
        short short3 = fraction1.shortValue();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction("1 45/52");
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.negate();
        int int9 = fraction4.compareTo(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction2.divideBy(fraction8);
        long long11 = fraction10.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction(4, (int) (byte) 103);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("3/4");
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction(3, (int) (byte) 6);
        org.apache.commons.lang3.math.Fraction fraction5 = fraction1.subtract(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.ONE_THIRD;
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.add(fraction7);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.abs();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.subtract(fraction9);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str3 = fraction2.toProperString();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int6 = fraction5.getNumerator();
        int int7 = fraction5.getDenominator();
        byte byte8 = fraction5.byteValue();
        int int9 = fraction5.getProperWhole();
        int int10 = fraction2.compareTo(fraction5);
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.negate();
        long long12 = fraction11.longValue();
        double double13 = fraction11.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction19 = fraction17.divideBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction20 = fraction18.abs();
        double double21 = fraction18.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.negate();
        boolean boolean23 = fraction11.equals((java.lang.Object) fraction22);
        org.apache.commons.lang3.math.Fraction fraction26 = org.apache.commons.lang3.math.Fraction.getFraction(10, (int) (byte) 1);
        int int27 = fraction26.intValue();
        java.lang.Class<?> wildcardClass28 = fraction26.getClass();
        int int29 = fraction26.intValue();
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int32 = fraction31.getNumerator();
        int int33 = fraction31.getDenominator();
        short short34 = fraction31.shortValue();
        boolean boolean36 = fraction31.equals((java.lang.Object) 10);
        org.apache.commons.lang3.math.Fraction fraction37 = fraction26.multiplyBy(fraction31);
        int int38 = fraction26.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction40 = fraction26.pow((int) (short) 0);
        org.apache.commons.lang3.math.Fraction fraction43 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean45 = fraction43.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int48 = fraction47.getNumerator();
        int int49 = fraction47.getDenominator();
        short short50 = fraction47.shortValue();
        org.apache.commons.lang3.math.Fraction fraction51 = fraction47.negate();
        int int52 = fraction43.compareTo(fraction47);
        int int53 = fraction43.getProperWhole();
        float float54 = fraction43.floatValue();
        org.apache.commons.lang3.math.Fraction fraction55 = org.apache.commons.lang3.math.Fraction.THREE_QUARTERS;
        int int56 = fraction55.getProperWhole();
        double double57 = fraction55.doubleValue();
        double double58 = fraction55.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction59 = fraction43.subtract(fraction55);
        org.apache.commons.lang3.math.Fraction fraction60 = fraction26.multiplyBy(fraction43);
        long long61 = fraction60.longValue();
        int int62 = fraction22.compareTo(fraction60);
        int int63 = fraction60.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 5/8" + "'", str3.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.625d) + "'", double13 == (-1.625d));
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.4d + "'", double21 == 0.4d);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + short34 + "' != '" + (short) 0 + "'", short34 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + short50 + "' != '" + (short) 0 + "'", short50 == (short) 0);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 1.625f + "'", float54 == 1.625f);
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.75d + "'", double57 == 0.75d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.75d + "'", double58 == 0.75d);
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertNotNull(fraction60);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 16L + "'", long61 == 16L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 65 + "'", int63 == 65);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, (int) (short) 103);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        long long5 = fraction1.longValue();
        java.lang.String str6 = fraction1.toString();
        long long7 = fraction1.longValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0/1" + "'", str6.equals("0/1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(1, 5);
        int int3 = fraction2.intValue();
        int int4 = fraction2.intValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction(32, (-200));
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int5 = fraction4.getNumerator();
        int int6 = fraction4.getDenominator();
        byte byte7 = fraction4.byteValue();
        int int8 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction4.reduce();
        java.lang.String str10 = fraction9.toString();
        org.apache.commons.lang3.math.Fraction fraction11 = fraction2.multiplyBy(fraction9);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0/1" + "'", str10.equals("0/1"));
        org.junit.Assert.assertNotNull(fraction11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        int int5 = fraction1.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.negate();
        double double7 = fraction6.doubleValue();
        java.lang.Class<?> wildcardClass8 = fraction6.getClass();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean13 = fraction11.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int16 = fraction15.getNumerator();
        int int17 = fraction15.getDenominator();
        short short18 = fraction15.shortValue();
        org.apache.commons.lang3.math.Fraction fraction19 = fraction15.negate();
        int int20 = fraction11.compareTo(fraction15);
        int int21 = fraction11.getProperWhole();
        float float22 = fraction11.floatValue();
        org.apache.commons.lang3.math.Fraction fraction23 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction24 = fraction11.add(fraction23);
        int int25 = fraction23.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction6.divideBy(fraction23);
        int int27 = fraction23.getNumerator();
        short short28 = fraction23.shortValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.625f + "'", float22 == 1.625f);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + short28 + "' != '" + (short) 1 + "'", short28 == (short) 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, (int) '#');
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean7 = fraction5.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int10 = fraction9.getNumerator();
        int int11 = fraction9.getDenominator();
        short short12 = fraction9.shortValue();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction9.negate();
        int int14 = fraction5.compareTo(fraction9);
        int int15 = fraction5.getProperWhole();
        float float16 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction17 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction18 = fraction5.add(fraction17);
        int int19 = fraction17.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction20 = fraction17.abs();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction20.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction25 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 10, (int) (byte) 100);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction25.negate();
        org.apache.commons.lang3.math.Fraction fraction27 = fraction26.negate();
        boolean boolean28 = fraction20.equals((java.lang.Object) fraction27);
        org.apache.commons.lang3.math.Fraction fraction29 = fraction2.divideBy(fraction20);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.getFraction(100, (int) ' ', (int) ' ');
        org.apache.commons.lang3.math.Fraction fraction34 = fraction2.add(fraction33);
        org.apache.commons.lang3.math.Fraction fraction35 = fraction34.reduce();
        float float36 = fraction35.floatValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.625f + "'", float16 == 1.625f);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(fraction29);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 101.02857f + "'", float36 == 101.02857f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        try {
            org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((-13), (int) (byte) 1, (-35));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The denominator must not be negative");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 2);
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 1, (int) 'a', 2);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction1.add(fraction5);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction("80/1");
        org.apache.commons.lang3.math.Fraction fraction9 = fraction5.divideBy(fraction8);
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((-8), (int) (byte) -1);
        org.junit.Assert.assertNotNull(fraction2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int4 = fraction3.getNumerator();
        int int5 = fraction3.getDenominator();
        short short6 = fraction3.shortValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction0.multiplyBy(fraction3);
        int int9 = fraction8.getProperNumerator();
        java.lang.String str10 = fraction8.toString();
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0/1" + "'", str10.equals("0/1"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int6 = fraction5.getNumerator();
        float float7 = fraction5.floatValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction1.divideBy(fraction5);
        org.apache.commons.lang3.math.Fraction fraction9 = fraction1.negate();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction1.negate();
        float float11 = fraction1.floatValue();
        org.apache.commons.lang3.math.Fraction fraction14 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean16 = fraction14.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int19 = fraction18.getNumerator();
        int int20 = fraction18.getDenominator();
        short short21 = fraction18.shortValue();
        org.apache.commons.lang3.math.Fraction fraction22 = fraction18.negate();
        int int23 = fraction14.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction24 = fraction14.abs();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean29 = fraction27.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int32 = fraction31.getNumerator();
        int int33 = fraction31.getDenominator();
        short short34 = fraction31.shortValue();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction31.negate();
        int int36 = fraction27.compareTo(fraction31);
        int int37 = fraction27.getProperWhole();
        float float38 = fraction27.floatValue();
        org.apache.commons.lang3.math.Fraction fraction39 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction40 = fraction27.add(fraction39);
        int int41 = fraction39.getDenominator();
        short short42 = fraction39.shortValue();
        long long43 = fraction39.longValue();
        org.apache.commons.lang3.math.Fraction fraction44 = fraction14.divideBy(fraction39);
        org.apache.commons.lang3.math.Fraction fraction46 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int47 = fraction46.getNumerator();
        int int48 = fraction46.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction52 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction53 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction54 = fraction52.divideBy(fraction53);
        org.apache.commons.lang3.math.Fraction fraction55 = fraction46.divideBy(fraction53);
        org.apache.commons.lang3.math.Fraction fraction56 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction57 = fraction56.reduce();
        boolean boolean58 = fraction53.equals((java.lang.Object) fraction56);
        org.apache.commons.lang3.math.Fraction fraction59 = fraction39.add(fraction53);
        org.apache.commons.lang3.math.Fraction fraction60 = fraction1.divideBy(fraction39);
        float float61 = fraction39.floatValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 0 + "'", short21 == (short) 0);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + short34 + "' != '" + (short) 0 + "'", short34 == (short) 0);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.625f + "'", float38 == 1.625f);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + short42 + "' != '" + (short) 1 + "'", short42 == (short) 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(fraction52);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertNotNull(fraction56);
        org.junit.Assert.assertNotNull(fraction57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(fraction59);
        org.junit.Assert.assertNotNull(fraction60);
        org.junit.Assert.assertTrue("'" + float61 + "' != '" + 1.0f + "'", float61 == 1.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int2 = fraction1.getNumerator();
        int int3 = fraction1.getDenominator();
        byte byte4 = fraction1.byteValue();
        float float5 = fraction1.floatValue();
        org.apache.commons.lang3.math.Fraction fraction7 = fraction1.pow((int) (byte) 0);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.invert();
        org.apache.commons.lang3.math.Fraction fraction9 = fraction8.reduce();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertNotNull(fraction9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 10, 2);
        byte byte4 = fraction3.byteValue();
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.reduce();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 6 + "'", byte4 == (byte) 6);
        org.junit.Assert.assertNotNull(fraction5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str4 = fraction3.toProperString();
        int int5 = fraction3.intValue();
        int int6 = fraction3.getDenominator();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1 45/52" + "'", str4.equals("1 45/52"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) '4', (int) (byte) 100, (int) 'a');
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction("0/1");
        org.apache.commons.lang3.math.Fraction fraction6 = fraction5.abs();
        int int7 = fraction6.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction12 = fraction11.negate();
        org.apache.commons.lang3.math.Fraction fraction13 = fraction12.abs();
        int int14 = fraction12.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction6.multiplyBy(fraction12);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction3.divideBy(fraction12);
        byte byte17 = fraction12.byteValue();
        java.lang.Class<?> wildcardClass18 = fraction12.getClass();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) -1 + "'", byte17 == (byte) -1);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int1 = fraction0.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction2 = fraction0.invert();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.getFraction(10, (int) (byte) 1);
        int int6 = fraction5.intValue();
        java.lang.Class<?> wildcardClass7 = fraction5.getClass();
        int int8 = fraction5.intValue();
        org.apache.commons.lang3.math.Fraction fraction10 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int11 = fraction10.getNumerator();
        int int12 = fraction10.getDenominator();
        short short13 = fraction10.shortValue();
        boolean boolean15 = fraction10.equals((java.lang.Object) 10);
        org.apache.commons.lang3.math.Fraction fraction16 = fraction5.multiplyBy(fraction10);
        int int17 = fraction5.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean22 = fraction20.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int25 = fraction24.getNumerator();
        int int26 = fraction24.getDenominator();
        short short27 = fraction24.shortValue();
        org.apache.commons.lang3.math.Fraction fraction28 = fraction24.negate();
        int int29 = fraction28.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction20.add(fraction28);
        java.lang.String str31 = fraction28.toProperString();
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int34 = fraction33.getNumerator();
        int int35 = fraction33.getDenominator();
        short short36 = fraction33.shortValue();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction33.negate();
        org.apache.commons.lang3.math.Fraction fraction38 = fraction28.multiplyBy(fraction33);
        org.apache.commons.lang3.math.Fraction fraction39 = fraction33.reduce();
        short short40 = fraction39.shortValue();
        org.apache.commons.lang3.math.Fraction fraction41 = fraction5.subtract(fraction39);
        org.apache.commons.lang3.math.Fraction fraction42 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int43 = fraction42.getNumerator();
        float float44 = fraction42.floatValue();
        int int45 = fraction42.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction48 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 100, 4);
        org.apache.commons.lang3.math.Fraction fraction49 = fraction42.divideBy(fraction48);
        org.apache.commons.lang3.math.Fraction fraction50 = fraction39.divideBy(fraction42);
        org.apache.commons.lang3.math.Fraction fraction51 = fraction2.divideBy(fraction42);
        org.apache.commons.lang3.math.Fraction fraction55 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long56 = fraction55.longValue();
        int int57 = fraction55.intValue();
        short short58 = fraction55.shortValue();
        double double59 = fraction55.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction60 = fraction51.divideBy(fraction55);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + short27 + "' != '" + (short) 0 + "'", short27 == (short) 0);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + short36 + "' != '" + (short) 0 + "'", short36 == (short) 0);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction38);
        org.junit.Assert.assertNotNull(fraction39);
        org.junit.Assert.assertTrue("'" + short40 + "' != '" + (short) 0 + "'", short40 == (short) 0);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.5f + "'", float44 == 0.5f);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(fraction48);
        org.junit.Assert.assertNotNull(fraction49);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertNotNull(fraction55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2L) + "'", long56 == (-2L));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-2) + "'", int57 == (-2));
        org.junit.Assert.assertTrue("'" + short58 + "' != '" + (short) -2 + "'", short58 == (short) -2);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + (-2.0d) + "'", double59 == (-2.0d));
        org.junit.Assert.assertNotNull(fraction60);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.lang3.math.Fraction fraction0 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        int int1 = fraction0.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean6 = fraction4.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int9 = fraction8.getNumerator();
        int int10 = fraction8.getDenominator();
        short short11 = fraction8.shortValue();
        org.apache.commons.lang3.math.Fraction fraction12 = fraction8.negate();
        int int13 = fraction12.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction14 = fraction4.add(fraction12);
        java.lang.String str15 = fraction12.toProperString();
        boolean boolean16 = fraction0.equals((java.lang.Object) fraction12);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 1, (int) '4');
        int int20 = fraction0.compareTo(fraction19);
        org.apache.commons.lang3.math.Fraction fraction22 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int23 = fraction22.getNumerator();
        int int24 = fraction22.getDenominator();
        short short25 = fraction22.shortValue();
        org.apache.commons.lang3.math.Fraction fraction26 = fraction22.negate();
        int int27 = fraction26.getNumerator();
        java.lang.Class<?> wildcardClass28 = fraction26.getClass();
        java.lang.Class<?> wildcardClass29 = fraction26.getClass();
        org.apache.commons.lang3.math.Fraction fraction30 = fraction19.add(fraction26);
        org.apache.commons.lang3.math.Fraction fraction31 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction32 = fraction31.reduce();
        int int33 = fraction31.getProperWhole();
        java.lang.Class<?> wildcardClass34 = fraction31.getClass();
        org.apache.commons.lang3.math.Fraction fraction35 = fraction26.add(fraction31);
        org.apache.commons.lang3.math.Fraction fraction37 = org.apache.commons.lang3.math.Fraction.getFraction((double) (short) 0);
        org.apache.commons.lang3.math.Fraction fraction41 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) 1, 10, 2);
        int int42 = fraction41.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction45 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction47 = org.apache.commons.lang3.math.Fraction.getFraction("1 45/52");
        org.apache.commons.lang3.math.Fraction fraction50 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction51 = fraction50.negate();
        int int52 = fraction47.compareTo(fraction51);
        org.apache.commons.lang3.math.Fraction fraction53 = fraction45.divideBy(fraction51);
        org.apache.commons.lang3.math.Fraction fraction54 = fraction41.subtract(fraction53);
        byte byte55 = fraction54.byteValue();
        float float56 = fraction54.floatValue();
        org.apache.commons.lang3.math.Fraction fraction57 = fraction37.divideBy(fraction54);
        org.apache.commons.lang3.math.Fraction fraction58 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int59 = fraction58.getNumerator();
        org.apache.commons.lang3.math.Fraction fraction61 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int62 = fraction61.getNumerator();
        int int63 = fraction61.getDenominator();
        short short64 = fraction61.shortValue();
        org.apache.commons.lang3.math.Fraction fraction65 = fraction61.negate();
        org.apache.commons.lang3.math.Fraction fraction66 = fraction58.multiplyBy(fraction61);
        short short67 = fraction66.shortValue();
        org.apache.commons.lang3.math.Fraction fraction68 = fraction66.abs();
        org.apache.commons.lang3.math.Fraction fraction70 = fraction68.pow(0);
        org.apache.commons.lang3.math.Fraction fraction71 = fraction54.multiplyBy(fraction68);
        int int72 = fraction35.compareTo(fraction54);
        org.junit.Assert.assertNotNull(fraction0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(fraction14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(fraction22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(fraction30);
        org.junit.Assert.assertNotNull(fraction31);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertNotNull(fraction50);
        org.junit.Assert.assertNotNull(fraction51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(fraction53);
        org.junit.Assert.assertNotNull(fraction54);
        org.junit.Assert.assertTrue("'" + byte55 + "' != '" + (byte) 7 + "'", byte55 == (byte) 7);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 7.0f + "'", float56 == 7.0f);
        org.junit.Assert.assertNotNull(fraction57);
        org.junit.Assert.assertNotNull(fraction58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(fraction61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + short64 + "' != '" + (short) 0 + "'", short64 == (short) 0);
        org.junit.Assert.assertNotNull(fraction65);
        org.junit.Assert.assertNotNull(fraction66);
        org.junit.Assert.assertTrue("'" + short67 + "' != '" + (short) 0 + "'", short67 == (short) 0);
        org.junit.Assert.assertNotNull(fraction68);
        org.junit.Assert.assertNotNull(fraction70);
        org.junit.Assert.assertNotNull(fraction71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        org.apache.commons.lang3.math.Fraction fraction4 = fraction3.negate();
        org.apache.commons.lang3.math.Fraction fraction5 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        java.lang.String str9 = fraction8.toProperString();
        org.apache.commons.lang3.math.Fraction fraction11 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int12 = fraction11.getNumerator();
        int int13 = fraction11.getDenominator();
        byte byte14 = fraction11.byteValue();
        int int15 = fraction11.getProperWhole();
        int int16 = fraction8.compareTo(fraction11);
        org.apache.commons.lang3.math.Fraction fraction17 = fraction8.negate();
        org.apache.commons.lang3.math.Fraction fraction18 = org.apache.commons.lang3.math.Fraction.ONE_HALF;
        int int19 = fraction18.getNumerator();
        float float20 = fraction18.floatValue();
        org.apache.commons.lang3.math.Fraction fraction24 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction25 = fraction18.subtract(fraction24);
        int int26 = fraction18.getNumerator();
        int int27 = fraction8.compareTo(fraction18);
        org.apache.commons.lang3.math.Fraction fraction28 = fraction5.multiplyBy(fraction18);
        org.apache.commons.lang3.math.Fraction fraction32 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction33 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction34 = fraction32.divideBy(fraction33);
        org.apache.commons.lang3.math.Fraction fraction35 = fraction33.abs();
        double double36 = fraction33.doubleValue();
        org.apache.commons.lang3.math.Fraction fraction37 = fraction5.subtract(fraction33);
        int int38 = fraction33.getProperNumerator();
        boolean boolean39 = fraction4.equals((java.lang.Object) int38);
        java.lang.String str40 = fraction4.toProperString();
        java.lang.String str41 = fraction4.toProperString();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1 5/8" + "'", str9.equals("1 5/8"));
        org.junit.Assert.assertNotNull(fraction11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 0 + "'", byte14 == (byte) 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(fraction17);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNotNull(fraction24);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction33);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertNotNull(fraction35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.4d + "'", double36 == 0.4d);
        org.junit.Assert.assertNotNull(fraction37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "-1 45/52" + "'", str40.equals("-1 45/52"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "-1 45/52" + "'", str41.equals("-1 45/52"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.apache.commons.lang3.math.Fraction fraction1 = org.apache.commons.lang3.math.Fraction.getFraction("3/5");
        long long2 = fraction1.longValue();
        org.junit.Assert.assertNotNull(fraction1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        long long4 = fraction3.longValue();
        int int5 = fraction3.intValue();
        org.apache.commons.lang3.math.Fraction fraction8 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean10 = fraction8.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int13 = fraction12.getNumerator();
        int int14 = fraction12.getDenominator();
        short short15 = fraction12.shortValue();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction12.negate();
        int int17 = fraction8.compareTo(fraction12);
        int int18 = fraction8.getProperWhole();
        float float19 = fraction8.floatValue();
        org.apache.commons.lang3.math.Fraction fraction20 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction21 = fraction8.add(fraction20);
        int int22 = fraction20.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction20.abs();
        org.apache.commons.lang3.math.Fraction fraction25 = fraction23.pow((int) (byte) -1);
        org.apache.commons.lang3.math.Fraction fraction26 = fraction3.subtract(fraction25);
        float float27 = fraction3.floatValue();
        byte byte28 = fraction3.byteValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2L) + "'", long4 == (-2L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2) + "'", int5 == (-2));
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.625f + "'", float19 == 1.625f);
        org.junit.Assert.assertNotNull(fraction20);
        org.junit.Assert.assertNotNull(fraction21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertNotNull(fraction25);
        org.junit.Assert.assertNotNull(fraction26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + (-2.0f) + "'", float27 == (-2.0f));
        org.junit.Assert.assertTrue("'" + byte28 + "' != '" + (byte) -2 + "'", byte28 == (byte) -2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getFraction((-2), (int) (byte) 100);
        short short3 = fraction2.shortValue();
        org.apache.commons.lang3.math.Fraction fraction4 = fraction2.abs();
        int int5 = fraction4.getProperWhole();
        org.apache.commons.lang3.math.Fraction fraction9 = org.apache.commons.lang3.math.Fraction.getFraction((int) (byte) 0, (int) 'a', (int) '4');
        java.lang.String str10 = fraction9.toProperString();
        int int11 = fraction9.intValue();
        org.apache.commons.lang3.math.Fraction fraction12 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction13 = fraction12.reduce();
        int int14 = fraction13.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction15 = fraction13.abs();
        org.apache.commons.lang3.math.Fraction fraction16 = fraction9.add(fraction13);
        int int17 = fraction16.getProperNumerator();
        org.apache.commons.lang3.math.Fraction fraction18 = fraction4.multiplyBy(fraction16);
        int int19 = fraction4.getProperWhole();
        int int20 = fraction4.getNumerator();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(fraction9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 45/52" + "'", str10.equals("1 45/52"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertNotNull(fraction16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 173 + "'", int17 == 173);
        org.junit.Assert.assertNotNull(fraction18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.lang3.math.Fraction fraction3 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction5 = fraction3.divideBy(fraction4);
        org.apache.commons.lang3.math.Fraction fraction6 = fraction4.abs();
        long long7 = fraction6.longValue();
        org.apache.commons.lang3.math.Fraction fraction8 = fraction6.abs();
        double double9 = fraction6.doubleValue();
        org.junit.Assert.assertNotNull(fraction3);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction5);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.4d + "'", double9 == 0.4d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction4 = org.apache.commons.lang3.math.Fraction.getFraction("1 45/52");
        org.apache.commons.lang3.math.Fraction fraction7 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) (short) 10, 1);
        org.apache.commons.lang3.math.Fraction fraction8 = fraction7.negate();
        int int9 = fraction4.compareTo(fraction8);
        org.apache.commons.lang3.math.Fraction fraction10 = fraction2.divideBy(fraction8);
        java.lang.Class<?> wildcardClass11 = fraction8.getClass();
        long long12 = fraction8.longValue();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertNotNull(fraction4);
        org.junit.Assert.assertNotNull(fraction7);
        org.junit.Assert.assertNotNull(fraction8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-10L) + "'", long12 == (-10L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.lang3.math.Fraction fraction2 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean4 = fraction2.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction6 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int7 = fraction6.getNumerator();
        int int8 = fraction6.getDenominator();
        short short9 = fraction6.shortValue();
        org.apache.commons.lang3.math.Fraction fraction10 = fraction6.negate();
        int int11 = fraction2.compareTo(fraction6);
        org.apache.commons.lang3.math.Fraction fraction12 = fraction2.abs();
        org.apache.commons.lang3.math.Fraction fraction15 = org.apache.commons.lang3.math.Fraction.getReducedFraction((int) '4', (int) ' ');
        boolean boolean17 = fraction15.equals((java.lang.Object) 0L);
        org.apache.commons.lang3.math.Fraction fraction19 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int20 = fraction19.getNumerator();
        int int21 = fraction19.getDenominator();
        short short22 = fraction19.shortValue();
        org.apache.commons.lang3.math.Fraction fraction23 = fraction19.negate();
        int int24 = fraction15.compareTo(fraction19);
        int int25 = fraction15.getProperWhole();
        float float26 = fraction15.floatValue();
        org.apache.commons.lang3.math.Fraction fraction27 = org.apache.commons.lang3.math.Fraction.ONE;
        org.apache.commons.lang3.math.Fraction fraction28 = fraction15.add(fraction27);
        int int29 = fraction27.getDenominator();
        short short30 = fraction27.shortValue();
        long long31 = fraction27.longValue();
        org.apache.commons.lang3.math.Fraction fraction32 = fraction2.divideBy(fraction27);
        org.apache.commons.lang3.math.Fraction fraction34 = org.apache.commons.lang3.math.Fraction.getFraction((double) 0.0f);
        int int35 = fraction34.getNumerator();
        int int36 = fraction34.getDenominator();
        org.apache.commons.lang3.math.Fraction fraction40 = org.apache.commons.lang3.math.Fraction.getFraction((int) (short) -1, 1, (int) (byte) 1);
        org.apache.commons.lang3.math.Fraction fraction41 = org.apache.commons.lang3.math.Fraction.TWO_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction42 = fraction40.divideBy(fraction41);
        org.apache.commons.lang3.math.Fraction fraction43 = fraction34.divideBy(fraction41);
        org.apache.commons.lang3.math.Fraction fraction44 = org.apache.commons.lang3.math.Fraction.FOUR_FIFTHS;
        org.apache.commons.lang3.math.Fraction fraction45 = fraction44.reduce();
        boolean boolean46 = fraction41.equals((java.lang.Object) fraction44);
        org.apache.commons.lang3.math.Fraction fraction47 = fraction27.add(fraction41);
        org.apache.commons.lang3.math.Fraction fraction48 = fraction47.abs();
        org.junit.Assert.assertNotNull(fraction2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(fraction6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertNotNull(fraction10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(fraction12);
        org.junit.Assert.assertNotNull(fraction15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(fraction19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + short22 + "' != '" + (short) 0 + "'", short22 == (short) 0);
        org.junit.Assert.assertNotNull(fraction23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.625f + "'", float26 == 1.625f);
        org.junit.Assert.assertNotNull(fraction27);
        org.junit.Assert.assertNotNull(fraction28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 1 + "'", short30 == (short) 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertNotNull(fraction32);
        org.junit.Assert.assertNotNull(fraction34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(fraction40);
        org.junit.Assert.assertNotNull(fraction41);
        org.junit.Assert.assertNotNull(fraction42);
        org.junit.Assert.assertNotNull(fraction43);
        org.junit.Assert.assertNotNull(fraction44);
        org.junit.Assert.assertNotNull(fraction45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(fraction47);
        org.junit.Assert.assertNotNull(fraction48);
    }
}

