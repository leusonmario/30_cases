import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi", (java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi##########hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi##########hi" + "'", str1.equals("hi##########hi"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "a", (java.lang.CharSequence) "          hi          ", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###################...", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("          ##########hi                                                                    ", "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          ##########hi                                                                    " + "'", str2.equals("          ##########hi                                                                    "));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "hihihihihihihihihihihihi", (java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!H", 1210);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("          ##########hi                                                                    ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          ##########hi                                                                    " + "'", str2.equals("          ##########hi                                                                    "));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str1.equals("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihihihihi" + "'", str2.equals("hihihihihi"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH" + "'", str1.equals("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("                      ", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "                      " + "'", str12.equals("                      "));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "i!hi!hi!hi", "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", (int) (byte) 1, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i!hi!hi!hi!" + "'", str3.equals("i!hi!hi!hi!"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                            ", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        char[] charArray0 = new char[] {};
        char[] charArray1 = new char[] {};
        char[] charArray2 = new char[] {};
        char[] charArray3 = new char[] {};
        char[][] charArray4 = new char[][] { charArray0, charArray1, charArray2, charArray3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray4);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!h");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 0, 1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!h" + "'", str5.equals("hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "                                        ##########hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5198 + "'", int2 == 5198);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "                                                                                                    hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (byte) 1, "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH", 1210);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           "));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "hi##########hi", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("#########################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########################################################################################" + "'", str1.equals("#########################################################################################"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 297, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("####################################################################################################", "                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################" + "'", str2.equals("####################################################################################################"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = null;
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", "");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray6, strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray3, strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str11.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str12.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                            ", (java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 120);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                        ##########hi", "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h", "##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                        ##########hi" + "'", str3.equals("                                        ##########hi"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" hi hi hi hi hi hi hi hi hi hi hi hi                                                                ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " hi hi hi hi hi hi hi hi hi hi hi hi                                                                " + "'", str3.equals(" hi hi hi hi hi hi hi hi hi hi hi hi                                                                "));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("444", (int) (short) 1, "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444" + "'", str3.equals("444"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                                                                                 !hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!h", "hhi!hiI!HI!HI!HI!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih" + "'", str2.equals("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("IiHIiHIiHI", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI" + "'", str2.equals("IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("HHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hihihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihihihihihihihihihihihi" + "'", str1.equals("hihihihihihihihihihihihi"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "HI", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", "HI!HI!HI!HI!HI!HI!HI!", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                " + "'", str4.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                "));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", (-1));
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "          hi          ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hihihihihi", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "a", (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hihihihihi" + "'", str4.equals("hihihihihi"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                                                                                                    hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("ng;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ng;" + "'", str1.equals("ng;"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("####################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################" + "'", str1.equals("####################################################################################################"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" hi hi hi hi hi hi hi hi hi hi hi hi                                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi hi hi hi hi hi hi hi hi hi hi hi" + "'", str1.equals("hi hi hi hi hi hi hi hi hi hi hi hi"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray10 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                    ", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                        ##########hi", "I!HI!HI!HI", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                        ##########hi" + "'", str3.equals("                                        ##########hi"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hihihihihihihihihihihihi", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h" + "'", str2.equals("h"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "iiHIiHIiHI", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str1.equals("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!", (int) (short) 10);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "hi!");
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray8);
        java.lang.Class<?> wildcardClass12 = strArray8.getClass();
        java.lang.Class<?> wildcardClass13 = strArray8.getClass();
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray17);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray18);
        java.lang.Class<?> wildcardClass20 = strArray18.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray21 = new java.lang.reflect.AnnotatedElement[] { wildcardClass4, wildcardClass13, wildcardClass20 };
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray21);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(annotatedElementArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str22.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) (byte) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", 2, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih" + "'", str3.equals("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h", "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", (int) ' ', "444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str3.equals("hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("i!hi!hi!hi!", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                      ");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                            ", "##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1087 + "'", int1 == 1087);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("          ##########hi                                                                    ", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "!hi", 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hI!HI!hiI!HI" + "'", str3.equals("hI!HI!hiI!HI"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    " + "'", str2.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    "));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("!hi", "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI           ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", "I!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih" + "'", str2.equals("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("          ##########hi                                                                    ", "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          ##########hi                                                                    " + "'", str2.equals("          ##########hi                                                                    "));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h" + "'", str2.equals("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!hi" + "'", str1.equals("!hi"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("i!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i!hi!hi!hi" + "'", str1.equals("i!hi!hi!hi"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "HI!HI!HI!HI!HI!HI!HI!H", 10);
        java.lang.String[] strArray8 = new java.lang.String[] { "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "IiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI           ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI           " + "'", str2.equals("                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI           "));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi hi hi hi hi hi hi hi hi hi hi hi", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "hI!HI!hiI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("a");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                      ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "####################################################################################################");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "          ##########hi                                                                    ");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", strArray4, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str8.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", 297);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) " hi hi hi hi hi hi hi hi hi hi hi hi                                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("HI!HI!HI!HI!HI!HI!HI!H", "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;" + "'", str3.equals("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("##############################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############################" + "'", str1.equals("##############################"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "hi hi hi hi hi hi hi hi hi hi hi hi", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                      ##############################", 22, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################" + "'", str3.equals("##############################"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ", (java.lang.CharSequence) "iiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("HI!HI!HI!HI!HI!HI!HI!H", (int) (byte) -1, "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str2.equals("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        char[] charArray11 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "####################################################################################################", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!H", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "i", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 21, "                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("i!hi!hi!hi", "444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444" + "'", str2.equals("444"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", 10, "iiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str3.equals("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 22, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "#########################################################################################", 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str4.equals("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", "iiHIiHIiHI", "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..." + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..."));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", charSequence2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) '4', "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                    " + "'", str3.equals("                                                    "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "i", "                      ##############################", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str4.equals("Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                 !hi", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("I!hi!hi!hi", 1220, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "!hi", (java.lang.CharSequence) "hihihihihi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "H" + "'", str1.equals("H"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "#########################################################################################", (java.lang.CharSequence) "          hi          ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", "hihihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..." + "'", str1.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..."));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("hhi!hiI!HI!HI!HI!hi!hi", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          hhi!hiI!HI!HI!HI!hi!hi" + "'", str2.equals("          hhi!hiI!HI!HI!HI!hi!hi"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "hi##########hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI", charSequence1, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("               ###################...               ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", "HI!HI!HI!HI!HI!HI!HI!H", 0);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("HHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", strArray4, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 12");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 10, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hI!HI!hiI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!HI!hiI!HI" + "'", str1.equals("hI!HI!hiI!HI"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("I!HI!HI!HI", "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi hi hi hi hi hi hi hi hi hi hi hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi hi hi hi hi hi hi hi hi hi hi hi" + "'", str1.equals("hi hi hi hi hi hi hi hi hi hi hi hi"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!", 5198, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("##########", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                    hi", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                ..." + "'", str2.equals("                                ..."));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str1.equals("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "          ##########hi                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("i!hi!hi!hi", "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("IiHIiHIiHI", 12, "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "IiHIiHIiHIih" + "'", str3.equals("IiHIiHIiHIih"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                ...", (java.lang.CharSequence) "IiHIiHIiHIih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                                    hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    hi" + "'", str1.equals("                                                                                                    hi"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi##########hi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "                                                                                                 !hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 !hi" + "'", str2.equals("                                                                                                 !hi"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86 + "'", int2 == 86);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("####################################################################################################", "hiaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 297);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "####################################################################################################" + "'", str4.equals("####################################################################################################"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                ", "IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "hi");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!h", "          hi          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi" + "'", str3.equals("H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                      ", (int) (short) 0, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      " + "'", str3.equals("                      "));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("I!HI!HI!HI", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I!HI!HI!HI" + "'", str3.equals("I!HI!HI!HI"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("          ##########hi                                                                    ", 21, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          ##########hi                                                                    " + "'", str3.equals("          ##########hi                                                                    "));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "          ##########hi                                                                    ", 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("HI", (int) (short) 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HIaaaaaaaa" + "'", str3.equals("HIaaaaaaaa"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("##########", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 86);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("i!hi!hi!hi", "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", 12);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 34");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaa", 30, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray3, strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str9.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("HI!HI!HI!HI!HI!HI!HI!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (byte) 1, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str2.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "hi!");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray4);
        java.lang.Class<?> wildcardClass8 = strArray4.getClass();
        java.lang.Class<?> wildcardClass9 = strArray4.getClass();
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "HHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    " + "'", str1.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    "));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "iiHIiHIiHI", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "i");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaa", 10, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                ...", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "##############################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                ..." + "'", str3.equals("                                ..."));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "IiHIiHIiHIih", 297);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 95 + "'", int3 == 95);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "444", (java.lang.CharSequence) "          ##########hi                                                                    ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("          hi          ", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          hi          " + "'", str2.equals("          hi          "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("          hi          ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 1, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str4.equals(" HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 1210, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                            ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "iiHIiHIiHI", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 12, "#########################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############" + "'", str3.equals("############"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence[]) strArray13);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("          ##########hi                                                                    ", strArray6, strArray13);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", '#');
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 100, 1);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEach("                      ", strArray13, strArray20);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "          ##########hi                                                                    " + "'", str17.equals("          ##########hi                                                                    "));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str26.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "                      " + "'", str27.equals("                      "));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("h", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h" + "'", str2.equals("h"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "I!HI!HI!HI", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!iH" + "'", str1.equals("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!iH"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "          ##########hi                                                                    ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str5.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("##########hi", 86, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####################################################################################################", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (byte) 1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "iiHIiHIiHI", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!", (java.lang.CharSequence) "aaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "HIaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("IiHIiHIiHIih", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "                                        ##########hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#########################################################################################", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "", (int) (byte) 100, 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", 18, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', (int) '#', (int) (byte) 0);
        java.lang.Class<?> wildcardClass6 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("####################################################################################################", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################################################" + "'", str3.equals("####################################################################################################"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("          hi          ", "hi hi hi hi hi hi hi hi hi hi hi hi", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                                                    ", "H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                      ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 30);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi", "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", 5198);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "          ##########hi                                                                    ");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "############", 0, 297);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", " hi hi hi hi hi hi hi hi hi hi hi hi                                                                ", "I!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "ng;", (java.lang.CharSequence) "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                        ##########hi", "hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "", "###################...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                        ##########hi", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                            ", 1220);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hI!HI!hiI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HII!HI" + "'", str1.equals("HI!HI!HII!HI"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", 21, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", charSequence2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!H", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        java.lang.String[] strArray2 = new java.lang.String[] { "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" };
        java.lang.String[][] strArray3 = new java.lang.String[][] { strArray2 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "iiHIiHIiHI", (int) 'a', (int) ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                      ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      " + "'", str2.equals("                      "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 5198);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 485 + "'", int3 == 485);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..." + "'", str1.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..."));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "I!hi!hi!hi", (java.lang.CharSequence) "                                ", 1220);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hiaaaaaaaaaa", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", 1220);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "!hi", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("HI!HI!HI!HI!HI!HI!HI!H", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "                                                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", (java.lang.CharSequence) "h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hhi!hiI!HI!HI!HI!hi!hi", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH", (java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 120);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi", (java.lang.CharSequence) "                                                    ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                ...", 0, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                ..." + "'", str3.equals("                                ..."));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", "HI!HI!HI!HI!HI!HI!HI!H", 0);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hi!hi!hi!hi!hi!hi!hi!h", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH", 485);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!h" + "'", str4.equals("hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence[]) strArray13);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("          ##########hi                                                                    ", strArray6, strArray13);
        int int18 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "h", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "          ##########hi                                                                    " + "'", str17.equals("          ##########hi                                                                    "));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "ih!", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                                 !hi", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hI!HI!hiI!HI", 32, 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (short) -1, 1220);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "H");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I!" + "'", str2.equals("I!"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hihihihihihihihihihihihi", "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str4.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1260 + "'", int1 == 1260);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("          hi          ", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          hi          " + "'", str2.equals("          hi          "));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           i!HI!HI!HIHI!HI!HI!HI!HI!" + "'", str2.equals("                           i!HI!HI!HIHI!HI!HI!HI!HI!"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", 0, "##########hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str3.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("i!hi!hi!hi!", "I!hi!hi!hi", "          hhi!hiI!HI!HI!HI!hi!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "           " + "'", str3.equals("           "));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "HI", (java.lang.CharSequence) "HHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 485);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 34 + "'", int3 == 34);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", (java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!H", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        char[] charArray9 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 120, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "hhi!hiI!HI!HI!HI!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("          hhi!hiI!HI!HI!HI!hi!hi", 100, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi          hhi!hiI!HI!HI!HI!hi!hi" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi          hhi!hiI!HI!HI!HI!hi!hi"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "I!HI!HI!HI", (java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hhi!hiI!HI!HI!HI!hi!hi", "          hhi!hiI!HI!HI!HI!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hhi!hiI!HI!HI!HI!hi!hi" + "'", str2.equals("hhi!hiI!HI!HI!HI!hi!hi"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "i!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "I!hi!hi!hi", (int) (short) 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "hiaaaaaaaaaa", 1, (-1));
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray10);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray18);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi", "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 297);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi", strArray3, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str5.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "##########");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "hiaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                      ##############################");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi          hhi!hiI!HI!HI!HI!hi!hi", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi          hhi!hiI!HI!HI!HI!hi!hi", (java.lang.CharSequence) "H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                                                                    hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    hi" + "'", str3.equals("                                                                                                    hi"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                            ", "                                        ##########hi", 95);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                            " + "'", str3.equals("                                                            "));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "############", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH", (java.lang.CharSequence) "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", (java.lang.CharSequence) "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("############", "", 21);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("############", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", 3, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...#########" + "'", str4.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...#########"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("I!", "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h" + "'", str1.equals("h"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("I!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!HI!HI!HI" + "'", str1.equals("I!HI!HI!HI"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray2, strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str5.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi" + "'", str6.equals("hi"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi" + "'", str7.equals("hi"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "###################...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 15, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("iiHIiHIiHI", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "iiHIiHIiHI" + "'", str2.equals("iiHIiHIiHI"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ", "IiHIiHIiHIih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           "));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        char[][][] charArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(charArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("          ##########hi                                                                    ", "##########");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("IiHIiHIiHIih", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IiHIiHIiHI" + "'", str2.equals("IiHIiHIiHI"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("hihihihihi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihihihihi" + "'", str1.equals("hihihihihi"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "!hi", (java.lang.CharSequence) "hI!HI!hiI!HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("          hhi!hiI!HI!HI!HI!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hhi!hiI!HI!HI!HI!hi!hi" + "'", str1.equals("hhi!hiI!HI!HI!HI!hi!hi"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "HI!HI!HII!HI", (java.lang.CharSequence) "I!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#########################################################################################", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          " + "'", str1.equals("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          "));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", ' ');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str8.equals("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("i!hi!hi!hi", 21, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i!hi!hi!hi           " + "'", str3.equals("i!hi!hi!hi           "));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", 297, 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     " + "'", str3.equals("                     "));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", "aaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 0, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################" + "'", str3.equals("###################################"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "          hhi!hiI!HI!HI!HI!hi!hi", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi hi hi hi hi hi hi hi hi hi hi hi", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 95, 1260);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("          ", '4');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 89, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ", (java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hihihihihi", (java.lang.CharSequence) "##############################", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                    ", "hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "                                                                                                    ", "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "I!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                ...", "h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                ..." + "'", str2.equals("                                ..."));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "HHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 35, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "hi hi hi hi hi hi hi hi hi hi hi hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi" + "'", str4.equals("hi"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1860 + "'", int1 == 1860);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI" + "'", str1.equals("IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                      ##############################", "###################...", "####################################################################################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("iiHIiHIiHI", "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "iiHIiHIiHI" + "'", str3.equals("iiHIiHIiHI"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "##########hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi          hhi!hiI!HI!HI!HI!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 10);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (short) 1, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("ng;", (int) ' ', 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "##########", (java.lang.CharSequence) "IiHIiHIiHIih", 1210);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", (java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("iiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "iiHIiHIiHI" + "'", str1.equals("iiHIiHIiHI"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..." + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..."));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray11 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "####################################################################################################", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!H", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("          ##########hi                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          ##########hi                                                                    " + "'", str1.equals("          ##########hi                                                                    "));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                                    hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                                 !hi");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("###################...", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################..." + "'", str2.equals("###################..."));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("HI!HI!HI!HI!HI!HI!HI!", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hI!HI!hiI!HI", 1210);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hI!HI!hiI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              " + "'", str2.equals("hI!HI!hiI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              "));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "I!hi!hi!hi", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        char[] charArray10 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!H", charArray10);
        java.lang.Class<?> wildcardClass14 = charArray10.getClass();
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "           ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "hI!HI!hiI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", 1860);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("i", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", 1860);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("############", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "IiHIiHIiHIih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("i!hi!hi!hi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(" hi hi hi hi hi hi hi hi hi hi hi hi                                                                ", "i!hi!hi!hi!", 30, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " i!hi!hi!hi! hi hi                                                                " + "'", str4.equals(" i!hi!hi!hi! hi hi                                                                "));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                      ", 2, 120);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!h", "           ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi          hhi!hiI!HI!HI!HI!hi!hi", (java.lang.CharSequence) "ih!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (java.lang.CharSequence) "hiaaaaaaaaaa", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33 + "'", int3 == 33);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###################...", (java.lang.CharSequence) "4444444444", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("HI!HI!HI!HI!HI!HI!HI!H", "                      ##############################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 1260);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) " hi hi hi hi hi hi hi hi hi hi hi hi                                                                ", (java.lang.CharSequence) "I!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("4444444444", 1860, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "HIaaaaaaaa", (java.lang.CharSequence) "ng;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("hI!HI!hiI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", "                                                    ", 1860);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("HI!HI!HI!HI!HI!HI!HI!H", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!H"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str5.equals("HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("HI!HI!HI!HI!HI!HI!HI!H", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "i", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("ng;", "          hhi!hiI!HI!HI!HI!hi!hi", "!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !", 1260);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ng;" + "'", str4.equals("ng;"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("h", "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("HI!HI!HI!HI!HI!HI!HI!H", " i!hi!hi!hi! hi hi                                                                ", 1087);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("####################################################################################################", "hiaaaaaaaaaa", "ih!", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "####################################################################################################" + "'", str4.equals("####################################################################################################"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("i", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "hI!HI!hiI!HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i" + "'", str3.equals("i"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hihihihihihihihihihihihi", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "###################...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("hi hi hi hi hi hi hi hi hi hi hi hi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("HIaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HIaaaaaaaa" + "'", str1.equals("HIaaaaaaaa"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("ih!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ih!" + "'", str1.equals("ih!"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("H", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 1260);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(" HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 86);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi          hhi!hiI!HI!HI!HI!hi!hi");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "hI!HI!hiI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 297);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "4444444444", (java.lang.CharSequence) "###################...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 0, 1220);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }
}

