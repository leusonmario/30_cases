import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("i!hi!hi!hi           ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI", "               ###################...               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "###################################", (java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "###################################" + "'", charSequence2.equals("###################################"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "i!hi!hi!hi           ", (java.lang.CharSequence) "444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "i!hi!hi!hi           " + "'", charSequence2.equals("i!hi!hi!hi           "));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 29, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                      hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str4.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                      hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" i!hi!hi!hi! hi hi                                                                ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                 hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                 hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (int) '#', 1260);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("!hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi", " i!hi!hi!hi! hi hi                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 86);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                    ", charSequence1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("class [Ljava.lang.String;", "                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;" + "'", str2.equals("class [Ljava.lang.String;"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        char[] charArray15 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray15);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray15);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", charArray15);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray15);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray15);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "!hi", charArray15);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray15);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray15);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "i!hi!hi!hi", charArray15);
        java.lang.Class<?> wildcardClass25 = charArray15.getClass();
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaa", "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                     ", (java.lang.CharSequence) "!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95 + "'", int2 == 95);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "hihihihihi", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h", 77, "hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hhi!hiI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hhhi!hiI!HI!HI!HI" + "'", str3.equals("hhi!hiI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hhhi!hiI!HI!HI!HI"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "          hhi!hiI!HI!HI!HI!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("H", "HIaaaaaaaa", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "H" + "'", str3.equals("H"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ", (java.lang.CharSequence) "            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", (java.lang.CharSequence) "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray12 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "####################################################################################################", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!H", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                     hi##########hi", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hh hh hh h", "h                                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", "                     hi##########hi", 297, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                     hi##########hi          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          " + "'", str4.equals("                     hi##########hi          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          "));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                            ", 32, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                            " + "'", str3.equals("                                                            "));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", (int) (byte) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 194, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                ...", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                ..." + "'", str2.equals("                                ..."));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi hi hi hi hi hi hi hi hi hi hi hi", (java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split(" HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", "###################...", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hI!HI!hiI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 33, 60);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 33");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 1860);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hh hh hh h", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "hiaaaaaaaaaa", 1, (-1));
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (java.lang.CharSequence) "h");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", charSequence2.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "hhi!hiI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hhhi!hiI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", 0, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI", 0, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHI" + "'", str3.equals("IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHI"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ", "               ###################...               ");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", strArray8, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;" + "'", str12.equals("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "I");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                 hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("a", 120, 33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...#########", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...#########" + "'", str2.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...#########"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "H", "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", "!hi", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str4.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!iH", (java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) " HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hhi!hiI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hhhi!hiI!HI!HI!HI", (java.lang.CharSequence) "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                                    hi", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "                                                                                                    hi" + "'", str6.equals("                                                                                                    hi"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi hi hi hi hi hi hi hi hi hi hi hi", "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "HI!HI!HI!HI!HI!HI!HI!H", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...#########", 194);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        char[] charArray6 = new char[] { '4', '#', '#', ' ', 'a', '4' };
        char[] charArray13 = new char[] { '4', '#', '#', ' ', 'a', '4' };
        char[] charArray20 = new char[] { '4', '#', '#', ' ', 'a', '4' };
        char[] charArray27 = new char[] { '4', '#', '#', ' ', 'a', '4' };
        char[][] charArray28 = new char[][] { charArray6, charArray13, charArray20, charArray27 };
        char[][][] charArray29 = new char[][][] { charArray28 };
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join(charArray29);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charArray29, "hI!HI!hiI!HI");
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(charArray29);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hihihihihi", (java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("444", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444" + "'", str2.equals("444"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                ...", "               ###################...               ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI", "####################################################################################################", "iiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI" + "'", str3.equals("IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("iiHIiHIiHI", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHI" + "'", str2.equals("iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHI"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (java.lang.CharSequence) "!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("I", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(" hi hi hi hi hi hi hi hi hi hi hi hi                                                                ", 0, 86);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " hi hi hi hi hi hi hi hi hi hi hi hi                                                  " + "'", str3.equals(" hi hi hi hi hi hi hi hi hi hi hi hi                                                  "));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("H", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "H" + "'", str2.equals("H"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "                                       aaaaaaaaaa                                        I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                       aaaaaaaaaa                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                            ##########hi", 22, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                            ##########hi" + "'", str3.equals("          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                            ##########hi"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                     hi##########hi          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("############");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "############" + "'", str1.equals("############"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("iiHIiHIiHI", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "                                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "HI!HI!", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 297);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "HI!HI!HII!HI", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", 1210);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "          hhi!hiI!HI!HI!HI!hi!hi", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("h", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (short) 10);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "                                                                                                 !hi", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "i!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                     hi##########hi", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("          hi          ", "                                                                                                 !hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          hi          " + "'", str2.equals("          hi          "));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", "Hi##########hi", 86);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "############", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "HI!HI!HII!HI", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "hi!hi!hi!hi!hi!hi!hi!h", (int) '#', 891);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("          hhi!hiI!HI!HI!HI!hi!hi", "HI!HI!HII!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          hhi!hiI!HI!HI!HI!hi!hi" + "'", str2.equals("          hhi!hiI!HI!HI!HI!hi!hi"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", 77);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("HI!HI!HI!HI!HI!HI!HI!H", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "HI!HI!HII!HI", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("HI!HI!HI!HI!HI!HI!HI!", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi          hhi!hiI!HI!HI!HI!hi!hi", "hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..." + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..."));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("hihihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihihihihihihihihihihih" + "'", str1.equals("hihihihihihihihihihihih"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH", "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h", 120);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "aaaaaaaaaaaa", 89, 485);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                         aaaaaaaaaaaa                           hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str4.equals("                                                                                         aaaaaaaaaaaa                           hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("hiaaaaaaaaaa", "               ###################...               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hiaaaaaaaaaa" + "'", str2.equals("hiaaaaaaaaaa"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("hihihihihihihihihihihih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihihihihihihihihihihih" + "'", str1.equals("hihihihihihihihihihihih"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "I", 297);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", "!hi", 1220, 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                HI!!hi" + "'", str4.equals("                                HI!!hi"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                       aaaaaaaaaa                                        ", "hhi!hiI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hhhi!hiI!HI!HI!HI");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ", (java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hihihihihihihihihihihih", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 131 + "'", int2 == 131);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                    ", "I!HI!HI!HI", 22);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) ' ', "i!HI!HI!HIHI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str2.equals("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "HI", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "4444444444", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi     " + "'", str2.equals("iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi     "));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("h", "HHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!Iaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "hI!          hi          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (int) (byte) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!HI!HI!HI!" + "'", str3.equals("!HI!HI!HI!"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1260, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "aaaaaaaaaaaaaaa...", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 94);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("HI!HI!HI!HI!HI!HI!HI!", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!H..." + "'", str2.equals("HI!HI!H..."));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("class [Ljava.lang.String;", "                     hi##########hi          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;" + "'", str3.equals("class [Ljava.lang.String;"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("###################...", "                                       aaaaaaaaaa                                        ", "                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "hhi!hiI!HI!HI!HI!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!", (int) (short) 10);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "####################################################################################################", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ", (int) '#', "i!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            " + "'", str3.equals("                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            "));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hI!HI!hiI!HI", "                                                                                                 !hi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 29 + "'", int4 == 29);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("          ##########hi                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########hi" + "'", str1.equals("##########hi"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!", 5198, "hI!HI!hiI!HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!hI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hi" + "'", str3.equals("hI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!hI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hi"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("I!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!hi!hi!hi" + "'", str1.equals("I!hi!hi!hi"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        char[] charArray3 = new char[] { '#', '4', '#' };
        char[][] charArray4 = new char[][] { charArray3 };
        char[] charArray8 = new char[] { '#', '4', '#' };
        char[][] charArray9 = new char[][] { charArray8 };
        char[] charArray13 = new char[] { '#', '4', '#' };
        char[][] charArray14 = new char[][] { charArray13 };
        char[] charArray18 = new char[] { '#', '4', '#' };
        char[][] charArray19 = new char[][] { charArray18 };
        char[][][] charArray20 = new char[][][] { charArray4, charArray9, charArray14, charArray19 };
        char[] charArray24 = new char[] { '#', '4', '#' };
        char[][] charArray25 = new char[][] { charArray24 };
        char[] charArray29 = new char[] { '#', '4', '#' };
        char[][] charArray30 = new char[][] { charArray29 };
        char[] charArray34 = new char[] { '#', '4', '#' };
        char[][] charArray35 = new char[][] { charArray34 };
        char[] charArray39 = new char[] { '#', '4', '#' };
        char[][] charArray40 = new char[][] { charArray39 };
        char[][][] charArray41 = new char[][][] { charArray25, charArray30, charArray35, charArray40 };
        char[][][][] charArray42 = new char[][][][] { charArray20, charArray41 };
        java.lang.String str43 = org.apache.commons.lang3.StringUtils.join(charArray42);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertNotNull(charArray42);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", (java.lang.CharSequence) "               ###################...               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("hhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hi", 131);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hi" + "'", str2.equals("hihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hi"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", 194);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 1260, 95);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hihihihihi", "                                                                                                    ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "                                        ##########hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("############", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############" + "'", str2.equals("############"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "hhi!hiI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hhhi!hiI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str2.equals("          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 34, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hiaaaaaaaaaa", (int) ' ', "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hihiaaaaaaaaaa" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hihiaaaaaaaaaa"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray2, strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) " i!hi!hi!hi! hi hi                                                                ", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str7.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", 891);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) " HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hihiaaaaaaaaaa", "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!iH");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("!hi", "iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHI", "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                            ##########hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!h " + "'", str3.equals("!h "));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", " hi hi hi hi hi hi hi hi hi hi hi hi                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h", "hihihihihi", "          ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "                                       aaaaaaaaaa                                        I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                       aaaaaaaaaa                                        ", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "i");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi", (java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!iH", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                ...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("!hi", 1220);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!hi" + "'", str2.equals("!hi"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                      hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 220);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                      hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                      hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "HHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad(" HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 1220);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                " + "'", str2.equals(" HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                "));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "!h ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI#################!h ################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI#################!h ################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("HI!HI!HI!HI!HI!HI!HI", "aaaaaaaaaaaaaaa...", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                      hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 5198);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HI!HI!HI!HI!HI!HI!HI" + "'", str4.equals("HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "####################################################################################################", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", 100, "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", 194);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) " HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "i!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi##########hi", (java.lang.CharSequence) "hI!          hi          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("ng;", "i!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ng;" + "'", str2.equals("ng;"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hhi!hiI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hhhi!hiI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hhi!hiI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hhhi!hiI!HI!HI!HI" + "'", str1.equals("hhi!hiI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hhhi!hiI!HI!HI!HI"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!", "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!" + "'", str2.equals("####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    " + "'", str2.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    "));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(" hi hi hi hi hi hi hi hi hi hi hi hi                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " hi hi hi hi hi hi hi hi hi hi hi hi                                                  " + "'", str1.equals(" hi hi hi hi hi hi hi hi hi hi hi hi                                                  "));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                    ", "I!hi!hi!hi", "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI           ", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("A", "444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A" + "'", str2.equals("A"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HIaaaaaaaa", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hhi!hiI!HI!HI!HI!hi!hi", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hhi" + "'", str2.equals("hhi"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaa..." + "'", str1.equals("aaaaaaaaaaaaaaa..."));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "hihihihihi", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("###################################", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!Iaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 77);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("hi hi hi hi hi hi hi hi hi hi hi hi", "!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi hi hi hi hi hi hi hi hi hi hi hi" + "'", str2.equals("hi hi hi hi hi hi hi hi hi hi hi hi"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                ...", "!h ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hiaaaaaaaaaa", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!hi!hi!hi" + "'", str2.equals("i!hi!hi!hi"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!h", 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("H");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!hi" + "'", str1.equals("!hi"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                      hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                      hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                      hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        char[][] charArray0 = new char[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(charArray0);
        java.lang.Class<?> wildcardClass2 = charArray0.getClass();
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi          hhi!hiI!HI!HI!HI!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi          hhi!hiI!HI!HI!HI!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi          hhi!hiI!HI!HI!HI!hi!hi"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", (java.lang.CharSequence) "H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.CharSequence[] charSequenceArray4 = new java.lang.CharSequence[] { "HIaaaaaaaa", "hi hi hi hi hi hi hi hi hi hi hi hi", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", charSequenceArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray4, ' ', 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charSequenceArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        char[] charArray12 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "####################################################################################################", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!H", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hiaaaaaaaaaa", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "                           i!HI!HI!HIHI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("4444444444", (int) (short) 1, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444" + "'", str3.equals("444444444"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hhi", (-1), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hihihihihihihihihihihihi", 1260);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihihihihihihihihihihihi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str2.equals("hihihihihihihihihihihihi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!####################################################################################################!!!!!!!!!!", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!H", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                " + "'", str2.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                "));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("HI!HI!HII!HI", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HIaHIaHIIaHI" + "'", str3.equals("HIaHIaHIIaHI"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 485);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 220, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "hhi!hiI!HI!HI!HI!hi!hi", 891);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                         aaaaaaaaaaaa                           hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "                                                                                         aaaaaaaaaaaa                           hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", 194, 1260);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                         aaaaaaaaaaaa                           hi!                                                                                                                                                        aaaaaaaaaaaa                           hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str4.equals("                                                                                         aaaaaaaaaaaa                           hi!                                                                                                                                                        aaaaaaaaaaaa                           hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "i!hi!hi!hi", "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I HI HI HIHI HI HI HI HI HI HI HI HI HI HI" + "'", str3.equals("I HI HI HIHI HI HI HI HI HI HI HI HI HI HI"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "444444444", (java.lang.CharSequence) "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                            ##########hi", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Hi##########hi", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "I!hi!hi!hi", (int) (short) 1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(" hi hi hi hi hi hi hi hi hi hi hi hi                                                                ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hI!HI!hiI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", 131);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hI!HI!hiI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              " + "'", str2.equals("hI!HI!hiI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              "));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("!h ", "Hi##########hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!h " + "'", str2.equals("!h "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                                    ", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "HHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHI!HI!HI!HIHIHIHIHIHIHIHIHIHIHIHHHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 1860, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" hi hi hi hi hi hi hi hi hi hi hi hi                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi hi hi hi hi hi hi hi hi hi hi hi" + "'", str1.equals("hi hi hi hi hi hi hi hi hi hi hi hi"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                                 !hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("!h ", 2525);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hi hi hi hi hi hi hi hi hi hi hi hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;" + "'", str1.equals("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "          ##########hi                                                                    ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "            ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hhi!hiI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hhhi!hiI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1220 + "'", int1 == 1220);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("hI!HI!hiI!HI                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "hi hi hi hi hi hi hi hi hi hi hi hi", (java.lang.CharSequence) "                                                                                         aaaaaaaaaaaa                           hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!                                                                                                    hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                      ##############################", (java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaa...", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) (byte) -1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("hihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hi", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hi" + "'", str6.equals("hihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihhhii!hi!hi!hi!hi"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("##########hi", "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", 12);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Hhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hi", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("##########hi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "hihihihihihihihihihihih", 1220, 10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "444444444");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) " HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hihihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                      ");
        java.lang.Class<?> wildcardClass6 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str5.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 3, (int) (short) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", strArray2, strArray10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi" + "'", str8.equals("hi"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          " + "'", str11.equals("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("          ", '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray3, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "##########hi", (java.lang.CharSequence[]) strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi" + "'", str5.equals("hi"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          " + "'", str9.equals("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          "));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "          " + "'", str11.equals("          "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "IiHIiHIiHIih", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi" + "'", str1.equals("hi"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!H", (java.lang.CharSequence) "############");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("##########", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################" + "'", str2.equals("####################################################################################################"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                       aaaaaaaaaa                                        I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                       aaaaaaaaaa                                        ", (java.lang.CharSequence) "                                        ##########hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", (java.lang.CharSequence) "hihihihihihihihihihihihi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("hh hh hh h", "iiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hh hh hh h" + "'", str2.equals("hh hh hh h"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("          hhi!hiI!HI!HI!HI!hi!hi", "!HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI                   !HI");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", 89, "h                                                                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str3.equals("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                                    hi", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    hi" + "'", str2.equals("                                                                                                    hi"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "!hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h" + "'", str2.equals("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!hI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "               ###################...               ", (java.lang.CharSequence) "ih!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!HI!HI!HI!" + "'", str1.equals("!HI!HI!HI!"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...#########", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                 hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH", "hi##########hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH" + "'", str2.equals("IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                     hi##########hi          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", (java.lang.CharSequence) "HIaHIaHIIaHI", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("I");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 100, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI           ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("i!hi!hi!hi", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("##############################", "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                       aaaaaaaaaa                                        ", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 86);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                       aaaaaaaaaa                                        " + "'", str4.equals("                                       aaaaaaaaaa                                        "));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 1210);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) " i!hi!hi!hi! hi hi                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("##############################", 94, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        char[] charArray18 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray18);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray18);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", charArray18);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray18);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray18);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "!hi", charArray18);
        boolean boolean25 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray18);
        int int26 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray18);
        boolean boolean27 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!h", charArray18);
        boolean boolean28 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "HIaaaaaaaa", charArray18);
        int int29 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!", charArray18);
        boolean boolean30 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "I", charArray18);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (short) -1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "               ###################...               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   !ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        char[] charArray18 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray18);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray18);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", charArray18);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray18);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray18);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "!hi", charArray18);
        boolean boolean25 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray18);
        int int26 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray18);
        boolean boolean27 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!h", charArray18);
        boolean boolean28 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "HIaaaaaaaa", charArray18);
        int int29 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!", charArray18);
        boolean boolean30 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "I!hi!hi!hi", charArray18);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", '#');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH", 131);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH" + "'", str2.equals("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!iH"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                     hi##########hi          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                           i!HI!HI!HIHI!HI!HI!HI!HI!", (java.lang.CharSequence) "hI!          hi          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                           i!HI!HI!HIHI!HI!HI!HI!HI!", (int) (byte) 0, "####################################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                           i!HI!HI!HIHI!HI!HI!HI!HI!" + "'", str3.equals("                           i!HI!HI!HIHI!HI!HI!HI!HI!"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h", 220);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                   !hi", (java.lang.CharSequence) "HI!HI!HII!HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                        ##########hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                        ##########HI" + "'", str1.equals("                                        ##########HI"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", (java.lang.CharSequence) "                                        ##########HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                           i!HI!HI!HIHI!HI!HI!HI!HI!", "                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           i!HI!HI!HIHI!HI!HI!HI!HI!" + "'", str2.equals("                           i!HI!HI!HIHI!HI!HI!HI!HI!"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "###################################", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hI!          hi          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "H          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihH          hi          i!hi!hi!hi!hi", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("IiHIiHIiHI", 29, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaIiHIiHIiHI" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaIiHIiHIiHI"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!hI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hi", (java.lang.CharSequence) "!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(" hi hi hi hi hi hi hi hi hi hi hi hi                                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi hi hi hi hi hi hi hi hi hi hi hi" + "'", str1.equals("hi hi hi hi hi hi hi hi hi hi hi hi"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                HI!!hi", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                              HI!!hi" + "'", str2.equals("                                                                                              HI!!hi"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi", "##############################", 35, 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "  ##############################      !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi" + "'", str4.equals("  ##############################      !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "Hi##########hi", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("##########", 95, 120);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########" + "'", str3.equals("##########"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", "          hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!                            ##########hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihh44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihhi####################################################################################################hihhihhihhihhihhihhihhihhihhihh44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hiaaaaaaaaaa", "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hiaaaaaaaaaa" + "'", str2.equals("hiaaaaaaaaaa"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                    ", "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("ng;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ng;" + "'", str1.equals("ng;"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!h", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "  ##############################      !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("##########", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.CharSequence[] charSequenceArray0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "class [Ljava.lang.String;", (java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("hi!hi!hi!hi!hi!hi!hihiaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!hi!hi!hi!hi!hi!hihiaaaaaaaaaa" + "'", str1.equals("Hi!hi!hi!hi!hi!hi!hihiaaaaaaaaaa"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hihiaaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("I");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I" + "'", str1.equals("I"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "i!hi!hi!hi!", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", 297);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hhi", 194);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hhi" + "'", str2.equals("hhi"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                      " + "'", str1.equals("                      "));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", "i!HI!HI!HIHI!HI!HI!HI!HI!", "hhi", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   " + "'", str4.equals("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   "));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "IiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHIIiHIiHIiHI", 297);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "HI!HI!H...", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("HIaaaaaaaaaaaaaaaaaaaa", "          hi          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi     ", "                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi                   !hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi     " + "'", str2.equals("iiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIiiHIiHIiHIhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi     "));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("i!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!HI!HI!HI" + "'", str1.equals("I!HI!HI!HI"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("!hi");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Hhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhii!hi!hi!hi!hi", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("ng;", "                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                       aaaaaaaaaa                                        I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                       aaaaaaaaaa                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                       aaaaaaaaaa                                        I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                       aaaaaaaaaa                                       " + "'", str1.equals("                                       aaaaaaaaaa                                        I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                       aaaaaaaaaa                                       "));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I!HI!HI!HIHI!HI!HI" + "'", str2.equals("I!HI!HI!HIHI!HI!HI"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("HI", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI                                 " + "'", str2.equals("HI                                 "));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "hihihihihi", (java.lang.CharSequence) "                                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("HI!HI!", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("I!hi!hi!hi", ' ');
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   " + "'", str5.equals("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   "));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("hI!          hi          HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", 77, 86);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I!HI!HI!H" + "'", str3.equals("I!HI!HI!H"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!hI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hiI!HIhI!HI!hi", (java.lang.CharSequence) " i!hi!hi!hi! hi hi                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", "                                ", (int) (short) -1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "          hi          ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "IiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hihiaaaaaaaaaa", (java.lang.CharSequence) "                                       aaaaaaaaaa                                        I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                       aaaaaaaaaa                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################Hh                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!h                      ##############################!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 95, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...#########", "                   !hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...#########" + "'", str2.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...#########"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "hi!");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray6);
        java.lang.Class<?> wildcardClass10 = strArray6.getClass();
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.substringsBetween("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!h", "i!hi!hi!hi");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("I!HI!HI!HI", strArray12, strArray16);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "####################################################################################################");
        int int21 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray20);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, '4');
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("           ", strArray12, strArray20);
        int int25 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "HIaaaaaaaa", (java.lang.CharSequence[]) strArray12);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "I!HI!HI!HI" + "'", str17.equals("I!HI!HI!HI"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str23.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "           " + "'", str24.equals("           "));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 77, 89);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h" + "'", charSequence2.equals("hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                i");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hihihihihihihihihihihihi", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                HI!!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!!hi" + "'", str1.equals("HI!!hi"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str1.equals("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI..." + "'", str1.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI..."));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("a", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }
}

