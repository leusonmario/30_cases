import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "                      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", 100, 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str4.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################################################################", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "####################################################################################################" + "'", str4.equals("####################################################################################################"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "###################...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "IiHIiHIiHI", "hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", (java.lang.CharSequence) "##########hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "####################################################################################################", (java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                " + "'", str2.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                "));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hi", "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("i!hi!hi!hi", "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi" + "'", str1.equals("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 12, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("!hi", (int) (short) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 !hi" + "'", str3.equals("                                                                                                 !hi"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hiaaaaaaaaaa", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hiaaaaaaaaaa" + "'", str3.equals("hiaaaaaaaaaa"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi" + "'", str1.equals("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", (java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi" + "'", charSequence2.equals("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (byte) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   " + "'", str2.equals("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   "));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("##############################", (int) (byte) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################" + "'", str3.equals("##############################"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("hi!hi!hi!hi!hi!hi!hi!h", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str1.equals("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "          ##########hi                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("####################################################################################################", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################" + "'", str2.equals("####################################################################################################"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("##########hi", "", (int) (byte) -1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##########hi" + "'", str4.equals("##########hi"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                      ##############################", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                " + "'", str3.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                "));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                                    hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "                      ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "i!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1210 + "'", int2 == 1210);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi!hi!hi!hi!hi!h", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!h" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "          ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("i!hi!hi!hi", "                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      " + "'", str2.equals("                      "));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 3, "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("IiHIiHIiHI", (int) (short) -1, "##############################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "IiHIiHIiHI" + "'", str3.equals("IiHIiHIiHI"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) (short) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "##############################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "i!hi!hi!hi", 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("444", (int) (byte) 0, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444" + "'", str3.equals("444"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("##############################", "####################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################" + "'", str2.equals("##############################"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH" + "'", str1.equals("IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str1.equals("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1220 + "'", int2 == 1220);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str1.equals("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 1210);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "##########hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "          ##########hi                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "##########hi", (java.lang.CharSequence) "444", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h", (java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("hiaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hiaaaaaaaaaa" + "'", str1.equals("hiaaaaaaaaaa"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !" + "'", str1.equals("!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("I!HI!HI!HI", "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            " + "'", str2.equals("                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 " + "'", str1.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 "));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "hiaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", charSequence2.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi" + "'", str1.equals("hi"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hiaaaaaaaaaa", "a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hiaaaaaaaaaa" + "'", str2.equals("hiaaaaaaaaaa"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi" + "'", str2.equals("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("##########hi", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                        ##########hi" + "'", str2.equals("                                        ##########hi"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "i!hi!hi!hi", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                      ##############################", (java.lang.CharSequence) "a", 297);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                ", (int) (short) 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h" + "'", str1.equals("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "hi", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ", "                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 35, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (int) (short) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str3.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                      ##############################", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      ##############################" + "'", str2.equals("                      ##############################"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                                                    hi", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    " + "'", str3.equals("                                                                                                    "));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        char[] charArray5 = new char[] { '#', ' ', '#', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", 0, "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str3.equals("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 100, 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (int) '#', (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("IiHIiHIiHI", "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IiHIiHIiHI" + "'", str2.equals("IiHIiHIiHI"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ", (int) (short) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("a", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", (java.lang.CharSequence) "444", 1210);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hi!hi!hi!hi!hi!hi!hi!h", "hiaaaaaaaaaa", "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!h" + "'", str4.equals("hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "!hi", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charSequence1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("###################...", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi", "");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "####################################################################################################");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = null;
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("", "");
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray7, strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "444", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str12.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", 1220);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !", (-1), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (java.lang.CharSequence) "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH", "                                        ##########hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " hi hi hi hi hi hi hi hi hi hi hi hi                                                                " + "'", str3.equals(" hi hi hi hi hi hi hi hi hi hi hi hi                                                                "));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "          ##########hi                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 3, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaa..." + "'", str3.equals("aaaaaaaaaaaaaaa..."));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 " + "'", str2.equals("                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 "));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", 1210);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("I!HI!HI!HI", "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 1220);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi", "", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            " + "'", str2.equals("                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            "));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("##########hi", (int) (byte) 1, "hiaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########hi" + "'", str3.equals("##########hi"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "I!HI!HI!HI", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("hi", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          hi          " + "'", str2.equals("          hi          "));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.lang3.StringUtils[] stringUtilsArray0 = new org.apache.commons.lang3.StringUtils[] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray0);
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) stringUtilsArray0, "##############################", (int) '4', 1210);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stringUtilsArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 " + "'", str2.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 "));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!H", (java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) '#', (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("###################...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################..." + "'", str1.equals("###################..."));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi" + "'", str2.equals("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("hi", "##########", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi##########hi" + "'", str3.equals("hi##########hi"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          " + "'", str3.equals("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          "));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                        ##########hi", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                    hi", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    hi" + "'", str2.equals("                                                                                                    hi"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaa...", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "!hi", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 1210);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", "               ###################...               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 " + "'", str2.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 "));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                        ##########hi", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                            " + "'", str2.equals("                                                            "));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ", (java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    " + "'", charSequence2.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    "));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "          hi          ", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89 + "'", int2 == 89);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "aaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "          hi          ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", (java.lang.CharSequence) "###################...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih" + "'", charSequence2.equals("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence[]) strArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", 12, (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ih!" + "'", str1.equals("ih!"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                                            ", "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                            " + "'", str2.equals("                                                            "));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "####################################################################################################");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = null;
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("", "");
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray7, strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str12.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        char[] charArray6 = new char[] { '4', '#', '#', 'a' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "####################################################################################################", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "##############################", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (int) '4', "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h" + "'", str3.equals("hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "          hi          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;" + "'", str3.equals("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   " + "'", str1.equals("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", "!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 " + "'", str3.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 "));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (byte) -1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("##########", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "hi", 21);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##########" + "'", str4.equals("##########"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                      ##############################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                    ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("###################...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################..." + "'", str1.equals("###################..."));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "aaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                " + "'", str3.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                "));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444" + "'", str2.equals("444"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "i!hi!hi!hi", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih" + "'", str1.equals("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "hiaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i" + "'", str2.equals("i"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h", "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("i!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!hi!hi!hi" + "'", str1.equals("I!hi!hi!hi"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "##########hi", (java.lang.CharSequence) "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 297);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("HI!HI!HI!HI!HI!HI!HI!H", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!H"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str4.equals("HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "##############################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "!hi", (java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray2, strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, 'a');
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.split("          ", '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray10, strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray2, strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str7.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi" + "'", str12.equals("hi"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          " + "'", str16.equals("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str17.equals("Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("I!HI!HI!HI", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I!HI!HI!HI" + "'", str2.equals("I!HI!HI!HI"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                      ##############################", 18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "hiaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", "", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 " + "'", str2.equals("                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 "));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "aaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          " + "'", str2.equals("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "I!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                        ##########hi", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("I!hi!hi!hi", "                      ", 297);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                        ##########hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ", (int) (short) 10, "444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    " + "'", str3.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    "));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", (java.lang.CharSequence) "hi##########hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 89);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#########################################################################################" + "'", str2.equals("#########################################################################################"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "####################################################################################################");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("hi", "hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!", (int) (short) 10);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "I!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaa...", "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "####################################################################################################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                    hi", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    hi" + "'", str2.equals("                                                                                                    hi"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH", "                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "hiaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "                                                                                                    hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("i", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "##########hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (short) -1, 297);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str4.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("hiaaaaaaaaaa", "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hiaaaaaaaaaa" + "'", str2.equals("hiaaaaaaaaaa"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH", "!hi", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH" + "'", str3.equals("IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("##########hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##########" + "'", str4.equals("##########"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.lang.reflect.AnnotatedElement[] annotatedElementArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str1.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("##############################", 1220, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###################...", (java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "i");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih" + "'", str3.equals("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444" + "'", str1.equals("444"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ng;" + "'", str2.equals("ng;"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "hiaaaaaaaaaa", (java.lang.CharSequence) "aaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#########################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("          ##########hi                                                                    ", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          ##########hi                                                                    " + "'", str3.equals("          ##########hi                                                                    "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "aaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("I!HI!HI!HI");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                      ", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      " + "'", str2.equals("                      "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI" + "'", str1.equals("HI"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", (java.lang.CharSequence) "444", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "I!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hiaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi!", 2, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", (java.lang.CharSequence) "          hi          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##############################", "##############################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH" + "'", str1.equals("IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hi##########hi", "ih!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("a", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("          ", "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (-1), (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("ng;", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ng;" + "'", str2.equals("ng;"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", (java.lang.CharSequence) "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("IiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "iiHIiHIiHI" + "'", str1.equals("iiHIiHIiHI"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "hi!");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray4);
        java.lang.Class<?> wildcardClass8 = strArray4.getClass();
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################################################################", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", strArray9, strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str14.equals("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "###################...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "iiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "                                                                                                    ", 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                "));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih                                                                   ", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str4.equals("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", "                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI           " + "'", str2.equals("                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI           "));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "I!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "                                        ##########hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hihihihihihihihihihihihi" + "'", str4.equals("hihihihihihihihihihihihi"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                      ", "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI           ", "!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      " + "'", str3.equals("                      "));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", "                                                                                                    hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 " + "'", str2.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 "));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                      ", (java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("###################...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################..." + "'", str1.equals("###################..."));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                            ", "                      ##############################", "HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                            " + "'", str3.equals("                                                            "));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("I!HI!HI!HI", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "##########hi", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("#########################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########################################################################################" + "'", str1.equals("#########################################################################################"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", 1, "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                " + "'", str3.equals("Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "ng;", (java.lang.CharSequence) "hiaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "#########################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "#########################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaa..." + "'", str1.equals("aaaaaaaaaaaaaaa..."));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!hi" + "'", str2.equals("!hi"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", (java.lang.CharSequence) "               ###################...               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray3);
        java.lang.Class<?> wildcardClass7 = charArray3.getClass();
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str1.equals("####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!", (java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h" + "'", str1.equals("hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "!hi", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a", (int) (byte) 1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..." + "'", str2.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..."));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("hi!", "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "I!HI!HI!HI", 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hhi!hiI!HI!HI!HI!hi!hi" + "'", str3.equals("hhi!hiI!HI!HI!HI!hi!hi"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi", "I!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (int) (byte) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "Hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "hihihihihihihihihihihihi", "hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "                           i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                            ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h", (java.lang.CharSequence) "iiHIiHIiHI", 1210);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HII!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "###################...", (java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", (java.lang.CharSequence) "               ###################...               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("i!hi!hi!hi", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!hi!hi!hi" + "'", str2.equals("i!hi!hi!hi"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("##########hi", (int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                      ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      " + "'", str2.equals("                      "));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "####################################################################################################", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "          ##########hi                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("i!hi!hi!hi", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i!hi!hi!hi" + "'", str3.equals("i!hi!hi!hi"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "i!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("               ###################...               ", "ng;", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("IiHIiHIiHI", "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", (int) 'a');
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (java.lang.CharSequence) "                                                                                                 !hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hhi!hiI!HI!HI!HI!hi!hi", 1210);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str2.equals("hhi!hiI!HI!HI!HI!hi!hi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "##############################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hiHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 3, (int) (short) 0);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "hi##########hi", 18, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!", (java.lang.CharSequence) "###################...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ", " hi hi hi hi hi hi hi hi hi hi hi hi                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 21, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IHIH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH", "          ##########hi                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          ##########hi                                                                    " + "'", str2.equals("          ##########hi                                                                    "));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", (int) (short) 0, 89);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;" + "'", str3.equals("class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                                                    ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIhi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hiaaaaaaaaaa", (java.lang.CharSequence) "               ###################...               ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                      ##############################", (java.lang.CharSequence) "hiaaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) (byte) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "hhi!hiI!HI!HI!HI!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "##########", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "##########" + "'", charSequence2.equals("##########"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI####################################################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray2, strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str5.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi" + "'", str9.equals("hi"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str2.equals("i!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        char[] charArray9 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "##########hi", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) ' ');
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "I!HI!HI!HI", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#########################################################################################", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", (java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("HI!HI!HI!HI!HI!HI!HI!H", "          ", "hi!hi!hi!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!H" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "iiHIiHIiHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("!hi", "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("!          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !          ####################################################################################################          !          !          !          !          !          !          !          !          !          !");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        char[] charArray14 = new char[] { '#', '4', '#', '4', '#', '#' };
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray14);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray14);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ihih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", charArray14);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", charArray14);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray14);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "!hi", charArray14);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", charArray14);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                                                                ", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaa...", "                                   HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaa..." + "'", str2.equals("aaaaaaaaaaaaaaa..."));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("####################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################" + "'", str1.equals("####################################################################################################"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("I!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "hi!");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray6);
        java.lang.Class<?> wildcardClass10 = strArray6.getClass();
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", strArray2, strArray12);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str13.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...", "          hi          ", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("i!hi!hi!hi", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "Hhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hihihihihihihihihihihihi!hi!hi!hihihihihihihihihihihihHhi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..." + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi..."));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("ng;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ng;" + "'", str1.equals("ng;"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                   hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                                                 HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                                 !hi", (java.lang.CharSequence) "                      ##############################", 1220);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "hi!");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray4);
        java.lang.Class<?> wildcardClass8 = strArray4.getClass();
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#########################################################################################", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" hi hi hi hi hi hi hi hi hi hi hi hi                                                                ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 " + "'", str3.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 "));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "class [Ljava.lang.String; class [Ljava.lang.String; class [Ljava.lang.String;", (java.lang.CharSequence) "                                                                                                 !hi", 1210);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                                                                    ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "#########################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ng;", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (java.lang.CharSequence) "hihihihihihihihihihihi!hi!hi!hihihihihihihihihihihih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "ih!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "                                                                                                    hi", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "HI!HI!HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi####################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "IiHIiHIiHI", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "#########################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }
}

